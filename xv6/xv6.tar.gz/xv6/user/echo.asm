
echo:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <main>:
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	83 ec 08             	sub    $0x8,%esp
  14:	8b 31                	mov    (%ecx),%esi
  16:	8b 79 04             	mov    0x4(%ecx),%edi
  int i;

  for(i = 1; i < argc; i++)
  19:	b8 01 00 00 00       	mov    $0x1,%eax
  1e:	eb 1a                	jmp    3a <main+0x3a>
    printf(1, "%s%s", argv[i], i+1 < argc ? " " : "\n");
  20:	ba fe 02 00 00       	mov    $0x2fe,%edx
  25:	52                   	push   %edx
  26:	ff 34 87             	push   (%edi,%eax,4)
  29:	68 00 03 00 00       	push   $0x300
  2e:	6a 01                	push   $0x1
  30:	e8 67 01 00 00       	call   19c <printf>
  35:	83 c4 10             	add    $0x10,%esp
  for(i = 1; i < argc; i++)
  38:	89 d8                	mov    %ebx,%eax
  3a:	39 f0                	cmp    %esi,%eax
  3c:	7d 0e                	jge    4c <main+0x4c>
    printf(1, "%s%s", argv[i], i+1 < argc ? " " : "\n");
  3e:	8d 58 01             	lea    0x1(%eax),%ebx
  41:	39 f3                	cmp    %esi,%ebx
  43:	7d db                	jge    20 <main+0x20>
  45:	ba fc 02 00 00       	mov    $0x2fc,%edx
  4a:	eb d9                	jmp    25 <main+0x25>
  exit();
  4c:	e8 08 00 00 00       	call   59 <exit>

00000051 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
  51:	b8 01 00 00 00       	mov    $0x1,%eax
  56:	cd 40                	int    $0x40
  58:	c3                   	ret    

00000059 <exit>:
SYSCALL(exit)
  59:	b8 02 00 00 00       	mov    $0x2,%eax
  5e:	cd 40                	int    $0x40
  60:	c3                   	ret    

00000061 <wait>:
SYSCALL(wait)
  61:	b8 03 00 00 00       	mov    $0x3,%eax
  66:	cd 40                	int    $0x40
  68:	c3                   	ret    

00000069 <pipe>:
SYSCALL(pipe)
  69:	b8 04 00 00 00       	mov    $0x4,%eax
  6e:	cd 40                	int    $0x40
  70:	c3                   	ret    

00000071 <read>:
SYSCALL(read)
  71:	b8 05 00 00 00       	mov    $0x5,%eax
  76:	cd 40                	int    $0x40
  78:	c3                   	ret    

00000079 <write>:
SYSCALL(write)
  79:	b8 10 00 00 00       	mov    $0x10,%eax
  7e:	cd 40                	int    $0x40
  80:	c3                   	ret    

00000081 <close>:
SYSCALL(close)
  81:	b8 15 00 00 00       	mov    $0x15,%eax
  86:	cd 40                	int    $0x40
  88:	c3                   	ret    

00000089 <kill>:
SYSCALL(kill)
  89:	b8 06 00 00 00       	mov    $0x6,%eax
  8e:	cd 40                	int    $0x40
  90:	c3                   	ret    

00000091 <exec>:
SYSCALL(exec)
  91:	b8 07 00 00 00       	mov    $0x7,%eax
  96:	cd 40                	int    $0x40
  98:	c3                   	ret    

00000099 <open>:
SYSCALL(open)
  99:	b8 0f 00 00 00       	mov    $0xf,%eax
  9e:	cd 40                	int    $0x40
  a0:	c3                   	ret    

000000a1 <mknod>:
SYSCALL(mknod)
  a1:	b8 11 00 00 00       	mov    $0x11,%eax
  a6:	cd 40                	int    $0x40
  a8:	c3                   	ret    

000000a9 <unlink>:
SYSCALL(unlink)
  a9:	b8 12 00 00 00       	mov    $0x12,%eax
  ae:	cd 40                	int    $0x40
  b0:	c3                   	ret    

000000b1 <fstat>:
SYSCALL(fstat)
  b1:	b8 08 00 00 00       	mov    $0x8,%eax
  b6:	cd 40                	int    $0x40
  b8:	c3                   	ret    

000000b9 <link>:
SYSCALL(link)
  b9:	b8 13 00 00 00       	mov    $0x13,%eax
  be:	cd 40                	int    $0x40
  c0:	c3                   	ret    

000000c1 <mkdir>:
SYSCALL(mkdir)
  c1:	b8 14 00 00 00       	mov    $0x14,%eax
  c6:	cd 40                	int    $0x40
  c8:	c3                   	ret    

000000c9 <chdir>:
SYSCALL(chdir)
  c9:	b8 09 00 00 00       	mov    $0x9,%eax
  ce:	cd 40                	int    $0x40
  d0:	c3                   	ret    

000000d1 <dup>:
SYSCALL(dup)
  d1:	b8 0a 00 00 00       	mov    $0xa,%eax
  d6:	cd 40                	int    $0x40
  d8:	c3                   	ret    

000000d9 <getpid>:
SYSCALL(getpid)
  d9:	b8 0b 00 00 00       	mov    $0xb,%eax
  de:	cd 40                	int    $0x40
  e0:	c3                   	ret    

000000e1 <sbrk>:
SYSCALL(sbrk)
  e1:	b8 0c 00 00 00       	mov    $0xc,%eax
  e6:	cd 40                	int    $0x40
  e8:	c3                   	ret    

000000e9 <sleep>:
SYSCALL(sleep)
  e9:	b8 0d 00 00 00       	mov    $0xd,%eax
  ee:	cd 40                	int    $0x40
  f0:	c3                   	ret    

000000f1 <uptime>:
SYSCALL(uptime)
  f1:	b8 0e 00 00 00       	mov    $0xe,%eax
  f6:	cd 40                	int    $0x40
  f8:	c3                   	ret    

000000f9 <date>:
SYSCALL(date)
  f9:	b8 16 00 00 00       	mov    $0x16,%eax
  fe:	cd 40                	int    $0x40
 100:	c3                   	ret    

00000101 <dup2>:
SYSCALL(dup2)
 101:	b8 17 00 00 00       	mov    $0x17,%eax
 106:	cd 40                	int    $0x40
 108:	c3                   	ret    

00000109 <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 109:	55                   	push   %ebp
 10a:	89 e5                	mov    %esp,%ebp
 10c:	83 ec 1c             	sub    $0x1c,%esp
 10f:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 112:	6a 01                	push   $0x1
 114:	8d 55 f4             	lea    -0xc(%ebp),%edx
 117:	52                   	push   %edx
 118:	50                   	push   %eax
 119:	e8 5b ff ff ff       	call   79 <write>
}
 11e:	83 c4 10             	add    $0x10,%esp
 121:	c9                   	leave  
 122:	c3                   	ret    

00000123 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 123:	55                   	push   %ebp
 124:	89 e5                	mov    %esp,%ebp
 126:	57                   	push   %edi
 127:	56                   	push   %esi
 128:	53                   	push   %ebx
 129:	83 ec 2c             	sub    $0x2c,%esp
 12c:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 12f:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 131:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 135:	74 04                	je     13b <printint+0x18>
 137:	85 d2                	test   %edx,%edx
 139:	78 3c                	js     177 <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 13b:	89 d1                	mov    %edx,%ecx
  neg = 0;
 13d:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 144:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 149:	89 c8                	mov    %ecx,%eax
 14b:	ba 00 00 00 00       	mov    $0x0,%edx
 150:	f7 f6                	div    %esi
 152:	89 df                	mov    %ebx,%edi
 154:	43                   	inc    %ebx
 155:	8a 92 64 03 00 00    	mov    0x364(%edx),%dl
 15b:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 15f:	89 ca                	mov    %ecx,%edx
 161:	89 c1                	mov    %eax,%ecx
 163:	39 d6                	cmp    %edx,%esi
 165:	76 e2                	jbe    149 <printint+0x26>
  if(neg)
 167:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 16b:	74 24                	je     191 <printint+0x6e>
    buf[i++] = '-';
 16d:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 172:	8d 5f 02             	lea    0x2(%edi),%ebx
 175:	eb 1a                	jmp    191 <printint+0x6e>
    x = -xx;
 177:	89 d1                	mov    %edx,%ecx
 179:	f7 d9                	neg    %ecx
    neg = 1;
 17b:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 182:	eb c0                	jmp    144 <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 184:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 189:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 18c:	e8 78 ff ff ff       	call   109 <putc>
  while(--i >= 0)
 191:	4b                   	dec    %ebx
 192:	79 f0                	jns    184 <printint+0x61>
}
 194:	83 c4 2c             	add    $0x2c,%esp
 197:	5b                   	pop    %ebx
 198:	5e                   	pop    %esi
 199:	5f                   	pop    %edi
 19a:	5d                   	pop    %ebp
 19b:	c3                   	ret    

0000019c <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 19c:	55                   	push   %ebp
 19d:	89 e5                	mov    %esp,%ebp
 19f:	57                   	push   %edi
 1a0:	56                   	push   %esi
 1a1:	53                   	push   %ebx
 1a2:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 1a5:	8d 45 10             	lea    0x10(%ebp),%eax
 1a8:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 1ab:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 1b0:	bb 00 00 00 00       	mov    $0x0,%ebx
 1b5:	eb 12                	jmp    1c9 <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 1b7:	89 fa                	mov    %edi,%edx
 1b9:	8b 45 08             	mov    0x8(%ebp),%eax
 1bc:	e8 48 ff ff ff       	call   109 <putc>
 1c1:	eb 05                	jmp    1c8 <printf+0x2c>
      }
    } else if(state == '%'){
 1c3:	83 fe 25             	cmp    $0x25,%esi
 1c6:	74 22                	je     1ea <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 1c8:	43                   	inc    %ebx
 1c9:	8b 45 0c             	mov    0xc(%ebp),%eax
 1cc:	8a 04 18             	mov    (%eax,%ebx,1),%al
 1cf:	84 c0                	test   %al,%al
 1d1:	0f 84 1d 01 00 00    	je     2f4 <printf+0x158>
    c = fmt[i] & 0xff;
 1d7:	0f be f8             	movsbl %al,%edi
 1da:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 1dd:	85 f6                	test   %esi,%esi
 1df:	75 e2                	jne    1c3 <printf+0x27>
      if(c == '%'){
 1e1:	83 f8 25             	cmp    $0x25,%eax
 1e4:	75 d1                	jne    1b7 <printf+0x1b>
        state = '%';
 1e6:	89 c6                	mov    %eax,%esi
 1e8:	eb de                	jmp    1c8 <printf+0x2c>
      if(c == 'd'){
 1ea:	83 f8 25             	cmp    $0x25,%eax
 1ed:	0f 84 cc 00 00 00    	je     2bf <printf+0x123>
 1f3:	0f 8c da 00 00 00    	jl     2d3 <printf+0x137>
 1f9:	83 f8 78             	cmp    $0x78,%eax
 1fc:	0f 8f d1 00 00 00    	jg     2d3 <printf+0x137>
 202:	83 f8 63             	cmp    $0x63,%eax
 205:	0f 8c c8 00 00 00    	jl     2d3 <printf+0x137>
 20b:	83 e8 63             	sub    $0x63,%eax
 20e:	83 f8 15             	cmp    $0x15,%eax
 211:	0f 87 bc 00 00 00    	ja     2d3 <printf+0x137>
 217:	ff 24 85 0c 03 00 00 	jmp    *0x30c(,%eax,4)
        printint(fd, *ap, 10, 1);
 21e:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 221:	8b 17                	mov    (%edi),%edx
 223:	83 ec 0c             	sub    $0xc,%esp
 226:	6a 01                	push   $0x1
 228:	b9 0a 00 00 00       	mov    $0xa,%ecx
 22d:	8b 45 08             	mov    0x8(%ebp),%eax
 230:	e8 ee fe ff ff       	call   123 <printint>
        ap++;
 235:	83 c7 04             	add    $0x4,%edi
 238:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 23b:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 23e:	be 00 00 00 00       	mov    $0x0,%esi
 243:	eb 83                	jmp    1c8 <printf+0x2c>
        printint(fd, *ap, 16, 0);
 245:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 248:	8b 17                	mov    (%edi),%edx
 24a:	83 ec 0c             	sub    $0xc,%esp
 24d:	6a 00                	push   $0x0
 24f:	b9 10 00 00 00       	mov    $0x10,%ecx
 254:	8b 45 08             	mov    0x8(%ebp),%eax
 257:	e8 c7 fe ff ff       	call   123 <printint>
        ap++;
 25c:	83 c7 04             	add    $0x4,%edi
 25f:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 262:	83 c4 10             	add    $0x10,%esp
      state = 0;
 265:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 26a:	e9 59 ff ff ff       	jmp    1c8 <printf+0x2c>
        s = (char*)*ap;
 26f:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 272:	8b 30                	mov    (%eax),%esi
        ap++;
 274:	83 c0 04             	add    $0x4,%eax
 277:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 27a:	85 f6                	test   %esi,%esi
 27c:	75 13                	jne    291 <printf+0xf5>
          s = "(null)";
 27e:	be 05 03 00 00       	mov    $0x305,%esi
 283:	eb 0c                	jmp    291 <printf+0xf5>
          putc(fd, *s);
 285:	0f be d2             	movsbl %dl,%edx
 288:	8b 45 08             	mov    0x8(%ebp),%eax
 28b:	e8 79 fe ff ff       	call   109 <putc>
          s++;
 290:	46                   	inc    %esi
        while(*s != 0){
 291:	8a 16                	mov    (%esi),%dl
 293:	84 d2                	test   %dl,%dl
 295:	75 ee                	jne    285 <printf+0xe9>
      state = 0;
 297:	be 00 00 00 00       	mov    $0x0,%esi
 29c:	e9 27 ff ff ff       	jmp    1c8 <printf+0x2c>
        putc(fd, *ap);
 2a1:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 2a4:	0f be 17             	movsbl (%edi),%edx
 2a7:	8b 45 08             	mov    0x8(%ebp),%eax
 2aa:	e8 5a fe ff ff       	call   109 <putc>
        ap++;
 2af:	83 c7 04             	add    $0x4,%edi
 2b2:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 2b5:	be 00 00 00 00       	mov    $0x0,%esi
 2ba:	e9 09 ff ff ff       	jmp    1c8 <printf+0x2c>
        putc(fd, c);
 2bf:	89 fa                	mov    %edi,%edx
 2c1:	8b 45 08             	mov    0x8(%ebp),%eax
 2c4:	e8 40 fe ff ff       	call   109 <putc>
      state = 0;
 2c9:	be 00 00 00 00       	mov    $0x0,%esi
 2ce:	e9 f5 fe ff ff       	jmp    1c8 <printf+0x2c>
        putc(fd, '%');
 2d3:	ba 25 00 00 00       	mov    $0x25,%edx
 2d8:	8b 45 08             	mov    0x8(%ebp),%eax
 2db:	e8 29 fe ff ff       	call   109 <putc>
        putc(fd, c);
 2e0:	89 fa                	mov    %edi,%edx
 2e2:	8b 45 08             	mov    0x8(%ebp),%eax
 2e5:	e8 1f fe ff ff       	call   109 <putc>
      state = 0;
 2ea:	be 00 00 00 00       	mov    $0x0,%esi
 2ef:	e9 d4 fe ff ff       	jmp    1c8 <printf+0x2c>
    }
  }
}
 2f4:	8d 65 f4             	lea    -0xc(%ebp),%esp
 2f7:	5b                   	pop    %ebx
 2f8:	5e                   	pop    %esi
 2f9:	5f                   	pop    %edi
 2fa:	5d                   	pop    %ebp
 2fb:	c3                   	ret    
