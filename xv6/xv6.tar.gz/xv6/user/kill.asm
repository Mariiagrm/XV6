
kill:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <main>:
#include "stat.h"
#include "user.h"

int
main(int argc, char **argv)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	83 ec 08             	sub    $0x8,%esp
  14:	8b 31                	mov    (%ecx),%esi
  16:	8b 79 04             	mov    0x4(%ecx),%edi
  int i;

  if(argc < 2){
  19:	83 fe 01             	cmp    $0x1,%esi
  1c:	7e 07                	jle    25 <main+0x25>
    printf(2, "usage: kill pid...\n");
    exit();
  }
  for(i=1; i<argc; i++)
  1e:	bb 01 00 00 00       	mov    $0x1,%ebx
  23:	eb 2b                	jmp    50 <main+0x50>
    printf(2, "usage: kill pid...\n");
  25:	83 ec 08             	sub    $0x8,%esp
  28:	68 80 04 00 00       	push   $0x480
  2d:	6a 02                	push   $0x2
  2f:	e8 ea 02 00 00       	call   31e <printf>
    exit();
  34:	e8 a2 01 00 00       	call   1db <exit>
    kill(atoi(argv[i]));
  39:	83 ec 0c             	sub    $0xc,%esp
  3c:	ff 34 9f             	push   (%edi,%ebx,4)
  3f:	e8 39 01 00 00       	call   17d <atoi>
  44:	89 04 24             	mov    %eax,(%esp)
  47:	e8 bf 01 00 00       	call   20b <kill>
  for(i=1; i<argc; i++)
  4c:	43                   	inc    %ebx
  4d:	83 c4 10             	add    $0x10,%esp
  50:	39 f3                	cmp    %esi,%ebx
  52:	7c e5                	jl     39 <main+0x39>
  exit();
  54:	e8 82 01 00 00       	call   1db <exit>

00000059 <start>:

// Entry point of the library	
void
start()
{
}
  59:	c3                   	ret    

0000005a <strcpy>:

char*
strcpy(char *s, const char *t)
{
  5a:	55                   	push   %ebp
  5b:	89 e5                	mov    %esp,%ebp
  5d:	56                   	push   %esi
  5e:	53                   	push   %ebx
  5f:	8b 45 08             	mov    0x8(%ebp),%eax
  62:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  65:	89 c2                	mov    %eax,%edx
  67:	89 cb                	mov    %ecx,%ebx
  69:	41                   	inc    %ecx
  6a:	89 d6                	mov    %edx,%esi
  6c:	42                   	inc    %edx
  6d:	8a 1b                	mov    (%ebx),%bl
  6f:	88 1e                	mov    %bl,(%esi)
  71:	84 db                	test   %bl,%bl
  73:	75 f2                	jne    67 <strcpy+0xd>
    ;
  return os;
}
  75:	5b                   	pop    %ebx
  76:	5e                   	pop    %esi
  77:	5d                   	pop    %ebp
  78:	c3                   	ret    

00000079 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  79:	55                   	push   %ebp
  7a:	89 e5                	mov    %esp,%ebp
  7c:	8b 4d 08             	mov    0x8(%ebp),%ecx
  7f:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
  82:	eb 02                	jmp    86 <strcmp+0xd>
    p++, q++;
  84:	41                   	inc    %ecx
  85:	42                   	inc    %edx
  while(*p && *p == *q)
  86:	8a 01                	mov    (%ecx),%al
  88:	84 c0                	test   %al,%al
  8a:	74 04                	je     90 <strcmp+0x17>
  8c:	3a 02                	cmp    (%edx),%al
  8e:	74 f4                	je     84 <strcmp+0xb>
  return (uchar)*p - (uchar)*q;
  90:	0f b6 c0             	movzbl %al,%eax
  93:	0f b6 12             	movzbl (%edx),%edx
  96:	29 d0                	sub    %edx,%eax
}
  98:	5d                   	pop    %ebp
  99:	c3                   	ret    

0000009a <strlen>:

uint
strlen(const char *s)
{
  9a:	55                   	push   %ebp
  9b:	89 e5                	mov    %esp,%ebp
  9d:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
  a0:	b8 00 00 00 00       	mov    $0x0,%eax
  a5:	eb 01                	jmp    a8 <strlen+0xe>
  a7:	40                   	inc    %eax
  a8:	80 3c 01 00          	cmpb   $0x0,(%ecx,%eax,1)
  ac:	75 f9                	jne    a7 <strlen+0xd>
    ;
  return n;
}
  ae:	5d                   	pop    %ebp
  af:	c3                   	ret    

000000b0 <memset>:

void*
memset(void *dst, int c, uint n)
{
  b0:	55                   	push   %ebp
  b1:	89 e5                	mov    %esp,%ebp
  b3:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
  b4:	8b 7d 08             	mov    0x8(%ebp),%edi
  b7:	8b 4d 10             	mov    0x10(%ebp),%ecx
  ba:	8b 45 0c             	mov    0xc(%ebp),%eax
  bd:	fc                   	cld    
  be:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
  c0:	8b 45 08             	mov    0x8(%ebp),%eax
  c3:	8b 7d fc             	mov    -0x4(%ebp),%edi
  c6:	c9                   	leave  
  c7:	c3                   	ret    

000000c8 <strchr>:

char*
strchr(const char *s, char c)
{
  c8:	55                   	push   %ebp
  c9:	89 e5                	mov    %esp,%ebp
  cb:	8b 45 08             	mov    0x8(%ebp),%eax
  ce:	8a 4d 0c             	mov    0xc(%ebp),%cl
  for(; *s; s++)
  d1:	eb 01                	jmp    d4 <strchr+0xc>
  d3:	40                   	inc    %eax
  d4:	8a 10                	mov    (%eax),%dl
  d6:	84 d2                	test   %dl,%dl
  d8:	74 06                	je     e0 <strchr+0x18>
    if(*s == c)
  da:	38 ca                	cmp    %cl,%dl
  dc:	75 f5                	jne    d3 <strchr+0xb>
  de:	eb 05                	jmp    e5 <strchr+0x1d>
      return (char*)s;
  return 0;
  e0:	b8 00 00 00 00       	mov    $0x0,%eax
}
  e5:	5d                   	pop    %ebp
  e6:	c3                   	ret    

000000e7 <gets>:

char*
gets(char *buf, int max)
{
  e7:	55                   	push   %ebp
  e8:	89 e5                	mov    %esp,%ebp
  ea:	57                   	push   %edi
  eb:	56                   	push   %esi
  ec:	53                   	push   %ebx
  ed:	83 ec 1c             	sub    $0x1c,%esp
  f0:	8b 7d 08             	mov    0x8(%ebp),%edi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
  f3:	bb 00 00 00 00       	mov    $0x0,%ebx
  f8:	89 de                	mov    %ebx,%esi
  fa:	43                   	inc    %ebx
  fb:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
  fe:	7d 2b                	jge    12b <gets+0x44>
    cc = read(0, &c, 1);
 100:	83 ec 04             	sub    $0x4,%esp
 103:	6a 01                	push   $0x1
 105:	8d 45 e7             	lea    -0x19(%ebp),%eax
 108:	50                   	push   %eax
 109:	6a 00                	push   $0x0
 10b:	e8 e3 00 00 00       	call   1f3 <read>
    if(cc < 1)
 110:	83 c4 10             	add    $0x10,%esp
 113:	85 c0                	test   %eax,%eax
 115:	7e 14                	jle    12b <gets+0x44>
      break;
    buf[i++] = c;
 117:	8a 45 e7             	mov    -0x19(%ebp),%al
 11a:	88 04 37             	mov    %al,(%edi,%esi,1)
    if(c == '\n' || c == '\r')
 11d:	3c 0a                	cmp    $0xa,%al
 11f:	74 08                	je     129 <gets+0x42>
 121:	3c 0d                	cmp    $0xd,%al
 123:	75 d3                	jne    f8 <gets+0x11>
    buf[i++] = c;
 125:	89 de                	mov    %ebx,%esi
 127:	eb 02                	jmp    12b <gets+0x44>
 129:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 12b:	c6 04 37 00          	movb   $0x0,(%edi,%esi,1)
  return buf;
}
 12f:	89 f8                	mov    %edi,%eax
 131:	8d 65 f4             	lea    -0xc(%ebp),%esp
 134:	5b                   	pop    %ebx
 135:	5e                   	pop    %esi
 136:	5f                   	pop    %edi
 137:	5d                   	pop    %ebp
 138:	c3                   	ret    

00000139 <stat>:

int
stat(const char *n, struct stat *st)
{
 139:	55                   	push   %ebp
 13a:	89 e5                	mov    %esp,%ebp
 13c:	56                   	push   %esi
 13d:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 13e:	83 ec 08             	sub    $0x8,%esp
 141:	6a 00                	push   $0x0
 143:	ff 75 08             	push   0x8(%ebp)
 146:	e8 d0 00 00 00       	call   21b <open>
  if(fd < 0)
 14b:	83 c4 10             	add    $0x10,%esp
 14e:	85 c0                	test   %eax,%eax
 150:	78 24                	js     176 <stat+0x3d>
 152:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 154:	83 ec 08             	sub    $0x8,%esp
 157:	ff 75 0c             	push   0xc(%ebp)
 15a:	50                   	push   %eax
 15b:	e8 d3 00 00 00       	call   233 <fstat>
 160:	89 c6                	mov    %eax,%esi
  close(fd);
 162:	89 1c 24             	mov    %ebx,(%esp)
 165:	e8 99 00 00 00       	call   203 <close>
  return r;
 16a:	83 c4 10             	add    $0x10,%esp
}
 16d:	89 f0                	mov    %esi,%eax
 16f:	8d 65 f8             	lea    -0x8(%ebp),%esp
 172:	5b                   	pop    %ebx
 173:	5e                   	pop    %esi
 174:	5d                   	pop    %ebp
 175:	c3                   	ret    
    return -1;
 176:	be ff ff ff ff       	mov    $0xffffffff,%esi
 17b:	eb f0                	jmp    16d <stat+0x34>

0000017d <atoi>:

int
atoi(const char *s)
{
 17d:	55                   	push   %ebp
 17e:	89 e5                	mov    %esp,%ebp
 180:	53                   	push   %ebx
 181:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
 184:	ba 00 00 00 00       	mov    $0x0,%edx
  while('0' <= *s && *s <= '9')
 189:	eb 0e                	jmp    199 <atoi+0x1c>
    n = n*10 + *s++ - '0';
 18b:	8d 14 92             	lea    (%edx,%edx,4),%edx
 18e:	8d 1c 12             	lea    (%edx,%edx,1),%ebx
 191:	41                   	inc    %ecx
 192:	0f be c0             	movsbl %al,%eax
 195:	8d 54 18 d0          	lea    -0x30(%eax,%ebx,1),%edx
  while('0' <= *s && *s <= '9')
 199:	8a 01                	mov    (%ecx),%al
 19b:	8d 58 d0             	lea    -0x30(%eax),%ebx
 19e:	80 fb 09             	cmp    $0x9,%bl
 1a1:	76 e8                	jbe    18b <atoi+0xe>
  return n;
}
 1a3:	89 d0                	mov    %edx,%eax
 1a5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 1a8:	c9                   	leave  
 1a9:	c3                   	ret    

000001aa <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1aa:	55                   	push   %ebp
 1ab:	89 e5                	mov    %esp,%ebp
 1ad:	56                   	push   %esi
 1ae:	53                   	push   %ebx
 1af:	8b 45 08             	mov    0x8(%ebp),%eax
 1b2:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 1b5:	8b 55 10             	mov    0x10(%ebp),%edx
  char *dst;
  const char *src;

  dst = vdst;
 1b8:	89 c1                	mov    %eax,%ecx
  src = vsrc;
  while(n-- > 0)
 1ba:	eb 0c                	jmp    1c8 <memmove+0x1e>
    *dst++ = *src++;
 1bc:	8a 13                	mov    (%ebx),%dl
 1be:	88 11                	mov    %dl,(%ecx)
 1c0:	8d 5b 01             	lea    0x1(%ebx),%ebx
 1c3:	8d 49 01             	lea    0x1(%ecx),%ecx
  while(n-- > 0)
 1c6:	89 f2                	mov    %esi,%edx
 1c8:	8d 72 ff             	lea    -0x1(%edx),%esi
 1cb:	85 d2                	test   %edx,%edx
 1cd:	7f ed                	jg     1bc <memmove+0x12>
  return vdst;
}
 1cf:	5b                   	pop    %ebx
 1d0:	5e                   	pop    %esi
 1d1:	5d                   	pop    %ebp
 1d2:	c3                   	ret    

000001d3 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 1d3:	b8 01 00 00 00       	mov    $0x1,%eax
 1d8:	cd 40                	int    $0x40
 1da:	c3                   	ret    

000001db <exit>:
SYSCALL(exit)
 1db:	b8 02 00 00 00       	mov    $0x2,%eax
 1e0:	cd 40                	int    $0x40
 1e2:	c3                   	ret    

000001e3 <wait>:
SYSCALL(wait)
 1e3:	b8 03 00 00 00       	mov    $0x3,%eax
 1e8:	cd 40                	int    $0x40
 1ea:	c3                   	ret    

000001eb <pipe>:
SYSCALL(pipe)
 1eb:	b8 04 00 00 00       	mov    $0x4,%eax
 1f0:	cd 40                	int    $0x40
 1f2:	c3                   	ret    

000001f3 <read>:
SYSCALL(read)
 1f3:	b8 05 00 00 00       	mov    $0x5,%eax
 1f8:	cd 40                	int    $0x40
 1fa:	c3                   	ret    

000001fb <write>:
SYSCALL(write)
 1fb:	b8 10 00 00 00       	mov    $0x10,%eax
 200:	cd 40                	int    $0x40
 202:	c3                   	ret    

00000203 <close>:
SYSCALL(close)
 203:	b8 15 00 00 00       	mov    $0x15,%eax
 208:	cd 40                	int    $0x40
 20a:	c3                   	ret    

0000020b <kill>:
SYSCALL(kill)
 20b:	b8 06 00 00 00       	mov    $0x6,%eax
 210:	cd 40                	int    $0x40
 212:	c3                   	ret    

00000213 <exec>:
SYSCALL(exec)
 213:	b8 07 00 00 00       	mov    $0x7,%eax
 218:	cd 40                	int    $0x40
 21a:	c3                   	ret    

0000021b <open>:
SYSCALL(open)
 21b:	b8 0f 00 00 00       	mov    $0xf,%eax
 220:	cd 40                	int    $0x40
 222:	c3                   	ret    

00000223 <mknod>:
SYSCALL(mknod)
 223:	b8 11 00 00 00       	mov    $0x11,%eax
 228:	cd 40                	int    $0x40
 22a:	c3                   	ret    

0000022b <unlink>:
SYSCALL(unlink)
 22b:	b8 12 00 00 00       	mov    $0x12,%eax
 230:	cd 40                	int    $0x40
 232:	c3                   	ret    

00000233 <fstat>:
SYSCALL(fstat)
 233:	b8 08 00 00 00       	mov    $0x8,%eax
 238:	cd 40                	int    $0x40
 23a:	c3                   	ret    

0000023b <link>:
SYSCALL(link)
 23b:	b8 13 00 00 00       	mov    $0x13,%eax
 240:	cd 40                	int    $0x40
 242:	c3                   	ret    

00000243 <mkdir>:
SYSCALL(mkdir)
 243:	b8 14 00 00 00       	mov    $0x14,%eax
 248:	cd 40                	int    $0x40
 24a:	c3                   	ret    

0000024b <chdir>:
SYSCALL(chdir)
 24b:	b8 09 00 00 00       	mov    $0x9,%eax
 250:	cd 40                	int    $0x40
 252:	c3                   	ret    

00000253 <dup>:
SYSCALL(dup)
 253:	b8 0a 00 00 00       	mov    $0xa,%eax
 258:	cd 40                	int    $0x40
 25a:	c3                   	ret    

0000025b <getpid>:
SYSCALL(getpid)
 25b:	b8 0b 00 00 00       	mov    $0xb,%eax
 260:	cd 40                	int    $0x40
 262:	c3                   	ret    

00000263 <sbrk>:
SYSCALL(sbrk)
 263:	b8 0c 00 00 00       	mov    $0xc,%eax
 268:	cd 40                	int    $0x40
 26a:	c3                   	ret    

0000026b <sleep>:
SYSCALL(sleep)
 26b:	b8 0d 00 00 00       	mov    $0xd,%eax
 270:	cd 40                	int    $0x40
 272:	c3                   	ret    

00000273 <uptime>:
SYSCALL(uptime)
 273:	b8 0e 00 00 00       	mov    $0xe,%eax
 278:	cd 40                	int    $0x40
 27a:	c3                   	ret    

0000027b <date>:
SYSCALL(date)
 27b:	b8 16 00 00 00       	mov    $0x16,%eax
 280:	cd 40                	int    $0x40
 282:	c3                   	ret    

00000283 <dup2>:
SYSCALL(dup2)
 283:	b8 17 00 00 00       	mov    $0x17,%eax
 288:	cd 40                	int    $0x40
 28a:	c3                   	ret    

0000028b <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 28b:	55                   	push   %ebp
 28c:	89 e5                	mov    %esp,%ebp
 28e:	83 ec 1c             	sub    $0x1c,%esp
 291:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 294:	6a 01                	push   $0x1
 296:	8d 55 f4             	lea    -0xc(%ebp),%edx
 299:	52                   	push   %edx
 29a:	50                   	push   %eax
 29b:	e8 5b ff ff ff       	call   1fb <write>
}
 2a0:	83 c4 10             	add    $0x10,%esp
 2a3:	c9                   	leave  
 2a4:	c3                   	ret    

000002a5 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 2a5:	55                   	push   %ebp
 2a6:	89 e5                	mov    %esp,%ebp
 2a8:	57                   	push   %edi
 2a9:	56                   	push   %esi
 2aa:	53                   	push   %ebx
 2ab:	83 ec 2c             	sub    $0x2c,%esp
 2ae:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 2b1:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 2b3:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 2b7:	74 04                	je     2bd <printint+0x18>
 2b9:	85 d2                	test   %edx,%edx
 2bb:	78 3c                	js     2f9 <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 2bd:	89 d1                	mov    %edx,%ecx
  neg = 0;
 2bf:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 2c6:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 2cb:	89 c8                	mov    %ecx,%eax
 2cd:	ba 00 00 00 00       	mov    $0x0,%edx
 2d2:	f7 f6                	div    %esi
 2d4:	89 df                	mov    %ebx,%edi
 2d6:	43                   	inc    %ebx
 2d7:	8a 92 f4 04 00 00    	mov    0x4f4(%edx),%dl
 2dd:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 2e1:	89 ca                	mov    %ecx,%edx
 2e3:	89 c1                	mov    %eax,%ecx
 2e5:	39 d6                	cmp    %edx,%esi
 2e7:	76 e2                	jbe    2cb <printint+0x26>
  if(neg)
 2e9:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 2ed:	74 24                	je     313 <printint+0x6e>
    buf[i++] = '-';
 2ef:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 2f4:	8d 5f 02             	lea    0x2(%edi),%ebx
 2f7:	eb 1a                	jmp    313 <printint+0x6e>
    x = -xx;
 2f9:	89 d1                	mov    %edx,%ecx
 2fb:	f7 d9                	neg    %ecx
    neg = 1;
 2fd:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 304:	eb c0                	jmp    2c6 <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 306:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 30b:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 30e:	e8 78 ff ff ff       	call   28b <putc>
  while(--i >= 0)
 313:	4b                   	dec    %ebx
 314:	79 f0                	jns    306 <printint+0x61>
}
 316:	83 c4 2c             	add    $0x2c,%esp
 319:	5b                   	pop    %ebx
 31a:	5e                   	pop    %esi
 31b:	5f                   	pop    %edi
 31c:	5d                   	pop    %ebp
 31d:	c3                   	ret    

0000031e <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 31e:	55                   	push   %ebp
 31f:	89 e5                	mov    %esp,%ebp
 321:	57                   	push   %edi
 322:	56                   	push   %esi
 323:	53                   	push   %ebx
 324:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 327:	8d 45 10             	lea    0x10(%ebp),%eax
 32a:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 32d:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 332:	bb 00 00 00 00       	mov    $0x0,%ebx
 337:	eb 12                	jmp    34b <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 339:	89 fa                	mov    %edi,%edx
 33b:	8b 45 08             	mov    0x8(%ebp),%eax
 33e:	e8 48 ff ff ff       	call   28b <putc>
 343:	eb 05                	jmp    34a <printf+0x2c>
      }
    } else if(state == '%'){
 345:	83 fe 25             	cmp    $0x25,%esi
 348:	74 22                	je     36c <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 34a:	43                   	inc    %ebx
 34b:	8b 45 0c             	mov    0xc(%ebp),%eax
 34e:	8a 04 18             	mov    (%eax,%ebx,1),%al
 351:	84 c0                	test   %al,%al
 353:	0f 84 1d 01 00 00    	je     476 <printf+0x158>
    c = fmt[i] & 0xff;
 359:	0f be f8             	movsbl %al,%edi
 35c:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 35f:	85 f6                	test   %esi,%esi
 361:	75 e2                	jne    345 <printf+0x27>
      if(c == '%'){
 363:	83 f8 25             	cmp    $0x25,%eax
 366:	75 d1                	jne    339 <printf+0x1b>
        state = '%';
 368:	89 c6                	mov    %eax,%esi
 36a:	eb de                	jmp    34a <printf+0x2c>
      if(c == 'd'){
 36c:	83 f8 25             	cmp    $0x25,%eax
 36f:	0f 84 cc 00 00 00    	je     441 <printf+0x123>
 375:	0f 8c da 00 00 00    	jl     455 <printf+0x137>
 37b:	83 f8 78             	cmp    $0x78,%eax
 37e:	0f 8f d1 00 00 00    	jg     455 <printf+0x137>
 384:	83 f8 63             	cmp    $0x63,%eax
 387:	0f 8c c8 00 00 00    	jl     455 <printf+0x137>
 38d:	83 e8 63             	sub    $0x63,%eax
 390:	83 f8 15             	cmp    $0x15,%eax
 393:	0f 87 bc 00 00 00    	ja     455 <printf+0x137>
 399:	ff 24 85 9c 04 00 00 	jmp    *0x49c(,%eax,4)
        printint(fd, *ap, 10, 1);
 3a0:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 3a3:	8b 17                	mov    (%edi),%edx
 3a5:	83 ec 0c             	sub    $0xc,%esp
 3a8:	6a 01                	push   $0x1
 3aa:	b9 0a 00 00 00       	mov    $0xa,%ecx
 3af:	8b 45 08             	mov    0x8(%ebp),%eax
 3b2:	e8 ee fe ff ff       	call   2a5 <printint>
        ap++;
 3b7:	83 c7 04             	add    $0x4,%edi
 3ba:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 3bd:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 3c0:	be 00 00 00 00       	mov    $0x0,%esi
 3c5:	eb 83                	jmp    34a <printf+0x2c>
        printint(fd, *ap, 16, 0);
 3c7:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 3ca:	8b 17                	mov    (%edi),%edx
 3cc:	83 ec 0c             	sub    $0xc,%esp
 3cf:	6a 00                	push   $0x0
 3d1:	b9 10 00 00 00       	mov    $0x10,%ecx
 3d6:	8b 45 08             	mov    0x8(%ebp),%eax
 3d9:	e8 c7 fe ff ff       	call   2a5 <printint>
        ap++;
 3de:	83 c7 04             	add    $0x4,%edi
 3e1:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 3e4:	83 c4 10             	add    $0x10,%esp
      state = 0;
 3e7:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 3ec:	e9 59 ff ff ff       	jmp    34a <printf+0x2c>
        s = (char*)*ap;
 3f1:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 3f4:	8b 30                	mov    (%eax),%esi
        ap++;
 3f6:	83 c0 04             	add    $0x4,%eax
 3f9:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 3fc:	85 f6                	test   %esi,%esi
 3fe:	75 13                	jne    413 <printf+0xf5>
          s = "(null)";
 400:	be 94 04 00 00       	mov    $0x494,%esi
 405:	eb 0c                	jmp    413 <printf+0xf5>
          putc(fd, *s);
 407:	0f be d2             	movsbl %dl,%edx
 40a:	8b 45 08             	mov    0x8(%ebp),%eax
 40d:	e8 79 fe ff ff       	call   28b <putc>
          s++;
 412:	46                   	inc    %esi
        while(*s != 0){
 413:	8a 16                	mov    (%esi),%dl
 415:	84 d2                	test   %dl,%dl
 417:	75 ee                	jne    407 <printf+0xe9>
      state = 0;
 419:	be 00 00 00 00       	mov    $0x0,%esi
 41e:	e9 27 ff ff ff       	jmp    34a <printf+0x2c>
        putc(fd, *ap);
 423:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 426:	0f be 17             	movsbl (%edi),%edx
 429:	8b 45 08             	mov    0x8(%ebp),%eax
 42c:	e8 5a fe ff ff       	call   28b <putc>
        ap++;
 431:	83 c7 04             	add    $0x4,%edi
 434:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 437:	be 00 00 00 00       	mov    $0x0,%esi
 43c:	e9 09 ff ff ff       	jmp    34a <printf+0x2c>
        putc(fd, c);
 441:	89 fa                	mov    %edi,%edx
 443:	8b 45 08             	mov    0x8(%ebp),%eax
 446:	e8 40 fe ff ff       	call   28b <putc>
      state = 0;
 44b:	be 00 00 00 00       	mov    $0x0,%esi
 450:	e9 f5 fe ff ff       	jmp    34a <printf+0x2c>
        putc(fd, '%');
 455:	ba 25 00 00 00       	mov    $0x25,%edx
 45a:	8b 45 08             	mov    0x8(%ebp),%eax
 45d:	e8 29 fe ff ff       	call   28b <putc>
        putc(fd, c);
 462:	89 fa                	mov    %edi,%edx
 464:	8b 45 08             	mov    0x8(%ebp),%eax
 467:	e8 1f fe ff ff       	call   28b <putc>
      state = 0;
 46c:	be 00 00 00 00       	mov    $0x0,%esi
 471:	e9 d4 fe ff ff       	jmp    34a <printf+0x2c>
    }
  }
}
 476:	8d 65 f4             	lea    -0xc(%ebp),%esp
 479:	5b                   	pop    %ebx
 47a:	5e                   	pop    %esi
 47b:	5f                   	pop    %edi
 47c:	5d                   	pop    %ebp
 47d:	c3                   	ret    
