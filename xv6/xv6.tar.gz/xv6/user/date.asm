
date:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <main>:
# include "user.h"
# include "date.h"

int
main (int argc, char *argv [])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	51                   	push   %ecx
   e:	83 ec 30             	sub    $0x30,%esp
  struct rtcdate r;

  if (date(&r))
  11:	8d 45 e0             	lea    -0x20(%ebp),%eax
  14:	50                   	push   %eax
  15:	e8 e3 00 00 00       	call   fd <date>
  1a:	83 c4 10             	add    $0x10,%esp
  1d:	85 c0                	test   %eax,%eax
  1f:	74 14                	je     35 <main+0x35>
  {
    printf(2, "date failed\n");
  21:	83 ec 08             	sub    $0x8,%esp
  24:	68 00 03 00 00       	push   $0x300
  29:	6a 02                	push   $0x2
  2b:	e8 70 01 00 00       	call   1a0 <printf>
    exit();
  30:	e8 28 00 00 00       	call   5d <exit>
  }

  // Pon aquí tu código para imprimir la fecha en el formato que desees
  printf(1, "%d/%d/%d\n", r.day, r.month, r.year);
  35:	83 ec 0c             	sub    $0xc,%esp
  38:	ff 75 f4             	push   -0xc(%ebp)
  3b:	ff 75 f0             	push   -0x10(%ebp)
  3e:	ff 75 ec             	push   -0x14(%ebp)
  41:	68 0d 03 00 00       	push   $0x30d
  46:	6a 01                	push   $0x1
  48:	e8 53 01 00 00       	call   1a0 <printf>
  exit();
  4d:	83 c4 20             	add    $0x20,%esp
  50:	e8 08 00 00 00       	call   5d <exit>

00000055 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
  55:	b8 01 00 00 00       	mov    $0x1,%eax
  5a:	cd 40                	int    $0x40
  5c:	c3                   	ret    

0000005d <exit>:
SYSCALL(exit)
  5d:	b8 02 00 00 00       	mov    $0x2,%eax
  62:	cd 40                	int    $0x40
  64:	c3                   	ret    

00000065 <wait>:
SYSCALL(wait)
  65:	b8 03 00 00 00       	mov    $0x3,%eax
  6a:	cd 40                	int    $0x40
  6c:	c3                   	ret    

0000006d <pipe>:
SYSCALL(pipe)
  6d:	b8 04 00 00 00       	mov    $0x4,%eax
  72:	cd 40                	int    $0x40
  74:	c3                   	ret    

00000075 <read>:
SYSCALL(read)
  75:	b8 05 00 00 00       	mov    $0x5,%eax
  7a:	cd 40                	int    $0x40
  7c:	c3                   	ret    

0000007d <write>:
SYSCALL(write)
  7d:	b8 10 00 00 00       	mov    $0x10,%eax
  82:	cd 40                	int    $0x40
  84:	c3                   	ret    

00000085 <close>:
SYSCALL(close)
  85:	b8 15 00 00 00       	mov    $0x15,%eax
  8a:	cd 40                	int    $0x40
  8c:	c3                   	ret    

0000008d <kill>:
SYSCALL(kill)
  8d:	b8 06 00 00 00       	mov    $0x6,%eax
  92:	cd 40                	int    $0x40
  94:	c3                   	ret    

00000095 <exec>:
SYSCALL(exec)
  95:	b8 07 00 00 00       	mov    $0x7,%eax
  9a:	cd 40                	int    $0x40
  9c:	c3                   	ret    

0000009d <open>:
SYSCALL(open)
  9d:	b8 0f 00 00 00       	mov    $0xf,%eax
  a2:	cd 40                	int    $0x40
  a4:	c3                   	ret    

000000a5 <mknod>:
SYSCALL(mknod)
  a5:	b8 11 00 00 00       	mov    $0x11,%eax
  aa:	cd 40                	int    $0x40
  ac:	c3                   	ret    

000000ad <unlink>:
SYSCALL(unlink)
  ad:	b8 12 00 00 00       	mov    $0x12,%eax
  b2:	cd 40                	int    $0x40
  b4:	c3                   	ret    

000000b5 <fstat>:
SYSCALL(fstat)
  b5:	b8 08 00 00 00       	mov    $0x8,%eax
  ba:	cd 40                	int    $0x40
  bc:	c3                   	ret    

000000bd <link>:
SYSCALL(link)
  bd:	b8 13 00 00 00       	mov    $0x13,%eax
  c2:	cd 40                	int    $0x40
  c4:	c3                   	ret    

000000c5 <mkdir>:
SYSCALL(mkdir)
  c5:	b8 14 00 00 00       	mov    $0x14,%eax
  ca:	cd 40                	int    $0x40
  cc:	c3                   	ret    

000000cd <chdir>:
SYSCALL(chdir)
  cd:	b8 09 00 00 00       	mov    $0x9,%eax
  d2:	cd 40                	int    $0x40
  d4:	c3                   	ret    

000000d5 <dup>:
SYSCALL(dup)
  d5:	b8 0a 00 00 00       	mov    $0xa,%eax
  da:	cd 40                	int    $0x40
  dc:	c3                   	ret    

000000dd <getpid>:
SYSCALL(getpid)
  dd:	b8 0b 00 00 00       	mov    $0xb,%eax
  e2:	cd 40                	int    $0x40
  e4:	c3                   	ret    

000000e5 <sbrk>:
SYSCALL(sbrk)
  e5:	b8 0c 00 00 00       	mov    $0xc,%eax
  ea:	cd 40                	int    $0x40
  ec:	c3                   	ret    

000000ed <sleep>:
SYSCALL(sleep)
  ed:	b8 0d 00 00 00       	mov    $0xd,%eax
  f2:	cd 40                	int    $0x40
  f4:	c3                   	ret    

000000f5 <uptime>:
SYSCALL(uptime)
  f5:	b8 0e 00 00 00       	mov    $0xe,%eax
  fa:	cd 40                	int    $0x40
  fc:	c3                   	ret    

000000fd <date>:
SYSCALL(date)
  fd:	b8 16 00 00 00       	mov    $0x16,%eax
 102:	cd 40                	int    $0x40
 104:	c3                   	ret    

00000105 <dup2>:
SYSCALL(dup2)
 105:	b8 17 00 00 00       	mov    $0x17,%eax
 10a:	cd 40                	int    $0x40
 10c:	c3                   	ret    

0000010d <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 10d:	55                   	push   %ebp
 10e:	89 e5                	mov    %esp,%ebp
 110:	83 ec 1c             	sub    $0x1c,%esp
 113:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 116:	6a 01                	push   $0x1
 118:	8d 55 f4             	lea    -0xc(%ebp),%edx
 11b:	52                   	push   %edx
 11c:	50                   	push   %eax
 11d:	e8 5b ff ff ff       	call   7d <write>
}
 122:	83 c4 10             	add    $0x10,%esp
 125:	c9                   	leave  
 126:	c3                   	ret    

00000127 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 127:	55                   	push   %ebp
 128:	89 e5                	mov    %esp,%ebp
 12a:	57                   	push   %edi
 12b:	56                   	push   %esi
 12c:	53                   	push   %ebx
 12d:	83 ec 2c             	sub    $0x2c,%esp
 130:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 133:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 135:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 139:	74 04                	je     13f <printint+0x18>
 13b:	85 d2                	test   %edx,%edx
 13d:	78 3c                	js     17b <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 13f:	89 d1                	mov    %edx,%ecx
  neg = 0;
 141:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 148:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 14d:	89 c8                	mov    %ecx,%eax
 14f:	ba 00 00 00 00       	mov    $0x0,%edx
 154:	f7 f6                	div    %esi
 156:	89 df                	mov    %ebx,%edi
 158:	43                   	inc    %ebx
 159:	8a 92 78 03 00 00    	mov    0x378(%edx),%dl
 15f:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 163:	89 ca                	mov    %ecx,%edx
 165:	89 c1                	mov    %eax,%ecx
 167:	39 d6                	cmp    %edx,%esi
 169:	76 e2                	jbe    14d <printint+0x26>
  if(neg)
 16b:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 16f:	74 24                	je     195 <printint+0x6e>
    buf[i++] = '-';
 171:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 176:	8d 5f 02             	lea    0x2(%edi),%ebx
 179:	eb 1a                	jmp    195 <printint+0x6e>
    x = -xx;
 17b:	89 d1                	mov    %edx,%ecx
 17d:	f7 d9                	neg    %ecx
    neg = 1;
 17f:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 186:	eb c0                	jmp    148 <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 188:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 18d:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 190:	e8 78 ff ff ff       	call   10d <putc>
  while(--i >= 0)
 195:	4b                   	dec    %ebx
 196:	79 f0                	jns    188 <printint+0x61>
}
 198:	83 c4 2c             	add    $0x2c,%esp
 19b:	5b                   	pop    %ebx
 19c:	5e                   	pop    %esi
 19d:	5f                   	pop    %edi
 19e:	5d                   	pop    %ebp
 19f:	c3                   	ret    

000001a0 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 1a0:	55                   	push   %ebp
 1a1:	89 e5                	mov    %esp,%ebp
 1a3:	57                   	push   %edi
 1a4:	56                   	push   %esi
 1a5:	53                   	push   %ebx
 1a6:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 1a9:	8d 45 10             	lea    0x10(%ebp),%eax
 1ac:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 1af:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 1b4:	bb 00 00 00 00       	mov    $0x0,%ebx
 1b9:	eb 12                	jmp    1cd <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 1bb:	89 fa                	mov    %edi,%edx
 1bd:	8b 45 08             	mov    0x8(%ebp),%eax
 1c0:	e8 48 ff ff ff       	call   10d <putc>
 1c5:	eb 05                	jmp    1cc <printf+0x2c>
      }
    } else if(state == '%'){
 1c7:	83 fe 25             	cmp    $0x25,%esi
 1ca:	74 22                	je     1ee <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 1cc:	43                   	inc    %ebx
 1cd:	8b 45 0c             	mov    0xc(%ebp),%eax
 1d0:	8a 04 18             	mov    (%eax,%ebx,1),%al
 1d3:	84 c0                	test   %al,%al
 1d5:	0f 84 1d 01 00 00    	je     2f8 <printf+0x158>
    c = fmt[i] & 0xff;
 1db:	0f be f8             	movsbl %al,%edi
 1de:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 1e1:	85 f6                	test   %esi,%esi
 1e3:	75 e2                	jne    1c7 <printf+0x27>
      if(c == '%'){
 1e5:	83 f8 25             	cmp    $0x25,%eax
 1e8:	75 d1                	jne    1bb <printf+0x1b>
        state = '%';
 1ea:	89 c6                	mov    %eax,%esi
 1ec:	eb de                	jmp    1cc <printf+0x2c>
      if(c == 'd'){
 1ee:	83 f8 25             	cmp    $0x25,%eax
 1f1:	0f 84 cc 00 00 00    	je     2c3 <printf+0x123>
 1f7:	0f 8c da 00 00 00    	jl     2d7 <printf+0x137>
 1fd:	83 f8 78             	cmp    $0x78,%eax
 200:	0f 8f d1 00 00 00    	jg     2d7 <printf+0x137>
 206:	83 f8 63             	cmp    $0x63,%eax
 209:	0f 8c c8 00 00 00    	jl     2d7 <printf+0x137>
 20f:	83 e8 63             	sub    $0x63,%eax
 212:	83 f8 15             	cmp    $0x15,%eax
 215:	0f 87 bc 00 00 00    	ja     2d7 <printf+0x137>
 21b:	ff 24 85 20 03 00 00 	jmp    *0x320(,%eax,4)
        printint(fd, *ap, 10, 1);
 222:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 225:	8b 17                	mov    (%edi),%edx
 227:	83 ec 0c             	sub    $0xc,%esp
 22a:	6a 01                	push   $0x1
 22c:	b9 0a 00 00 00       	mov    $0xa,%ecx
 231:	8b 45 08             	mov    0x8(%ebp),%eax
 234:	e8 ee fe ff ff       	call   127 <printint>
        ap++;
 239:	83 c7 04             	add    $0x4,%edi
 23c:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 23f:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 242:	be 00 00 00 00       	mov    $0x0,%esi
 247:	eb 83                	jmp    1cc <printf+0x2c>
        printint(fd, *ap, 16, 0);
 249:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 24c:	8b 17                	mov    (%edi),%edx
 24e:	83 ec 0c             	sub    $0xc,%esp
 251:	6a 00                	push   $0x0
 253:	b9 10 00 00 00       	mov    $0x10,%ecx
 258:	8b 45 08             	mov    0x8(%ebp),%eax
 25b:	e8 c7 fe ff ff       	call   127 <printint>
        ap++;
 260:	83 c7 04             	add    $0x4,%edi
 263:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 266:	83 c4 10             	add    $0x10,%esp
      state = 0;
 269:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 26e:	e9 59 ff ff ff       	jmp    1cc <printf+0x2c>
        s = (char*)*ap;
 273:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 276:	8b 30                	mov    (%eax),%esi
        ap++;
 278:	83 c0 04             	add    $0x4,%eax
 27b:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 27e:	85 f6                	test   %esi,%esi
 280:	75 13                	jne    295 <printf+0xf5>
          s = "(null)";
 282:	be 17 03 00 00       	mov    $0x317,%esi
 287:	eb 0c                	jmp    295 <printf+0xf5>
          putc(fd, *s);
 289:	0f be d2             	movsbl %dl,%edx
 28c:	8b 45 08             	mov    0x8(%ebp),%eax
 28f:	e8 79 fe ff ff       	call   10d <putc>
          s++;
 294:	46                   	inc    %esi
        while(*s != 0){
 295:	8a 16                	mov    (%esi),%dl
 297:	84 d2                	test   %dl,%dl
 299:	75 ee                	jne    289 <printf+0xe9>
      state = 0;
 29b:	be 00 00 00 00       	mov    $0x0,%esi
 2a0:	e9 27 ff ff ff       	jmp    1cc <printf+0x2c>
        putc(fd, *ap);
 2a5:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 2a8:	0f be 17             	movsbl (%edi),%edx
 2ab:	8b 45 08             	mov    0x8(%ebp),%eax
 2ae:	e8 5a fe ff ff       	call   10d <putc>
        ap++;
 2b3:	83 c7 04             	add    $0x4,%edi
 2b6:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 2b9:	be 00 00 00 00       	mov    $0x0,%esi
 2be:	e9 09 ff ff ff       	jmp    1cc <printf+0x2c>
        putc(fd, c);
 2c3:	89 fa                	mov    %edi,%edx
 2c5:	8b 45 08             	mov    0x8(%ebp),%eax
 2c8:	e8 40 fe ff ff       	call   10d <putc>
      state = 0;
 2cd:	be 00 00 00 00       	mov    $0x0,%esi
 2d2:	e9 f5 fe ff ff       	jmp    1cc <printf+0x2c>
        putc(fd, '%');
 2d7:	ba 25 00 00 00       	mov    $0x25,%edx
 2dc:	8b 45 08             	mov    0x8(%ebp),%eax
 2df:	e8 29 fe ff ff       	call   10d <putc>
        putc(fd, c);
 2e4:	89 fa                	mov    %edi,%edx
 2e6:	8b 45 08             	mov    0x8(%ebp),%eax
 2e9:	e8 1f fe ff ff       	call   10d <putc>
      state = 0;
 2ee:	be 00 00 00 00       	mov    $0x0,%esi
 2f3:	e9 d4 fe ff ff       	jmp    1cc <printf+0x2c>
    }
  }
}
 2f8:	8d 65 f4             	lea    -0xc(%ebp),%esp
 2fb:	5b                   	pop    %ebx
 2fc:	5e                   	pop    %esi
 2fd:	5f                   	pop    %edi
 2fe:	5d                   	pop    %ebp
 2ff:	c3                   	ret    
