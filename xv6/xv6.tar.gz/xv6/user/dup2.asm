
dup2:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <main>:
#include "user.h"
#include "fcntl.h"

int
main(int argc, char* argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	53                   	push   %ebx
   e:	51                   	push   %ecx
  int fd;

  // Ejemplo de dup2 con un fd incorrecto
  if (dup2 (-1,8) >= 0)
   f:	83 ec 08             	sub    $0x8,%esp
  12:	6a 08                	push   $0x8
  14:	6a ff                	push   $0xffffffff
  16:	e8 e3 03 00 00       	call   3fe <dup2>
  1b:	83 c4 10             	add    $0x10,%esp
  1e:	85 c0                	test   %eax,%eax
  20:	0f 89 e6 01 00 00    	jns    20c <main+0x20c>
    printf (2, "dup2 no funciona con fd incorrecto.\n");

  // Ejemplo de dup2 con un newfd incorrecto
  if (dup2 (1,-1) >= 0)
  26:	83 ec 08             	sub    $0x8,%esp
  29:	6a ff                	push   $0xffffffff
  2b:	6a 01                	push   $0x1
  2d:	e8 cc 03 00 00       	call   3fe <dup2>
  32:	83 c4 10             	add    $0x10,%esp
  35:	85 c0                	test   %eax,%eax
  37:	0f 89 e6 01 00 00    	jns    223 <main+0x223>
    printf (2, "dup2 no funciona con fd incorrecto (2).\n");

  // Ejemplo de dup2 con un fd no mapeado
  if (dup2 (6,8) >= 0)
  3d:	83 ec 08             	sub    $0x8,%esp
  40:	6a 08                	push   $0x8
  42:	6a 06                	push   $0x6
  44:	e8 b5 03 00 00       	call   3fe <dup2>
  49:	83 c4 10             	add    $0x10,%esp
  4c:	85 c0                	test   %eax,%eax
  4e:	0f 89 e6 01 00 00    	jns    23a <main+0x23a>
    printf (2, "dup2 no funciona con fd no mapeado.\n");

  // Ejemplo de dup2 con un fd no mapeado (2)
  if (dup2 (8,1) >= 0)
  54:	83 ec 08             	sub    $0x8,%esp
  57:	6a 01                	push   $0x1
  59:	6a 08                	push   $0x8
  5b:	e8 9e 03 00 00       	call   3fe <dup2>
  60:	83 c4 10             	add    $0x10,%esp
  63:	85 c0                	test   %eax,%eax
  65:	0f 89 e6 01 00 00    	jns    251 <main+0x251>
    printf (2, "dup2 no funciona con fd no mapeado (2).\n");

  if (dup2 (1,25) >= 0)
  6b:	83 ec 08             	sub    $0x8,%esp
  6e:	6a 19                	push   $0x19
  70:	6a 01                	push   $0x1
  72:	e8 87 03 00 00       	call   3fe <dup2>
  77:	83 c4 10             	add    $0x10,%esp
  7a:	85 c0                	test   %eax,%eax
  7c:	0f 89 e6 01 00 00    	jns    268 <main+0x268>
    printf (2, "dup2 no funciona con fd superior a NOFILE.\n");

  // Ejemplo de dup2 con fd existente
  if (dup2 (1,4) != 4)
  82:	83 ec 08             	sub    $0x8,%esp
  85:	6a 04                	push   $0x4
  87:	6a 01                	push   $0x1
  89:	e8 70 03 00 00       	call   3fe <dup2>
  8e:	83 c4 10             	add    $0x10,%esp
  91:	83 f8 04             	cmp    $0x4,%eax
  94:	0f 85 e5 01 00 00    	jne    27f <main+0x27f>
    printf (2, "dup2 no funciona con fd existente.\n");

  printf (4, "Este mensaje debe salir por terminal.\n");
  9a:	83 ec 08             	sub    $0x8,%esp
  9d:	68 f4 06 00 00       	push   $0x6f4
  a2:	6a 04                	push   $0x4
  a4:	e8 f0 03 00 00       	call   499 <printf>

  if (dup2 (4,6) != 6)
  a9:	83 c4 08             	add    $0x8,%esp
  ac:	6a 06                	push   $0x6
  ae:	6a 04                	push   $0x4
  b0:	e8 49 03 00 00       	call   3fe <dup2>
  b5:	83 c4 10             	add    $0x10,%esp
  b8:	83 f8 06             	cmp    $0x6,%eax
  bb:	0f 85 d5 01 00 00    	jne    296 <main+0x296>
    printf (2, "dup2 no funciona con fd existente (2).\n");

  printf (6, "Este mensaje debe salir por terminal (2).\n");
  c1:	83 ec 08             	sub    $0x8,%esp
  c4:	68 44 07 00 00       	push   $0x744
  c9:	6a 06                	push   $0x6
  cb:	e8 c9 03 00 00       	call   499 <printf>

  if (close (4) != 0)
  d0:	c7 04 24 04 00 00 00 	movl   $0x4,(%esp)
  d7:	e8 a2 02 00 00       	call   37e <close>
  dc:	83 c4 10             	add    $0x10,%esp
  df:	85 c0                	test   %eax,%eax
  e1:	0f 85 c6 01 00 00    	jne    2ad <main+0x2ad>
    printf (2, "Error en close (4)\n");
  printf (6, "Este mensaje debe salir por terminal (3).\n");
  e7:	83 ec 08             	sub    $0x8,%esp
  ea:	68 70 07 00 00       	push   $0x770
  ef:	6a 06                	push   $0x6
  f1:	e8 a3 03 00 00       	call   499 <printf>
  if (close (6) != 0)
  f6:	c7 04 24 06 00 00 00 	movl   $0x6,(%esp)
  fd:	e8 7c 02 00 00       	call   37e <close>
 102:	83 c4 10             	add    $0x10,%esp
 105:	85 c0                	test   %eax,%eax
 107:	0f 85 b7 01 00 00    	jne    2c4 <main+0x2c4>
    printf (2, "Error en close (6)\n");
  if (close (6) == 0)
 10d:	83 ec 0c             	sub    $0xc,%esp
 110:	6a 06                	push   $0x6
 112:	e8 67 02 00 00       	call   37e <close>
 117:	83 c4 10             	add    $0x10,%esp
 11a:	85 c0                	test   %eax,%eax
 11c:	0f 84 b9 01 00 00    	je     2db <main+0x2db>
    printf (2, "Error en close (6) (2)\n");

  fd = open ("ficherosalida.txt", O_CREATE|O_RDWR);
 122:	83 ec 08             	sub    $0x8,%esp
 125:	68 02 02 00 00       	push   $0x202
 12a:	68 50 08 00 00       	push   $0x850
 12f:	e8 62 02 00 00       	call   396 <open>
 134:	89 c3                	mov    %eax,%ebx
  printf (fd, "Salida a fichero\n");
 136:	83 c4 08             	add    $0x8,%esp
 139:	68 62 08 00 00       	push   $0x862
 13e:	50                   	push   %eax
 13f:	e8 55 03 00 00       	call   499 <printf>

  if (dup2 (fd, 9) != 9)
 144:	83 c4 08             	add    $0x8,%esp
 147:	6a 09                	push   $0x9
 149:	53                   	push   %ebx
 14a:	e8 af 02 00 00       	call   3fe <dup2>
 14f:	83 c4 10             	add    $0x10,%esp
 152:	83 f8 09             	cmp    $0x9,%eax
 155:	0f 85 97 01 00 00    	jne    2f2 <main+0x2f2>
    printf (2, "dup2 no funciona con fd existente (3).\n");

  printf (9, "Salida también a fichero.\n");
 15b:	83 ec 08             	sub    $0x8,%esp
 15e:	68 74 08 00 00       	push   $0x874
 163:	6a 09                	push   $0x9
 165:	e8 2f 03 00 00       	call   499 <printf>

  if (dup2 (9, 9) != 9)
 16a:	83 c4 08             	add    $0x8,%esp
 16d:	6a 09                	push   $0x9
 16f:	6a 09                	push   $0x9
 171:	e8 88 02 00 00       	call   3fe <dup2>
 176:	83 c4 10             	add    $0x10,%esp
 179:	83 f8 09             	cmp    $0x9,%eax
 17c:	0f 85 87 01 00 00    	jne    309 <main+0x309>
    printf (2, "dup2 no funciona con newfd=oldfd.\n");

  printf (9, "Salida también a fichero.\n");
 182:	83 ec 08             	sub    $0x8,%esp
 185:	68 74 08 00 00       	push   $0x874
 18a:	6a 09                	push   $0x9
 18c:	e8 08 03 00 00       	call   499 <printf>

  close (9);
 191:	c7 04 24 09 00 00 00 	movl   $0x9,(%esp)
 198:	e8 e1 01 00 00       	call   37e <close>

  dup2 (1, 6);
 19d:	83 c4 08             	add    $0x8,%esp
 1a0:	6a 06                	push   $0x6
 1a2:	6a 01                	push   $0x1
 1a4:	e8 55 02 00 00       	call   3fe <dup2>

  if (dup2 (fd, 1) != 1)
 1a9:	83 c4 08             	add    $0x8,%esp
 1ac:	6a 01                	push   $0x1
 1ae:	53                   	push   %ebx
 1af:	e8 4a 02 00 00       	call   3fe <dup2>
 1b4:	83 c4 10             	add    $0x10,%esp
 1b7:	83 f8 01             	cmp    $0x1,%eax
 1ba:	0f 85 60 01 00 00    	jne    320 <main+0x320>
    printf (2, "dup2 no funciona con fd existente (4).\n");

  printf (1, "Cuarta salida a fichero.\n");
 1c0:	83 ec 08             	sub    $0x8,%esp
 1c3:	68 90 08 00 00       	push   $0x890
 1c8:	6a 01                	push   $0x1
 1ca:	e8 ca 02 00 00       	call   499 <printf>
  if (close (1) != 0)
 1cf:	c7 04 24 01 00 00 00 	movl   $0x1,(%esp)
 1d6:	e8 a3 01 00 00       	call   37e <close>
 1db:	83 c4 10             	add    $0x10,%esp
 1de:	85 c0                	test   %eax,%eax
 1e0:	0f 85 51 01 00 00    	jne    337 <main+0x337>
    printf (2, "Error en close (1).\n");

  dup2 (6,fd);
 1e6:	83 ec 08             	sub    $0x8,%esp
 1e9:	53                   	push   %ebx
 1ea:	6a 06                	push   $0x6
 1ec:	e8 0d 02 00 00       	call   3fe <dup2>

  printf (fd, "Este mensaje debe salir por terminal.\n");
 1f1:	83 c4 08             	add    $0x8,%esp
 1f4:	68 f4 06 00 00       	push   $0x6f4
 1f9:	53                   	push   %ebx
 1fa:	e8 9a 02 00 00       	call   499 <printf>
  close (fd);
 1ff:	89 1c 24             	mov    %ebx,(%esp)
 202:	e8 77 01 00 00       	call   37e <close>

  exit();
 207:	e8 4a 01 00 00       	call   356 <exit>
    printf (2, "dup2 no funciona con fd incorrecto.\n");
 20c:	83 ec 08             	sub    $0x8,%esp
 20f:	68 fc 05 00 00       	push   $0x5fc
 214:	6a 02                	push   $0x2
 216:	e8 7e 02 00 00       	call   499 <printf>
 21b:	83 c4 10             	add    $0x10,%esp
 21e:	e9 03 fe ff ff       	jmp    26 <main+0x26>
    printf (2, "dup2 no funciona con fd incorrecto (2).\n");
 223:	83 ec 08             	sub    $0x8,%esp
 226:	68 24 06 00 00       	push   $0x624
 22b:	6a 02                	push   $0x2
 22d:	e8 67 02 00 00       	call   499 <printf>
 232:	83 c4 10             	add    $0x10,%esp
 235:	e9 03 fe ff ff       	jmp    3d <main+0x3d>
    printf (2, "dup2 no funciona con fd no mapeado.\n");
 23a:	83 ec 08             	sub    $0x8,%esp
 23d:	68 50 06 00 00       	push   $0x650
 242:	6a 02                	push   $0x2
 244:	e8 50 02 00 00       	call   499 <printf>
 249:	83 c4 10             	add    $0x10,%esp
 24c:	e9 03 fe ff ff       	jmp    54 <main+0x54>
    printf (2, "dup2 no funciona con fd no mapeado (2).\n");
 251:	83 ec 08             	sub    $0x8,%esp
 254:	68 78 06 00 00       	push   $0x678
 259:	6a 02                	push   $0x2
 25b:	e8 39 02 00 00       	call   499 <printf>
 260:	83 c4 10             	add    $0x10,%esp
 263:	e9 03 fe ff ff       	jmp    6b <main+0x6b>
    printf (2, "dup2 no funciona con fd superior a NOFILE.\n");
 268:	83 ec 08             	sub    $0x8,%esp
 26b:	68 a4 06 00 00       	push   $0x6a4
 270:	6a 02                	push   $0x2
 272:	e8 22 02 00 00       	call   499 <printf>
 277:	83 c4 10             	add    $0x10,%esp
 27a:	e9 03 fe ff ff       	jmp    82 <main+0x82>
    printf (2, "dup2 no funciona con fd existente.\n");
 27f:	83 ec 08             	sub    $0x8,%esp
 282:	68 d0 06 00 00       	push   $0x6d0
 287:	6a 02                	push   $0x2
 289:	e8 0b 02 00 00       	call   499 <printf>
 28e:	83 c4 10             	add    $0x10,%esp
 291:	e9 04 fe ff ff       	jmp    9a <main+0x9a>
    printf (2, "dup2 no funciona con fd existente (2).\n");
 296:	83 ec 08             	sub    $0x8,%esp
 299:	68 1c 07 00 00       	push   $0x71c
 29e:	6a 02                	push   $0x2
 2a0:	e8 f4 01 00 00       	call   499 <printf>
 2a5:	83 c4 10             	add    $0x10,%esp
 2a8:	e9 14 fe ff ff       	jmp    c1 <main+0xc1>
    printf (2, "Error en close (4)\n");
 2ad:	83 ec 08             	sub    $0x8,%esp
 2b0:	68 10 08 00 00       	push   $0x810
 2b5:	6a 02                	push   $0x2
 2b7:	e8 dd 01 00 00       	call   499 <printf>
 2bc:	83 c4 10             	add    $0x10,%esp
 2bf:	e9 23 fe ff ff       	jmp    e7 <main+0xe7>
    printf (2, "Error en close (6)\n");
 2c4:	83 ec 08             	sub    $0x8,%esp
 2c7:	68 24 08 00 00       	push   $0x824
 2cc:	6a 02                	push   $0x2
 2ce:	e8 c6 01 00 00       	call   499 <printf>
 2d3:	83 c4 10             	add    $0x10,%esp
 2d6:	e9 32 fe ff ff       	jmp    10d <main+0x10d>
    printf (2, "Error en close (6) (2)\n");
 2db:	83 ec 08             	sub    $0x8,%esp
 2de:	68 38 08 00 00       	push   $0x838
 2e3:	6a 02                	push   $0x2
 2e5:	e8 af 01 00 00       	call   499 <printf>
 2ea:	83 c4 10             	add    $0x10,%esp
 2ed:	e9 30 fe ff ff       	jmp    122 <main+0x122>
    printf (2, "dup2 no funciona con fd existente (3).\n");
 2f2:	83 ec 08             	sub    $0x8,%esp
 2f5:	68 9c 07 00 00       	push   $0x79c
 2fa:	6a 02                	push   $0x2
 2fc:	e8 98 01 00 00       	call   499 <printf>
 301:	83 c4 10             	add    $0x10,%esp
 304:	e9 52 fe ff ff       	jmp    15b <main+0x15b>
    printf (2, "dup2 no funciona con newfd=oldfd.\n");
 309:	83 ec 08             	sub    $0x8,%esp
 30c:	68 c4 07 00 00       	push   $0x7c4
 311:	6a 02                	push   $0x2
 313:	e8 81 01 00 00       	call   499 <printf>
 318:	83 c4 10             	add    $0x10,%esp
 31b:	e9 62 fe ff ff       	jmp    182 <main+0x182>
    printf (2, "dup2 no funciona con fd existente (4).\n");
 320:	83 ec 08             	sub    $0x8,%esp
 323:	68 e8 07 00 00       	push   $0x7e8
 328:	6a 02                	push   $0x2
 32a:	e8 6a 01 00 00       	call   499 <printf>
 32f:	83 c4 10             	add    $0x10,%esp
 332:	e9 89 fe ff ff       	jmp    1c0 <main+0x1c0>
    printf (2, "Error en close (1).\n");
 337:	83 ec 08             	sub    $0x8,%esp
 33a:	68 aa 08 00 00       	push   $0x8aa
 33f:	6a 02                	push   $0x2
 341:	e8 53 01 00 00       	call   499 <printf>
 346:	83 c4 10             	add    $0x10,%esp
 349:	e9 98 fe ff ff       	jmp    1e6 <main+0x1e6>

0000034e <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 34e:	b8 01 00 00 00       	mov    $0x1,%eax
 353:	cd 40                	int    $0x40
 355:	c3                   	ret    

00000356 <exit>:
SYSCALL(exit)
 356:	b8 02 00 00 00       	mov    $0x2,%eax
 35b:	cd 40                	int    $0x40
 35d:	c3                   	ret    

0000035e <wait>:
SYSCALL(wait)
 35e:	b8 03 00 00 00       	mov    $0x3,%eax
 363:	cd 40                	int    $0x40
 365:	c3                   	ret    

00000366 <pipe>:
SYSCALL(pipe)
 366:	b8 04 00 00 00       	mov    $0x4,%eax
 36b:	cd 40                	int    $0x40
 36d:	c3                   	ret    

0000036e <read>:
SYSCALL(read)
 36e:	b8 05 00 00 00       	mov    $0x5,%eax
 373:	cd 40                	int    $0x40
 375:	c3                   	ret    

00000376 <write>:
SYSCALL(write)
 376:	b8 10 00 00 00       	mov    $0x10,%eax
 37b:	cd 40                	int    $0x40
 37d:	c3                   	ret    

0000037e <close>:
SYSCALL(close)
 37e:	b8 15 00 00 00       	mov    $0x15,%eax
 383:	cd 40                	int    $0x40
 385:	c3                   	ret    

00000386 <kill>:
SYSCALL(kill)
 386:	b8 06 00 00 00       	mov    $0x6,%eax
 38b:	cd 40                	int    $0x40
 38d:	c3                   	ret    

0000038e <exec>:
SYSCALL(exec)
 38e:	b8 07 00 00 00       	mov    $0x7,%eax
 393:	cd 40                	int    $0x40
 395:	c3                   	ret    

00000396 <open>:
SYSCALL(open)
 396:	b8 0f 00 00 00       	mov    $0xf,%eax
 39b:	cd 40                	int    $0x40
 39d:	c3                   	ret    

0000039e <mknod>:
SYSCALL(mknod)
 39e:	b8 11 00 00 00       	mov    $0x11,%eax
 3a3:	cd 40                	int    $0x40
 3a5:	c3                   	ret    

000003a6 <unlink>:
SYSCALL(unlink)
 3a6:	b8 12 00 00 00       	mov    $0x12,%eax
 3ab:	cd 40                	int    $0x40
 3ad:	c3                   	ret    

000003ae <fstat>:
SYSCALL(fstat)
 3ae:	b8 08 00 00 00       	mov    $0x8,%eax
 3b3:	cd 40                	int    $0x40
 3b5:	c3                   	ret    

000003b6 <link>:
SYSCALL(link)
 3b6:	b8 13 00 00 00       	mov    $0x13,%eax
 3bb:	cd 40                	int    $0x40
 3bd:	c3                   	ret    

000003be <mkdir>:
SYSCALL(mkdir)
 3be:	b8 14 00 00 00       	mov    $0x14,%eax
 3c3:	cd 40                	int    $0x40
 3c5:	c3                   	ret    

000003c6 <chdir>:
SYSCALL(chdir)
 3c6:	b8 09 00 00 00       	mov    $0x9,%eax
 3cb:	cd 40                	int    $0x40
 3cd:	c3                   	ret    

000003ce <dup>:
SYSCALL(dup)
 3ce:	b8 0a 00 00 00       	mov    $0xa,%eax
 3d3:	cd 40                	int    $0x40
 3d5:	c3                   	ret    

000003d6 <getpid>:
SYSCALL(getpid)
 3d6:	b8 0b 00 00 00       	mov    $0xb,%eax
 3db:	cd 40                	int    $0x40
 3dd:	c3                   	ret    

000003de <sbrk>:
SYSCALL(sbrk)
 3de:	b8 0c 00 00 00       	mov    $0xc,%eax
 3e3:	cd 40                	int    $0x40
 3e5:	c3                   	ret    

000003e6 <sleep>:
SYSCALL(sleep)
 3e6:	b8 0d 00 00 00       	mov    $0xd,%eax
 3eb:	cd 40                	int    $0x40
 3ed:	c3                   	ret    

000003ee <uptime>:
SYSCALL(uptime)
 3ee:	b8 0e 00 00 00       	mov    $0xe,%eax
 3f3:	cd 40                	int    $0x40
 3f5:	c3                   	ret    

000003f6 <date>:
SYSCALL(date)
 3f6:	b8 16 00 00 00       	mov    $0x16,%eax
 3fb:	cd 40                	int    $0x40
 3fd:	c3                   	ret    

000003fe <dup2>:
SYSCALL(dup2)
 3fe:	b8 17 00 00 00       	mov    $0x17,%eax
 403:	cd 40                	int    $0x40
 405:	c3                   	ret    

00000406 <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 406:	55                   	push   %ebp
 407:	89 e5                	mov    %esp,%ebp
 409:	83 ec 1c             	sub    $0x1c,%esp
 40c:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 40f:	6a 01                	push   $0x1
 411:	8d 55 f4             	lea    -0xc(%ebp),%edx
 414:	52                   	push   %edx
 415:	50                   	push   %eax
 416:	e8 5b ff ff ff       	call   376 <write>
}
 41b:	83 c4 10             	add    $0x10,%esp
 41e:	c9                   	leave  
 41f:	c3                   	ret    

00000420 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 420:	55                   	push   %ebp
 421:	89 e5                	mov    %esp,%ebp
 423:	57                   	push   %edi
 424:	56                   	push   %esi
 425:	53                   	push   %ebx
 426:	83 ec 2c             	sub    $0x2c,%esp
 429:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 42c:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 42e:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 432:	74 04                	je     438 <printint+0x18>
 434:	85 d2                	test   %edx,%edx
 436:	78 3c                	js     474 <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 438:	89 d1                	mov    %edx,%ecx
  neg = 0;
 43a:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 441:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 446:	89 c8                	mov    %ecx,%eax
 448:	ba 00 00 00 00       	mov    $0x0,%edx
 44d:	f7 f6                	div    %esi
 44f:	89 df                	mov    %ebx,%edi
 451:	43                   	inc    %ebx
 452:	8a 92 20 09 00 00    	mov    0x920(%edx),%dl
 458:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 45c:	89 ca                	mov    %ecx,%edx
 45e:	89 c1                	mov    %eax,%ecx
 460:	39 d6                	cmp    %edx,%esi
 462:	76 e2                	jbe    446 <printint+0x26>
  if(neg)
 464:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 468:	74 24                	je     48e <printint+0x6e>
    buf[i++] = '-';
 46a:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 46f:	8d 5f 02             	lea    0x2(%edi),%ebx
 472:	eb 1a                	jmp    48e <printint+0x6e>
    x = -xx;
 474:	89 d1                	mov    %edx,%ecx
 476:	f7 d9                	neg    %ecx
    neg = 1;
 478:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 47f:	eb c0                	jmp    441 <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 481:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 486:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 489:	e8 78 ff ff ff       	call   406 <putc>
  while(--i >= 0)
 48e:	4b                   	dec    %ebx
 48f:	79 f0                	jns    481 <printint+0x61>
}
 491:	83 c4 2c             	add    $0x2c,%esp
 494:	5b                   	pop    %ebx
 495:	5e                   	pop    %esi
 496:	5f                   	pop    %edi
 497:	5d                   	pop    %ebp
 498:	c3                   	ret    

00000499 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 499:	55                   	push   %ebp
 49a:	89 e5                	mov    %esp,%ebp
 49c:	57                   	push   %edi
 49d:	56                   	push   %esi
 49e:	53                   	push   %ebx
 49f:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 4a2:	8d 45 10             	lea    0x10(%ebp),%eax
 4a5:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 4a8:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 4ad:	bb 00 00 00 00       	mov    $0x0,%ebx
 4b2:	eb 12                	jmp    4c6 <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 4b4:	89 fa                	mov    %edi,%edx
 4b6:	8b 45 08             	mov    0x8(%ebp),%eax
 4b9:	e8 48 ff ff ff       	call   406 <putc>
 4be:	eb 05                	jmp    4c5 <printf+0x2c>
      }
    } else if(state == '%'){
 4c0:	83 fe 25             	cmp    $0x25,%esi
 4c3:	74 22                	je     4e7 <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 4c5:	43                   	inc    %ebx
 4c6:	8b 45 0c             	mov    0xc(%ebp),%eax
 4c9:	8a 04 18             	mov    (%eax,%ebx,1),%al
 4cc:	84 c0                	test   %al,%al
 4ce:	0f 84 1d 01 00 00    	je     5f1 <printf+0x158>
    c = fmt[i] & 0xff;
 4d4:	0f be f8             	movsbl %al,%edi
 4d7:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 4da:	85 f6                	test   %esi,%esi
 4dc:	75 e2                	jne    4c0 <printf+0x27>
      if(c == '%'){
 4de:	83 f8 25             	cmp    $0x25,%eax
 4e1:	75 d1                	jne    4b4 <printf+0x1b>
        state = '%';
 4e3:	89 c6                	mov    %eax,%esi
 4e5:	eb de                	jmp    4c5 <printf+0x2c>
      if(c == 'd'){
 4e7:	83 f8 25             	cmp    $0x25,%eax
 4ea:	0f 84 cc 00 00 00    	je     5bc <printf+0x123>
 4f0:	0f 8c da 00 00 00    	jl     5d0 <printf+0x137>
 4f6:	83 f8 78             	cmp    $0x78,%eax
 4f9:	0f 8f d1 00 00 00    	jg     5d0 <printf+0x137>
 4ff:	83 f8 63             	cmp    $0x63,%eax
 502:	0f 8c c8 00 00 00    	jl     5d0 <printf+0x137>
 508:	83 e8 63             	sub    $0x63,%eax
 50b:	83 f8 15             	cmp    $0x15,%eax
 50e:	0f 87 bc 00 00 00    	ja     5d0 <printf+0x137>
 514:	ff 24 85 c8 08 00 00 	jmp    *0x8c8(,%eax,4)
        printint(fd, *ap, 10, 1);
 51b:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 51e:	8b 17                	mov    (%edi),%edx
 520:	83 ec 0c             	sub    $0xc,%esp
 523:	6a 01                	push   $0x1
 525:	b9 0a 00 00 00       	mov    $0xa,%ecx
 52a:	8b 45 08             	mov    0x8(%ebp),%eax
 52d:	e8 ee fe ff ff       	call   420 <printint>
        ap++;
 532:	83 c7 04             	add    $0x4,%edi
 535:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 538:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 53b:	be 00 00 00 00       	mov    $0x0,%esi
 540:	eb 83                	jmp    4c5 <printf+0x2c>
        printint(fd, *ap, 16, 0);
 542:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 545:	8b 17                	mov    (%edi),%edx
 547:	83 ec 0c             	sub    $0xc,%esp
 54a:	6a 00                	push   $0x0
 54c:	b9 10 00 00 00       	mov    $0x10,%ecx
 551:	8b 45 08             	mov    0x8(%ebp),%eax
 554:	e8 c7 fe ff ff       	call   420 <printint>
        ap++;
 559:	83 c7 04             	add    $0x4,%edi
 55c:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 55f:	83 c4 10             	add    $0x10,%esp
      state = 0;
 562:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 567:	e9 59 ff ff ff       	jmp    4c5 <printf+0x2c>
        s = (char*)*ap;
 56c:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 56f:	8b 30                	mov    (%eax),%esi
        ap++;
 571:	83 c0 04             	add    $0x4,%eax
 574:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 577:	85 f6                	test   %esi,%esi
 579:	75 13                	jne    58e <printf+0xf5>
          s = "(null)";
 57b:	be bf 08 00 00       	mov    $0x8bf,%esi
 580:	eb 0c                	jmp    58e <printf+0xf5>
          putc(fd, *s);
 582:	0f be d2             	movsbl %dl,%edx
 585:	8b 45 08             	mov    0x8(%ebp),%eax
 588:	e8 79 fe ff ff       	call   406 <putc>
          s++;
 58d:	46                   	inc    %esi
        while(*s != 0){
 58e:	8a 16                	mov    (%esi),%dl
 590:	84 d2                	test   %dl,%dl
 592:	75 ee                	jne    582 <printf+0xe9>
      state = 0;
 594:	be 00 00 00 00       	mov    $0x0,%esi
 599:	e9 27 ff ff ff       	jmp    4c5 <printf+0x2c>
        putc(fd, *ap);
 59e:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 5a1:	0f be 17             	movsbl (%edi),%edx
 5a4:	8b 45 08             	mov    0x8(%ebp),%eax
 5a7:	e8 5a fe ff ff       	call   406 <putc>
        ap++;
 5ac:	83 c7 04             	add    $0x4,%edi
 5af:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 5b2:	be 00 00 00 00       	mov    $0x0,%esi
 5b7:	e9 09 ff ff ff       	jmp    4c5 <printf+0x2c>
        putc(fd, c);
 5bc:	89 fa                	mov    %edi,%edx
 5be:	8b 45 08             	mov    0x8(%ebp),%eax
 5c1:	e8 40 fe ff ff       	call   406 <putc>
      state = 0;
 5c6:	be 00 00 00 00       	mov    $0x0,%esi
 5cb:	e9 f5 fe ff ff       	jmp    4c5 <printf+0x2c>
        putc(fd, '%');
 5d0:	ba 25 00 00 00       	mov    $0x25,%edx
 5d5:	8b 45 08             	mov    0x8(%ebp),%eax
 5d8:	e8 29 fe ff ff       	call   406 <putc>
        putc(fd, c);
 5dd:	89 fa                	mov    %edi,%edx
 5df:	8b 45 08             	mov    0x8(%ebp),%eax
 5e2:	e8 1f fe ff ff       	call   406 <putc>
      state = 0;
 5e7:	be 00 00 00 00       	mov    $0x0,%esi
 5ec:	e9 d4 fe ff ff       	jmp    4c5 <printf+0x2c>
    }
  }
}
 5f1:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5f4:	5b                   	pop    %ebx
 5f5:	5e                   	pop    %esi
 5f6:	5f                   	pop    %edi
 5f7:	5d                   	pop    %ebp
 5f8:	c3                   	ret    
