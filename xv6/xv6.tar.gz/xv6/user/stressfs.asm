
stressfs:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <main>:
#include "fs.h"
#include "fcntl.h"

int
main(int argc, char *argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	81 ec 20 02 00 00    	sub    $0x220,%esp
  int fd, i;
  char path[] = "stressfs0";
  17:	8d 7d de             	lea    -0x22(%ebp),%edi
  1a:	be 5b 05 00 00       	mov    $0x55b,%esi
  1f:	b9 0a 00 00 00       	mov    $0xa,%ecx
  24:	f3 a4                	rep movsb %ds:(%esi),%es:(%edi)
  char data[512];

  printf(1, "stressfs starting\n");
  26:	68 38 05 00 00       	push   $0x538
  2b:	6a 01                	push   $0x1
  2d:	e8 a5 03 00 00       	call   3d7 <printf>
  memset(data, 'a', sizeof(data));
  32:	83 c4 0c             	add    $0xc,%esp
  35:	68 00 02 00 00       	push   $0x200
  3a:	6a 61                	push   $0x61
  3c:	8d 85 de fd ff ff    	lea    -0x222(%ebp),%eax
  42:	50                   	push   %eax
  43:	e8 21 01 00 00       	call   169 <memset>

  for(i = 0; i < 4; i++)
  48:	83 c4 10             	add    $0x10,%esp
  4b:	bb 00 00 00 00       	mov    $0x0,%ebx
  50:	83 fb 03             	cmp    $0x3,%ebx
  53:	7f 0c                	jg     61 <main+0x61>
    if(fork() > 0)
  55:	e8 32 02 00 00       	call   28c <fork>
  5a:	85 c0                	test   %eax,%eax
  5c:	7f 03                	jg     61 <main+0x61>
  for(i = 0; i < 4; i++)
  5e:	43                   	inc    %ebx
  5f:	eb ef                	jmp    50 <main+0x50>
      break;

  printf(1, "write %d\n", i);
  61:	83 ec 04             	sub    $0x4,%esp
  64:	53                   	push   %ebx
  65:	68 4b 05 00 00       	push   $0x54b
  6a:	6a 01                	push   $0x1
  6c:	e8 66 03 00 00       	call   3d7 <printf>

  path[8] += i;
  71:	00 5d e6             	add    %bl,-0x1a(%ebp)
  fd = open(path, O_CREATE | O_RDWR);
  74:	83 c4 08             	add    $0x8,%esp
  77:	68 02 02 00 00       	push   $0x202
  7c:	8d 45 de             	lea    -0x22(%ebp),%eax
  7f:	50                   	push   %eax
  80:	e8 4f 02 00 00       	call   2d4 <open>
  85:	89 c6                	mov    %eax,%esi
  for(i = 0; i < 20; i++)
  87:	83 c4 10             	add    $0x10,%esp
  8a:	bb 00 00 00 00       	mov    $0x0,%ebx
  8f:	eb 19                	jmp    aa <main+0xaa>
//    printf(fd, "%d\n", i);
    write(fd, data, sizeof(data));
  91:	83 ec 04             	sub    $0x4,%esp
  94:	68 00 02 00 00       	push   $0x200
  99:	8d 85 de fd ff ff    	lea    -0x222(%ebp),%eax
  9f:	50                   	push   %eax
  a0:	56                   	push   %esi
  a1:	e8 0e 02 00 00       	call   2b4 <write>
  for(i = 0; i < 20; i++)
  a6:	43                   	inc    %ebx
  a7:	83 c4 10             	add    $0x10,%esp
  aa:	83 fb 13             	cmp    $0x13,%ebx
  ad:	7e e2                	jle    91 <main+0x91>
  close(fd);
  af:	83 ec 0c             	sub    $0xc,%esp
  b2:	56                   	push   %esi
  b3:	e8 04 02 00 00       	call   2bc <close>

  printf(1, "read\n");
  b8:	83 c4 08             	add    $0x8,%esp
  bb:	68 55 05 00 00       	push   $0x555
  c0:	6a 01                	push   $0x1
  c2:	e8 10 03 00 00       	call   3d7 <printf>

  fd = open(path, O_RDONLY);
  c7:	83 c4 08             	add    $0x8,%esp
  ca:	6a 00                	push   $0x0
  cc:	8d 45 de             	lea    -0x22(%ebp),%eax
  cf:	50                   	push   %eax
  d0:	e8 ff 01 00 00       	call   2d4 <open>
  d5:	89 c6                	mov    %eax,%esi
  for (i = 0; i < 20; i++)
  d7:	83 c4 10             	add    $0x10,%esp
  da:	bb 00 00 00 00       	mov    $0x0,%ebx
  df:	eb 19                	jmp    fa <main+0xfa>
    read(fd, data, sizeof(data));
  e1:	83 ec 04             	sub    $0x4,%esp
  e4:	68 00 02 00 00       	push   $0x200
  e9:	8d 85 de fd ff ff    	lea    -0x222(%ebp),%eax
  ef:	50                   	push   %eax
  f0:	56                   	push   %esi
  f1:	e8 b6 01 00 00       	call   2ac <read>
  for (i = 0; i < 20; i++)
  f6:	43                   	inc    %ebx
  f7:	83 c4 10             	add    $0x10,%esp
  fa:	83 fb 13             	cmp    $0x13,%ebx
  fd:	7e e2                	jle    e1 <main+0xe1>
  close(fd);
  ff:	83 ec 0c             	sub    $0xc,%esp
 102:	56                   	push   %esi
 103:	e8 b4 01 00 00       	call   2bc <close>

  wait();
 108:	e8 8f 01 00 00       	call   29c <wait>

  exit();
 10d:	e8 82 01 00 00       	call   294 <exit>

00000112 <start>:

// Entry point of the library	
void
start()
{
}
 112:	c3                   	ret    

00000113 <strcpy>:

char*
strcpy(char *s, const char *t)
{
 113:	55                   	push   %ebp
 114:	89 e5                	mov    %esp,%ebp
 116:	56                   	push   %esi
 117:	53                   	push   %ebx
 118:	8b 45 08             	mov    0x8(%ebp),%eax
 11b:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 11e:	89 c2                	mov    %eax,%edx
 120:	89 cb                	mov    %ecx,%ebx
 122:	41                   	inc    %ecx
 123:	89 d6                	mov    %edx,%esi
 125:	42                   	inc    %edx
 126:	8a 1b                	mov    (%ebx),%bl
 128:	88 1e                	mov    %bl,(%esi)
 12a:	84 db                	test   %bl,%bl
 12c:	75 f2                	jne    120 <strcpy+0xd>
    ;
  return os;
}
 12e:	5b                   	pop    %ebx
 12f:	5e                   	pop    %esi
 130:	5d                   	pop    %ebp
 131:	c3                   	ret    

00000132 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 132:	55                   	push   %ebp
 133:	89 e5                	mov    %esp,%ebp
 135:	8b 4d 08             	mov    0x8(%ebp),%ecx
 138:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
 13b:	eb 02                	jmp    13f <strcmp+0xd>
    p++, q++;
 13d:	41                   	inc    %ecx
 13e:	42                   	inc    %edx
  while(*p && *p == *q)
 13f:	8a 01                	mov    (%ecx),%al
 141:	84 c0                	test   %al,%al
 143:	74 04                	je     149 <strcmp+0x17>
 145:	3a 02                	cmp    (%edx),%al
 147:	74 f4                	je     13d <strcmp+0xb>
  return (uchar)*p - (uchar)*q;
 149:	0f b6 c0             	movzbl %al,%eax
 14c:	0f b6 12             	movzbl (%edx),%edx
 14f:	29 d0                	sub    %edx,%eax
}
 151:	5d                   	pop    %ebp
 152:	c3                   	ret    

00000153 <strlen>:

uint
strlen(const char *s)
{
 153:	55                   	push   %ebp
 154:	89 e5                	mov    %esp,%ebp
 156:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
 159:	b8 00 00 00 00       	mov    $0x0,%eax
 15e:	eb 01                	jmp    161 <strlen+0xe>
 160:	40                   	inc    %eax
 161:	80 3c 01 00          	cmpb   $0x0,(%ecx,%eax,1)
 165:	75 f9                	jne    160 <strlen+0xd>
    ;
  return n;
}
 167:	5d                   	pop    %ebp
 168:	c3                   	ret    

00000169 <memset>:

void*
memset(void *dst, int c, uint n)
{
 169:	55                   	push   %ebp
 16a:	89 e5                	mov    %esp,%ebp
 16c:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 16d:	8b 7d 08             	mov    0x8(%ebp),%edi
 170:	8b 4d 10             	mov    0x10(%ebp),%ecx
 173:	8b 45 0c             	mov    0xc(%ebp),%eax
 176:	fc                   	cld    
 177:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 179:	8b 45 08             	mov    0x8(%ebp),%eax
 17c:	8b 7d fc             	mov    -0x4(%ebp),%edi
 17f:	c9                   	leave  
 180:	c3                   	ret    

00000181 <strchr>:

char*
strchr(const char *s, char c)
{
 181:	55                   	push   %ebp
 182:	89 e5                	mov    %esp,%ebp
 184:	8b 45 08             	mov    0x8(%ebp),%eax
 187:	8a 4d 0c             	mov    0xc(%ebp),%cl
  for(; *s; s++)
 18a:	eb 01                	jmp    18d <strchr+0xc>
 18c:	40                   	inc    %eax
 18d:	8a 10                	mov    (%eax),%dl
 18f:	84 d2                	test   %dl,%dl
 191:	74 06                	je     199 <strchr+0x18>
    if(*s == c)
 193:	38 ca                	cmp    %cl,%dl
 195:	75 f5                	jne    18c <strchr+0xb>
 197:	eb 05                	jmp    19e <strchr+0x1d>
      return (char*)s;
  return 0;
 199:	b8 00 00 00 00       	mov    $0x0,%eax
}
 19e:	5d                   	pop    %ebp
 19f:	c3                   	ret    

000001a0 <gets>:

char*
gets(char *buf, int max)
{
 1a0:	55                   	push   %ebp
 1a1:	89 e5                	mov    %esp,%ebp
 1a3:	57                   	push   %edi
 1a4:	56                   	push   %esi
 1a5:	53                   	push   %ebx
 1a6:	83 ec 1c             	sub    $0x1c,%esp
 1a9:	8b 7d 08             	mov    0x8(%ebp),%edi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1ac:	bb 00 00 00 00       	mov    $0x0,%ebx
 1b1:	89 de                	mov    %ebx,%esi
 1b3:	43                   	inc    %ebx
 1b4:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 1b7:	7d 2b                	jge    1e4 <gets+0x44>
    cc = read(0, &c, 1);
 1b9:	83 ec 04             	sub    $0x4,%esp
 1bc:	6a 01                	push   $0x1
 1be:	8d 45 e7             	lea    -0x19(%ebp),%eax
 1c1:	50                   	push   %eax
 1c2:	6a 00                	push   $0x0
 1c4:	e8 e3 00 00 00       	call   2ac <read>
    if(cc < 1)
 1c9:	83 c4 10             	add    $0x10,%esp
 1cc:	85 c0                	test   %eax,%eax
 1ce:	7e 14                	jle    1e4 <gets+0x44>
      break;
    buf[i++] = c;
 1d0:	8a 45 e7             	mov    -0x19(%ebp),%al
 1d3:	88 04 37             	mov    %al,(%edi,%esi,1)
    if(c == '\n' || c == '\r')
 1d6:	3c 0a                	cmp    $0xa,%al
 1d8:	74 08                	je     1e2 <gets+0x42>
 1da:	3c 0d                	cmp    $0xd,%al
 1dc:	75 d3                	jne    1b1 <gets+0x11>
    buf[i++] = c;
 1de:	89 de                	mov    %ebx,%esi
 1e0:	eb 02                	jmp    1e4 <gets+0x44>
 1e2:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 1e4:	c6 04 37 00          	movb   $0x0,(%edi,%esi,1)
  return buf;
}
 1e8:	89 f8                	mov    %edi,%eax
 1ea:	8d 65 f4             	lea    -0xc(%ebp),%esp
 1ed:	5b                   	pop    %ebx
 1ee:	5e                   	pop    %esi
 1ef:	5f                   	pop    %edi
 1f0:	5d                   	pop    %ebp
 1f1:	c3                   	ret    

000001f2 <stat>:

int
stat(const char *n, struct stat *st)
{
 1f2:	55                   	push   %ebp
 1f3:	89 e5                	mov    %esp,%ebp
 1f5:	56                   	push   %esi
 1f6:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 1f7:	83 ec 08             	sub    $0x8,%esp
 1fa:	6a 00                	push   $0x0
 1fc:	ff 75 08             	push   0x8(%ebp)
 1ff:	e8 d0 00 00 00       	call   2d4 <open>
  if(fd < 0)
 204:	83 c4 10             	add    $0x10,%esp
 207:	85 c0                	test   %eax,%eax
 209:	78 24                	js     22f <stat+0x3d>
 20b:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 20d:	83 ec 08             	sub    $0x8,%esp
 210:	ff 75 0c             	push   0xc(%ebp)
 213:	50                   	push   %eax
 214:	e8 d3 00 00 00       	call   2ec <fstat>
 219:	89 c6                	mov    %eax,%esi
  close(fd);
 21b:	89 1c 24             	mov    %ebx,(%esp)
 21e:	e8 99 00 00 00       	call   2bc <close>
  return r;
 223:	83 c4 10             	add    $0x10,%esp
}
 226:	89 f0                	mov    %esi,%eax
 228:	8d 65 f8             	lea    -0x8(%ebp),%esp
 22b:	5b                   	pop    %ebx
 22c:	5e                   	pop    %esi
 22d:	5d                   	pop    %ebp
 22e:	c3                   	ret    
    return -1;
 22f:	be ff ff ff ff       	mov    $0xffffffff,%esi
 234:	eb f0                	jmp    226 <stat+0x34>

00000236 <atoi>:

int
atoi(const char *s)
{
 236:	55                   	push   %ebp
 237:	89 e5                	mov    %esp,%ebp
 239:	53                   	push   %ebx
 23a:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
 23d:	ba 00 00 00 00       	mov    $0x0,%edx
  while('0' <= *s && *s <= '9')
 242:	eb 0e                	jmp    252 <atoi+0x1c>
    n = n*10 + *s++ - '0';
 244:	8d 14 92             	lea    (%edx,%edx,4),%edx
 247:	8d 1c 12             	lea    (%edx,%edx,1),%ebx
 24a:	41                   	inc    %ecx
 24b:	0f be c0             	movsbl %al,%eax
 24e:	8d 54 18 d0          	lea    -0x30(%eax,%ebx,1),%edx
  while('0' <= *s && *s <= '9')
 252:	8a 01                	mov    (%ecx),%al
 254:	8d 58 d0             	lea    -0x30(%eax),%ebx
 257:	80 fb 09             	cmp    $0x9,%bl
 25a:	76 e8                	jbe    244 <atoi+0xe>
  return n;
}
 25c:	89 d0                	mov    %edx,%eax
 25e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 261:	c9                   	leave  
 262:	c3                   	ret    

00000263 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 263:	55                   	push   %ebp
 264:	89 e5                	mov    %esp,%ebp
 266:	56                   	push   %esi
 267:	53                   	push   %ebx
 268:	8b 45 08             	mov    0x8(%ebp),%eax
 26b:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 26e:	8b 55 10             	mov    0x10(%ebp),%edx
  char *dst;
  const char *src;

  dst = vdst;
 271:	89 c1                	mov    %eax,%ecx
  src = vsrc;
  while(n-- > 0)
 273:	eb 0c                	jmp    281 <memmove+0x1e>
    *dst++ = *src++;
 275:	8a 13                	mov    (%ebx),%dl
 277:	88 11                	mov    %dl,(%ecx)
 279:	8d 5b 01             	lea    0x1(%ebx),%ebx
 27c:	8d 49 01             	lea    0x1(%ecx),%ecx
  while(n-- > 0)
 27f:	89 f2                	mov    %esi,%edx
 281:	8d 72 ff             	lea    -0x1(%edx),%esi
 284:	85 d2                	test   %edx,%edx
 286:	7f ed                	jg     275 <memmove+0x12>
  return vdst;
}
 288:	5b                   	pop    %ebx
 289:	5e                   	pop    %esi
 28a:	5d                   	pop    %ebp
 28b:	c3                   	ret    

0000028c <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 28c:	b8 01 00 00 00       	mov    $0x1,%eax
 291:	cd 40                	int    $0x40
 293:	c3                   	ret    

00000294 <exit>:
SYSCALL(exit)
 294:	b8 02 00 00 00       	mov    $0x2,%eax
 299:	cd 40                	int    $0x40
 29b:	c3                   	ret    

0000029c <wait>:
SYSCALL(wait)
 29c:	b8 03 00 00 00       	mov    $0x3,%eax
 2a1:	cd 40                	int    $0x40
 2a3:	c3                   	ret    

000002a4 <pipe>:
SYSCALL(pipe)
 2a4:	b8 04 00 00 00       	mov    $0x4,%eax
 2a9:	cd 40                	int    $0x40
 2ab:	c3                   	ret    

000002ac <read>:
SYSCALL(read)
 2ac:	b8 05 00 00 00       	mov    $0x5,%eax
 2b1:	cd 40                	int    $0x40
 2b3:	c3                   	ret    

000002b4 <write>:
SYSCALL(write)
 2b4:	b8 10 00 00 00       	mov    $0x10,%eax
 2b9:	cd 40                	int    $0x40
 2bb:	c3                   	ret    

000002bc <close>:
SYSCALL(close)
 2bc:	b8 15 00 00 00       	mov    $0x15,%eax
 2c1:	cd 40                	int    $0x40
 2c3:	c3                   	ret    

000002c4 <kill>:
SYSCALL(kill)
 2c4:	b8 06 00 00 00       	mov    $0x6,%eax
 2c9:	cd 40                	int    $0x40
 2cb:	c3                   	ret    

000002cc <exec>:
SYSCALL(exec)
 2cc:	b8 07 00 00 00       	mov    $0x7,%eax
 2d1:	cd 40                	int    $0x40
 2d3:	c3                   	ret    

000002d4 <open>:
SYSCALL(open)
 2d4:	b8 0f 00 00 00       	mov    $0xf,%eax
 2d9:	cd 40                	int    $0x40
 2db:	c3                   	ret    

000002dc <mknod>:
SYSCALL(mknod)
 2dc:	b8 11 00 00 00       	mov    $0x11,%eax
 2e1:	cd 40                	int    $0x40
 2e3:	c3                   	ret    

000002e4 <unlink>:
SYSCALL(unlink)
 2e4:	b8 12 00 00 00       	mov    $0x12,%eax
 2e9:	cd 40                	int    $0x40
 2eb:	c3                   	ret    

000002ec <fstat>:
SYSCALL(fstat)
 2ec:	b8 08 00 00 00       	mov    $0x8,%eax
 2f1:	cd 40                	int    $0x40
 2f3:	c3                   	ret    

000002f4 <link>:
SYSCALL(link)
 2f4:	b8 13 00 00 00       	mov    $0x13,%eax
 2f9:	cd 40                	int    $0x40
 2fb:	c3                   	ret    

000002fc <mkdir>:
SYSCALL(mkdir)
 2fc:	b8 14 00 00 00       	mov    $0x14,%eax
 301:	cd 40                	int    $0x40
 303:	c3                   	ret    

00000304 <chdir>:
SYSCALL(chdir)
 304:	b8 09 00 00 00       	mov    $0x9,%eax
 309:	cd 40                	int    $0x40
 30b:	c3                   	ret    

0000030c <dup>:
SYSCALL(dup)
 30c:	b8 0a 00 00 00       	mov    $0xa,%eax
 311:	cd 40                	int    $0x40
 313:	c3                   	ret    

00000314 <getpid>:
SYSCALL(getpid)
 314:	b8 0b 00 00 00       	mov    $0xb,%eax
 319:	cd 40                	int    $0x40
 31b:	c3                   	ret    

0000031c <sbrk>:
SYSCALL(sbrk)
 31c:	b8 0c 00 00 00       	mov    $0xc,%eax
 321:	cd 40                	int    $0x40
 323:	c3                   	ret    

00000324 <sleep>:
SYSCALL(sleep)
 324:	b8 0d 00 00 00       	mov    $0xd,%eax
 329:	cd 40                	int    $0x40
 32b:	c3                   	ret    

0000032c <uptime>:
SYSCALL(uptime)
 32c:	b8 0e 00 00 00       	mov    $0xe,%eax
 331:	cd 40                	int    $0x40
 333:	c3                   	ret    

00000334 <date>:
SYSCALL(date)
 334:	b8 16 00 00 00       	mov    $0x16,%eax
 339:	cd 40                	int    $0x40
 33b:	c3                   	ret    

0000033c <dup2>:
SYSCALL(dup2)
 33c:	b8 17 00 00 00       	mov    $0x17,%eax
 341:	cd 40                	int    $0x40
 343:	c3                   	ret    

00000344 <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 344:	55                   	push   %ebp
 345:	89 e5                	mov    %esp,%ebp
 347:	83 ec 1c             	sub    $0x1c,%esp
 34a:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 34d:	6a 01                	push   $0x1
 34f:	8d 55 f4             	lea    -0xc(%ebp),%edx
 352:	52                   	push   %edx
 353:	50                   	push   %eax
 354:	e8 5b ff ff ff       	call   2b4 <write>
}
 359:	83 c4 10             	add    $0x10,%esp
 35c:	c9                   	leave  
 35d:	c3                   	ret    

0000035e <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 35e:	55                   	push   %ebp
 35f:	89 e5                	mov    %esp,%ebp
 361:	57                   	push   %edi
 362:	56                   	push   %esi
 363:	53                   	push   %ebx
 364:	83 ec 2c             	sub    $0x2c,%esp
 367:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 36a:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 36c:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 370:	74 04                	je     376 <printint+0x18>
 372:	85 d2                	test   %edx,%edx
 374:	78 3c                	js     3b2 <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 376:	89 d1                	mov    %edx,%ecx
  neg = 0;
 378:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 37f:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 384:	89 c8                	mov    %ecx,%eax
 386:	ba 00 00 00 00       	mov    $0x0,%edx
 38b:	f7 f6                	div    %esi
 38d:	89 df                	mov    %ebx,%edi
 38f:	43                   	inc    %ebx
 390:	8a 92 c4 05 00 00    	mov    0x5c4(%edx),%dl
 396:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 39a:	89 ca                	mov    %ecx,%edx
 39c:	89 c1                	mov    %eax,%ecx
 39e:	39 d6                	cmp    %edx,%esi
 3a0:	76 e2                	jbe    384 <printint+0x26>
  if(neg)
 3a2:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 3a6:	74 24                	je     3cc <printint+0x6e>
    buf[i++] = '-';
 3a8:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 3ad:	8d 5f 02             	lea    0x2(%edi),%ebx
 3b0:	eb 1a                	jmp    3cc <printint+0x6e>
    x = -xx;
 3b2:	89 d1                	mov    %edx,%ecx
 3b4:	f7 d9                	neg    %ecx
    neg = 1;
 3b6:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 3bd:	eb c0                	jmp    37f <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 3bf:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 3c4:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 3c7:	e8 78 ff ff ff       	call   344 <putc>
  while(--i >= 0)
 3cc:	4b                   	dec    %ebx
 3cd:	79 f0                	jns    3bf <printint+0x61>
}
 3cf:	83 c4 2c             	add    $0x2c,%esp
 3d2:	5b                   	pop    %ebx
 3d3:	5e                   	pop    %esi
 3d4:	5f                   	pop    %edi
 3d5:	5d                   	pop    %ebp
 3d6:	c3                   	ret    

000003d7 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 3d7:	55                   	push   %ebp
 3d8:	89 e5                	mov    %esp,%ebp
 3da:	57                   	push   %edi
 3db:	56                   	push   %esi
 3dc:	53                   	push   %ebx
 3dd:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 3e0:	8d 45 10             	lea    0x10(%ebp),%eax
 3e3:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 3e6:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 3eb:	bb 00 00 00 00       	mov    $0x0,%ebx
 3f0:	eb 12                	jmp    404 <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 3f2:	89 fa                	mov    %edi,%edx
 3f4:	8b 45 08             	mov    0x8(%ebp),%eax
 3f7:	e8 48 ff ff ff       	call   344 <putc>
 3fc:	eb 05                	jmp    403 <printf+0x2c>
      }
    } else if(state == '%'){
 3fe:	83 fe 25             	cmp    $0x25,%esi
 401:	74 22                	je     425 <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 403:	43                   	inc    %ebx
 404:	8b 45 0c             	mov    0xc(%ebp),%eax
 407:	8a 04 18             	mov    (%eax,%ebx,1),%al
 40a:	84 c0                	test   %al,%al
 40c:	0f 84 1d 01 00 00    	je     52f <printf+0x158>
    c = fmt[i] & 0xff;
 412:	0f be f8             	movsbl %al,%edi
 415:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 418:	85 f6                	test   %esi,%esi
 41a:	75 e2                	jne    3fe <printf+0x27>
      if(c == '%'){
 41c:	83 f8 25             	cmp    $0x25,%eax
 41f:	75 d1                	jne    3f2 <printf+0x1b>
        state = '%';
 421:	89 c6                	mov    %eax,%esi
 423:	eb de                	jmp    403 <printf+0x2c>
      if(c == 'd'){
 425:	83 f8 25             	cmp    $0x25,%eax
 428:	0f 84 cc 00 00 00    	je     4fa <printf+0x123>
 42e:	0f 8c da 00 00 00    	jl     50e <printf+0x137>
 434:	83 f8 78             	cmp    $0x78,%eax
 437:	0f 8f d1 00 00 00    	jg     50e <printf+0x137>
 43d:	83 f8 63             	cmp    $0x63,%eax
 440:	0f 8c c8 00 00 00    	jl     50e <printf+0x137>
 446:	83 e8 63             	sub    $0x63,%eax
 449:	83 f8 15             	cmp    $0x15,%eax
 44c:	0f 87 bc 00 00 00    	ja     50e <printf+0x137>
 452:	ff 24 85 6c 05 00 00 	jmp    *0x56c(,%eax,4)
        printint(fd, *ap, 10, 1);
 459:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 45c:	8b 17                	mov    (%edi),%edx
 45e:	83 ec 0c             	sub    $0xc,%esp
 461:	6a 01                	push   $0x1
 463:	b9 0a 00 00 00       	mov    $0xa,%ecx
 468:	8b 45 08             	mov    0x8(%ebp),%eax
 46b:	e8 ee fe ff ff       	call   35e <printint>
        ap++;
 470:	83 c7 04             	add    $0x4,%edi
 473:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 476:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 479:	be 00 00 00 00       	mov    $0x0,%esi
 47e:	eb 83                	jmp    403 <printf+0x2c>
        printint(fd, *ap, 16, 0);
 480:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 483:	8b 17                	mov    (%edi),%edx
 485:	83 ec 0c             	sub    $0xc,%esp
 488:	6a 00                	push   $0x0
 48a:	b9 10 00 00 00       	mov    $0x10,%ecx
 48f:	8b 45 08             	mov    0x8(%ebp),%eax
 492:	e8 c7 fe ff ff       	call   35e <printint>
        ap++;
 497:	83 c7 04             	add    $0x4,%edi
 49a:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 49d:	83 c4 10             	add    $0x10,%esp
      state = 0;
 4a0:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 4a5:	e9 59 ff ff ff       	jmp    403 <printf+0x2c>
        s = (char*)*ap;
 4aa:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 4ad:	8b 30                	mov    (%eax),%esi
        ap++;
 4af:	83 c0 04             	add    $0x4,%eax
 4b2:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 4b5:	85 f6                	test   %esi,%esi
 4b7:	75 13                	jne    4cc <printf+0xf5>
          s = "(null)";
 4b9:	be 65 05 00 00       	mov    $0x565,%esi
 4be:	eb 0c                	jmp    4cc <printf+0xf5>
          putc(fd, *s);
 4c0:	0f be d2             	movsbl %dl,%edx
 4c3:	8b 45 08             	mov    0x8(%ebp),%eax
 4c6:	e8 79 fe ff ff       	call   344 <putc>
          s++;
 4cb:	46                   	inc    %esi
        while(*s != 0){
 4cc:	8a 16                	mov    (%esi),%dl
 4ce:	84 d2                	test   %dl,%dl
 4d0:	75 ee                	jne    4c0 <printf+0xe9>
      state = 0;
 4d2:	be 00 00 00 00       	mov    $0x0,%esi
 4d7:	e9 27 ff ff ff       	jmp    403 <printf+0x2c>
        putc(fd, *ap);
 4dc:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 4df:	0f be 17             	movsbl (%edi),%edx
 4e2:	8b 45 08             	mov    0x8(%ebp),%eax
 4e5:	e8 5a fe ff ff       	call   344 <putc>
        ap++;
 4ea:	83 c7 04             	add    $0x4,%edi
 4ed:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 4f0:	be 00 00 00 00       	mov    $0x0,%esi
 4f5:	e9 09 ff ff ff       	jmp    403 <printf+0x2c>
        putc(fd, c);
 4fa:	89 fa                	mov    %edi,%edx
 4fc:	8b 45 08             	mov    0x8(%ebp),%eax
 4ff:	e8 40 fe ff ff       	call   344 <putc>
      state = 0;
 504:	be 00 00 00 00       	mov    $0x0,%esi
 509:	e9 f5 fe ff ff       	jmp    403 <printf+0x2c>
        putc(fd, '%');
 50e:	ba 25 00 00 00       	mov    $0x25,%edx
 513:	8b 45 08             	mov    0x8(%ebp),%eax
 516:	e8 29 fe ff ff       	call   344 <putc>
        putc(fd, c);
 51b:	89 fa                	mov    %edi,%edx
 51d:	8b 45 08             	mov    0x8(%ebp),%eax
 520:	e8 1f fe ff ff       	call   344 <putc>
      state = 0;
 525:	be 00 00 00 00       	mov    $0x0,%esi
 52a:	e9 d4 fe ff ff       	jmp    403 <printf+0x2c>
    }
  }
}
 52f:	8d 65 f4             	lea    -0xc(%ebp),%esp
 532:	5b                   	pop    %ebx
 533:	5e                   	pop    %esi
 534:	5f                   	pop    %edi
 535:	5d                   	pop    %ebp
 536:	c3                   	ret    
