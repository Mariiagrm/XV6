
sh:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <getcmd>:
  exit();
}

int
getcmd(char *buf, int nbuf)
{
   0:	55                   	push   %ebp
   1:	89 e5                	mov    %esp,%ebp
   3:	56                   	push   %esi
   4:	53                   	push   %ebx
   5:	8b 5d 08             	mov    0x8(%ebp),%ebx
   8:	8b 75 0c             	mov    0xc(%ebp),%esi
  printf(2, "$ ");
   b:	83 ec 08             	sub    $0x8,%esp
   e:	68 0c 0f 00 00       	push   $0xf0c
  13:	6a 02                	push   $0x2
  15:	e8 4a 0c 00 00       	call   c64 <printf>
  memset(buf, 0, nbuf);
  1a:	83 c4 0c             	add    $0xc,%esp
  1d:	56                   	push   %esi
  1e:	6a 00                	push   $0x0
  20:	53                   	push   %ebx
  21:	e8 d0 09 00 00       	call   9f6 <memset>
  gets(buf, nbuf);
  26:	83 c4 08             	add    $0x8,%esp
  29:	56                   	push   %esi
  2a:	53                   	push   %ebx
  2b:	e8 fd 09 00 00       	call   a2d <gets>
  if(buf[0] == 0) // EOF
  30:	83 c4 10             	add    $0x10,%esp
  33:	80 3b 00             	cmpb   $0x0,(%ebx)
  36:	74 0c                	je     44 <getcmd+0x44>
    return -1;
  return 0;
  38:	b8 00 00 00 00       	mov    $0x0,%eax
}
  3d:	8d 65 f8             	lea    -0x8(%ebp),%esp
  40:	5b                   	pop    %ebx
  41:	5e                   	pop    %esi
  42:	5d                   	pop    %ebp
  43:	c3                   	ret    
    return -1;
  44:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  49:	eb f2                	jmp    3d <getcmd+0x3d>

0000004b <panic>:
  exit();
}

void
panic(char *s)
{
  4b:	55                   	push   %ebp
  4c:	89 e5                	mov    %esp,%ebp
  4e:	83 ec 0c             	sub    $0xc,%esp
  printf(2, "%s\n", s);
  51:	ff 75 08             	push   0x8(%ebp)
  54:	68 a9 0f 00 00       	push   $0xfa9
  59:	6a 02                	push   $0x2
  5b:	e8 04 0c 00 00       	call   c64 <printf>
  exit();
  60:	e8 bc 0a 00 00       	call   b21 <exit>

00000065 <fork1>:
}

int
fork1(void)
{
  65:	55                   	push   %ebp
  66:	89 e5                	mov    %esp,%ebp
  68:	83 ec 08             	sub    $0x8,%esp
  int pid;

  pid = fork();
  6b:	e8 a9 0a 00 00       	call   b19 <fork>
  if(pid == -1)
  70:	83 f8 ff             	cmp    $0xffffffff,%eax
  73:	74 02                	je     77 <fork1+0x12>
    panic("fork");
  return pid;
}
  75:	c9                   	leave  
  76:	c3                   	ret    
    panic("fork");
  77:	83 ec 0c             	sub    $0xc,%esp
  7a:	68 0f 0f 00 00       	push   $0xf0f
  7f:	e8 c7 ff ff ff       	call   4b <panic>

00000084 <runcmd>:
{
  84:	55                   	push   %ebp
  85:	89 e5                	mov    %esp,%ebp
  87:	53                   	push   %ebx
  88:	83 ec 14             	sub    $0x14,%esp
  8b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  if(cmd == 0)
  8e:	85 db                	test   %ebx,%ebx
  90:	74 0e                	je     a0 <runcmd+0x1c>
  switch(cmd->type){
  92:	8b 03                	mov    (%ebx),%eax
  94:	83 f8 05             	cmp    $0x5,%eax
  97:	77 0c                	ja     a5 <runcmd+0x21>
  99:	ff 24 85 c4 0f 00 00 	jmp    *0xfc4(,%eax,4)
    exit();
  a0:	e8 7c 0a 00 00       	call   b21 <exit>
    panic("runcmd");
  a5:	83 ec 0c             	sub    $0xc,%esp
  a8:	68 14 0f 00 00       	push   $0xf14
  ad:	e8 99 ff ff ff       	call   4b <panic>
    if(ecmd->argv[0] == 0)
  b2:	8b 43 04             	mov    0x4(%ebx),%eax
  b5:	85 c0                	test   %eax,%eax
  b7:	74 27                	je     e0 <runcmd+0x5c>
    exec(ecmd->argv[0], ecmd->argv);
  b9:	8d 53 04             	lea    0x4(%ebx),%edx
  bc:	83 ec 08             	sub    $0x8,%esp
  bf:	52                   	push   %edx
  c0:	50                   	push   %eax
  c1:	e8 93 0a 00 00       	call   b59 <exec>
    printf(2, "exec %s failed\n", ecmd->argv[0]);
  c6:	83 c4 0c             	add    $0xc,%esp
  c9:	ff 73 04             	push   0x4(%ebx)
  cc:	68 1b 0f 00 00       	push   $0xf1b
  d1:	6a 02                	push   $0x2
  d3:	e8 8c 0b 00 00       	call   c64 <printf>
    break;
  d8:	83 c4 10             	add    $0x10,%esp
  exit();
  db:	e8 41 0a 00 00       	call   b21 <exit>
      exit();
  e0:	e8 3c 0a 00 00       	call   b21 <exit>
    close(rcmd->fd);
  e5:	83 ec 0c             	sub    $0xc,%esp
  e8:	ff 73 14             	push   0x14(%ebx)
  eb:	e8 59 0a 00 00       	call   b49 <close>
    if(open(rcmd->file, rcmd->mode) < 0){
  f0:	83 c4 08             	add    $0x8,%esp
  f3:	ff 73 10             	push   0x10(%ebx)
  f6:	ff 73 08             	push   0x8(%ebx)
  f9:	e8 63 0a 00 00       	call   b61 <open>
  fe:	83 c4 10             	add    $0x10,%esp
 101:	85 c0                	test   %eax,%eax
 103:	78 0b                	js     110 <runcmd+0x8c>
    runcmd(rcmd->cmd);
 105:	83 ec 0c             	sub    $0xc,%esp
 108:	ff 73 04             	push   0x4(%ebx)
 10b:	e8 74 ff ff ff       	call   84 <runcmd>
      printf(2, "open %s failed\n", rcmd->file);
 110:	83 ec 04             	sub    $0x4,%esp
 113:	ff 73 08             	push   0x8(%ebx)
 116:	68 2b 0f 00 00       	push   $0xf2b
 11b:	6a 02                	push   $0x2
 11d:	e8 42 0b 00 00       	call   c64 <printf>
      exit();
 122:	e8 fa 09 00 00       	call   b21 <exit>
    if(fork1() == 0)
 127:	e8 39 ff ff ff       	call   65 <fork1>
 12c:	85 c0                	test   %eax,%eax
 12e:	74 10                	je     140 <runcmd+0xbc>
    wait();
 130:	e8 f4 09 00 00       	call   b29 <wait>
    runcmd(lcmd->right);
 135:	83 ec 0c             	sub    $0xc,%esp
 138:	ff 73 08             	push   0x8(%ebx)
 13b:	e8 44 ff ff ff       	call   84 <runcmd>
      runcmd(lcmd->left);
 140:	83 ec 0c             	sub    $0xc,%esp
 143:	ff 73 04             	push   0x4(%ebx)
 146:	e8 39 ff ff ff       	call   84 <runcmd>
    if(pipe(p) < 0)
 14b:	83 ec 0c             	sub    $0xc,%esp
 14e:	8d 45 f0             	lea    -0x10(%ebp),%eax
 151:	50                   	push   %eax
 152:	e8 da 09 00 00       	call   b31 <pipe>
 157:	83 c4 10             	add    $0x10,%esp
 15a:	85 c0                	test   %eax,%eax
 15c:	78 3a                	js     198 <runcmd+0x114>
    if(fork1() == 0){
 15e:	e8 02 ff ff ff       	call   65 <fork1>
 163:	85 c0                	test   %eax,%eax
 165:	74 3e                	je     1a5 <runcmd+0x121>
    if(fork1() == 0){
 167:	e8 f9 fe ff ff       	call   65 <fork1>
 16c:	85 c0                	test   %eax,%eax
 16e:	74 6b                	je     1db <runcmd+0x157>
    close(p[0]);
 170:	83 ec 0c             	sub    $0xc,%esp
 173:	ff 75 f0             	push   -0x10(%ebp)
 176:	e8 ce 09 00 00       	call   b49 <close>
    close(p[1]);
 17b:	83 c4 04             	add    $0x4,%esp
 17e:	ff 75 f4             	push   -0xc(%ebp)
 181:	e8 c3 09 00 00       	call   b49 <close>
    wait();
 186:	e8 9e 09 00 00       	call   b29 <wait>
    wait();
 18b:	e8 99 09 00 00       	call   b29 <wait>
    break;
 190:	83 c4 10             	add    $0x10,%esp
 193:	e9 43 ff ff ff       	jmp    db <runcmd+0x57>
      panic("pipe");
 198:	83 ec 0c             	sub    $0xc,%esp
 19b:	68 3b 0f 00 00       	push   $0xf3b
 1a0:	e8 a6 fe ff ff       	call   4b <panic>
      close(1);
 1a5:	83 ec 0c             	sub    $0xc,%esp
 1a8:	6a 01                	push   $0x1
 1aa:	e8 9a 09 00 00       	call   b49 <close>
      dup(p[1]);
 1af:	83 c4 04             	add    $0x4,%esp
 1b2:	ff 75 f4             	push   -0xc(%ebp)
 1b5:	e8 df 09 00 00       	call   b99 <dup>
      close(p[0]);
 1ba:	83 c4 04             	add    $0x4,%esp
 1bd:	ff 75 f0             	push   -0x10(%ebp)
 1c0:	e8 84 09 00 00       	call   b49 <close>
      close(p[1]);
 1c5:	83 c4 04             	add    $0x4,%esp
 1c8:	ff 75 f4             	push   -0xc(%ebp)
 1cb:	e8 79 09 00 00       	call   b49 <close>
      runcmd(pcmd->left);
 1d0:	83 c4 04             	add    $0x4,%esp
 1d3:	ff 73 04             	push   0x4(%ebx)
 1d6:	e8 a9 fe ff ff       	call   84 <runcmd>
      close(0);
 1db:	83 ec 0c             	sub    $0xc,%esp
 1de:	6a 00                	push   $0x0
 1e0:	e8 64 09 00 00       	call   b49 <close>
      dup(p[0]);
 1e5:	83 c4 04             	add    $0x4,%esp
 1e8:	ff 75 f0             	push   -0x10(%ebp)
 1eb:	e8 a9 09 00 00       	call   b99 <dup>
      close(p[0]);
 1f0:	83 c4 04             	add    $0x4,%esp
 1f3:	ff 75 f0             	push   -0x10(%ebp)
 1f6:	e8 4e 09 00 00       	call   b49 <close>
      close(p[1]);
 1fb:	83 c4 04             	add    $0x4,%esp
 1fe:	ff 75 f4             	push   -0xc(%ebp)
 201:	e8 43 09 00 00       	call   b49 <close>
      runcmd(pcmd->right);
 206:	83 c4 04             	add    $0x4,%esp
 209:	ff 73 08             	push   0x8(%ebx)
 20c:	e8 73 fe ff ff       	call   84 <runcmd>
    if(fork1() == 0)
 211:	e8 4f fe ff ff       	call   65 <fork1>
 216:	85 c0                	test   %eax,%eax
 218:	0f 85 bd fe ff ff    	jne    db <runcmd+0x57>
      runcmd(bcmd->cmd);
 21e:	83 ec 0c             	sub    $0xc,%esp
 221:	ff 73 04             	push   0x4(%ebx)
 224:	e8 5b fe ff ff       	call   84 <runcmd>

00000229 <execcmd>:
//PAGEBREAK!
// Constructors

struct cmd*
execcmd(void)
{
 229:	55                   	push   %ebp
 22a:	89 e5                	mov    %esp,%ebp
 22c:	53                   	push   %ebx
 22d:	83 ec 10             	sub    $0x10,%esp
  struct execcmd *cmd;

  cmd = malloc(sizeof(*cmd));
 230:	6a 54                	push   $0x54
 232:	e8 4d 0c 00 00       	call   e84 <malloc>
 237:	89 c3                	mov    %eax,%ebx
  memset(cmd, 0, sizeof(*cmd));
 239:	83 c4 0c             	add    $0xc,%esp
 23c:	6a 54                	push   $0x54
 23e:	6a 00                	push   $0x0
 240:	50                   	push   %eax
 241:	e8 b0 07 00 00       	call   9f6 <memset>
  cmd->type = EXEC;
 246:	c7 03 01 00 00 00    	movl   $0x1,(%ebx)
  return (struct cmd*)cmd;
}
 24c:	89 d8                	mov    %ebx,%eax
 24e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 251:	c9                   	leave  
 252:	c3                   	ret    

00000253 <redircmd>:

struct cmd*
redircmd(struct cmd *subcmd, char *file, char *efile, int mode, int fd)
{
 253:	55                   	push   %ebp
 254:	89 e5                	mov    %esp,%ebp
 256:	53                   	push   %ebx
 257:	83 ec 10             	sub    $0x10,%esp
  struct redircmd *cmd;

  cmd = malloc(sizeof(*cmd));
 25a:	6a 18                	push   $0x18
 25c:	e8 23 0c 00 00       	call   e84 <malloc>
 261:	89 c3                	mov    %eax,%ebx
  memset(cmd, 0, sizeof(*cmd));
 263:	83 c4 0c             	add    $0xc,%esp
 266:	6a 18                	push   $0x18
 268:	6a 00                	push   $0x0
 26a:	50                   	push   %eax
 26b:	e8 86 07 00 00       	call   9f6 <memset>
  cmd->type = REDIR;
 270:	c7 03 02 00 00 00    	movl   $0x2,(%ebx)
  cmd->cmd = subcmd;
 276:	8b 45 08             	mov    0x8(%ebp),%eax
 279:	89 43 04             	mov    %eax,0x4(%ebx)
  cmd->file = file;
 27c:	8b 45 0c             	mov    0xc(%ebp),%eax
 27f:	89 43 08             	mov    %eax,0x8(%ebx)
  cmd->efile = efile;
 282:	8b 45 10             	mov    0x10(%ebp),%eax
 285:	89 43 0c             	mov    %eax,0xc(%ebx)
  cmd->mode = mode;
 288:	8b 45 14             	mov    0x14(%ebp),%eax
 28b:	89 43 10             	mov    %eax,0x10(%ebx)
  cmd->fd = fd;
 28e:	8b 45 18             	mov    0x18(%ebp),%eax
 291:	89 43 14             	mov    %eax,0x14(%ebx)
  return (struct cmd*)cmd;
}
 294:	89 d8                	mov    %ebx,%eax
 296:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 299:	c9                   	leave  
 29a:	c3                   	ret    

0000029b <pipecmd>:

struct cmd*
pipecmd(struct cmd *left, struct cmd *right)
{
 29b:	55                   	push   %ebp
 29c:	89 e5                	mov    %esp,%ebp
 29e:	53                   	push   %ebx
 29f:	83 ec 10             	sub    $0x10,%esp
  struct pipecmd *cmd;

  cmd = malloc(sizeof(*cmd));
 2a2:	6a 0c                	push   $0xc
 2a4:	e8 db 0b 00 00       	call   e84 <malloc>
 2a9:	89 c3                	mov    %eax,%ebx
  memset(cmd, 0, sizeof(*cmd));
 2ab:	83 c4 0c             	add    $0xc,%esp
 2ae:	6a 0c                	push   $0xc
 2b0:	6a 00                	push   $0x0
 2b2:	50                   	push   %eax
 2b3:	e8 3e 07 00 00       	call   9f6 <memset>
  cmd->type = PIPE;
 2b8:	c7 03 03 00 00 00    	movl   $0x3,(%ebx)
  cmd->left = left;
 2be:	8b 45 08             	mov    0x8(%ebp),%eax
 2c1:	89 43 04             	mov    %eax,0x4(%ebx)
  cmd->right = right;
 2c4:	8b 45 0c             	mov    0xc(%ebp),%eax
 2c7:	89 43 08             	mov    %eax,0x8(%ebx)
  return (struct cmd*)cmd;
}
 2ca:	89 d8                	mov    %ebx,%eax
 2cc:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 2cf:	c9                   	leave  
 2d0:	c3                   	ret    

000002d1 <listcmd>:

struct cmd*
listcmd(struct cmd *left, struct cmd *right)
{
 2d1:	55                   	push   %ebp
 2d2:	89 e5                	mov    %esp,%ebp
 2d4:	53                   	push   %ebx
 2d5:	83 ec 10             	sub    $0x10,%esp
  struct listcmd *cmd;

  cmd = malloc(sizeof(*cmd));
 2d8:	6a 0c                	push   $0xc
 2da:	e8 a5 0b 00 00       	call   e84 <malloc>
 2df:	89 c3                	mov    %eax,%ebx
  memset(cmd, 0, sizeof(*cmd));
 2e1:	83 c4 0c             	add    $0xc,%esp
 2e4:	6a 0c                	push   $0xc
 2e6:	6a 00                	push   $0x0
 2e8:	50                   	push   %eax
 2e9:	e8 08 07 00 00       	call   9f6 <memset>
  cmd->type = LIST;
 2ee:	c7 03 04 00 00 00    	movl   $0x4,(%ebx)
  cmd->left = left;
 2f4:	8b 45 08             	mov    0x8(%ebp),%eax
 2f7:	89 43 04             	mov    %eax,0x4(%ebx)
  cmd->right = right;
 2fa:	8b 45 0c             	mov    0xc(%ebp),%eax
 2fd:	89 43 08             	mov    %eax,0x8(%ebx)
  return (struct cmd*)cmd;
}
 300:	89 d8                	mov    %ebx,%eax
 302:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 305:	c9                   	leave  
 306:	c3                   	ret    

00000307 <backcmd>:

struct cmd*
backcmd(struct cmd *subcmd)
{
 307:	55                   	push   %ebp
 308:	89 e5                	mov    %esp,%ebp
 30a:	53                   	push   %ebx
 30b:	83 ec 10             	sub    $0x10,%esp
  struct backcmd *cmd;

  cmd = malloc(sizeof(*cmd));
 30e:	6a 08                	push   $0x8
 310:	e8 6f 0b 00 00       	call   e84 <malloc>
 315:	89 c3                	mov    %eax,%ebx
  memset(cmd, 0, sizeof(*cmd));
 317:	83 c4 0c             	add    $0xc,%esp
 31a:	6a 08                	push   $0x8
 31c:	6a 00                	push   $0x0
 31e:	50                   	push   %eax
 31f:	e8 d2 06 00 00       	call   9f6 <memset>
  cmd->type = BACK;
 324:	c7 03 05 00 00 00    	movl   $0x5,(%ebx)
  cmd->cmd = subcmd;
 32a:	8b 45 08             	mov    0x8(%ebp),%eax
 32d:	89 43 04             	mov    %eax,0x4(%ebx)
  return (struct cmd*)cmd;
}
 330:	89 d8                	mov    %ebx,%eax
 332:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 335:	c9                   	leave  
 336:	c3                   	ret    

00000337 <gettoken>:
char whitespace[] = " \t\r\n\v";
char symbols[] = "<|>&;()";

int
gettoken(char **ps, char *es, char **q, char **eq)
{
 337:	55                   	push   %ebp
 338:	89 e5                	mov    %esp,%ebp
 33a:	57                   	push   %edi
 33b:	56                   	push   %esi
 33c:	53                   	push   %ebx
 33d:	83 ec 0c             	sub    $0xc,%esp
 340:	8b 75 0c             	mov    0xc(%ebp),%esi
 343:	8b 7d 10             	mov    0x10(%ebp),%edi
  char *s;
  int ret;

  s = *ps;
 346:	8b 45 08             	mov    0x8(%ebp),%eax
 349:	8b 18                	mov    (%eax),%ebx
  while(s < es && strchr(whitespace, *s))
 34b:	eb 01                	jmp    34e <gettoken+0x17>
    s++;
 34d:	43                   	inc    %ebx
  while(s < es && strchr(whitespace, *s))
 34e:	39 f3                	cmp    %esi,%ebx
 350:	73 18                	jae    36a <gettoken+0x33>
 352:	83 ec 08             	sub    $0x8,%esp
 355:	0f be 03             	movsbl (%ebx),%eax
 358:	50                   	push   %eax
 359:	68 e4 15 00 00       	push   $0x15e4
 35e:	e8 ab 06 00 00       	call   a0e <strchr>
 363:	83 c4 10             	add    $0x10,%esp
 366:	85 c0                	test   %eax,%eax
 368:	75 e3                	jne    34d <gettoken+0x16>
  if(q)
 36a:	85 ff                	test   %edi,%edi
 36c:	74 02                	je     370 <gettoken+0x39>
    *q = s;
 36e:	89 1f                	mov    %ebx,(%edi)
  ret = *s;
 370:	8a 03                	mov    (%ebx),%al
 372:	0f be f8             	movsbl %al,%edi
  switch(*s){
 375:	3c 3c                	cmp    $0x3c,%al
 377:	7f 25                	jg     39e <gettoken+0x67>
 379:	3c 3b                	cmp    $0x3b,%al
 37b:	7d 13                	jge    390 <gettoken+0x59>
 37d:	84 c0                	test   %al,%al
 37f:	74 10                	je     391 <gettoken+0x5a>
 381:	78 3d                	js     3c0 <gettoken+0x89>
 383:	3c 26                	cmp    $0x26,%al
 385:	74 09                	je     390 <gettoken+0x59>
 387:	7c 37                	jl     3c0 <gettoken+0x89>
 389:	83 e8 28             	sub    $0x28,%eax
 38c:	3c 01                	cmp    $0x1,%al
 38e:	77 30                	ja     3c0 <gettoken+0x89>
  case '(':
  case ')':
  case ';':
  case '&':
  case '<':
    s++;
 390:	43                   	inc    %ebx
    ret = 'a';
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
      s++;
    break;
  }
  if(eq)
 391:	83 7d 14 00          	cmpl   $0x0,0x14(%ebp)
 395:	74 73                	je     40a <gettoken+0xd3>
    *eq = s;
 397:	8b 45 14             	mov    0x14(%ebp),%eax
 39a:	89 18                	mov    %ebx,(%eax)
 39c:	eb 6c                	jmp    40a <gettoken+0xd3>
  switch(*s){
 39e:	3c 3e                	cmp    $0x3e,%al
 3a0:	75 0d                	jne    3af <gettoken+0x78>
    s++;
 3a2:	8d 43 01             	lea    0x1(%ebx),%eax
    if(*s == '>'){
 3a5:	80 7b 01 3e          	cmpb   $0x3e,0x1(%ebx)
 3a9:	74 0a                	je     3b5 <gettoken+0x7e>
    s++;
 3ab:	89 c3                	mov    %eax,%ebx
 3ad:	eb e2                	jmp    391 <gettoken+0x5a>
  switch(*s){
 3af:	3c 7c                	cmp    $0x7c,%al
 3b1:	75 0d                	jne    3c0 <gettoken+0x89>
 3b3:	eb db                	jmp    390 <gettoken+0x59>
      s++;
 3b5:	83 c3 02             	add    $0x2,%ebx
      ret = '+';
 3b8:	bf 2b 00 00 00       	mov    $0x2b,%edi
 3bd:	eb d2                	jmp    391 <gettoken+0x5a>
      s++;
 3bf:	43                   	inc    %ebx
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
 3c0:	39 f3                	cmp    %esi,%ebx
 3c2:	73 37                	jae    3fb <gettoken+0xc4>
 3c4:	83 ec 08             	sub    $0x8,%esp
 3c7:	0f be 03             	movsbl (%ebx),%eax
 3ca:	50                   	push   %eax
 3cb:	68 e4 15 00 00       	push   $0x15e4
 3d0:	e8 39 06 00 00       	call   a0e <strchr>
 3d5:	83 c4 10             	add    $0x10,%esp
 3d8:	85 c0                	test   %eax,%eax
 3da:	75 26                	jne    402 <gettoken+0xcb>
 3dc:	83 ec 08             	sub    $0x8,%esp
 3df:	0f be 03             	movsbl (%ebx),%eax
 3e2:	50                   	push   %eax
 3e3:	68 dc 15 00 00       	push   $0x15dc
 3e8:	e8 21 06 00 00       	call   a0e <strchr>
 3ed:	83 c4 10             	add    $0x10,%esp
 3f0:	85 c0                	test   %eax,%eax
 3f2:	74 cb                	je     3bf <gettoken+0x88>
    ret = 'a';
 3f4:	bf 61 00 00 00       	mov    $0x61,%edi
 3f9:	eb 96                	jmp    391 <gettoken+0x5a>
 3fb:	bf 61 00 00 00       	mov    $0x61,%edi
 400:	eb 8f                	jmp    391 <gettoken+0x5a>
 402:	bf 61 00 00 00       	mov    $0x61,%edi
 407:	eb 88                	jmp    391 <gettoken+0x5a>

  while(s < es && strchr(whitespace, *s))
    s++;
 409:	43                   	inc    %ebx
  while(s < es && strchr(whitespace, *s))
 40a:	39 f3                	cmp    %esi,%ebx
 40c:	73 18                	jae    426 <gettoken+0xef>
 40e:	83 ec 08             	sub    $0x8,%esp
 411:	0f be 03             	movsbl (%ebx),%eax
 414:	50                   	push   %eax
 415:	68 e4 15 00 00       	push   $0x15e4
 41a:	e8 ef 05 00 00       	call   a0e <strchr>
 41f:	83 c4 10             	add    $0x10,%esp
 422:	85 c0                	test   %eax,%eax
 424:	75 e3                	jne    409 <gettoken+0xd2>
  *ps = s;
 426:	8b 45 08             	mov    0x8(%ebp),%eax
 429:	89 18                	mov    %ebx,(%eax)
  return ret;
}
 42b:	89 f8                	mov    %edi,%eax
 42d:	8d 65 f4             	lea    -0xc(%ebp),%esp
 430:	5b                   	pop    %ebx
 431:	5e                   	pop    %esi
 432:	5f                   	pop    %edi
 433:	5d                   	pop    %ebp
 434:	c3                   	ret    

00000435 <peek>:

int
peek(char **ps, char *es, char *toks)
{
 435:	55                   	push   %ebp
 436:	89 e5                	mov    %esp,%ebp
 438:	57                   	push   %edi
 439:	56                   	push   %esi
 43a:	53                   	push   %ebx
 43b:	83 ec 0c             	sub    $0xc,%esp
 43e:	8b 7d 08             	mov    0x8(%ebp),%edi
 441:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *s;

  s = *ps;
 444:	8b 1f                	mov    (%edi),%ebx
  while(s < es && strchr(whitespace, *s))
 446:	eb 01                	jmp    449 <peek+0x14>
    s++;
 448:	43                   	inc    %ebx
  while(s < es && strchr(whitespace, *s))
 449:	39 f3                	cmp    %esi,%ebx
 44b:	73 18                	jae    465 <peek+0x30>
 44d:	83 ec 08             	sub    $0x8,%esp
 450:	0f be 03             	movsbl (%ebx),%eax
 453:	50                   	push   %eax
 454:	68 e4 15 00 00       	push   $0x15e4
 459:	e8 b0 05 00 00       	call   a0e <strchr>
 45e:	83 c4 10             	add    $0x10,%esp
 461:	85 c0                	test   %eax,%eax
 463:	75 e3                	jne    448 <peek+0x13>
  *ps = s;
 465:	89 1f                	mov    %ebx,(%edi)
  return *s && strchr(toks, *s);
 467:	8a 03                	mov    (%ebx),%al
 469:	84 c0                	test   %al,%al
 46b:	75 0d                	jne    47a <peek+0x45>
 46d:	b8 00 00 00 00       	mov    $0x0,%eax
}
 472:	8d 65 f4             	lea    -0xc(%ebp),%esp
 475:	5b                   	pop    %ebx
 476:	5e                   	pop    %esi
 477:	5f                   	pop    %edi
 478:	5d                   	pop    %ebp
 479:	c3                   	ret    
  return *s && strchr(toks, *s);
 47a:	83 ec 08             	sub    $0x8,%esp
 47d:	0f be c0             	movsbl %al,%eax
 480:	50                   	push   %eax
 481:	ff 75 10             	push   0x10(%ebp)
 484:	e8 85 05 00 00       	call   a0e <strchr>
 489:	83 c4 10             	add    $0x10,%esp
 48c:	85 c0                	test   %eax,%eax
 48e:	74 07                	je     497 <peek+0x62>
 490:	b8 01 00 00 00       	mov    $0x1,%eax
 495:	eb db                	jmp    472 <peek+0x3d>
 497:	b8 00 00 00 00       	mov    $0x0,%eax
 49c:	eb d4                	jmp    472 <peek+0x3d>

0000049e <parseredirs>:
  return cmd;
}

struct cmd*
parseredirs(struct cmd *cmd, char **ps, char *es)
{
 49e:	55                   	push   %ebp
 49f:	89 e5                	mov    %esp,%ebp
 4a1:	57                   	push   %edi
 4a2:	56                   	push   %esi
 4a3:	53                   	push   %ebx
 4a4:	83 ec 1c             	sub    $0x1c,%esp
 4a7:	8b 7d 0c             	mov    0xc(%ebp),%edi
 4aa:	8b 75 10             	mov    0x10(%ebp),%esi
  int tok;
  char *q, *eq;

  while(peek(ps, es, "<>")){
 4ad:	eb 28                	jmp    4d7 <parseredirs+0x39>
    tok = gettoken(ps, es, 0, 0);
    if(gettoken(ps, es, &q, &eq) != 'a')
      panic("missing file for redirection");
 4af:	83 ec 0c             	sub    $0xc,%esp
 4b2:	68 40 0f 00 00       	push   $0xf40
 4b7:	e8 8f fb ff ff       	call   4b <panic>
    switch(tok){
    case '<':
      cmd = redircmd(cmd, q, eq, O_RDONLY, 0);
 4bc:	83 ec 0c             	sub    $0xc,%esp
 4bf:	6a 00                	push   $0x0
 4c1:	6a 00                	push   $0x0
 4c3:	ff 75 e0             	push   -0x20(%ebp)
 4c6:	ff 75 e4             	push   -0x1c(%ebp)
 4c9:	ff 75 08             	push   0x8(%ebp)
 4cc:	e8 82 fd ff ff       	call   253 <redircmd>
 4d1:	89 45 08             	mov    %eax,0x8(%ebp)
      break;
 4d4:	83 c4 20             	add    $0x20,%esp
  while(peek(ps, es, "<>")){
 4d7:	83 ec 04             	sub    $0x4,%esp
 4da:	68 5d 0f 00 00       	push   $0xf5d
 4df:	56                   	push   %esi
 4e0:	57                   	push   %edi
 4e1:	e8 4f ff ff ff       	call   435 <peek>
 4e6:	83 c4 10             	add    $0x10,%esp
 4e9:	85 c0                	test   %eax,%eax
 4eb:	74 76                	je     563 <parseredirs+0xc5>
    tok = gettoken(ps, es, 0, 0);
 4ed:	6a 00                	push   $0x0
 4ef:	6a 00                	push   $0x0
 4f1:	56                   	push   %esi
 4f2:	57                   	push   %edi
 4f3:	e8 3f fe ff ff       	call   337 <gettoken>
 4f8:	89 c3                	mov    %eax,%ebx
    if(gettoken(ps, es, &q, &eq) != 'a')
 4fa:	8d 45 e0             	lea    -0x20(%ebp),%eax
 4fd:	50                   	push   %eax
 4fe:	8d 45 e4             	lea    -0x1c(%ebp),%eax
 501:	50                   	push   %eax
 502:	56                   	push   %esi
 503:	57                   	push   %edi
 504:	e8 2e fe ff ff       	call   337 <gettoken>
 509:	83 c4 20             	add    $0x20,%esp
 50c:	83 f8 61             	cmp    $0x61,%eax
 50f:	75 9e                	jne    4af <parseredirs+0x11>
    switch(tok){
 511:	83 fb 3c             	cmp    $0x3c,%ebx
 514:	74 a6                	je     4bc <parseredirs+0x1e>
 516:	83 fb 3e             	cmp    $0x3e,%ebx
 519:	74 25                	je     540 <parseredirs+0xa2>
 51b:	83 fb 2b             	cmp    $0x2b,%ebx
 51e:	75 b7                	jne    4d7 <parseredirs+0x39>
    case '>':
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
      break;
    case '+':  // >>
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
 520:	83 ec 0c             	sub    $0xc,%esp
 523:	6a 01                	push   $0x1
 525:	68 01 02 00 00       	push   $0x201
 52a:	ff 75 e0             	push   -0x20(%ebp)
 52d:	ff 75 e4             	push   -0x1c(%ebp)
 530:	ff 75 08             	push   0x8(%ebp)
 533:	e8 1b fd ff ff       	call   253 <redircmd>
 538:	89 45 08             	mov    %eax,0x8(%ebp)
      break;
 53b:	83 c4 20             	add    $0x20,%esp
 53e:	eb 97                	jmp    4d7 <parseredirs+0x39>
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
 540:	83 ec 0c             	sub    $0xc,%esp
 543:	6a 01                	push   $0x1
 545:	68 01 02 00 00       	push   $0x201
 54a:	ff 75 e0             	push   -0x20(%ebp)
 54d:	ff 75 e4             	push   -0x1c(%ebp)
 550:	ff 75 08             	push   0x8(%ebp)
 553:	e8 fb fc ff ff       	call   253 <redircmd>
 558:	89 45 08             	mov    %eax,0x8(%ebp)
      break;
 55b:	83 c4 20             	add    $0x20,%esp
 55e:	e9 74 ff ff ff       	jmp    4d7 <parseredirs+0x39>
    }
  }
  return cmd;
}
 563:	8b 45 08             	mov    0x8(%ebp),%eax
 566:	8d 65 f4             	lea    -0xc(%ebp),%esp
 569:	5b                   	pop    %ebx
 56a:	5e                   	pop    %esi
 56b:	5f                   	pop    %edi
 56c:	5d                   	pop    %ebp
 56d:	c3                   	ret    

0000056e <parseexec>:
  return cmd;
}

struct cmd*
parseexec(char **ps, char *es)
{
 56e:	55                   	push   %ebp
 56f:	89 e5                	mov    %esp,%ebp
 571:	57                   	push   %edi
 572:	56                   	push   %esi
 573:	53                   	push   %ebx
 574:	83 ec 30             	sub    $0x30,%esp
 577:	8b 75 08             	mov    0x8(%ebp),%esi
 57a:	8b 7d 0c             	mov    0xc(%ebp),%edi
  char *q, *eq;
  int tok, argc;
  struct execcmd *cmd;
  struct cmd *ret;

  if(peek(ps, es, "("))
 57d:	68 60 0f 00 00       	push   $0xf60
 582:	57                   	push   %edi
 583:	56                   	push   %esi
 584:	e8 ac fe ff ff       	call   435 <peek>
 589:	83 c4 10             	add    $0x10,%esp
 58c:	85 c0                	test   %eax,%eax
 58e:	75 1d                	jne    5ad <parseexec+0x3f>
 590:	89 c3                	mov    %eax,%ebx
    return parseblock(ps, es);

  ret = execcmd();
 592:	e8 92 fc ff ff       	call   229 <execcmd>
 597:	89 45 d0             	mov    %eax,-0x30(%ebp)
  cmd = (struct execcmd*)ret;

  argc = 0;
  ret = parseredirs(ret, ps, es);
 59a:	83 ec 04             	sub    $0x4,%esp
 59d:	57                   	push   %edi
 59e:	56                   	push   %esi
 59f:	50                   	push   %eax
 5a0:	e8 f9 fe ff ff       	call   49e <parseredirs>
 5a5:	89 45 d4             	mov    %eax,-0x2c(%ebp)
  while(!peek(ps, es, "|)&;")){
 5a8:	83 c4 10             	add    $0x10,%esp
 5ab:	eb 3b                	jmp    5e8 <parseexec+0x7a>
    return parseblock(ps, es);
 5ad:	83 ec 08             	sub    $0x8,%esp
 5b0:	57                   	push   %edi
 5b1:	56                   	push   %esi
 5b2:	e8 8d 01 00 00       	call   744 <parseblock>
 5b7:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 5ba:	83 c4 10             	add    $0x10,%esp
    ret = parseredirs(ret, ps, es);
  }
  cmd->argv[argc] = 0;
  cmd->eargv[argc] = 0;
  return ret;
}
 5bd:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 5c0:	8d 65 f4             	lea    -0xc(%ebp),%esp
 5c3:	5b                   	pop    %ebx
 5c4:	5e                   	pop    %esi
 5c5:	5f                   	pop    %edi
 5c6:	5d                   	pop    %ebp
 5c7:	c3                   	ret    
      panic("syntax");
 5c8:	83 ec 0c             	sub    $0xc,%esp
 5cb:	68 62 0f 00 00       	push   $0xf62
 5d0:	e8 76 fa ff ff       	call   4b <panic>
    ret = parseredirs(ret, ps, es);
 5d5:	83 ec 04             	sub    $0x4,%esp
 5d8:	57                   	push   %edi
 5d9:	56                   	push   %esi
 5da:	ff 75 d4             	push   -0x2c(%ebp)
 5dd:	e8 bc fe ff ff       	call   49e <parseredirs>
 5e2:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 5e5:	83 c4 10             	add    $0x10,%esp
  while(!peek(ps, es, "|)&;")){
 5e8:	83 ec 04             	sub    $0x4,%esp
 5eb:	68 77 0f 00 00       	push   $0xf77
 5f0:	57                   	push   %edi
 5f1:	56                   	push   %esi
 5f2:	e8 3e fe ff ff       	call   435 <peek>
 5f7:	83 c4 10             	add    $0x10,%esp
 5fa:	85 c0                	test   %eax,%eax
 5fc:	75 3f                	jne    63d <parseexec+0xcf>
    if((tok=gettoken(ps, es, &q, &eq)) == 0)
 5fe:	8d 45 e0             	lea    -0x20(%ebp),%eax
 601:	50                   	push   %eax
 602:	8d 45 e4             	lea    -0x1c(%ebp),%eax
 605:	50                   	push   %eax
 606:	57                   	push   %edi
 607:	56                   	push   %esi
 608:	e8 2a fd ff ff       	call   337 <gettoken>
 60d:	83 c4 10             	add    $0x10,%esp
 610:	85 c0                	test   %eax,%eax
 612:	74 29                	je     63d <parseexec+0xcf>
    if(tok != 'a')
 614:	83 f8 61             	cmp    $0x61,%eax
 617:	75 af                	jne    5c8 <parseexec+0x5a>
    cmd->argv[argc] = q;
 619:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 61c:	8b 55 d0             	mov    -0x30(%ebp),%edx
 61f:	89 44 9a 04          	mov    %eax,0x4(%edx,%ebx,4)
    cmd->eargv[argc] = eq;
 623:	8b 45 e0             	mov    -0x20(%ebp),%eax
 626:	89 44 9a 2c          	mov    %eax,0x2c(%edx,%ebx,4)
    argc++;
 62a:	43                   	inc    %ebx
    if(argc >= MAXARGS)
 62b:	83 fb 09             	cmp    $0x9,%ebx
 62e:	7e a5                	jle    5d5 <parseexec+0x67>
      panic("too many args");
 630:	83 ec 0c             	sub    $0xc,%esp
 633:	68 69 0f 00 00       	push   $0xf69
 638:	e8 0e fa ff ff       	call   4b <panic>
  cmd->argv[argc] = 0;
 63d:	8b 45 d0             	mov    -0x30(%ebp),%eax
 640:	c7 44 98 04 00 00 00 	movl   $0x0,0x4(%eax,%ebx,4)
 647:	00 
  cmd->eargv[argc] = 0;
 648:	c7 44 98 2c 00 00 00 	movl   $0x0,0x2c(%eax,%ebx,4)
 64f:	00 
  return ret;
 650:	e9 68 ff ff ff       	jmp    5bd <parseexec+0x4f>

00000655 <parsepipe>:
{
 655:	55                   	push   %ebp
 656:	89 e5                	mov    %esp,%ebp
 658:	57                   	push   %edi
 659:	56                   	push   %esi
 65a:	53                   	push   %ebx
 65b:	83 ec 14             	sub    $0x14,%esp
 65e:	8b 75 08             	mov    0x8(%ebp),%esi
 661:	8b 7d 0c             	mov    0xc(%ebp),%edi
  cmd = parseexec(ps, es);
 664:	57                   	push   %edi
 665:	56                   	push   %esi
 666:	e8 03 ff ff ff       	call   56e <parseexec>
 66b:	89 c3                	mov    %eax,%ebx
  if(peek(ps, es, "|")){
 66d:	83 c4 0c             	add    $0xc,%esp
 670:	68 7c 0f 00 00       	push   $0xf7c
 675:	57                   	push   %edi
 676:	56                   	push   %esi
 677:	e8 b9 fd ff ff       	call   435 <peek>
 67c:	83 c4 10             	add    $0x10,%esp
 67f:	85 c0                	test   %eax,%eax
 681:	75 0a                	jne    68d <parsepipe+0x38>
}
 683:	89 d8                	mov    %ebx,%eax
 685:	8d 65 f4             	lea    -0xc(%ebp),%esp
 688:	5b                   	pop    %ebx
 689:	5e                   	pop    %esi
 68a:	5f                   	pop    %edi
 68b:	5d                   	pop    %ebp
 68c:	c3                   	ret    
    gettoken(ps, es, 0, 0);
 68d:	6a 00                	push   $0x0
 68f:	6a 00                	push   $0x0
 691:	57                   	push   %edi
 692:	56                   	push   %esi
 693:	e8 9f fc ff ff       	call   337 <gettoken>
    cmd = pipecmd(cmd, parsepipe(ps, es));
 698:	83 c4 08             	add    $0x8,%esp
 69b:	57                   	push   %edi
 69c:	56                   	push   %esi
 69d:	e8 b3 ff ff ff       	call   655 <parsepipe>
 6a2:	83 c4 08             	add    $0x8,%esp
 6a5:	50                   	push   %eax
 6a6:	53                   	push   %ebx
 6a7:	e8 ef fb ff ff       	call   29b <pipecmd>
 6ac:	89 c3                	mov    %eax,%ebx
 6ae:	83 c4 10             	add    $0x10,%esp
  return cmd;
 6b1:	eb d0                	jmp    683 <parsepipe+0x2e>

000006b3 <parseline>:
{
 6b3:	55                   	push   %ebp
 6b4:	89 e5                	mov    %esp,%ebp
 6b6:	57                   	push   %edi
 6b7:	56                   	push   %esi
 6b8:	53                   	push   %ebx
 6b9:	83 ec 14             	sub    $0x14,%esp
 6bc:	8b 75 08             	mov    0x8(%ebp),%esi
 6bf:	8b 7d 0c             	mov    0xc(%ebp),%edi
  cmd = parsepipe(ps, es);
 6c2:	57                   	push   %edi
 6c3:	56                   	push   %esi
 6c4:	e8 8c ff ff ff       	call   655 <parsepipe>
 6c9:	89 c3                	mov    %eax,%ebx
  while(peek(ps, es, "&")){
 6cb:	83 c4 10             	add    $0x10,%esp
 6ce:	eb 18                	jmp    6e8 <parseline+0x35>
    gettoken(ps, es, 0, 0);
 6d0:	6a 00                	push   $0x0
 6d2:	6a 00                	push   $0x0
 6d4:	57                   	push   %edi
 6d5:	56                   	push   %esi
 6d6:	e8 5c fc ff ff       	call   337 <gettoken>
    cmd = backcmd(cmd);
 6db:	89 1c 24             	mov    %ebx,(%esp)
 6de:	e8 24 fc ff ff       	call   307 <backcmd>
 6e3:	89 c3                	mov    %eax,%ebx
 6e5:	83 c4 10             	add    $0x10,%esp
  while(peek(ps, es, "&")){
 6e8:	83 ec 04             	sub    $0x4,%esp
 6eb:	68 7e 0f 00 00       	push   $0xf7e
 6f0:	57                   	push   %edi
 6f1:	56                   	push   %esi
 6f2:	e8 3e fd ff ff       	call   435 <peek>
 6f7:	83 c4 10             	add    $0x10,%esp
 6fa:	85 c0                	test   %eax,%eax
 6fc:	75 d2                	jne    6d0 <parseline+0x1d>
  if(peek(ps, es, ";")){
 6fe:	83 ec 04             	sub    $0x4,%esp
 701:	68 7a 0f 00 00       	push   $0xf7a
 706:	57                   	push   %edi
 707:	56                   	push   %esi
 708:	e8 28 fd ff ff       	call   435 <peek>
 70d:	83 c4 10             	add    $0x10,%esp
 710:	85 c0                	test   %eax,%eax
 712:	75 0a                	jne    71e <parseline+0x6b>
}
 714:	89 d8                	mov    %ebx,%eax
 716:	8d 65 f4             	lea    -0xc(%ebp),%esp
 719:	5b                   	pop    %ebx
 71a:	5e                   	pop    %esi
 71b:	5f                   	pop    %edi
 71c:	5d                   	pop    %ebp
 71d:	c3                   	ret    
    gettoken(ps, es, 0, 0);
 71e:	6a 00                	push   $0x0
 720:	6a 00                	push   $0x0
 722:	57                   	push   %edi
 723:	56                   	push   %esi
 724:	e8 0e fc ff ff       	call   337 <gettoken>
    cmd = listcmd(cmd, parseline(ps, es));
 729:	83 c4 08             	add    $0x8,%esp
 72c:	57                   	push   %edi
 72d:	56                   	push   %esi
 72e:	e8 80 ff ff ff       	call   6b3 <parseline>
 733:	83 c4 08             	add    $0x8,%esp
 736:	50                   	push   %eax
 737:	53                   	push   %ebx
 738:	e8 94 fb ff ff       	call   2d1 <listcmd>
 73d:	89 c3                	mov    %eax,%ebx
 73f:	83 c4 10             	add    $0x10,%esp
  return cmd;
 742:	eb d0                	jmp    714 <parseline+0x61>

00000744 <parseblock>:
{
 744:	55                   	push   %ebp
 745:	89 e5                	mov    %esp,%ebp
 747:	57                   	push   %edi
 748:	56                   	push   %esi
 749:	53                   	push   %ebx
 74a:	83 ec 10             	sub    $0x10,%esp
 74d:	8b 5d 08             	mov    0x8(%ebp),%ebx
 750:	8b 75 0c             	mov    0xc(%ebp),%esi
  if(!peek(ps, es, "("))
 753:	68 60 0f 00 00       	push   $0xf60
 758:	56                   	push   %esi
 759:	53                   	push   %ebx
 75a:	e8 d6 fc ff ff       	call   435 <peek>
 75f:	83 c4 10             	add    $0x10,%esp
 762:	85 c0                	test   %eax,%eax
 764:	74 4b                	je     7b1 <parseblock+0x6d>
  gettoken(ps, es, 0, 0);
 766:	6a 00                	push   $0x0
 768:	6a 00                	push   $0x0
 76a:	56                   	push   %esi
 76b:	53                   	push   %ebx
 76c:	e8 c6 fb ff ff       	call   337 <gettoken>
  cmd = parseline(ps, es);
 771:	83 c4 08             	add    $0x8,%esp
 774:	56                   	push   %esi
 775:	53                   	push   %ebx
 776:	e8 38 ff ff ff       	call   6b3 <parseline>
 77b:	89 c7                	mov    %eax,%edi
  if(!peek(ps, es, ")"))
 77d:	83 c4 0c             	add    $0xc,%esp
 780:	68 9c 0f 00 00       	push   $0xf9c
 785:	56                   	push   %esi
 786:	53                   	push   %ebx
 787:	e8 a9 fc ff ff       	call   435 <peek>
 78c:	83 c4 10             	add    $0x10,%esp
 78f:	85 c0                	test   %eax,%eax
 791:	74 2b                	je     7be <parseblock+0x7a>
  gettoken(ps, es, 0, 0);
 793:	6a 00                	push   $0x0
 795:	6a 00                	push   $0x0
 797:	56                   	push   %esi
 798:	53                   	push   %ebx
 799:	e8 99 fb ff ff       	call   337 <gettoken>
  cmd = parseredirs(cmd, ps, es);
 79e:	83 c4 0c             	add    $0xc,%esp
 7a1:	56                   	push   %esi
 7a2:	53                   	push   %ebx
 7a3:	57                   	push   %edi
 7a4:	e8 f5 fc ff ff       	call   49e <parseredirs>
}
 7a9:	8d 65 f4             	lea    -0xc(%ebp),%esp
 7ac:	5b                   	pop    %ebx
 7ad:	5e                   	pop    %esi
 7ae:	5f                   	pop    %edi
 7af:	5d                   	pop    %ebp
 7b0:	c3                   	ret    
    panic("parseblock");
 7b1:	83 ec 0c             	sub    $0xc,%esp
 7b4:	68 80 0f 00 00       	push   $0xf80
 7b9:	e8 8d f8 ff ff       	call   4b <panic>
    panic("syntax - missing )");
 7be:	83 ec 0c             	sub    $0xc,%esp
 7c1:	68 8b 0f 00 00       	push   $0xf8b
 7c6:	e8 80 f8 ff ff       	call   4b <panic>

000007cb <nulterminate>:

// NUL-terminate all the counted strings.
struct cmd*
nulterminate(struct cmd *cmd)
{
 7cb:	55                   	push   %ebp
 7cc:	89 e5                	mov    %esp,%ebp
 7ce:	53                   	push   %ebx
 7cf:	83 ec 04             	sub    $0x4,%esp
 7d2:	8b 5d 08             	mov    0x8(%ebp),%ebx
  struct execcmd *ecmd;
  struct listcmd *lcmd;
  struct pipecmd *pcmd;
  struct redircmd *rcmd;

  if(cmd == 0)
 7d5:	85 db                	test   %ebx,%ebx
 7d7:	74 1d                	je     7f6 <nulterminate+0x2b>
    return 0;

  switch(cmd->type){
 7d9:	8b 03                	mov    (%ebx),%eax
 7db:	83 f8 05             	cmp    $0x5,%eax
 7de:	77 16                	ja     7f6 <nulterminate+0x2b>
 7e0:	ff 24 85 dc 0f 00 00 	jmp    *0xfdc(,%eax,4)
  case EXEC:
    ecmd = (struct execcmd*)cmd;
    for(i=0; ecmd->argv[i]; i++)
      *ecmd->eargv[i] = 0;
 7e7:	8b 54 83 2c          	mov    0x2c(%ebx,%eax,4),%edx
 7eb:	c6 02 00             	movb   $0x0,(%edx)
    for(i=0; ecmd->argv[i]; i++)
 7ee:	40                   	inc    %eax
 7ef:	83 7c 83 04 00       	cmpl   $0x0,0x4(%ebx,%eax,4)
 7f4:	75 f1                	jne    7e7 <nulterminate+0x1c>
    bcmd = (struct backcmd*)cmd;
    nulterminate(bcmd->cmd);
    break;
  }
  return cmd;
}
 7f6:	89 d8                	mov    %ebx,%eax
 7f8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 7fb:	c9                   	leave  
 7fc:	c3                   	ret    
  switch(cmd->type){
 7fd:	b8 00 00 00 00       	mov    $0x0,%eax
 802:	eb eb                	jmp    7ef <nulterminate+0x24>
    nulterminate(rcmd->cmd);
 804:	83 ec 0c             	sub    $0xc,%esp
 807:	ff 73 04             	push   0x4(%ebx)
 80a:	e8 bc ff ff ff       	call   7cb <nulterminate>
    *rcmd->efile = 0;
 80f:	8b 43 0c             	mov    0xc(%ebx),%eax
 812:	c6 00 00             	movb   $0x0,(%eax)
    break;
 815:	83 c4 10             	add    $0x10,%esp
 818:	eb dc                	jmp    7f6 <nulterminate+0x2b>
    nulterminate(pcmd->left);
 81a:	83 ec 0c             	sub    $0xc,%esp
 81d:	ff 73 04             	push   0x4(%ebx)
 820:	e8 a6 ff ff ff       	call   7cb <nulterminate>
    nulterminate(pcmd->right);
 825:	83 c4 04             	add    $0x4,%esp
 828:	ff 73 08             	push   0x8(%ebx)
 82b:	e8 9b ff ff ff       	call   7cb <nulterminate>
    break;
 830:	83 c4 10             	add    $0x10,%esp
 833:	eb c1                	jmp    7f6 <nulterminate+0x2b>
    nulterminate(lcmd->left);
 835:	83 ec 0c             	sub    $0xc,%esp
 838:	ff 73 04             	push   0x4(%ebx)
 83b:	e8 8b ff ff ff       	call   7cb <nulterminate>
    nulterminate(lcmd->right);
 840:	83 c4 04             	add    $0x4,%esp
 843:	ff 73 08             	push   0x8(%ebx)
 846:	e8 80 ff ff ff       	call   7cb <nulterminate>
    break;
 84b:	83 c4 10             	add    $0x10,%esp
 84e:	eb a6                	jmp    7f6 <nulterminate+0x2b>
    nulterminate(bcmd->cmd);
 850:	83 ec 0c             	sub    $0xc,%esp
 853:	ff 73 04             	push   0x4(%ebx)
 856:	e8 70 ff ff ff       	call   7cb <nulterminate>
    break;
 85b:	83 c4 10             	add    $0x10,%esp
 85e:	eb 96                	jmp    7f6 <nulterminate+0x2b>

00000860 <parsecmd>:
{
 860:	55                   	push   %ebp
 861:	89 e5                	mov    %esp,%ebp
 863:	56                   	push   %esi
 864:	53                   	push   %ebx
  es = s + strlen(s);
 865:	8b 5d 08             	mov    0x8(%ebp),%ebx
 868:	83 ec 0c             	sub    $0xc,%esp
 86b:	53                   	push   %ebx
 86c:	e8 6f 01 00 00       	call   9e0 <strlen>
 871:	01 c3                	add    %eax,%ebx
  cmd = parseline(&s, es);
 873:	83 c4 08             	add    $0x8,%esp
 876:	53                   	push   %ebx
 877:	8d 45 08             	lea    0x8(%ebp),%eax
 87a:	50                   	push   %eax
 87b:	e8 33 fe ff ff       	call   6b3 <parseline>
 880:	89 c6                	mov    %eax,%esi
  peek(&s, es, "");
 882:	83 c4 0c             	add    $0xc,%esp
 885:	68 2a 0f 00 00       	push   $0xf2a
 88a:	53                   	push   %ebx
 88b:	8d 45 08             	lea    0x8(%ebp),%eax
 88e:	50                   	push   %eax
 88f:	e8 a1 fb ff ff       	call   435 <peek>
  if(s != es){
 894:	8b 45 08             	mov    0x8(%ebp),%eax
 897:	83 c4 10             	add    $0x10,%esp
 89a:	39 d8                	cmp    %ebx,%eax
 89c:	75 12                	jne    8b0 <parsecmd+0x50>
  nulterminate(cmd);
 89e:	83 ec 0c             	sub    $0xc,%esp
 8a1:	56                   	push   %esi
 8a2:	e8 24 ff ff ff       	call   7cb <nulterminate>
}
 8a7:	89 f0                	mov    %esi,%eax
 8a9:	8d 65 f8             	lea    -0x8(%ebp),%esp
 8ac:	5b                   	pop    %ebx
 8ad:	5e                   	pop    %esi
 8ae:	5d                   	pop    %ebp
 8af:	c3                   	ret    
    printf(2, "leftovers: %s\n", s);
 8b0:	83 ec 04             	sub    $0x4,%esp
 8b3:	50                   	push   %eax
 8b4:	68 9e 0f 00 00       	push   $0xf9e
 8b9:	6a 02                	push   $0x2
 8bb:	e8 a4 03 00 00       	call   c64 <printf>
    panic("syntax");
 8c0:	c7 04 24 62 0f 00 00 	movl   $0xf62,(%esp)
 8c7:	e8 7f f7 ff ff       	call   4b <panic>

000008cc <main>:
{
 8cc:	8d 4c 24 04          	lea    0x4(%esp),%ecx
 8d0:	83 e4 f0             	and    $0xfffffff0,%esp
 8d3:	ff 71 fc             	push   -0x4(%ecx)
 8d6:	55                   	push   %ebp
 8d7:	89 e5                	mov    %esp,%ebp
 8d9:	51                   	push   %ecx
 8da:	83 ec 04             	sub    $0x4,%esp
  while((fd = open("console", O_RDWR)) >= 0){
 8dd:	83 ec 08             	sub    $0x8,%esp
 8e0:	6a 02                	push   $0x2
 8e2:	68 ad 0f 00 00       	push   $0xfad
 8e7:	e8 75 02 00 00       	call   b61 <open>
 8ec:	83 c4 10             	add    $0x10,%esp
 8ef:	85 c0                	test   %eax,%eax
 8f1:	78 21                	js     914 <main+0x48>
    if(fd >= 3){
 8f3:	83 f8 02             	cmp    $0x2,%eax
 8f6:	7e e5                	jle    8dd <main+0x11>
      close(fd);
 8f8:	83 ec 0c             	sub    $0xc,%esp
 8fb:	50                   	push   %eax
 8fc:	e8 48 02 00 00       	call   b49 <close>
      break;
 901:	83 c4 10             	add    $0x10,%esp
 904:	eb 0e                	jmp    914 <main+0x48>
    if(fork1() == 0)
 906:	e8 5a f7 ff ff       	call   65 <fork1>
 90b:	85 c0                	test   %eax,%eax
 90d:	74 76                	je     985 <main+0xb9>
    wait();
 90f:	e8 15 02 00 00       	call   b29 <wait>
  while(getcmd(buf, sizeof(buf)) >= 0){
 914:	83 ec 08             	sub    $0x8,%esp
 917:	6a 64                	push   $0x64
 919:	68 00 16 00 00       	push   $0x1600
 91e:	e8 dd f6 ff ff       	call   0 <getcmd>
 923:	83 c4 10             	add    $0x10,%esp
 926:	85 c0                	test   %eax,%eax
 928:	78 70                	js     99a <main+0xce>
    if(buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' '){
 92a:	80 3d 00 16 00 00 63 	cmpb   $0x63,0x1600
 931:	75 d3                	jne    906 <main+0x3a>
 933:	80 3d 01 16 00 00 64 	cmpb   $0x64,0x1601
 93a:	75 ca                	jne    906 <main+0x3a>
 93c:	80 3d 02 16 00 00 20 	cmpb   $0x20,0x1602
 943:	75 c1                	jne    906 <main+0x3a>
      buf[strlen(buf)-1] = 0;  // chop \n
 945:	83 ec 0c             	sub    $0xc,%esp
 948:	68 00 16 00 00       	push   $0x1600
 94d:	e8 8e 00 00 00       	call   9e0 <strlen>
 952:	c6 80 ff 15 00 00 00 	movb   $0x0,0x15ff(%eax)
      if(chdir(buf+3) < 0)
 959:	c7 04 24 03 16 00 00 	movl   $0x1603,(%esp)
 960:	e8 2c 02 00 00       	call   b91 <chdir>
 965:	83 c4 10             	add    $0x10,%esp
 968:	85 c0                	test   %eax,%eax
 96a:	79 a8                	jns    914 <main+0x48>
        printf(2, "cannot cd %s\n", buf+3);
 96c:	83 ec 04             	sub    $0x4,%esp
 96f:	68 03 16 00 00       	push   $0x1603
 974:	68 b5 0f 00 00       	push   $0xfb5
 979:	6a 02                	push   $0x2
 97b:	e8 e4 02 00 00       	call   c64 <printf>
 980:	83 c4 10             	add    $0x10,%esp
      continue;
 983:	eb 8f                	jmp    914 <main+0x48>
      runcmd(parsecmd(buf));
 985:	83 ec 0c             	sub    $0xc,%esp
 988:	68 00 16 00 00       	push   $0x1600
 98d:	e8 ce fe ff ff       	call   860 <parsecmd>
 992:	89 04 24             	mov    %eax,(%esp)
 995:	e8 ea f6 ff ff       	call   84 <runcmd>
  exit();
 99a:	e8 82 01 00 00       	call   b21 <exit>

0000099f <start>:

// Entry point of the library	
void
start()
{
}
 99f:	c3                   	ret    

000009a0 <strcpy>:

char*
strcpy(char *s, const char *t)
{
 9a0:	55                   	push   %ebp
 9a1:	89 e5                	mov    %esp,%ebp
 9a3:	56                   	push   %esi
 9a4:	53                   	push   %ebx
 9a5:	8b 45 08             	mov    0x8(%ebp),%eax
 9a8:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 9ab:	89 c2                	mov    %eax,%edx
 9ad:	89 cb                	mov    %ecx,%ebx
 9af:	41                   	inc    %ecx
 9b0:	89 d6                	mov    %edx,%esi
 9b2:	42                   	inc    %edx
 9b3:	8a 1b                	mov    (%ebx),%bl
 9b5:	88 1e                	mov    %bl,(%esi)
 9b7:	84 db                	test   %bl,%bl
 9b9:	75 f2                	jne    9ad <strcpy+0xd>
    ;
  return os;
}
 9bb:	5b                   	pop    %ebx
 9bc:	5e                   	pop    %esi
 9bd:	5d                   	pop    %ebp
 9be:	c3                   	ret    

000009bf <strcmp>:

int
strcmp(const char *p, const char *q)
{
 9bf:	55                   	push   %ebp
 9c0:	89 e5                	mov    %esp,%ebp
 9c2:	8b 4d 08             	mov    0x8(%ebp),%ecx
 9c5:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
 9c8:	eb 02                	jmp    9cc <strcmp+0xd>
    p++, q++;
 9ca:	41                   	inc    %ecx
 9cb:	42                   	inc    %edx
  while(*p && *p == *q)
 9cc:	8a 01                	mov    (%ecx),%al
 9ce:	84 c0                	test   %al,%al
 9d0:	74 04                	je     9d6 <strcmp+0x17>
 9d2:	3a 02                	cmp    (%edx),%al
 9d4:	74 f4                	je     9ca <strcmp+0xb>
  return (uchar)*p - (uchar)*q;
 9d6:	0f b6 c0             	movzbl %al,%eax
 9d9:	0f b6 12             	movzbl (%edx),%edx
 9dc:	29 d0                	sub    %edx,%eax
}
 9de:	5d                   	pop    %ebp
 9df:	c3                   	ret    

000009e0 <strlen>:

uint
strlen(const char *s)
{
 9e0:	55                   	push   %ebp
 9e1:	89 e5                	mov    %esp,%ebp
 9e3:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
 9e6:	b8 00 00 00 00       	mov    $0x0,%eax
 9eb:	eb 01                	jmp    9ee <strlen+0xe>
 9ed:	40                   	inc    %eax
 9ee:	80 3c 01 00          	cmpb   $0x0,(%ecx,%eax,1)
 9f2:	75 f9                	jne    9ed <strlen+0xd>
    ;
  return n;
}
 9f4:	5d                   	pop    %ebp
 9f5:	c3                   	ret    

000009f6 <memset>:

void*
memset(void *dst, int c, uint n)
{
 9f6:	55                   	push   %ebp
 9f7:	89 e5                	mov    %esp,%ebp
 9f9:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 9fa:	8b 7d 08             	mov    0x8(%ebp),%edi
 9fd:	8b 4d 10             	mov    0x10(%ebp),%ecx
 a00:	8b 45 0c             	mov    0xc(%ebp),%eax
 a03:	fc                   	cld    
 a04:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 a06:	8b 45 08             	mov    0x8(%ebp),%eax
 a09:	8b 7d fc             	mov    -0x4(%ebp),%edi
 a0c:	c9                   	leave  
 a0d:	c3                   	ret    

00000a0e <strchr>:

char*
strchr(const char *s, char c)
{
 a0e:	55                   	push   %ebp
 a0f:	89 e5                	mov    %esp,%ebp
 a11:	8b 45 08             	mov    0x8(%ebp),%eax
 a14:	8a 4d 0c             	mov    0xc(%ebp),%cl
  for(; *s; s++)
 a17:	eb 01                	jmp    a1a <strchr+0xc>
 a19:	40                   	inc    %eax
 a1a:	8a 10                	mov    (%eax),%dl
 a1c:	84 d2                	test   %dl,%dl
 a1e:	74 06                	je     a26 <strchr+0x18>
    if(*s == c)
 a20:	38 ca                	cmp    %cl,%dl
 a22:	75 f5                	jne    a19 <strchr+0xb>
 a24:	eb 05                	jmp    a2b <strchr+0x1d>
      return (char*)s;
  return 0;
 a26:	b8 00 00 00 00       	mov    $0x0,%eax
}
 a2b:	5d                   	pop    %ebp
 a2c:	c3                   	ret    

00000a2d <gets>:

char*
gets(char *buf, int max)
{
 a2d:	55                   	push   %ebp
 a2e:	89 e5                	mov    %esp,%ebp
 a30:	57                   	push   %edi
 a31:	56                   	push   %esi
 a32:	53                   	push   %ebx
 a33:	83 ec 1c             	sub    $0x1c,%esp
 a36:	8b 7d 08             	mov    0x8(%ebp),%edi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 a39:	bb 00 00 00 00       	mov    $0x0,%ebx
 a3e:	89 de                	mov    %ebx,%esi
 a40:	43                   	inc    %ebx
 a41:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 a44:	7d 2b                	jge    a71 <gets+0x44>
    cc = read(0, &c, 1);
 a46:	83 ec 04             	sub    $0x4,%esp
 a49:	6a 01                	push   $0x1
 a4b:	8d 45 e7             	lea    -0x19(%ebp),%eax
 a4e:	50                   	push   %eax
 a4f:	6a 00                	push   $0x0
 a51:	e8 e3 00 00 00       	call   b39 <read>
    if(cc < 1)
 a56:	83 c4 10             	add    $0x10,%esp
 a59:	85 c0                	test   %eax,%eax
 a5b:	7e 14                	jle    a71 <gets+0x44>
      break;
    buf[i++] = c;
 a5d:	8a 45 e7             	mov    -0x19(%ebp),%al
 a60:	88 04 37             	mov    %al,(%edi,%esi,1)
    if(c == '\n' || c == '\r')
 a63:	3c 0a                	cmp    $0xa,%al
 a65:	74 08                	je     a6f <gets+0x42>
 a67:	3c 0d                	cmp    $0xd,%al
 a69:	75 d3                	jne    a3e <gets+0x11>
    buf[i++] = c;
 a6b:	89 de                	mov    %ebx,%esi
 a6d:	eb 02                	jmp    a71 <gets+0x44>
 a6f:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 a71:	c6 04 37 00          	movb   $0x0,(%edi,%esi,1)
  return buf;
}
 a75:	89 f8                	mov    %edi,%eax
 a77:	8d 65 f4             	lea    -0xc(%ebp),%esp
 a7a:	5b                   	pop    %ebx
 a7b:	5e                   	pop    %esi
 a7c:	5f                   	pop    %edi
 a7d:	5d                   	pop    %ebp
 a7e:	c3                   	ret    

00000a7f <stat>:

int
stat(const char *n, struct stat *st)
{
 a7f:	55                   	push   %ebp
 a80:	89 e5                	mov    %esp,%ebp
 a82:	56                   	push   %esi
 a83:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 a84:	83 ec 08             	sub    $0x8,%esp
 a87:	6a 00                	push   $0x0
 a89:	ff 75 08             	push   0x8(%ebp)
 a8c:	e8 d0 00 00 00       	call   b61 <open>
  if(fd < 0)
 a91:	83 c4 10             	add    $0x10,%esp
 a94:	85 c0                	test   %eax,%eax
 a96:	78 24                	js     abc <stat+0x3d>
 a98:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 a9a:	83 ec 08             	sub    $0x8,%esp
 a9d:	ff 75 0c             	push   0xc(%ebp)
 aa0:	50                   	push   %eax
 aa1:	e8 d3 00 00 00       	call   b79 <fstat>
 aa6:	89 c6                	mov    %eax,%esi
  close(fd);
 aa8:	89 1c 24             	mov    %ebx,(%esp)
 aab:	e8 99 00 00 00       	call   b49 <close>
  return r;
 ab0:	83 c4 10             	add    $0x10,%esp
}
 ab3:	89 f0                	mov    %esi,%eax
 ab5:	8d 65 f8             	lea    -0x8(%ebp),%esp
 ab8:	5b                   	pop    %ebx
 ab9:	5e                   	pop    %esi
 aba:	5d                   	pop    %ebp
 abb:	c3                   	ret    
    return -1;
 abc:	be ff ff ff ff       	mov    $0xffffffff,%esi
 ac1:	eb f0                	jmp    ab3 <stat+0x34>

00000ac3 <atoi>:

int
atoi(const char *s)
{
 ac3:	55                   	push   %ebp
 ac4:	89 e5                	mov    %esp,%ebp
 ac6:	53                   	push   %ebx
 ac7:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
 aca:	ba 00 00 00 00       	mov    $0x0,%edx
  while('0' <= *s && *s <= '9')
 acf:	eb 0e                	jmp    adf <atoi+0x1c>
    n = n*10 + *s++ - '0';
 ad1:	8d 14 92             	lea    (%edx,%edx,4),%edx
 ad4:	8d 1c 12             	lea    (%edx,%edx,1),%ebx
 ad7:	41                   	inc    %ecx
 ad8:	0f be c0             	movsbl %al,%eax
 adb:	8d 54 18 d0          	lea    -0x30(%eax,%ebx,1),%edx
  while('0' <= *s && *s <= '9')
 adf:	8a 01                	mov    (%ecx),%al
 ae1:	8d 58 d0             	lea    -0x30(%eax),%ebx
 ae4:	80 fb 09             	cmp    $0x9,%bl
 ae7:	76 e8                	jbe    ad1 <atoi+0xe>
  return n;
}
 ae9:	89 d0                	mov    %edx,%eax
 aeb:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 aee:	c9                   	leave  
 aef:	c3                   	ret    

00000af0 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 af0:	55                   	push   %ebp
 af1:	89 e5                	mov    %esp,%ebp
 af3:	56                   	push   %esi
 af4:	53                   	push   %ebx
 af5:	8b 45 08             	mov    0x8(%ebp),%eax
 af8:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 afb:	8b 55 10             	mov    0x10(%ebp),%edx
  char *dst;
  const char *src;

  dst = vdst;
 afe:	89 c1                	mov    %eax,%ecx
  src = vsrc;
  while(n-- > 0)
 b00:	eb 0c                	jmp    b0e <memmove+0x1e>
    *dst++ = *src++;
 b02:	8a 13                	mov    (%ebx),%dl
 b04:	88 11                	mov    %dl,(%ecx)
 b06:	8d 5b 01             	lea    0x1(%ebx),%ebx
 b09:	8d 49 01             	lea    0x1(%ecx),%ecx
  while(n-- > 0)
 b0c:	89 f2                	mov    %esi,%edx
 b0e:	8d 72 ff             	lea    -0x1(%edx),%esi
 b11:	85 d2                	test   %edx,%edx
 b13:	7f ed                	jg     b02 <memmove+0x12>
  return vdst;
}
 b15:	5b                   	pop    %ebx
 b16:	5e                   	pop    %esi
 b17:	5d                   	pop    %ebp
 b18:	c3                   	ret    

00000b19 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 b19:	b8 01 00 00 00       	mov    $0x1,%eax
 b1e:	cd 40                	int    $0x40
 b20:	c3                   	ret    

00000b21 <exit>:
SYSCALL(exit)
 b21:	b8 02 00 00 00       	mov    $0x2,%eax
 b26:	cd 40                	int    $0x40
 b28:	c3                   	ret    

00000b29 <wait>:
SYSCALL(wait)
 b29:	b8 03 00 00 00       	mov    $0x3,%eax
 b2e:	cd 40                	int    $0x40
 b30:	c3                   	ret    

00000b31 <pipe>:
SYSCALL(pipe)
 b31:	b8 04 00 00 00       	mov    $0x4,%eax
 b36:	cd 40                	int    $0x40
 b38:	c3                   	ret    

00000b39 <read>:
SYSCALL(read)
 b39:	b8 05 00 00 00       	mov    $0x5,%eax
 b3e:	cd 40                	int    $0x40
 b40:	c3                   	ret    

00000b41 <write>:
SYSCALL(write)
 b41:	b8 10 00 00 00       	mov    $0x10,%eax
 b46:	cd 40                	int    $0x40
 b48:	c3                   	ret    

00000b49 <close>:
SYSCALL(close)
 b49:	b8 15 00 00 00       	mov    $0x15,%eax
 b4e:	cd 40                	int    $0x40
 b50:	c3                   	ret    

00000b51 <kill>:
SYSCALL(kill)
 b51:	b8 06 00 00 00       	mov    $0x6,%eax
 b56:	cd 40                	int    $0x40
 b58:	c3                   	ret    

00000b59 <exec>:
SYSCALL(exec)
 b59:	b8 07 00 00 00       	mov    $0x7,%eax
 b5e:	cd 40                	int    $0x40
 b60:	c3                   	ret    

00000b61 <open>:
SYSCALL(open)
 b61:	b8 0f 00 00 00       	mov    $0xf,%eax
 b66:	cd 40                	int    $0x40
 b68:	c3                   	ret    

00000b69 <mknod>:
SYSCALL(mknod)
 b69:	b8 11 00 00 00       	mov    $0x11,%eax
 b6e:	cd 40                	int    $0x40
 b70:	c3                   	ret    

00000b71 <unlink>:
SYSCALL(unlink)
 b71:	b8 12 00 00 00       	mov    $0x12,%eax
 b76:	cd 40                	int    $0x40
 b78:	c3                   	ret    

00000b79 <fstat>:
SYSCALL(fstat)
 b79:	b8 08 00 00 00       	mov    $0x8,%eax
 b7e:	cd 40                	int    $0x40
 b80:	c3                   	ret    

00000b81 <link>:
SYSCALL(link)
 b81:	b8 13 00 00 00       	mov    $0x13,%eax
 b86:	cd 40                	int    $0x40
 b88:	c3                   	ret    

00000b89 <mkdir>:
SYSCALL(mkdir)
 b89:	b8 14 00 00 00       	mov    $0x14,%eax
 b8e:	cd 40                	int    $0x40
 b90:	c3                   	ret    

00000b91 <chdir>:
SYSCALL(chdir)
 b91:	b8 09 00 00 00       	mov    $0x9,%eax
 b96:	cd 40                	int    $0x40
 b98:	c3                   	ret    

00000b99 <dup>:
SYSCALL(dup)
 b99:	b8 0a 00 00 00       	mov    $0xa,%eax
 b9e:	cd 40                	int    $0x40
 ba0:	c3                   	ret    

00000ba1 <getpid>:
SYSCALL(getpid)
 ba1:	b8 0b 00 00 00       	mov    $0xb,%eax
 ba6:	cd 40                	int    $0x40
 ba8:	c3                   	ret    

00000ba9 <sbrk>:
SYSCALL(sbrk)
 ba9:	b8 0c 00 00 00       	mov    $0xc,%eax
 bae:	cd 40                	int    $0x40
 bb0:	c3                   	ret    

00000bb1 <sleep>:
SYSCALL(sleep)
 bb1:	b8 0d 00 00 00       	mov    $0xd,%eax
 bb6:	cd 40                	int    $0x40
 bb8:	c3                   	ret    

00000bb9 <uptime>:
SYSCALL(uptime)
 bb9:	b8 0e 00 00 00       	mov    $0xe,%eax
 bbe:	cd 40                	int    $0x40
 bc0:	c3                   	ret    

00000bc1 <date>:
SYSCALL(date)
 bc1:	b8 16 00 00 00       	mov    $0x16,%eax
 bc6:	cd 40                	int    $0x40
 bc8:	c3                   	ret    

00000bc9 <dup2>:
SYSCALL(dup2)
 bc9:	b8 17 00 00 00       	mov    $0x17,%eax
 bce:	cd 40                	int    $0x40
 bd0:	c3                   	ret    

00000bd1 <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 bd1:	55                   	push   %ebp
 bd2:	89 e5                	mov    %esp,%ebp
 bd4:	83 ec 1c             	sub    $0x1c,%esp
 bd7:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 bda:	6a 01                	push   $0x1
 bdc:	8d 55 f4             	lea    -0xc(%ebp),%edx
 bdf:	52                   	push   %edx
 be0:	50                   	push   %eax
 be1:	e8 5b ff ff ff       	call   b41 <write>
}
 be6:	83 c4 10             	add    $0x10,%esp
 be9:	c9                   	leave  
 bea:	c3                   	ret    

00000beb <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 beb:	55                   	push   %ebp
 bec:	89 e5                	mov    %esp,%ebp
 bee:	57                   	push   %edi
 bef:	56                   	push   %esi
 bf0:	53                   	push   %ebx
 bf1:	83 ec 2c             	sub    $0x2c,%esp
 bf4:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 bf7:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 bf9:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 bfd:	74 04                	je     c03 <printint+0x18>
 bff:	85 d2                	test   %edx,%edx
 c01:	78 3c                	js     c3f <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 c03:	89 d1                	mov    %edx,%ecx
  neg = 0;
 c05:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 c0c:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 c11:	89 c8                	mov    %ecx,%eax
 c13:	ba 00 00 00 00       	mov    $0x0,%edx
 c18:	f7 f6                	div    %esi
 c1a:	89 df                	mov    %ebx,%edi
 c1c:	43                   	inc    %ebx
 c1d:	8a 92 54 10 00 00    	mov    0x1054(%edx),%dl
 c23:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 c27:	89 ca                	mov    %ecx,%edx
 c29:	89 c1                	mov    %eax,%ecx
 c2b:	39 d6                	cmp    %edx,%esi
 c2d:	76 e2                	jbe    c11 <printint+0x26>
  if(neg)
 c2f:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 c33:	74 24                	je     c59 <printint+0x6e>
    buf[i++] = '-';
 c35:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 c3a:	8d 5f 02             	lea    0x2(%edi),%ebx
 c3d:	eb 1a                	jmp    c59 <printint+0x6e>
    x = -xx;
 c3f:	89 d1                	mov    %edx,%ecx
 c41:	f7 d9                	neg    %ecx
    neg = 1;
 c43:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 c4a:	eb c0                	jmp    c0c <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 c4c:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 c51:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 c54:	e8 78 ff ff ff       	call   bd1 <putc>
  while(--i >= 0)
 c59:	4b                   	dec    %ebx
 c5a:	79 f0                	jns    c4c <printint+0x61>
}
 c5c:	83 c4 2c             	add    $0x2c,%esp
 c5f:	5b                   	pop    %ebx
 c60:	5e                   	pop    %esi
 c61:	5f                   	pop    %edi
 c62:	5d                   	pop    %ebp
 c63:	c3                   	ret    

00000c64 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 c64:	55                   	push   %ebp
 c65:	89 e5                	mov    %esp,%ebp
 c67:	57                   	push   %edi
 c68:	56                   	push   %esi
 c69:	53                   	push   %ebx
 c6a:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 c6d:	8d 45 10             	lea    0x10(%ebp),%eax
 c70:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 c73:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 c78:	bb 00 00 00 00       	mov    $0x0,%ebx
 c7d:	eb 12                	jmp    c91 <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 c7f:	89 fa                	mov    %edi,%edx
 c81:	8b 45 08             	mov    0x8(%ebp),%eax
 c84:	e8 48 ff ff ff       	call   bd1 <putc>
 c89:	eb 05                	jmp    c90 <printf+0x2c>
      }
    } else if(state == '%'){
 c8b:	83 fe 25             	cmp    $0x25,%esi
 c8e:	74 22                	je     cb2 <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 c90:	43                   	inc    %ebx
 c91:	8b 45 0c             	mov    0xc(%ebp),%eax
 c94:	8a 04 18             	mov    (%eax,%ebx,1),%al
 c97:	84 c0                	test   %al,%al
 c99:	0f 84 1d 01 00 00    	je     dbc <printf+0x158>
    c = fmt[i] & 0xff;
 c9f:	0f be f8             	movsbl %al,%edi
 ca2:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 ca5:	85 f6                	test   %esi,%esi
 ca7:	75 e2                	jne    c8b <printf+0x27>
      if(c == '%'){
 ca9:	83 f8 25             	cmp    $0x25,%eax
 cac:	75 d1                	jne    c7f <printf+0x1b>
        state = '%';
 cae:	89 c6                	mov    %eax,%esi
 cb0:	eb de                	jmp    c90 <printf+0x2c>
      if(c == 'd'){
 cb2:	83 f8 25             	cmp    $0x25,%eax
 cb5:	0f 84 cc 00 00 00    	je     d87 <printf+0x123>
 cbb:	0f 8c da 00 00 00    	jl     d9b <printf+0x137>
 cc1:	83 f8 78             	cmp    $0x78,%eax
 cc4:	0f 8f d1 00 00 00    	jg     d9b <printf+0x137>
 cca:	83 f8 63             	cmp    $0x63,%eax
 ccd:	0f 8c c8 00 00 00    	jl     d9b <printf+0x137>
 cd3:	83 e8 63             	sub    $0x63,%eax
 cd6:	83 f8 15             	cmp    $0x15,%eax
 cd9:	0f 87 bc 00 00 00    	ja     d9b <printf+0x137>
 cdf:	ff 24 85 fc 0f 00 00 	jmp    *0xffc(,%eax,4)
        printint(fd, *ap, 10, 1);
 ce6:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 ce9:	8b 17                	mov    (%edi),%edx
 ceb:	83 ec 0c             	sub    $0xc,%esp
 cee:	6a 01                	push   $0x1
 cf0:	b9 0a 00 00 00       	mov    $0xa,%ecx
 cf5:	8b 45 08             	mov    0x8(%ebp),%eax
 cf8:	e8 ee fe ff ff       	call   beb <printint>
        ap++;
 cfd:	83 c7 04             	add    $0x4,%edi
 d00:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 d03:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 d06:	be 00 00 00 00       	mov    $0x0,%esi
 d0b:	eb 83                	jmp    c90 <printf+0x2c>
        printint(fd, *ap, 16, 0);
 d0d:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 d10:	8b 17                	mov    (%edi),%edx
 d12:	83 ec 0c             	sub    $0xc,%esp
 d15:	6a 00                	push   $0x0
 d17:	b9 10 00 00 00       	mov    $0x10,%ecx
 d1c:	8b 45 08             	mov    0x8(%ebp),%eax
 d1f:	e8 c7 fe ff ff       	call   beb <printint>
        ap++;
 d24:	83 c7 04             	add    $0x4,%edi
 d27:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 d2a:	83 c4 10             	add    $0x10,%esp
      state = 0;
 d2d:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 d32:	e9 59 ff ff ff       	jmp    c90 <printf+0x2c>
        s = (char*)*ap;
 d37:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 d3a:	8b 30                	mov    (%eax),%esi
        ap++;
 d3c:	83 c0 04             	add    $0x4,%eax
 d3f:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 d42:	85 f6                	test   %esi,%esi
 d44:	75 13                	jne    d59 <printf+0xf5>
          s = "(null)";
 d46:	be f4 0f 00 00       	mov    $0xff4,%esi
 d4b:	eb 0c                	jmp    d59 <printf+0xf5>
          putc(fd, *s);
 d4d:	0f be d2             	movsbl %dl,%edx
 d50:	8b 45 08             	mov    0x8(%ebp),%eax
 d53:	e8 79 fe ff ff       	call   bd1 <putc>
          s++;
 d58:	46                   	inc    %esi
        while(*s != 0){
 d59:	8a 16                	mov    (%esi),%dl
 d5b:	84 d2                	test   %dl,%dl
 d5d:	75 ee                	jne    d4d <printf+0xe9>
      state = 0;
 d5f:	be 00 00 00 00       	mov    $0x0,%esi
 d64:	e9 27 ff ff ff       	jmp    c90 <printf+0x2c>
        putc(fd, *ap);
 d69:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 d6c:	0f be 17             	movsbl (%edi),%edx
 d6f:	8b 45 08             	mov    0x8(%ebp),%eax
 d72:	e8 5a fe ff ff       	call   bd1 <putc>
        ap++;
 d77:	83 c7 04             	add    $0x4,%edi
 d7a:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 d7d:	be 00 00 00 00       	mov    $0x0,%esi
 d82:	e9 09 ff ff ff       	jmp    c90 <printf+0x2c>
        putc(fd, c);
 d87:	89 fa                	mov    %edi,%edx
 d89:	8b 45 08             	mov    0x8(%ebp),%eax
 d8c:	e8 40 fe ff ff       	call   bd1 <putc>
      state = 0;
 d91:	be 00 00 00 00       	mov    $0x0,%esi
 d96:	e9 f5 fe ff ff       	jmp    c90 <printf+0x2c>
        putc(fd, '%');
 d9b:	ba 25 00 00 00       	mov    $0x25,%edx
 da0:	8b 45 08             	mov    0x8(%ebp),%eax
 da3:	e8 29 fe ff ff       	call   bd1 <putc>
        putc(fd, c);
 da8:	89 fa                	mov    %edi,%edx
 daa:	8b 45 08             	mov    0x8(%ebp),%eax
 dad:	e8 1f fe ff ff       	call   bd1 <putc>
      state = 0;
 db2:	be 00 00 00 00       	mov    $0x0,%esi
 db7:	e9 d4 fe ff ff       	jmp    c90 <printf+0x2c>
    }
  }
}
 dbc:	8d 65 f4             	lea    -0xc(%ebp),%esp
 dbf:	5b                   	pop    %ebx
 dc0:	5e                   	pop    %esi
 dc1:	5f                   	pop    %edi
 dc2:	5d                   	pop    %ebp
 dc3:	c3                   	ret    

00000dc4 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 dc4:	55                   	push   %ebp
 dc5:	89 e5                	mov    %esp,%ebp
 dc7:	57                   	push   %edi
 dc8:	56                   	push   %esi
 dc9:	53                   	push   %ebx
 dca:	8b 5d 08             	mov    0x8(%ebp),%ebx
  Header *bp, *p;

  bp = (Header*)ap - 1;
 dcd:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 dd0:	a1 64 16 00 00       	mov    0x1664,%eax
 dd5:	eb 02                	jmp    dd9 <free+0x15>
 dd7:	89 d0                	mov    %edx,%eax
 dd9:	39 c8                	cmp    %ecx,%eax
 ddb:	73 04                	jae    de1 <free+0x1d>
 ddd:	39 08                	cmp    %ecx,(%eax)
 ddf:	77 12                	ja     df3 <free+0x2f>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 de1:	8b 10                	mov    (%eax),%edx
 de3:	39 c2                	cmp    %eax,%edx
 de5:	77 f0                	ja     dd7 <free+0x13>
 de7:	39 c8                	cmp    %ecx,%eax
 de9:	72 08                	jb     df3 <free+0x2f>
 deb:	39 ca                	cmp    %ecx,%edx
 ded:	77 04                	ja     df3 <free+0x2f>
 def:	89 d0                	mov    %edx,%eax
 df1:	eb e6                	jmp    dd9 <free+0x15>
      break;
  if(bp + bp->s.size == p->s.ptr){
 df3:	8b 73 fc             	mov    -0x4(%ebx),%esi
 df6:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 df9:	8b 10                	mov    (%eax),%edx
 dfb:	39 d7                	cmp    %edx,%edi
 dfd:	74 19                	je     e18 <free+0x54>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
 dff:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
 e02:	8b 50 04             	mov    0x4(%eax),%edx
 e05:	8d 34 d0             	lea    (%eax,%edx,8),%esi
 e08:	39 ce                	cmp    %ecx,%esi
 e0a:	74 1b                	je     e27 <free+0x63>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
 e0c:	89 08                	mov    %ecx,(%eax)
  freep = p;
 e0e:	a3 64 16 00 00       	mov    %eax,0x1664
}
 e13:	5b                   	pop    %ebx
 e14:	5e                   	pop    %esi
 e15:	5f                   	pop    %edi
 e16:	5d                   	pop    %ebp
 e17:	c3                   	ret    
    bp->s.size += p->s.ptr->s.size;
 e18:	03 72 04             	add    0x4(%edx),%esi
 e1b:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 e1e:	8b 10                	mov    (%eax),%edx
 e20:	8b 12                	mov    (%edx),%edx
 e22:	89 53 f8             	mov    %edx,-0x8(%ebx)
 e25:	eb db                	jmp    e02 <free+0x3e>
    p->s.size += bp->s.size;
 e27:	03 53 fc             	add    -0x4(%ebx),%edx
 e2a:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
 e2d:	8b 53 f8             	mov    -0x8(%ebx),%edx
 e30:	89 10                	mov    %edx,(%eax)
 e32:	eb da                	jmp    e0e <free+0x4a>

00000e34 <morecore>:

static Header*
morecore(uint nu)
{
 e34:	55                   	push   %ebp
 e35:	89 e5                	mov    %esp,%ebp
 e37:	53                   	push   %ebx
 e38:	83 ec 04             	sub    $0x4,%esp
 e3b:	89 c3                	mov    %eax,%ebx
  char *p;
  Header *hp;

  if(nu < 4096)
 e3d:	3d ff 0f 00 00       	cmp    $0xfff,%eax
 e42:	77 05                	ja     e49 <morecore+0x15>
    nu = 4096;
 e44:	bb 00 10 00 00       	mov    $0x1000,%ebx
  p = sbrk(nu * sizeof(Header));
 e49:	8d 04 dd 00 00 00 00 	lea    0x0(,%ebx,8),%eax
 e50:	83 ec 0c             	sub    $0xc,%esp
 e53:	50                   	push   %eax
 e54:	e8 50 fd ff ff       	call   ba9 <sbrk>
  if(p == (char*)-1)
 e59:	83 c4 10             	add    $0x10,%esp
 e5c:	83 f8 ff             	cmp    $0xffffffff,%eax
 e5f:	74 1c                	je     e7d <morecore+0x49>
    return 0;
  hp = (Header*)p;
  hp->s.size = nu;
 e61:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 e64:	83 c0 08             	add    $0x8,%eax
 e67:	83 ec 0c             	sub    $0xc,%esp
 e6a:	50                   	push   %eax
 e6b:	e8 54 ff ff ff       	call   dc4 <free>
  return freep;
 e70:	a1 64 16 00 00       	mov    0x1664,%eax
 e75:	83 c4 10             	add    $0x10,%esp
}
 e78:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 e7b:	c9                   	leave  
 e7c:	c3                   	ret    
    return 0;
 e7d:	b8 00 00 00 00       	mov    $0x0,%eax
 e82:	eb f4                	jmp    e78 <morecore+0x44>

00000e84 <malloc>:

void*
malloc(uint nbytes)
{
 e84:	55                   	push   %ebp
 e85:	89 e5                	mov    %esp,%ebp
 e87:	53                   	push   %ebx
 e88:	83 ec 04             	sub    $0x4,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 e8b:	8b 45 08             	mov    0x8(%ebp),%eax
 e8e:	8d 58 07             	lea    0x7(%eax),%ebx
 e91:	c1 eb 03             	shr    $0x3,%ebx
 e94:	43                   	inc    %ebx
  if((prevp = freep) == 0){
 e95:	8b 0d 64 16 00 00    	mov    0x1664,%ecx
 e9b:	85 c9                	test   %ecx,%ecx
 e9d:	74 04                	je     ea3 <malloc+0x1f>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 e9f:	8b 01                	mov    (%ecx),%eax
 ea1:	eb 4a                	jmp    eed <malloc+0x69>
    base.s.ptr = freep = prevp = &base;
 ea3:	c7 05 64 16 00 00 68 	movl   $0x1668,0x1664
 eaa:	16 00 00 
 ead:	c7 05 68 16 00 00 68 	movl   $0x1668,0x1668
 eb4:	16 00 00 
    base.s.size = 0;
 eb7:	c7 05 6c 16 00 00 00 	movl   $0x0,0x166c
 ebe:	00 00 00 
    base.s.ptr = freep = prevp = &base;
 ec1:	b9 68 16 00 00       	mov    $0x1668,%ecx
 ec6:	eb d7                	jmp    e9f <malloc+0x1b>
    if(p->s.size >= nunits){
      if(p->s.size == nunits)
 ec8:	74 19                	je     ee3 <malloc+0x5f>
        prevp->s.ptr = p->s.ptr;
      else {
        p->s.size -= nunits;
 eca:	29 da                	sub    %ebx,%edx
 ecc:	89 50 04             	mov    %edx,0x4(%eax)
        p += p->s.size;
 ecf:	8d 04 d0             	lea    (%eax,%edx,8),%eax
        p->s.size = nunits;
 ed2:	89 58 04             	mov    %ebx,0x4(%eax)
      }
      freep = prevp;
 ed5:	89 0d 64 16 00 00    	mov    %ecx,0x1664
      return (void*)(p + 1);
 edb:	83 c0 08             	add    $0x8,%eax
    }
    if(p == freep)
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 ede:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 ee1:	c9                   	leave  
 ee2:	c3                   	ret    
        prevp->s.ptr = p->s.ptr;
 ee3:	8b 10                	mov    (%eax),%edx
 ee5:	89 11                	mov    %edx,(%ecx)
 ee7:	eb ec                	jmp    ed5 <malloc+0x51>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 ee9:	89 c1                	mov    %eax,%ecx
 eeb:	8b 00                	mov    (%eax),%eax
    if(p->s.size >= nunits){
 eed:	8b 50 04             	mov    0x4(%eax),%edx
 ef0:	39 da                	cmp    %ebx,%edx
 ef2:	73 d4                	jae    ec8 <malloc+0x44>
    if(p == freep)
 ef4:	39 05 64 16 00 00    	cmp    %eax,0x1664
 efa:	75 ed                	jne    ee9 <malloc+0x65>
      if((p = morecore(nunits)) == 0)
 efc:	89 d8                	mov    %ebx,%eax
 efe:	e8 31 ff ff ff       	call   e34 <morecore>
 f03:	85 c0                	test   %eax,%eax
 f05:	75 e2                	jne    ee9 <malloc+0x65>
 f07:	eb d5                	jmp    ede <malloc+0x5a>
