
init:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <main>:

char *argv[] = { "sh", 0 };

int
main(void)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	53                   	push   %ebx
   e:	51                   	push   %ecx
  int pid, wpid;

  if(open("console", O_RDWR) < 0){
   f:	83 ec 08             	sub    $0x8,%esp
  12:	6a 02                	push   $0x2
  14:	68 88 03 00 00       	push   $0x388
  19:	e8 07 01 00 00       	call   125 <open>
  1e:	83 c4 10             	add    $0x10,%esp
  21:	85 c0                	test   %eax,%eax
  23:	78 1b                	js     40 <main+0x40>
    mknod("console", 1, 1);
    open("console", O_RDWR);
  }
  dup(0);  // stdout
  25:	83 ec 0c             	sub    $0xc,%esp
  28:	6a 00                	push   $0x0
  2a:	e8 2e 01 00 00       	call   15d <dup>
  dup(0);  // stderr
  2f:	c7 04 24 00 00 00 00 	movl   $0x0,(%esp)
  36:	e8 22 01 00 00       	call   15d <dup>
  3b:	83 c4 10             	add    $0x10,%esp
  3e:	eb 58                	jmp    98 <main+0x98>
    mknod("console", 1, 1);
  40:	83 ec 04             	sub    $0x4,%esp
  43:	6a 01                	push   $0x1
  45:	6a 01                	push   $0x1
  47:	68 88 03 00 00       	push   $0x388
  4c:	e8 dc 00 00 00       	call   12d <mknod>
    open("console", O_RDWR);
  51:	83 c4 08             	add    $0x8,%esp
  54:	6a 02                	push   $0x2
  56:	68 88 03 00 00       	push   $0x388
  5b:	e8 c5 00 00 00       	call   125 <open>
  60:	83 c4 10             	add    $0x10,%esp
  63:	eb c0                	jmp    25 <main+0x25>

  for(;;){
    printf(1, "init: starting sh\n");
    pid = fork();
    if(pid < 0){
      printf(1, "init: fork failed\n");
  65:	83 ec 08             	sub    $0x8,%esp
  68:	68 a3 03 00 00       	push   $0x3a3
  6d:	6a 01                	push   $0x1
  6f:	e8 b4 01 00 00       	call   228 <printf>
      exit();
  74:	e8 6c 00 00 00       	call   e5 <exit>
      exec("sh", argv);
      printf(1, "init: exec sh failed\n");
      exit();
    }
    while((wpid=wait()) >= 0 && wpid != pid)
      printf(1, "zombie!\n");
  79:	83 ec 08             	sub    $0x8,%esp
  7c:	68 cf 03 00 00       	push   $0x3cf
  81:	6a 01                	push   $0x1
  83:	e8 a0 01 00 00       	call   228 <printf>
  88:	83 c4 10             	add    $0x10,%esp
    while((wpid=wait()) >= 0 && wpid != pid)
  8b:	e8 5d 00 00 00       	call   ed <wait>
  90:	85 c0                	test   %eax,%eax
  92:	78 04                	js     98 <main+0x98>
  94:	39 c3                	cmp    %eax,%ebx
  96:	75 e1                	jne    79 <main+0x79>
    printf(1, "init: starting sh\n");
  98:	83 ec 08             	sub    $0x8,%esp
  9b:	68 90 03 00 00       	push   $0x390
  a0:	6a 01                	push   $0x1
  a2:	e8 81 01 00 00       	call   228 <printf>
    pid = fork();
  a7:	e8 31 00 00 00       	call   dd <fork>
  ac:	89 c3                	mov    %eax,%ebx
    if(pid < 0){
  ae:	83 c4 10             	add    $0x10,%esp
  b1:	85 c0                	test   %eax,%eax
  b3:	78 b0                	js     65 <main+0x65>
    if(pid == 0){
  b5:	75 d4                	jne    8b <main+0x8b>
      exec("sh", argv);
  b7:	83 ec 08             	sub    $0x8,%esp
  ba:	68 08 05 00 00       	push   $0x508
  bf:	68 b6 03 00 00       	push   $0x3b6
  c4:	e8 54 00 00 00       	call   11d <exec>
      printf(1, "init: exec sh failed\n");
  c9:	83 c4 08             	add    $0x8,%esp
  cc:	68 b9 03 00 00       	push   $0x3b9
  d1:	6a 01                	push   $0x1
  d3:	e8 50 01 00 00       	call   228 <printf>
      exit();
  d8:	e8 08 00 00 00       	call   e5 <exit>

000000dd <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
  dd:	b8 01 00 00 00       	mov    $0x1,%eax
  e2:	cd 40                	int    $0x40
  e4:	c3                   	ret    

000000e5 <exit>:
SYSCALL(exit)
  e5:	b8 02 00 00 00       	mov    $0x2,%eax
  ea:	cd 40                	int    $0x40
  ec:	c3                   	ret    

000000ed <wait>:
SYSCALL(wait)
  ed:	b8 03 00 00 00       	mov    $0x3,%eax
  f2:	cd 40                	int    $0x40
  f4:	c3                   	ret    

000000f5 <pipe>:
SYSCALL(pipe)
  f5:	b8 04 00 00 00       	mov    $0x4,%eax
  fa:	cd 40                	int    $0x40
  fc:	c3                   	ret    

000000fd <read>:
SYSCALL(read)
  fd:	b8 05 00 00 00       	mov    $0x5,%eax
 102:	cd 40                	int    $0x40
 104:	c3                   	ret    

00000105 <write>:
SYSCALL(write)
 105:	b8 10 00 00 00       	mov    $0x10,%eax
 10a:	cd 40                	int    $0x40
 10c:	c3                   	ret    

0000010d <close>:
SYSCALL(close)
 10d:	b8 15 00 00 00       	mov    $0x15,%eax
 112:	cd 40                	int    $0x40
 114:	c3                   	ret    

00000115 <kill>:
SYSCALL(kill)
 115:	b8 06 00 00 00       	mov    $0x6,%eax
 11a:	cd 40                	int    $0x40
 11c:	c3                   	ret    

0000011d <exec>:
SYSCALL(exec)
 11d:	b8 07 00 00 00       	mov    $0x7,%eax
 122:	cd 40                	int    $0x40
 124:	c3                   	ret    

00000125 <open>:
SYSCALL(open)
 125:	b8 0f 00 00 00       	mov    $0xf,%eax
 12a:	cd 40                	int    $0x40
 12c:	c3                   	ret    

0000012d <mknod>:
SYSCALL(mknod)
 12d:	b8 11 00 00 00       	mov    $0x11,%eax
 132:	cd 40                	int    $0x40
 134:	c3                   	ret    

00000135 <unlink>:
SYSCALL(unlink)
 135:	b8 12 00 00 00       	mov    $0x12,%eax
 13a:	cd 40                	int    $0x40
 13c:	c3                   	ret    

0000013d <fstat>:
SYSCALL(fstat)
 13d:	b8 08 00 00 00       	mov    $0x8,%eax
 142:	cd 40                	int    $0x40
 144:	c3                   	ret    

00000145 <link>:
SYSCALL(link)
 145:	b8 13 00 00 00       	mov    $0x13,%eax
 14a:	cd 40                	int    $0x40
 14c:	c3                   	ret    

0000014d <mkdir>:
SYSCALL(mkdir)
 14d:	b8 14 00 00 00       	mov    $0x14,%eax
 152:	cd 40                	int    $0x40
 154:	c3                   	ret    

00000155 <chdir>:
SYSCALL(chdir)
 155:	b8 09 00 00 00       	mov    $0x9,%eax
 15a:	cd 40                	int    $0x40
 15c:	c3                   	ret    

0000015d <dup>:
SYSCALL(dup)
 15d:	b8 0a 00 00 00       	mov    $0xa,%eax
 162:	cd 40                	int    $0x40
 164:	c3                   	ret    

00000165 <getpid>:
SYSCALL(getpid)
 165:	b8 0b 00 00 00       	mov    $0xb,%eax
 16a:	cd 40                	int    $0x40
 16c:	c3                   	ret    

0000016d <sbrk>:
SYSCALL(sbrk)
 16d:	b8 0c 00 00 00       	mov    $0xc,%eax
 172:	cd 40                	int    $0x40
 174:	c3                   	ret    

00000175 <sleep>:
SYSCALL(sleep)
 175:	b8 0d 00 00 00       	mov    $0xd,%eax
 17a:	cd 40                	int    $0x40
 17c:	c3                   	ret    

0000017d <uptime>:
SYSCALL(uptime)
 17d:	b8 0e 00 00 00       	mov    $0xe,%eax
 182:	cd 40                	int    $0x40
 184:	c3                   	ret    

00000185 <date>:
SYSCALL(date)
 185:	b8 16 00 00 00       	mov    $0x16,%eax
 18a:	cd 40                	int    $0x40
 18c:	c3                   	ret    

0000018d <dup2>:
SYSCALL(dup2)
 18d:	b8 17 00 00 00       	mov    $0x17,%eax
 192:	cd 40                	int    $0x40
 194:	c3                   	ret    

00000195 <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 195:	55                   	push   %ebp
 196:	89 e5                	mov    %esp,%ebp
 198:	83 ec 1c             	sub    $0x1c,%esp
 19b:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 19e:	6a 01                	push   $0x1
 1a0:	8d 55 f4             	lea    -0xc(%ebp),%edx
 1a3:	52                   	push   %edx
 1a4:	50                   	push   %eax
 1a5:	e8 5b ff ff ff       	call   105 <write>
}
 1aa:	83 c4 10             	add    $0x10,%esp
 1ad:	c9                   	leave  
 1ae:	c3                   	ret    

000001af <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 1af:	55                   	push   %ebp
 1b0:	89 e5                	mov    %esp,%ebp
 1b2:	57                   	push   %edi
 1b3:	56                   	push   %esi
 1b4:	53                   	push   %ebx
 1b5:	83 ec 2c             	sub    $0x2c,%esp
 1b8:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 1bb:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 1bd:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 1c1:	74 04                	je     1c7 <printint+0x18>
 1c3:	85 d2                	test   %edx,%edx
 1c5:	78 3c                	js     203 <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 1c7:	89 d1                	mov    %edx,%ecx
  neg = 0;
 1c9:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 1d0:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 1d5:	89 c8                	mov    %ecx,%eax
 1d7:	ba 00 00 00 00       	mov    $0x0,%edx
 1dc:	f7 f6                	div    %esi
 1de:	89 df                	mov    %ebx,%edi
 1e0:	43                   	inc    %ebx
 1e1:	8a 92 38 04 00 00    	mov    0x438(%edx),%dl
 1e7:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 1eb:	89 ca                	mov    %ecx,%edx
 1ed:	89 c1                	mov    %eax,%ecx
 1ef:	39 d6                	cmp    %edx,%esi
 1f1:	76 e2                	jbe    1d5 <printint+0x26>
  if(neg)
 1f3:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 1f7:	74 24                	je     21d <printint+0x6e>
    buf[i++] = '-';
 1f9:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 1fe:	8d 5f 02             	lea    0x2(%edi),%ebx
 201:	eb 1a                	jmp    21d <printint+0x6e>
    x = -xx;
 203:	89 d1                	mov    %edx,%ecx
 205:	f7 d9                	neg    %ecx
    neg = 1;
 207:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 20e:	eb c0                	jmp    1d0 <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 210:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 215:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 218:	e8 78 ff ff ff       	call   195 <putc>
  while(--i >= 0)
 21d:	4b                   	dec    %ebx
 21e:	79 f0                	jns    210 <printint+0x61>
}
 220:	83 c4 2c             	add    $0x2c,%esp
 223:	5b                   	pop    %ebx
 224:	5e                   	pop    %esi
 225:	5f                   	pop    %edi
 226:	5d                   	pop    %ebp
 227:	c3                   	ret    

00000228 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 228:	55                   	push   %ebp
 229:	89 e5                	mov    %esp,%ebp
 22b:	57                   	push   %edi
 22c:	56                   	push   %esi
 22d:	53                   	push   %ebx
 22e:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 231:	8d 45 10             	lea    0x10(%ebp),%eax
 234:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 237:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 23c:	bb 00 00 00 00       	mov    $0x0,%ebx
 241:	eb 12                	jmp    255 <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 243:	89 fa                	mov    %edi,%edx
 245:	8b 45 08             	mov    0x8(%ebp),%eax
 248:	e8 48 ff ff ff       	call   195 <putc>
 24d:	eb 05                	jmp    254 <printf+0x2c>
      }
    } else if(state == '%'){
 24f:	83 fe 25             	cmp    $0x25,%esi
 252:	74 22                	je     276 <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 254:	43                   	inc    %ebx
 255:	8b 45 0c             	mov    0xc(%ebp),%eax
 258:	8a 04 18             	mov    (%eax,%ebx,1),%al
 25b:	84 c0                	test   %al,%al
 25d:	0f 84 1d 01 00 00    	je     380 <printf+0x158>
    c = fmt[i] & 0xff;
 263:	0f be f8             	movsbl %al,%edi
 266:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 269:	85 f6                	test   %esi,%esi
 26b:	75 e2                	jne    24f <printf+0x27>
      if(c == '%'){
 26d:	83 f8 25             	cmp    $0x25,%eax
 270:	75 d1                	jne    243 <printf+0x1b>
        state = '%';
 272:	89 c6                	mov    %eax,%esi
 274:	eb de                	jmp    254 <printf+0x2c>
      if(c == 'd'){
 276:	83 f8 25             	cmp    $0x25,%eax
 279:	0f 84 cc 00 00 00    	je     34b <printf+0x123>
 27f:	0f 8c da 00 00 00    	jl     35f <printf+0x137>
 285:	83 f8 78             	cmp    $0x78,%eax
 288:	0f 8f d1 00 00 00    	jg     35f <printf+0x137>
 28e:	83 f8 63             	cmp    $0x63,%eax
 291:	0f 8c c8 00 00 00    	jl     35f <printf+0x137>
 297:	83 e8 63             	sub    $0x63,%eax
 29a:	83 f8 15             	cmp    $0x15,%eax
 29d:	0f 87 bc 00 00 00    	ja     35f <printf+0x137>
 2a3:	ff 24 85 e0 03 00 00 	jmp    *0x3e0(,%eax,4)
        printint(fd, *ap, 10, 1);
 2aa:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 2ad:	8b 17                	mov    (%edi),%edx
 2af:	83 ec 0c             	sub    $0xc,%esp
 2b2:	6a 01                	push   $0x1
 2b4:	b9 0a 00 00 00       	mov    $0xa,%ecx
 2b9:	8b 45 08             	mov    0x8(%ebp),%eax
 2bc:	e8 ee fe ff ff       	call   1af <printint>
        ap++;
 2c1:	83 c7 04             	add    $0x4,%edi
 2c4:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 2c7:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 2ca:	be 00 00 00 00       	mov    $0x0,%esi
 2cf:	eb 83                	jmp    254 <printf+0x2c>
        printint(fd, *ap, 16, 0);
 2d1:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 2d4:	8b 17                	mov    (%edi),%edx
 2d6:	83 ec 0c             	sub    $0xc,%esp
 2d9:	6a 00                	push   $0x0
 2db:	b9 10 00 00 00       	mov    $0x10,%ecx
 2e0:	8b 45 08             	mov    0x8(%ebp),%eax
 2e3:	e8 c7 fe ff ff       	call   1af <printint>
        ap++;
 2e8:	83 c7 04             	add    $0x4,%edi
 2eb:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 2ee:	83 c4 10             	add    $0x10,%esp
      state = 0;
 2f1:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 2f6:	e9 59 ff ff ff       	jmp    254 <printf+0x2c>
        s = (char*)*ap;
 2fb:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 2fe:	8b 30                	mov    (%eax),%esi
        ap++;
 300:	83 c0 04             	add    $0x4,%eax
 303:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 306:	85 f6                	test   %esi,%esi
 308:	75 13                	jne    31d <printf+0xf5>
          s = "(null)";
 30a:	be d8 03 00 00       	mov    $0x3d8,%esi
 30f:	eb 0c                	jmp    31d <printf+0xf5>
          putc(fd, *s);
 311:	0f be d2             	movsbl %dl,%edx
 314:	8b 45 08             	mov    0x8(%ebp),%eax
 317:	e8 79 fe ff ff       	call   195 <putc>
          s++;
 31c:	46                   	inc    %esi
        while(*s != 0){
 31d:	8a 16                	mov    (%esi),%dl
 31f:	84 d2                	test   %dl,%dl
 321:	75 ee                	jne    311 <printf+0xe9>
      state = 0;
 323:	be 00 00 00 00       	mov    $0x0,%esi
 328:	e9 27 ff ff ff       	jmp    254 <printf+0x2c>
        putc(fd, *ap);
 32d:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 330:	0f be 17             	movsbl (%edi),%edx
 333:	8b 45 08             	mov    0x8(%ebp),%eax
 336:	e8 5a fe ff ff       	call   195 <putc>
        ap++;
 33b:	83 c7 04             	add    $0x4,%edi
 33e:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 341:	be 00 00 00 00       	mov    $0x0,%esi
 346:	e9 09 ff ff ff       	jmp    254 <printf+0x2c>
        putc(fd, c);
 34b:	89 fa                	mov    %edi,%edx
 34d:	8b 45 08             	mov    0x8(%ebp),%eax
 350:	e8 40 fe ff ff       	call   195 <putc>
      state = 0;
 355:	be 00 00 00 00       	mov    $0x0,%esi
 35a:	e9 f5 fe ff ff       	jmp    254 <printf+0x2c>
        putc(fd, '%');
 35f:	ba 25 00 00 00       	mov    $0x25,%edx
 364:	8b 45 08             	mov    0x8(%ebp),%eax
 367:	e8 29 fe ff ff       	call   195 <putc>
        putc(fd, c);
 36c:	89 fa                	mov    %edi,%edx
 36e:	8b 45 08             	mov    0x8(%ebp),%eax
 371:	e8 1f fe ff ff       	call   195 <putc>
      state = 0;
 376:	be 00 00 00 00       	mov    $0x0,%esi
 37b:	e9 d4 fe ff ff       	jmp    254 <printf+0x2c>
    }
  }
}
 380:	8d 65 f4             	lea    -0xc(%ebp),%esp
 383:	5b                   	pop    %ebx
 384:	5e                   	pop    %esi
 385:	5f                   	pop    %edi
 386:	5d                   	pop    %ebp
 387:	c3                   	ret    
