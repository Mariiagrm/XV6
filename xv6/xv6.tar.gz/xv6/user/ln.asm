
ln:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <main>:
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	53                   	push   %ebx
   e:	51                   	push   %ecx
   f:	8b 59 04             	mov    0x4(%ecx),%ebx
  if(argc != 3){
  12:	83 39 03             	cmpl   $0x3,(%ecx)
  15:	74 14                	je     2b <main+0x2b>
    printf(2, "Usage: ln old new\n");
  17:	83 ec 08             	sub    $0x8,%esp
  1a:	68 08 03 00 00       	push   $0x308
  1f:	6a 02                	push   $0x2
  21:	e8 81 01 00 00       	call   1a7 <printf>
    exit();
  26:	e8 39 00 00 00       	call   64 <exit>
  }
  if(link(argv[1], argv[2]) < 0)
  2b:	83 ec 08             	sub    $0x8,%esp
  2e:	ff 73 08             	push   0x8(%ebx)
  31:	ff 73 04             	push   0x4(%ebx)
  34:	e8 8b 00 00 00       	call   c4 <link>
  39:	83 c4 10             	add    $0x10,%esp
  3c:	85 c0                	test   %eax,%eax
  3e:	78 05                	js     45 <main+0x45>
    printf(2, "link %s %s: failed\n", argv[1], argv[2]);
  exit();
  40:	e8 1f 00 00 00       	call   64 <exit>
    printf(2, "link %s %s: failed\n", argv[1], argv[2]);
  45:	ff 73 08             	push   0x8(%ebx)
  48:	ff 73 04             	push   0x4(%ebx)
  4b:	68 1b 03 00 00       	push   $0x31b
  50:	6a 02                	push   $0x2
  52:	e8 50 01 00 00       	call   1a7 <printf>
  57:	83 c4 10             	add    $0x10,%esp
  5a:	eb e4                	jmp    40 <main+0x40>

0000005c <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
  5c:	b8 01 00 00 00       	mov    $0x1,%eax
  61:	cd 40                	int    $0x40
  63:	c3                   	ret    

00000064 <exit>:
SYSCALL(exit)
  64:	b8 02 00 00 00       	mov    $0x2,%eax
  69:	cd 40                	int    $0x40
  6b:	c3                   	ret    

0000006c <wait>:
SYSCALL(wait)
  6c:	b8 03 00 00 00       	mov    $0x3,%eax
  71:	cd 40                	int    $0x40
  73:	c3                   	ret    

00000074 <pipe>:
SYSCALL(pipe)
  74:	b8 04 00 00 00       	mov    $0x4,%eax
  79:	cd 40                	int    $0x40
  7b:	c3                   	ret    

0000007c <read>:
SYSCALL(read)
  7c:	b8 05 00 00 00       	mov    $0x5,%eax
  81:	cd 40                	int    $0x40
  83:	c3                   	ret    

00000084 <write>:
SYSCALL(write)
  84:	b8 10 00 00 00       	mov    $0x10,%eax
  89:	cd 40                	int    $0x40
  8b:	c3                   	ret    

0000008c <close>:
SYSCALL(close)
  8c:	b8 15 00 00 00       	mov    $0x15,%eax
  91:	cd 40                	int    $0x40
  93:	c3                   	ret    

00000094 <kill>:
SYSCALL(kill)
  94:	b8 06 00 00 00       	mov    $0x6,%eax
  99:	cd 40                	int    $0x40
  9b:	c3                   	ret    

0000009c <exec>:
SYSCALL(exec)
  9c:	b8 07 00 00 00       	mov    $0x7,%eax
  a1:	cd 40                	int    $0x40
  a3:	c3                   	ret    

000000a4 <open>:
SYSCALL(open)
  a4:	b8 0f 00 00 00       	mov    $0xf,%eax
  a9:	cd 40                	int    $0x40
  ab:	c3                   	ret    

000000ac <mknod>:
SYSCALL(mknod)
  ac:	b8 11 00 00 00       	mov    $0x11,%eax
  b1:	cd 40                	int    $0x40
  b3:	c3                   	ret    

000000b4 <unlink>:
SYSCALL(unlink)
  b4:	b8 12 00 00 00       	mov    $0x12,%eax
  b9:	cd 40                	int    $0x40
  bb:	c3                   	ret    

000000bc <fstat>:
SYSCALL(fstat)
  bc:	b8 08 00 00 00       	mov    $0x8,%eax
  c1:	cd 40                	int    $0x40
  c3:	c3                   	ret    

000000c4 <link>:
SYSCALL(link)
  c4:	b8 13 00 00 00       	mov    $0x13,%eax
  c9:	cd 40                	int    $0x40
  cb:	c3                   	ret    

000000cc <mkdir>:
SYSCALL(mkdir)
  cc:	b8 14 00 00 00       	mov    $0x14,%eax
  d1:	cd 40                	int    $0x40
  d3:	c3                   	ret    

000000d4 <chdir>:
SYSCALL(chdir)
  d4:	b8 09 00 00 00       	mov    $0x9,%eax
  d9:	cd 40                	int    $0x40
  db:	c3                   	ret    

000000dc <dup>:
SYSCALL(dup)
  dc:	b8 0a 00 00 00       	mov    $0xa,%eax
  e1:	cd 40                	int    $0x40
  e3:	c3                   	ret    

000000e4 <getpid>:
SYSCALL(getpid)
  e4:	b8 0b 00 00 00       	mov    $0xb,%eax
  e9:	cd 40                	int    $0x40
  eb:	c3                   	ret    

000000ec <sbrk>:
SYSCALL(sbrk)
  ec:	b8 0c 00 00 00       	mov    $0xc,%eax
  f1:	cd 40                	int    $0x40
  f3:	c3                   	ret    

000000f4 <sleep>:
SYSCALL(sleep)
  f4:	b8 0d 00 00 00       	mov    $0xd,%eax
  f9:	cd 40                	int    $0x40
  fb:	c3                   	ret    

000000fc <uptime>:
SYSCALL(uptime)
  fc:	b8 0e 00 00 00       	mov    $0xe,%eax
 101:	cd 40                	int    $0x40
 103:	c3                   	ret    

00000104 <date>:
SYSCALL(date)
 104:	b8 16 00 00 00       	mov    $0x16,%eax
 109:	cd 40                	int    $0x40
 10b:	c3                   	ret    

0000010c <dup2>:
SYSCALL(dup2)
 10c:	b8 17 00 00 00       	mov    $0x17,%eax
 111:	cd 40                	int    $0x40
 113:	c3                   	ret    

00000114 <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 114:	55                   	push   %ebp
 115:	89 e5                	mov    %esp,%ebp
 117:	83 ec 1c             	sub    $0x1c,%esp
 11a:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 11d:	6a 01                	push   $0x1
 11f:	8d 55 f4             	lea    -0xc(%ebp),%edx
 122:	52                   	push   %edx
 123:	50                   	push   %eax
 124:	e8 5b ff ff ff       	call   84 <write>
}
 129:	83 c4 10             	add    $0x10,%esp
 12c:	c9                   	leave  
 12d:	c3                   	ret    

0000012e <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 12e:	55                   	push   %ebp
 12f:	89 e5                	mov    %esp,%ebp
 131:	57                   	push   %edi
 132:	56                   	push   %esi
 133:	53                   	push   %ebx
 134:	83 ec 2c             	sub    $0x2c,%esp
 137:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 13a:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 13c:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 140:	74 04                	je     146 <printint+0x18>
 142:	85 d2                	test   %edx,%edx
 144:	78 3c                	js     182 <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 146:	89 d1                	mov    %edx,%ecx
  neg = 0;
 148:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 14f:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 154:	89 c8                	mov    %ecx,%eax
 156:	ba 00 00 00 00       	mov    $0x0,%edx
 15b:	f7 f6                	div    %esi
 15d:	89 df                	mov    %ebx,%edi
 15f:	43                   	inc    %ebx
 160:	8a 92 90 03 00 00    	mov    0x390(%edx),%dl
 166:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 16a:	89 ca                	mov    %ecx,%edx
 16c:	89 c1                	mov    %eax,%ecx
 16e:	39 d6                	cmp    %edx,%esi
 170:	76 e2                	jbe    154 <printint+0x26>
  if(neg)
 172:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 176:	74 24                	je     19c <printint+0x6e>
    buf[i++] = '-';
 178:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 17d:	8d 5f 02             	lea    0x2(%edi),%ebx
 180:	eb 1a                	jmp    19c <printint+0x6e>
    x = -xx;
 182:	89 d1                	mov    %edx,%ecx
 184:	f7 d9                	neg    %ecx
    neg = 1;
 186:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 18d:	eb c0                	jmp    14f <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 18f:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 194:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 197:	e8 78 ff ff ff       	call   114 <putc>
  while(--i >= 0)
 19c:	4b                   	dec    %ebx
 19d:	79 f0                	jns    18f <printint+0x61>
}
 19f:	83 c4 2c             	add    $0x2c,%esp
 1a2:	5b                   	pop    %ebx
 1a3:	5e                   	pop    %esi
 1a4:	5f                   	pop    %edi
 1a5:	5d                   	pop    %ebp
 1a6:	c3                   	ret    

000001a7 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 1a7:	55                   	push   %ebp
 1a8:	89 e5                	mov    %esp,%ebp
 1aa:	57                   	push   %edi
 1ab:	56                   	push   %esi
 1ac:	53                   	push   %ebx
 1ad:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 1b0:	8d 45 10             	lea    0x10(%ebp),%eax
 1b3:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 1b6:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 1bb:	bb 00 00 00 00       	mov    $0x0,%ebx
 1c0:	eb 12                	jmp    1d4 <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 1c2:	89 fa                	mov    %edi,%edx
 1c4:	8b 45 08             	mov    0x8(%ebp),%eax
 1c7:	e8 48 ff ff ff       	call   114 <putc>
 1cc:	eb 05                	jmp    1d3 <printf+0x2c>
      }
    } else if(state == '%'){
 1ce:	83 fe 25             	cmp    $0x25,%esi
 1d1:	74 22                	je     1f5 <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 1d3:	43                   	inc    %ebx
 1d4:	8b 45 0c             	mov    0xc(%ebp),%eax
 1d7:	8a 04 18             	mov    (%eax,%ebx,1),%al
 1da:	84 c0                	test   %al,%al
 1dc:	0f 84 1d 01 00 00    	je     2ff <printf+0x158>
    c = fmt[i] & 0xff;
 1e2:	0f be f8             	movsbl %al,%edi
 1e5:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 1e8:	85 f6                	test   %esi,%esi
 1ea:	75 e2                	jne    1ce <printf+0x27>
      if(c == '%'){
 1ec:	83 f8 25             	cmp    $0x25,%eax
 1ef:	75 d1                	jne    1c2 <printf+0x1b>
        state = '%';
 1f1:	89 c6                	mov    %eax,%esi
 1f3:	eb de                	jmp    1d3 <printf+0x2c>
      if(c == 'd'){
 1f5:	83 f8 25             	cmp    $0x25,%eax
 1f8:	0f 84 cc 00 00 00    	je     2ca <printf+0x123>
 1fe:	0f 8c da 00 00 00    	jl     2de <printf+0x137>
 204:	83 f8 78             	cmp    $0x78,%eax
 207:	0f 8f d1 00 00 00    	jg     2de <printf+0x137>
 20d:	83 f8 63             	cmp    $0x63,%eax
 210:	0f 8c c8 00 00 00    	jl     2de <printf+0x137>
 216:	83 e8 63             	sub    $0x63,%eax
 219:	83 f8 15             	cmp    $0x15,%eax
 21c:	0f 87 bc 00 00 00    	ja     2de <printf+0x137>
 222:	ff 24 85 38 03 00 00 	jmp    *0x338(,%eax,4)
        printint(fd, *ap, 10, 1);
 229:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 22c:	8b 17                	mov    (%edi),%edx
 22e:	83 ec 0c             	sub    $0xc,%esp
 231:	6a 01                	push   $0x1
 233:	b9 0a 00 00 00       	mov    $0xa,%ecx
 238:	8b 45 08             	mov    0x8(%ebp),%eax
 23b:	e8 ee fe ff ff       	call   12e <printint>
        ap++;
 240:	83 c7 04             	add    $0x4,%edi
 243:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 246:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 249:	be 00 00 00 00       	mov    $0x0,%esi
 24e:	eb 83                	jmp    1d3 <printf+0x2c>
        printint(fd, *ap, 16, 0);
 250:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 253:	8b 17                	mov    (%edi),%edx
 255:	83 ec 0c             	sub    $0xc,%esp
 258:	6a 00                	push   $0x0
 25a:	b9 10 00 00 00       	mov    $0x10,%ecx
 25f:	8b 45 08             	mov    0x8(%ebp),%eax
 262:	e8 c7 fe ff ff       	call   12e <printint>
        ap++;
 267:	83 c7 04             	add    $0x4,%edi
 26a:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 26d:	83 c4 10             	add    $0x10,%esp
      state = 0;
 270:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 275:	e9 59 ff ff ff       	jmp    1d3 <printf+0x2c>
        s = (char*)*ap;
 27a:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 27d:	8b 30                	mov    (%eax),%esi
        ap++;
 27f:	83 c0 04             	add    $0x4,%eax
 282:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 285:	85 f6                	test   %esi,%esi
 287:	75 13                	jne    29c <printf+0xf5>
          s = "(null)";
 289:	be 2f 03 00 00       	mov    $0x32f,%esi
 28e:	eb 0c                	jmp    29c <printf+0xf5>
          putc(fd, *s);
 290:	0f be d2             	movsbl %dl,%edx
 293:	8b 45 08             	mov    0x8(%ebp),%eax
 296:	e8 79 fe ff ff       	call   114 <putc>
          s++;
 29b:	46                   	inc    %esi
        while(*s != 0){
 29c:	8a 16                	mov    (%esi),%dl
 29e:	84 d2                	test   %dl,%dl
 2a0:	75 ee                	jne    290 <printf+0xe9>
      state = 0;
 2a2:	be 00 00 00 00       	mov    $0x0,%esi
 2a7:	e9 27 ff ff ff       	jmp    1d3 <printf+0x2c>
        putc(fd, *ap);
 2ac:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 2af:	0f be 17             	movsbl (%edi),%edx
 2b2:	8b 45 08             	mov    0x8(%ebp),%eax
 2b5:	e8 5a fe ff ff       	call   114 <putc>
        ap++;
 2ba:	83 c7 04             	add    $0x4,%edi
 2bd:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 2c0:	be 00 00 00 00       	mov    $0x0,%esi
 2c5:	e9 09 ff ff ff       	jmp    1d3 <printf+0x2c>
        putc(fd, c);
 2ca:	89 fa                	mov    %edi,%edx
 2cc:	8b 45 08             	mov    0x8(%ebp),%eax
 2cf:	e8 40 fe ff ff       	call   114 <putc>
      state = 0;
 2d4:	be 00 00 00 00       	mov    $0x0,%esi
 2d9:	e9 f5 fe ff ff       	jmp    1d3 <printf+0x2c>
        putc(fd, '%');
 2de:	ba 25 00 00 00       	mov    $0x25,%edx
 2e3:	8b 45 08             	mov    0x8(%ebp),%eax
 2e6:	e8 29 fe ff ff       	call   114 <putc>
        putc(fd, c);
 2eb:	89 fa                	mov    %edi,%edx
 2ed:	8b 45 08             	mov    0x8(%ebp),%eax
 2f0:	e8 1f fe ff ff       	call   114 <putc>
      state = 0;
 2f5:	be 00 00 00 00       	mov    $0x0,%esi
 2fa:	e9 d4 fe ff ff       	jmp    1d3 <printf+0x2c>
    }
  }
}
 2ff:	8d 65 f4             	lea    -0xc(%ebp),%esp
 302:	5b                   	pop    %ebx
 303:	5e                   	pop    %esi
 304:	5f                   	pop    %edi
 305:	5d                   	pop    %ebp
 306:	c3                   	ret    
