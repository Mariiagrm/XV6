
forktest:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <printf>:

#define N  1000

void
printf(int fd, const char *s, ...)
{
   0:	55                   	push   %ebp
   1:	89 e5                	mov    %esp,%ebp
   3:	53                   	push   %ebx
   4:	83 ec 10             	sub    $0x10,%esp
   7:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  write(fd, s, strlen(s));
   a:	53                   	push   %ebx
   b:	e8 16 01 00 00       	call   126 <strlen>
  10:	83 c4 0c             	add    $0xc,%esp
  13:	50                   	push   %eax
  14:	53                   	push   %ebx
  15:	ff 75 08             	push   0x8(%ebp)
  18:	e8 6a 02 00 00       	call   287 <write>
}
  1d:	83 c4 10             	add    $0x10,%esp
  20:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  23:	c9                   	leave  
  24:	c3                   	ret    

00000025 <forktest>:

void
forktest(void)
{
  25:	55                   	push   %ebp
  26:	89 e5                	mov    %esp,%ebp
  28:	53                   	push   %ebx
  29:	83 ec 0c             	sub    $0xc,%esp
  int n, pid;

  printf(1, "fork test\n");
  2c:	68 18 03 00 00       	push   $0x318
  31:	6a 01                	push   $0x1
  33:	e8 c8 ff ff ff       	call   0 <printf>

  for(n=0; n<N; n++){
  38:	83 c4 10             	add    $0x10,%esp
  3b:	bb 00 00 00 00       	mov    $0x0,%ebx
  40:	81 fb e7 03 00 00    	cmp    $0x3e7,%ebx
  46:	7f 13                	jg     5b <forktest+0x36>
    pid = fork();
  48:	e8 12 02 00 00       	call   25f <fork>
    if(pid < 0)
  4d:	85 c0                	test   %eax,%eax
  4f:	78 0a                	js     5b <forktest+0x36>
      break;
    if(pid == 0)
  51:	74 03                	je     56 <forktest+0x31>
  for(n=0; n<N; n++){
  53:	43                   	inc    %ebx
  54:	eb ea                	jmp    40 <forktest+0x1b>
      exit();
  56:	e8 0c 02 00 00       	call   267 <exit>
  }

  if(n == N){
  5b:	81 fb e8 03 00 00    	cmp    $0x3e8,%ebx
  61:	74 10                	je     73 <forktest+0x4e>
    printf(1, "fork claimed to work N times!\n", N);
    exit();
  }

  for(; n > 0; n--){
  63:	85 db                	test   %ebx,%ebx
  65:	7e 39                	jle    a0 <forktest+0x7b>
    if(wait() < 0){
  67:	e8 03 02 00 00       	call   26f <wait>
  6c:	85 c0                	test   %eax,%eax
  6e:	78 1c                	js     8c <forktest+0x67>
  for(; n > 0; n--){
  70:	4b                   	dec    %ebx
  71:	eb f0                	jmp    63 <forktest+0x3e>
    printf(1, "fork claimed to work N times!\n", N);
  73:	83 ec 04             	sub    $0x4,%esp
  76:	68 e8 03 00 00       	push   $0x3e8
  7b:	68 58 03 00 00       	push   $0x358
  80:	6a 01                	push   $0x1
  82:	e8 79 ff ff ff       	call   0 <printf>
    exit();
  87:	e8 db 01 00 00       	call   267 <exit>
      printf(1, "wait stopped early\n");
  8c:	83 ec 08             	sub    $0x8,%esp
  8f:	68 23 03 00 00       	push   $0x323
  94:	6a 01                	push   $0x1
  96:	e8 65 ff ff ff       	call   0 <printf>
      exit();
  9b:	e8 c7 01 00 00       	call   267 <exit>
    }
  }

  if(wait() != -1){
  a0:	e8 ca 01 00 00       	call   26f <wait>
  a5:	83 f8 ff             	cmp    $0xffffffff,%eax
  a8:	75 17                	jne    c1 <forktest+0x9c>
    printf(1, "wait got too many\n");
    exit();
  }

  printf(1, "fork test OK\n");
  aa:	83 ec 08             	sub    $0x8,%esp
  ad:	68 4a 03 00 00       	push   $0x34a
  b2:	6a 01                	push   $0x1
  b4:	e8 47 ff ff ff       	call   0 <printf>
}
  b9:	83 c4 10             	add    $0x10,%esp
  bc:	8b 5d fc             	mov    -0x4(%ebp),%ebx
  bf:	c9                   	leave  
  c0:	c3                   	ret    
    printf(1, "wait got too many\n");
  c1:	83 ec 08             	sub    $0x8,%esp
  c4:	68 37 03 00 00       	push   $0x337
  c9:	6a 01                	push   $0x1
  cb:	e8 30 ff ff ff       	call   0 <printf>
    exit();
  d0:	e8 92 01 00 00       	call   267 <exit>

000000d5 <main>:

int
main(void)
{
  d5:	55                   	push   %ebp
  d6:	89 e5                	mov    %esp,%ebp
  d8:	83 e4 f0             	and    $0xfffffff0,%esp
  forktest();
  db:	e8 45 ff ff ff       	call   25 <forktest>
  exit();
  e0:	e8 82 01 00 00       	call   267 <exit>

000000e5 <start>:

// Entry point of the library	
void
start()
{
}
  e5:	c3                   	ret    

000000e6 <strcpy>:

char*
strcpy(char *s, const char *t)
{
  e6:	55                   	push   %ebp
  e7:	89 e5                	mov    %esp,%ebp
  e9:	56                   	push   %esi
  ea:	53                   	push   %ebx
  eb:	8b 45 08             	mov    0x8(%ebp),%eax
  ee:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  f1:	89 c2                	mov    %eax,%edx
  f3:	89 cb                	mov    %ecx,%ebx
  f5:	41                   	inc    %ecx
  f6:	89 d6                	mov    %edx,%esi
  f8:	42                   	inc    %edx
  f9:	8a 1b                	mov    (%ebx),%bl
  fb:	88 1e                	mov    %bl,(%esi)
  fd:	84 db                	test   %bl,%bl
  ff:	75 f2                	jne    f3 <strcpy+0xd>
    ;
  return os;
}
 101:	5b                   	pop    %ebx
 102:	5e                   	pop    %esi
 103:	5d                   	pop    %ebp
 104:	c3                   	ret    

00000105 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 105:	55                   	push   %ebp
 106:	89 e5                	mov    %esp,%ebp
 108:	8b 4d 08             	mov    0x8(%ebp),%ecx
 10b:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
 10e:	eb 02                	jmp    112 <strcmp+0xd>
    p++, q++;
 110:	41                   	inc    %ecx
 111:	42                   	inc    %edx
  while(*p && *p == *q)
 112:	8a 01                	mov    (%ecx),%al
 114:	84 c0                	test   %al,%al
 116:	74 04                	je     11c <strcmp+0x17>
 118:	3a 02                	cmp    (%edx),%al
 11a:	74 f4                	je     110 <strcmp+0xb>
  return (uchar)*p - (uchar)*q;
 11c:	0f b6 c0             	movzbl %al,%eax
 11f:	0f b6 12             	movzbl (%edx),%edx
 122:	29 d0                	sub    %edx,%eax
}
 124:	5d                   	pop    %ebp
 125:	c3                   	ret    

00000126 <strlen>:

uint
strlen(const char *s)
{
 126:	55                   	push   %ebp
 127:	89 e5                	mov    %esp,%ebp
 129:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
 12c:	b8 00 00 00 00       	mov    $0x0,%eax
 131:	eb 01                	jmp    134 <strlen+0xe>
 133:	40                   	inc    %eax
 134:	80 3c 01 00          	cmpb   $0x0,(%ecx,%eax,1)
 138:	75 f9                	jne    133 <strlen+0xd>
    ;
  return n;
}
 13a:	5d                   	pop    %ebp
 13b:	c3                   	ret    

0000013c <memset>:

void*
memset(void *dst, int c, uint n)
{
 13c:	55                   	push   %ebp
 13d:	89 e5                	mov    %esp,%ebp
 13f:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 140:	8b 7d 08             	mov    0x8(%ebp),%edi
 143:	8b 4d 10             	mov    0x10(%ebp),%ecx
 146:	8b 45 0c             	mov    0xc(%ebp),%eax
 149:	fc                   	cld    
 14a:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 14c:	8b 45 08             	mov    0x8(%ebp),%eax
 14f:	8b 7d fc             	mov    -0x4(%ebp),%edi
 152:	c9                   	leave  
 153:	c3                   	ret    

00000154 <strchr>:

char*
strchr(const char *s, char c)
{
 154:	55                   	push   %ebp
 155:	89 e5                	mov    %esp,%ebp
 157:	8b 45 08             	mov    0x8(%ebp),%eax
 15a:	8a 4d 0c             	mov    0xc(%ebp),%cl
  for(; *s; s++)
 15d:	eb 01                	jmp    160 <strchr+0xc>
 15f:	40                   	inc    %eax
 160:	8a 10                	mov    (%eax),%dl
 162:	84 d2                	test   %dl,%dl
 164:	74 06                	je     16c <strchr+0x18>
    if(*s == c)
 166:	38 ca                	cmp    %cl,%dl
 168:	75 f5                	jne    15f <strchr+0xb>
 16a:	eb 05                	jmp    171 <strchr+0x1d>
      return (char*)s;
  return 0;
 16c:	b8 00 00 00 00       	mov    $0x0,%eax
}
 171:	5d                   	pop    %ebp
 172:	c3                   	ret    

00000173 <gets>:

char*
gets(char *buf, int max)
{
 173:	55                   	push   %ebp
 174:	89 e5                	mov    %esp,%ebp
 176:	57                   	push   %edi
 177:	56                   	push   %esi
 178:	53                   	push   %ebx
 179:	83 ec 1c             	sub    $0x1c,%esp
 17c:	8b 7d 08             	mov    0x8(%ebp),%edi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 17f:	bb 00 00 00 00       	mov    $0x0,%ebx
 184:	89 de                	mov    %ebx,%esi
 186:	43                   	inc    %ebx
 187:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 18a:	7d 2b                	jge    1b7 <gets+0x44>
    cc = read(0, &c, 1);
 18c:	83 ec 04             	sub    $0x4,%esp
 18f:	6a 01                	push   $0x1
 191:	8d 45 e7             	lea    -0x19(%ebp),%eax
 194:	50                   	push   %eax
 195:	6a 00                	push   $0x0
 197:	e8 e3 00 00 00       	call   27f <read>
    if(cc < 1)
 19c:	83 c4 10             	add    $0x10,%esp
 19f:	85 c0                	test   %eax,%eax
 1a1:	7e 14                	jle    1b7 <gets+0x44>
      break;
    buf[i++] = c;
 1a3:	8a 45 e7             	mov    -0x19(%ebp),%al
 1a6:	88 04 37             	mov    %al,(%edi,%esi,1)
    if(c == '\n' || c == '\r')
 1a9:	3c 0a                	cmp    $0xa,%al
 1ab:	74 08                	je     1b5 <gets+0x42>
 1ad:	3c 0d                	cmp    $0xd,%al
 1af:	75 d3                	jne    184 <gets+0x11>
    buf[i++] = c;
 1b1:	89 de                	mov    %ebx,%esi
 1b3:	eb 02                	jmp    1b7 <gets+0x44>
 1b5:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 1b7:	c6 04 37 00          	movb   $0x0,(%edi,%esi,1)
  return buf;
}
 1bb:	89 f8                	mov    %edi,%eax
 1bd:	8d 65 f4             	lea    -0xc(%ebp),%esp
 1c0:	5b                   	pop    %ebx
 1c1:	5e                   	pop    %esi
 1c2:	5f                   	pop    %edi
 1c3:	5d                   	pop    %ebp
 1c4:	c3                   	ret    

000001c5 <stat>:

int
stat(const char *n, struct stat *st)
{
 1c5:	55                   	push   %ebp
 1c6:	89 e5                	mov    %esp,%ebp
 1c8:	56                   	push   %esi
 1c9:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 1ca:	83 ec 08             	sub    $0x8,%esp
 1cd:	6a 00                	push   $0x0
 1cf:	ff 75 08             	push   0x8(%ebp)
 1d2:	e8 d0 00 00 00       	call   2a7 <open>
  if(fd < 0)
 1d7:	83 c4 10             	add    $0x10,%esp
 1da:	85 c0                	test   %eax,%eax
 1dc:	78 24                	js     202 <stat+0x3d>
 1de:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 1e0:	83 ec 08             	sub    $0x8,%esp
 1e3:	ff 75 0c             	push   0xc(%ebp)
 1e6:	50                   	push   %eax
 1e7:	e8 d3 00 00 00       	call   2bf <fstat>
 1ec:	89 c6                	mov    %eax,%esi
  close(fd);
 1ee:	89 1c 24             	mov    %ebx,(%esp)
 1f1:	e8 99 00 00 00       	call   28f <close>
  return r;
 1f6:	83 c4 10             	add    $0x10,%esp
}
 1f9:	89 f0                	mov    %esi,%eax
 1fb:	8d 65 f8             	lea    -0x8(%ebp),%esp
 1fe:	5b                   	pop    %ebx
 1ff:	5e                   	pop    %esi
 200:	5d                   	pop    %ebp
 201:	c3                   	ret    
    return -1;
 202:	be ff ff ff ff       	mov    $0xffffffff,%esi
 207:	eb f0                	jmp    1f9 <stat+0x34>

00000209 <atoi>:

int
atoi(const char *s)
{
 209:	55                   	push   %ebp
 20a:	89 e5                	mov    %esp,%ebp
 20c:	53                   	push   %ebx
 20d:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
 210:	ba 00 00 00 00       	mov    $0x0,%edx
  while('0' <= *s && *s <= '9')
 215:	eb 0e                	jmp    225 <atoi+0x1c>
    n = n*10 + *s++ - '0';
 217:	8d 14 92             	lea    (%edx,%edx,4),%edx
 21a:	8d 1c 12             	lea    (%edx,%edx,1),%ebx
 21d:	41                   	inc    %ecx
 21e:	0f be c0             	movsbl %al,%eax
 221:	8d 54 18 d0          	lea    -0x30(%eax,%ebx,1),%edx
  while('0' <= *s && *s <= '9')
 225:	8a 01                	mov    (%ecx),%al
 227:	8d 58 d0             	lea    -0x30(%eax),%ebx
 22a:	80 fb 09             	cmp    $0x9,%bl
 22d:	76 e8                	jbe    217 <atoi+0xe>
  return n;
}
 22f:	89 d0                	mov    %edx,%eax
 231:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 234:	c9                   	leave  
 235:	c3                   	ret    

00000236 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 236:	55                   	push   %ebp
 237:	89 e5                	mov    %esp,%ebp
 239:	56                   	push   %esi
 23a:	53                   	push   %ebx
 23b:	8b 45 08             	mov    0x8(%ebp),%eax
 23e:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 241:	8b 55 10             	mov    0x10(%ebp),%edx
  char *dst;
  const char *src;

  dst = vdst;
 244:	89 c1                	mov    %eax,%ecx
  src = vsrc;
  while(n-- > 0)
 246:	eb 0c                	jmp    254 <memmove+0x1e>
    *dst++ = *src++;
 248:	8a 13                	mov    (%ebx),%dl
 24a:	88 11                	mov    %dl,(%ecx)
 24c:	8d 5b 01             	lea    0x1(%ebx),%ebx
 24f:	8d 49 01             	lea    0x1(%ecx),%ecx
  while(n-- > 0)
 252:	89 f2                	mov    %esi,%edx
 254:	8d 72 ff             	lea    -0x1(%edx),%esi
 257:	85 d2                	test   %edx,%edx
 259:	7f ed                	jg     248 <memmove+0x12>
  return vdst;
}
 25b:	5b                   	pop    %ebx
 25c:	5e                   	pop    %esi
 25d:	5d                   	pop    %ebp
 25e:	c3                   	ret    

0000025f <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 25f:	b8 01 00 00 00       	mov    $0x1,%eax
 264:	cd 40                	int    $0x40
 266:	c3                   	ret    

00000267 <exit>:
SYSCALL(exit)
 267:	b8 02 00 00 00       	mov    $0x2,%eax
 26c:	cd 40                	int    $0x40
 26e:	c3                   	ret    

0000026f <wait>:
SYSCALL(wait)
 26f:	b8 03 00 00 00       	mov    $0x3,%eax
 274:	cd 40                	int    $0x40
 276:	c3                   	ret    

00000277 <pipe>:
SYSCALL(pipe)
 277:	b8 04 00 00 00       	mov    $0x4,%eax
 27c:	cd 40                	int    $0x40
 27e:	c3                   	ret    

0000027f <read>:
SYSCALL(read)
 27f:	b8 05 00 00 00       	mov    $0x5,%eax
 284:	cd 40                	int    $0x40
 286:	c3                   	ret    

00000287 <write>:
SYSCALL(write)
 287:	b8 10 00 00 00       	mov    $0x10,%eax
 28c:	cd 40                	int    $0x40
 28e:	c3                   	ret    

0000028f <close>:
SYSCALL(close)
 28f:	b8 15 00 00 00       	mov    $0x15,%eax
 294:	cd 40                	int    $0x40
 296:	c3                   	ret    

00000297 <kill>:
SYSCALL(kill)
 297:	b8 06 00 00 00       	mov    $0x6,%eax
 29c:	cd 40                	int    $0x40
 29e:	c3                   	ret    

0000029f <exec>:
SYSCALL(exec)
 29f:	b8 07 00 00 00       	mov    $0x7,%eax
 2a4:	cd 40                	int    $0x40
 2a6:	c3                   	ret    

000002a7 <open>:
SYSCALL(open)
 2a7:	b8 0f 00 00 00       	mov    $0xf,%eax
 2ac:	cd 40                	int    $0x40
 2ae:	c3                   	ret    

000002af <mknod>:
SYSCALL(mknod)
 2af:	b8 11 00 00 00       	mov    $0x11,%eax
 2b4:	cd 40                	int    $0x40
 2b6:	c3                   	ret    

000002b7 <unlink>:
SYSCALL(unlink)
 2b7:	b8 12 00 00 00       	mov    $0x12,%eax
 2bc:	cd 40                	int    $0x40
 2be:	c3                   	ret    

000002bf <fstat>:
SYSCALL(fstat)
 2bf:	b8 08 00 00 00       	mov    $0x8,%eax
 2c4:	cd 40                	int    $0x40
 2c6:	c3                   	ret    

000002c7 <link>:
SYSCALL(link)
 2c7:	b8 13 00 00 00       	mov    $0x13,%eax
 2cc:	cd 40                	int    $0x40
 2ce:	c3                   	ret    

000002cf <mkdir>:
SYSCALL(mkdir)
 2cf:	b8 14 00 00 00       	mov    $0x14,%eax
 2d4:	cd 40                	int    $0x40
 2d6:	c3                   	ret    

000002d7 <chdir>:
SYSCALL(chdir)
 2d7:	b8 09 00 00 00       	mov    $0x9,%eax
 2dc:	cd 40                	int    $0x40
 2de:	c3                   	ret    

000002df <dup>:
SYSCALL(dup)
 2df:	b8 0a 00 00 00       	mov    $0xa,%eax
 2e4:	cd 40                	int    $0x40
 2e6:	c3                   	ret    

000002e7 <getpid>:
SYSCALL(getpid)
 2e7:	b8 0b 00 00 00       	mov    $0xb,%eax
 2ec:	cd 40                	int    $0x40
 2ee:	c3                   	ret    

000002ef <sbrk>:
SYSCALL(sbrk)
 2ef:	b8 0c 00 00 00       	mov    $0xc,%eax
 2f4:	cd 40                	int    $0x40
 2f6:	c3                   	ret    

000002f7 <sleep>:
SYSCALL(sleep)
 2f7:	b8 0d 00 00 00       	mov    $0xd,%eax
 2fc:	cd 40                	int    $0x40
 2fe:	c3                   	ret    

000002ff <uptime>:
SYSCALL(uptime)
 2ff:	b8 0e 00 00 00       	mov    $0xe,%eax
 304:	cd 40                	int    $0x40
 306:	c3                   	ret    

00000307 <date>:
SYSCALL(date)
 307:	b8 16 00 00 00       	mov    $0x16,%eax
 30c:	cd 40                	int    $0x40
 30e:	c3                   	ret    

0000030f <dup2>:
SYSCALL(dup2)
 30f:	b8 17 00 00 00       	mov    $0x17,%eax
 314:	cd 40                	int    $0x40
 316:	c3                   	ret    
