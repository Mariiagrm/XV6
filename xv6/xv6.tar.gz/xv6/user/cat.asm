
cat:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <cat>:

char buf[512];

void
cat(int fd)
{
   0:	55                   	push   %ebp
   1:	89 e5                	mov    %esp,%ebp
   3:	56                   	push   %esi
   4:	53                   	push   %ebx
   5:	8b 75 08             	mov    0x8(%ebp),%esi
  int n;

  while((n = read(fd, buf, sizeof(buf))) > 0) {
   8:	83 ec 04             	sub    $0x4,%esp
   b:	68 00 02 00 00       	push   $0x200
  10:	68 40 05 00 00       	push   $0x540
  15:	56                   	push   %esi
  16:	e8 fb 00 00 00       	call   116 <read>
  1b:	89 c3                	mov    %eax,%ebx
  1d:	83 c4 10             	add    $0x10,%esp
  20:	85 c0                	test   %eax,%eax
  22:	7e 2b                	jle    4f <cat+0x4f>
    if (write(1, buf, n) != n) {
  24:	83 ec 04             	sub    $0x4,%esp
  27:	53                   	push   %ebx
  28:	68 40 05 00 00       	push   $0x540
  2d:	6a 01                	push   $0x1
  2f:	e8 ea 00 00 00       	call   11e <write>
  34:	83 c4 10             	add    $0x10,%esp
  37:	39 d8                	cmp    %ebx,%eax
  39:	74 cd                	je     8 <cat+0x8>
      printf(1, "cat: write error\n");
  3b:	83 ec 08             	sub    $0x8,%esp
  3e:	68 a4 03 00 00       	push   $0x3a4
  43:	6a 01                	push   $0x1
  45:	e8 f7 01 00 00       	call   241 <printf>
      exit();
  4a:	e8 af 00 00 00       	call   fe <exit>
    }
  }
  if(n < 0){
  4f:	78 07                	js     58 <cat+0x58>
    printf(1, "cat: read error\n");
    exit();
  }
}
  51:	8d 65 f8             	lea    -0x8(%ebp),%esp
  54:	5b                   	pop    %ebx
  55:	5e                   	pop    %esi
  56:	5d                   	pop    %ebp
  57:	c3                   	ret    
    printf(1, "cat: read error\n");
  58:	83 ec 08             	sub    $0x8,%esp
  5b:	68 b6 03 00 00       	push   $0x3b6
  60:	6a 01                	push   $0x1
  62:	e8 da 01 00 00       	call   241 <printf>
    exit();
  67:	e8 92 00 00 00       	call   fe <exit>

0000006c <main>:

int
main(int argc, char *argv[])
{
  6c:	8d 4c 24 04          	lea    0x4(%esp),%ecx
  70:	83 e4 f0             	and    $0xfffffff0,%esp
  73:	ff 71 fc             	push   -0x4(%ecx)
  76:	55                   	push   %ebp
  77:	89 e5                	mov    %esp,%ebp
  79:	57                   	push   %edi
  7a:	56                   	push   %esi
  7b:	53                   	push   %ebx
  7c:	51                   	push   %ecx
  7d:	83 ec 18             	sub    $0x18,%esp
  80:	8b 01                	mov    (%ecx),%eax
  82:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  85:	8b 51 04             	mov    0x4(%ecx),%edx
  88:	89 55 e0             	mov    %edx,-0x20(%ebp)
  int fd, i;

  if(argc <= 1){
  8b:	83 f8 01             	cmp    $0x1,%eax
  8e:	7e 07                	jle    97 <main+0x2b>
    cat(0);
    exit();
  }

  for(i = 1; i < argc; i++){
  90:	be 01 00 00 00       	mov    $0x1,%esi
  95:	eb 24                	jmp    bb <main+0x4f>
    cat(0);
  97:	83 ec 0c             	sub    $0xc,%esp
  9a:	6a 00                	push   $0x0
  9c:	e8 5f ff ff ff       	call   0 <cat>
    exit();
  a1:	e8 58 00 00 00       	call   fe <exit>
    if((fd = open(argv[i], 0)) < 0){
      printf(1, "cat: cannot open %s\n", argv[i]);
      exit();
    }
    cat(fd);
  a6:	83 ec 0c             	sub    $0xc,%esp
  a9:	50                   	push   %eax
  aa:	e8 51 ff ff ff       	call   0 <cat>
    close(fd);
  af:	89 1c 24             	mov    %ebx,(%esp)
  b2:	e8 6f 00 00 00       	call   126 <close>
  for(i = 1; i < argc; i++){
  b7:	46                   	inc    %esi
  b8:	83 c4 10             	add    $0x10,%esp
  bb:	3b 75 e4             	cmp    -0x1c(%ebp),%esi
  be:	7d 31                	jge    f1 <main+0x85>
    if((fd = open(argv[i], 0)) < 0){
  c0:	8b 45 e0             	mov    -0x20(%ebp),%eax
  c3:	8d 3c b0             	lea    (%eax,%esi,4),%edi
  c6:	83 ec 08             	sub    $0x8,%esp
  c9:	6a 00                	push   $0x0
  cb:	ff 37                	push   (%edi)
  cd:	e8 6c 00 00 00       	call   13e <open>
  d2:	89 c3                	mov    %eax,%ebx
  d4:	83 c4 10             	add    $0x10,%esp
  d7:	85 c0                	test   %eax,%eax
  d9:	79 cb                	jns    a6 <main+0x3a>
      printf(1, "cat: cannot open %s\n", argv[i]);
  db:	83 ec 04             	sub    $0x4,%esp
  de:	ff 37                	push   (%edi)
  e0:	68 c7 03 00 00       	push   $0x3c7
  e5:	6a 01                	push   $0x1
  e7:	e8 55 01 00 00       	call   241 <printf>
      exit();
  ec:	e8 0d 00 00 00       	call   fe <exit>
  }
  exit();
  f1:	e8 08 00 00 00       	call   fe <exit>

000000f6 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
  f6:	b8 01 00 00 00       	mov    $0x1,%eax
  fb:	cd 40                	int    $0x40
  fd:	c3                   	ret    

000000fe <exit>:
SYSCALL(exit)
  fe:	b8 02 00 00 00       	mov    $0x2,%eax
 103:	cd 40                	int    $0x40
 105:	c3                   	ret    

00000106 <wait>:
SYSCALL(wait)
 106:	b8 03 00 00 00       	mov    $0x3,%eax
 10b:	cd 40                	int    $0x40
 10d:	c3                   	ret    

0000010e <pipe>:
SYSCALL(pipe)
 10e:	b8 04 00 00 00       	mov    $0x4,%eax
 113:	cd 40                	int    $0x40
 115:	c3                   	ret    

00000116 <read>:
SYSCALL(read)
 116:	b8 05 00 00 00       	mov    $0x5,%eax
 11b:	cd 40                	int    $0x40
 11d:	c3                   	ret    

0000011e <write>:
SYSCALL(write)
 11e:	b8 10 00 00 00       	mov    $0x10,%eax
 123:	cd 40                	int    $0x40
 125:	c3                   	ret    

00000126 <close>:
SYSCALL(close)
 126:	b8 15 00 00 00       	mov    $0x15,%eax
 12b:	cd 40                	int    $0x40
 12d:	c3                   	ret    

0000012e <kill>:
SYSCALL(kill)
 12e:	b8 06 00 00 00       	mov    $0x6,%eax
 133:	cd 40                	int    $0x40
 135:	c3                   	ret    

00000136 <exec>:
SYSCALL(exec)
 136:	b8 07 00 00 00       	mov    $0x7,%eax
 13b:	cd 40                	int    $0x40
 13d:	c3                   	ret    

0000013e <open>:
SYSCALL(open)
 13e:	b8 0f 00 00 00       	mov    $0xf,%eax
 143:	cd 40                	int    $0x40
 145:	c3                   	ret    

00000146 <mknod>:
SYSCALL(mknod)
 146:	b8 11 00 00 00       	mov    $0x11,%eax
 14b:	cd 40                	int    $0x40
 14d:	c3                   	ret    

0000014e <unlink>:
SYSCALL(unlink)
 14e:	b8 12 00 00 00       	mov    $0x12,%eax
 153:	cd 40                	int    $0x40
 155:	c3                   	ret    

00000156 <fstat>:
SYSCALL(fstat)
 156:	b8 08 00 00 00       	mov    $0x8,%eax
 15b:	cd 40                	int    $0x40
 15d:	c3                   	ret    

0000015e <link>:
SYSCALL(link)
 15e:	b8 13 00 00 00       	mov    $0x13,%eax
 163:	cd 40                	int    $0x40
 165:	c3                   	ret    

00000166 <mkdir>:
SYSCALL(mkdir)
 166:	b8 14 00 00 00       	mov    $0x14,%eax
 16b:	cd 40                	int    $0x40
 16d:	c3                   	ret    

0000016e <chdir>:
SYSCALL(chdir)
 16e:	b8 09 00 00 00       	mov    $0x9,%eax
 173:	cd 40                	int    $0x40
 175:	c3                   	ret    

00000176 <dup>:
SYSCALL(dup)
 176:	b8 0a 00 00 00       	mov    $0xa,%eax
 17b:	cd 40                	int    $0x40
 17d:	c3                   	ret    

0000017e <getpid>:
SYSCALL(getpid)
 17e:	b8 0b 00 00 00       	mov    $0xb,%eax
 183:	cd 40                	int    $0x40
 185:	c3                   	ret    

00000186 <sbrk>:
SYSCALL(sbrk)
 186:	b8 0c 00 00 00       	mov    $0xc,%eax
 18b:	cd 40                	int    $0x40
 18d:	c3                   	ret    

0000018e <sleep>:
SYSCALL(sleep)
 18e:	b8 0d 00 00 00       	mov    $0xd,%eax
 193:	cd 40                	int    $0x40
 195:	c3                   	ret    

00000196 <uptime>:
SYSCALL(uptime)
 196:	b8 0e 00 00 00       	mov    $0xe,%eax
 19b:	cd 40                	int    $0x40
 19d:	c3                   	ret    

0000019e <date>:
SYSCALL(date)
 19e:	b8 16 00 00 00       	mov    $0x16,%eax
 1a3:	cd 40                	int    $0x40
 1a5:	c3                   	ret    

000001a6 <dup2>:
SYSCALL(dup2)
 1a6:	b8 17 00 00 00       	mov    $0x17,%eax
 1ab:	cd 40                	int    $0x40
 1ad:	c3                   	ret    

000001ae <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 1ae:	55                   	push   %ebp
 1af:	89 e5                	mov    %esp,%ebp
 1b1:	83 ec 1c             	sub    $0x1c,%esp
 1b4:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 1b7:	6a 01                	push   $0x1
 1b9:	8d 55 f4             	lea    -0xc(%ebp),%edx
 1bc:	52                   	push   %edx
 1bd:	50                   	push   %eax
 1be:	e8 5b ff ff ff       	call   11e <write>
}
 1c3:	83 c4 10             	add    $0x10,%esp
 1c6:	c9                   	leave  
 1c7:	c3                   	ret    

000001c8 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 1c8:	55                   	push   %ebp
 1c9:	89 e5                	mov    %esp,%ebp
 1cb:	57                   	push   %edi
 1cc:	56                   	push   %esi
 1cd:	53                   	push   %ebx
 1ce:	83 ec 2c             	sub    $0x2c,%esp
 1d1:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 1d4:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 1d6:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 1da:	74 04                	je     1e0 <printint+0x18>
 1dc:	85 d2                	test   %edx,%edx
 1de:	78 3c                	js     21c <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 1e0:	89 d1                	mov    %edx,%ecx
  neg = 0;
 1e2:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 1e9:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 1ee:	89 c8                	mov    %ecx,%eax
 1f0:	ba 00 00 00 00       	mov    $0x0,%edx
 1f5:	f7 f6                	div    %esi
 1f7:	89 df                	mov    %ebx,%edi
 1f9:	43                   	inc    %ebx
 1fa:	8a 92 3c 04 00 00    	mov    0x43c(%edx),%dl
 200:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 204:	89 ca                	mov    %ecx,%edx
 206:	89 c1                	mov    %eax,%ecx
 208:	39 d6                	cmp    %edx,%esi
 20a:	76 e2                	jbe    1ee <printint+0x26>
  if(neg)
 20c:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 210:	74 24                	je     236 <printint+0x6e>
    buf[i++] = '-';
 212:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 217:	8d 5f 02             	lea    0x2(%edi),%ebx
 21a:	eb 1a                	jmp    236 <printint+0x6e>
    x = -xx;
 21c:	89 d1                	mov    %edx,%ecx
 21e:	f7 d9                	neg    %ecx
    neg = 1;
 220:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 227:	eb c0                	jmp    1e9 <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 229:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 22e:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 231:	e8 78 ff ff ff       	call   1ae <putc>
  while(--i >= 0)
 236:	4b                   	dec    %ebx
 237:	79 f0                	jns    229 <printint+0x61>
}
 239:	83 c4 2c             	add    $0x2c,%esp
 23c:	5b                   	pop    %ebx
 23d:	5e                   	pop    %esi
 23e:	5f                   	pop    %edi
 23f:	5d                   	pop    %ebp
 240:	c3                   	ret    

00000241 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 241:	55                   	push   %ebp
 242:	89 e5                	mov    %esp,%ebp
 244:	57                   	push   %edi
 245:	56                   	push   %esi
 246:	53                   	push   %ebx
 247:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 24a:	8d 45 10             	lea    0x10(%ebp),%eax
 24d:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 250:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 255:	bb 00 00 00 00       	mov    $0x0,%ebx
 25a:	eb 12                	jmp    26e <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 25c:	89 fa                	mov    %edi,%edx
 25e:	8b 45 08             	mov    0x8(%ebp),%eax
 261:	e8 48 ff ff ff       	call   1ae <putc>
 266:	eb 05                	jmp    26d <printf+0x2c>
      }
    } else if(state == '%'){
 268:	83 fe 25             	cmp    $0x25,%esi
 26b:	74 22                	je     28f <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 26d:	43                   	inc    %ebx
 26e:	8b 45 0c             	mov    0xc(%ebp),%eax
 271:	8a 04 18             	mov    (%eax,%ebx,1),%al
 274:	84 c0                	test   %al,%al
 276:	0f 84 1d 01 00 00    	je     399 <printf+0x158>
    c = fmt[i] & 0xff;
 27c:	0f be f8             	movsbl %al,%edi
 27f:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 282:	85 f6                	test   %esi,%esi
 284:	75 e2                	jne    268 <printf+0x27>
      if(c == '%'){
 286:	83 f8 25             	cmp    $0x25,%eax
 289:	75 d1                	jne    25c <printf+0x1b>
        state = '%';
 28b:	89 c6                	mov    %eax,%esi
 28d:	eb de                	jmp    26d <printf+0x2c>
      if(c == 'd'){
 28f:	83 f8 25             	cmp    $0x25,%eax
 292:	0f 84 cc 00 00 00    	je     364 <printf+0x123>
 298:	0f 8c da 00 00 00    	jl     378 <printf+0x137>
 29e:	83 f8 78             	cmp    $0x78,%eax
 2a1:	0f 8f d1 00 00 00    	jg     378 <printf+0x137>
 2a7:	83 f8 63             	cmp    $0x63,%eax
 2aa:	0f 8c c8 00 00 00    	jl     378 <printf+0x137>
 2b0:	83 e8 63             	sub    $0x63,%eax
 2b3:	83 f8 15             	cmp    $0x15,%eax
 2b6:	0f 87 bc 00 00 00    	ja     378 <printf+0x137>
 2bc:	ff 24 85 e4 03 00 00 	jmp    *0x3e4(,%eax,4)
        printint(fd, *ap, 10, 1);
 2c3:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 2c6:	8b 17                	mov    (%edi),%edx
 2c8:	83 ec 0c             	sub    $0xc,%esp
 2cb:	6a 01                	push   $0x1
 2cd:	b9 0a 00 00 00       	mov    $0xa,%ecx
 2d2:	8b 45 08             	mov    0x8(%ebp),%eax
 2d5:	e8 ee fe ff ff       	call   1c8 <printint>
        ap++;
 2da:	83 c7 04             	add    $0x4,%edi
 2dd:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 2e0:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 2e3:	be 00 00 00 00       	mov    $0x0,%esi
 2e8:	eb 83                	jmp    26d <printf+0x2c>
        printint(fd, *ap, 16, 0);
 2ea:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 2ed:	8b 17                	mov    (%edi),%edx
 2ef:	83 ec 0c             	sub    $0xc,%esp
 2f2:	6a 00                	push   $0x0
 2f4:	b9 10 00 00 00       	mov    $0x10,%ecx
 2f9:	8b 45 08             	mov    0x8(%ebp),%eax
 2fc:	e8 c7 fe ff ff       	call   1c8 <printint>
        ap++;
 301:	83 c7 04             	add    $0x4,%edi
 304:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 307:	83 c4 10             	add    $0x10,%esp
      state = 0;
 30a:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 30f:	e9 59 ff ff ff       	jmp    26d <printf+0x2c>
        s = (char*)*ap;
 314:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 317:	8b 30                	mov    (%eax),%esi
        ap++;
 319:	83 c0 04             	add    $0x4,%eax
 31c:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 31f:	85 f6                	test   %esi,%esi
 321:	75 13                	jne    336 <printf+0xf5>
          s = "(null)";
 323:	be dc 03 00 00       	mov    $0x3dc,%esi
 328:	eb 0c                	jmp    336 <printf+0xf5>
          putc(fd, *s);
 32a:	0f be d2             	movsbl %dl,%edx
 32d:	8b 45 08             	mov    0x8(%ebp),%eax
 330:	e8 79 fe ff ff       	call   1ae <putc>
          s++;
 335:	46                   	inc    %esi
        while(*s != 0){
 336:	8a 16                	mov    (%esi),%dl
 338:	84 d2                	test   %dl,%dl
 33a:	75 ee                	jne    32a <printf+0xe9>
      state = 0;
 33c:	be 00 00 00 00       	mov    $0x0,%esi
 341:	e9 27 ff ff ff       	jmp    26d <printf+0x2c>
        putc(fd, *ap);
 346:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 349:	0f be 17             	movsbl (%edi),%edx
 34c:	8b 45 08             	mov    0x8(%ebp),%eax
 34f:	e8 5a fe ff ff       	call   1ae <putc>
        ap++;
 354:	83 c7 04             	add    $0x4,%edi
 357:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 35a:	be 00 00 00 00       	mov    $0x0,%esi
 35f:	e9 09 ff ff ff       	jmp    26d <printf+0x2c>
        putc(fd, c);
 364:	89 fa                	mov    %edi,%edx
 366:	8b 45 08             	mov    0x8(%ebp),%eax
 369:	e8 40 fe ff ff       	call   1ae <putc>
      state = 0;
 36e:	be 00 00 00 00       	mov    $0x0,%esi
 373:	e9 f5 fe ff ff       	jmp    26d <printf+0x2c>
        putc(fd, '%');
 378:	ba 25 00 00 00       	mov    $0x25,%edx
 37d:	8b 45 08             	mov    0x8(%ebp),%eax
 380:	e8 29 fe ff ff       	call   1ae <putc>
        putc(fd, c);
 385:	89 fa                	mov    %edi,%edx
 387:	8b 45 08             	mov    0x8(%ebp),%eax
 38a:	e8 1f fe ff ff       	call   1ae <putc>
      state = 0;
 38f:	be 00 00 00 00       	mov    $0x0,%esi
 394:	e9 d4 fe ff ff       	jmp    26d <printf+0x2c>
    }
  }
}
 399:	8d 65 f4             	lea    -0xc(%ebp),%esp
 39c:	5b                   	pop    %ebx
 39d:	5e                   	pop    %esi
 39e:	5f                   	pop    %edi
 39f:	5d                   	pop    %ebp
 3a0:	c3                   	ret    
