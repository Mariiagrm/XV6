
ls:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <fmtname>:
#include "user.h"
#include "fs.h"

char*
fmtname(char *path)
{
   0:	55                   	push   %ebp
   1:	89 e5                	mov    %esp,%ebp
   3:	56                   	push   %esi
   4:	53                   	push   %ebx
   5:	8b 5d 08             	mov    0x8(%ebp),%ebx
  static char buf[DIRSIZ+1];
  char *p;

  // Find first character after last slash.
  for(p=path+strlen(path); p >= path && *p != '/'; p--)
   8:	83 ec 0c             	sub    $0xc,%esp
   b:	53                   	push   %ebx
   c:	e8 0e 03 00 00       	call   31f <strlen>
  11:	01 d8                	add    %ebx,%eax
  13:	83 c4 10             	add    $0x10,%esp
  16:	eb 01                	jmp    19 <fmtname+0x19>
  18:	48                   	dec    %eax
  19:	39 d8                	cmp    %ebx,%eax
  1b:	72 05                	jb     22 <fmtname+0x22>
  1d:	80 38 2f             	cmpb   $0x2f,(%eax)
  20:	75 f6                	jne    18 <fmtname+0x18>
    ;
  p++;
  22:	8d 58 01             	lea    0x1(%eax),%ebx

  // Return blank-padded name.
  if(strlen(p) >= DIRSIZ)
  25:	83 ec 0c             	sub    $0xc,%esp
  28:	53                   	push   %ebx
  29:	e8 f1 02 00 00       	call   31f <strlen>
  2e:	83 c4 10             	add    $0x10,%esp
  31:	83 f8 0d             	cmp    $0xd,%eax
  34:	76 09                	jbe    3f <fmtname+0x3f>
    return p;
  memmove(buf, p, strlen(p));
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  return buf;
}
  36:	89 d8                	mov    %ebx,%eax
  38:	8d 65 f8             	lea    -0x8(%ebp),%esp
  3b:	5b                   	pop    %ebx
  3c:	5e                   	pop    %esi
  3d:	5d                   	pop    %ebp
  3e:	c3                   	ret    
  memmove(buf, p, strlen(p));
  3f:	83 ec 0c             	sub    $0xc,%esp
  42:	53                   	push   %ebx
  43:	e8 d7 02 00 00       	call   31f <strlen>
  48:	83 c4 0c             	add    $0xc,%esp
  4b:	50                   	push   %eax
  4c:	53                   	push   %ebx
  4d:	68 48 0a 00 00       	push   $0xa48
  52:	e8 d8 03 00 00       	call   42f <memmove>
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  57:	89 1c 24             	mov    %ebx,(%esp)
  5a:	e8 c0 02 00 00       	call   31f <strlen>
  5f:	89 c6                	mov    %eax,%esi
  61:	89 1c 24             	mov    %ebx,(%esp)
  64:	e8 b6 02 00 00       	call   31f <strlen>
  69:	83 c4 0c             	add    $0xc,%esp
  6c:	ba 0e 00 00 00       	mov    $0xe,%edx
  71:	29 f2                	sub    %esi,%edx
  73:	52                   	push   %edx
  74:	6a 20                	push   $0x20
  76:	05 48 0a 00 00       	add    $0xa48,%eax
  7b:	50                   	push   %eax
  7c:	e8 b4 02 00 00       	call   335 <memset>
  return buf;
  81:	83 c4 10             	add    $0x10,%esp
  84:	bb 48 0a 00 00       	mov    $0xa48,%ebx
  89:	eb ab                	jmp    36 <fmtname+0x36>

0000008b <ls>:

void
ls(char *path)
{
  8b:	55                   	push   %ebp
  8c:	89 e5                	mov    %esp,%ebp
  8e:	57                   	push   %edi
  8f:	56                   	push   %esi
  90:	53                   	push   %ebx
  91:	81 ec 54 02 00 00    	sub    $0x254,%esp
  97:	8b 5d 08             	mov    0x8(%ebp),%ebx
  char buf[512], *p;
  int fd;
  struct dirent de;
  struct stat st;

  if((fd = open(path, 0)) < 0){
  9a:	6a 00                	push   $0x0
  9c:	53                   	push   %ebx
  9d:	e8 fe 03 00 00       	call   4a0 <open>
  a2:	83 c4 10             	add    $0x10,%esp
  a5:	85 c0                	test   %eax,%eax
  a7:	0f 88 8b 00 00 00    	js     138 <ls+0xad>
  ad:	89 c7                	mov    %eax,%edi
    printf(2, "ls: cannot open %s\n", path);
    return;
  }

  if(fstat(fd, &st) < 0){
  af:	83 ec 08             	sub    $0x8,%esp
  b2:	8d 85 c4 fd ff ff    	lea    -0x23c(%ebp),%eax
  b8:	50                   	push   %eax
  b9:	57                   	push   %edi
  ba:	e8 f9 03 00 00       	call   4b8 <fstat>
  bf:	83 c4 10             	add    $0x10,%esp
  c2:	85 c0                	test   %eax,%eax
  c4:	0f 88 83 00 00 00    	js     14d <ls+0xc2>
    printf(2, "ls: cannot stat %s\n", path);
    close(fd);
    return;
  }

  switch(st.type){
  ca:	8b 85 c4 fd ff ff    	mov    -0x23c(%ebp),%eax
  d0:	0f bf f0             	movswl %ax,%esi
  d3:	66 83 f8 01          	cmp    $0x1,%ax
  d7:	0f 84 8d 00 00 00    	je     16a <ls+0xdf>
  dd:	66 83 f8 02          	cmp    $0x2,%ax
  e1:	75 41                	jne    124 <ls+0x99>
  case T_FILE:
    printf(1, "%s %d %d %d\n", fmtname(path), st.type, st.ino, st.size);
  e3:	8b 85 d4 fd ff ff    	mov    -0x22c(%ebp),%eax
  e9:	89 85 b4 fd ff ff    	mov    %eax,-0x24c(%ebp)
  ef:	8b 8d cc fd ff ff    	mov    -0x234(%ebp),%ecx
  f5:	89 8d b0 fd ff ff    	mov    %ecx,-0x250(%ebp)
  fb:	83 ec 0c             	sub    $0xc,%esp
  fe:	53                   	push   %ebx
  ff:	e8 fc fe ff ff       	call   0 <fmtname>
 104:	83 c4 08             	add    $0x8,%esp
 107:	ff b5 b4 fd ff ff    	push   -0x24c(%ebp)
 10d:	ff b5 b0 fd ff ff    	push   -0x250(%ebp)
 113:	56                   	push   %esi
 114:	50                   	push   %eax
 115:	68 2c 07 00 00       	push   $0x72c
 11a:	6a 01                	push   $0x1
 11c:	e8 82 04 00 00       	call   5a3 <printf>
    break;
 121:	83 c4 20             	add    $0x20,%esp
      }
      printf(1, "%s %d %d %d\n", fmtname(buf), st.type, st.ino, st.size);
    }
    break;
  }
  close(fd);
 124:	83 ec 0c             	sub    $0xc,%esp
 127:	57                   	push   %edi
 128:	e8 5b 03 00 00       	call   488 <close>
 12d:	83 c4 10             	add    $0x10,%esp
}
 130:	8d 65 f4             	lea    -0xc(%ebp),%esp
 133:	5b                   	pop    %ebx
 134:	5e                   	pop    %esi
 135:	5f                   	pop    %edi
 136:	5d                   	pop    %ebp
 137:	c3                   	ret    
    printf(2, "ls: cannot open %s\n", path);
 138:	83 ec 04             	sub    $0x4,%esp
 13b:	53                   	push   %ebx
 13c:	68 04 07 00 00       	push   $0x704
 141:	6a 02                	push   $0x2
 143:	e8 5b 04 00 00       	call   5a3 <printf>
    return;
 148:	83 c4 10             	add    $0x10,%esp
 14b:	eb e3                	jmp    130 <ls+0xa5>
    printf(2, "ls: cannot stat %s\n", path);
 14d:	83 ec 04             	sub    $0x4,%esp
 150:	53                   	push   %ebx
 151:	68 18 07 00 00       	push   $0x718
 156:	6a 02                	push   $0x2
 158:	e8 46 04 00 00       	call   5a3 <printf>
    close(fd);
 15d:	89 3c 24             	mov    %edi,(%esp)
 160:	e8 23 03 00 00       	call   488 <close>
    return;
 165:	83 c4 10             	add    $0x10,%esp
 168:	eb c6                	jmp    130 <ls+0xa5>
    if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
 16a:	83 ec 0c             	sub    $0xc,%esp
 16d:	53                   	push   %ebx
 16e:	e8 ac 01 00 00       	call   31f <strlen>
 173:	83 c0 10             	add    $0x10,%eax
 176:	83 c4 10             	add    $0x10,%esp
 179:	3d 00 02 00 00       	cmp    $0x200,%eax
 17e:	76 14                	jbe    194 <ls+0x109>
      printf(1, "ls: path too long\n");
 180:	83 ec 08             	sub    $0x8,%esp
 183:	68 39 07 00 00       	push   $0x739
 188:	6a 01                	push   $0x1
 18a:	e8 14 04 00 00       	call   5a3 <printf>
      break;
 18f:	83 c4 10             	add    $0x10,%esp
 192:	eb 90                	jmp    124 <ls+0x99>
    strcpy(buf, path);
 194:	83 ec 08             	sub    $0x8,%esp
 197:	53                   	push   %ebx
 198:	8d 9d e8 fd ff ff    	lea    -0x218(%ebp),%ebx
 19e:	53                   	push   %ebx
 19f:	e8 3b 01 00 00       	call   2df <strcpy>
    p = buf+strlen(buf);
 1a4:	89 1c 24             	mov    %ebx,(%esp)
 1a7:	e8 73 01 00 00       	call   31f <strlen>
 1ac:	8d 34 03             	lea    (%ebx,%eax,1),%esi
    *p++ = '/';
 1af:	8d 44 03 01          	lea    0x1(%ebx,%eax,1),%eax
 1b3:	89 85 ac fd ff ff    	mov    %eax,-0x254(%ebp)
 1b9:	c6 06 2f             	movb   $0x2f,(%esi)
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
 1bc:	83 c4 10             	add    $0x10,%esp
 1bf:	eb 19                	jmp    1da <ls+0x14f>
        printf(1, "ls: cannot stat %s\n", buf);
 1c1:	83 ec 04             	sub    $0x4,%esp
 1c4:	8d 85 e8 fd ff ff    	lea    -0x218(%ebp),%eax
 1ca:	50                   	push   %eax
 1cb:	68 18 07 00 00       	push   $0x718
 1d0:	6a 01                	push   $0x1
 1d2:	e8 cc 03 00 00       	call   5a3 <printf>
        continue;
 1d7:	83 c4 10             	add    $0x10,%esp
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
 1da:	83 ec 04             	sub    $0x4,%esp
 1dd:	6a 10                	push   $0x10
 1df:	8d 85 d8 fd ff ff    	lea    -0x228(%ebp),%eax
 1e5:	50                   	push   %eax
 1e6:	57                   	push   %edi
 1e7:	e8 8c 02 00 00       	call   478 <read>
 1ec:	83 c4 10             	add    $0x10,%esp
 1ef:	83 f8 10             	cmp    $0x10,%eax
 1f2:	0f 85 2c ff ff ff    	jne    124 <ls+0x99>
      if(de.inum == 0)
 1f8:	66 83 bd d8 fd ff ff 	cmpw   $0x0,-0x228(%ebp)
 1ff:	00 
 200:	74 d8                	je     1da <ls+0x14f>
      memmove(p, de.name, DIRSIZ);
 202:	83 ec 04             	sub    $0x4,%esp
 205:	6a 0e                	push   $0xe
 207:	8d 85 da fd ff ff    	lea    -0x226(%ebp),%eax
 20d:	50                   	push   %eax
 20e:	ff b5 ac fd ff ff    	push   -0x254(%ebp)
 214:	e8 16 02 00 00       	call   42f <memmove>
      p[DIRSIZ] = 0;
 219:	c6 46 0f 00          	movb   $0x0,0xf(%esi)
      if(stat(buf, &st) < 0){
 21d:	83 c4 08             	add    $0x8,%esp
 220:	8d 85 c4 fd ff ff    	lea    -0x23c(%ebp),%eax
 226:	50                   	push   %eax
 227:	8d 85 e8 fd ff ff    	lea    -0x218(%ebp),%eax
 22d:	50                   	push   %eax
 22e:	e8 8b 01 00 00       	call   3be <stat>
 233:	83 c4 10             	add    $0x10,%esp
 236:	85 c0                	test   %eax,%eax
 238:	78 87                	js     1c1 <ls+0x136>
      printf(1, "%s %d %d %d\n", fmtname(buf), st.type, st.ino, st.size);
 23a:	8b 85 d4 fd ff ff    	mov    -0x22c(%ebp),%eax
 240:	89 85 b4 fd ff ff    	mov    %eax,-0x24c(%ebp)
 246:	8b 95 cc fd ff ff    	mov    -0x234(%ebp),%edx
 24c:	89 95 b0 fd ff ff    	mov    %edx,-0x250(%ebp)
 252:	8b 9d c4 fd ff ff    	mov    -0x23c(%ebp),%ebx
 258:	83 ec 0c             	sub    $0xc,%esp
 25b:	8d 85 e8 fd ff ff    	lea    -0x218(%ebp),%eax
 261:	50                   	push   %eax
 262:	e8 99 fd ff ff       	call   0 <fmtname>
 267:	83 c4 08             	add    $0x8,%esp
 26a:	ff b5 b4 fd ff ff    	push   -0x24c(%ebp)
 270:	ff b5 b0 fd ff ff    	push   -0x250(%ebp)
 276:	0f bf db             	movswl %bx,%ebx
 279:	53                   	push   %ebx
 27a:	50                   	push   %eax
 27b:	68 2c 07 00 00       	push   $0x72c
 280:	6a 01                	push   $0x1
 282:	e8 1c 03 00 00       	call   5a3 <printf>
 287:	83 c4 20             	add    $0x20,%esp
 28a:	e9 4b ff ff ff       	jmp    1da <ls+0x14f>

0000028f <main>:

int
main(int argc, char *argv[])
{
 28f:	8d 4c 24 04          	lea    0x4(%esp),%ecx
 293:	83 e4 f0             	and    $0xfffffff0,%esp
 296:	ff 71 fc             	push   -0x4(%ecx)
 299:	55                   	push   %ebp
 29a:	89 e5                	mov    %esp,%ebp
 29c:	57                   	push   %edi
 29d:	56                   	push   %esi
 29e:	53                   	push   %ebx
 29f:	51                   	push   %ecx
 2a0:	83 ec 08             	sub    $0x8,%esp
 2a3:	8b 31                	mov    (%ecx),%esi
 2a5:	8b 79 04             	mov    0x4(%ecx),%edi
  int i;

  if(argc < 2){
 2a8:	83 fe 01             	cmp    $0x1,%esi
 2ab:	7e 07                	jle    2b4 <main+0x25>
    ls(".");
    exit();
  }
  for(i=1; i<argc; i++)
 2ad:	bb 01 00 00 00       	mov    $0x1,%ebx
 2b2:	eb 21                	jmp    2d5 <main+0x46>
    ls(".");
 2b4:	83 ec 0c             	sub    $0xc,%esp
 2b7:	68 4c 07 00 00       	push   $0x74c
 2bc:	e8 ca fd ff ff       	call   8b <ls>
    exit();
 2c1:	e8 9a 01 00 00       	call   460 <exit>
    ls(argv[i]);
 2c6:	83 ec 0c             	sub    $0xc,%esp
 2c9:	ff 34 9f             	push   (%edi,%ebx,4)
 2cc:	e8 ba fd ff ff       	call   8b <ls>
  for(i=1; i<argc; i++)
 2d1:	43                   	inc    %ebx
 2d2:	83 c4 10             	add    $0x10,%esp
 2d5:	39 f3                	cmp    %esi,%ebx
 2d7:	7c ed                	jl     2c6 <main+0x37>
  exit();
 2d9:	e8 82 01 00 00       	call   460 <exit>

000002de <start>:

// Entry point of the library	
void
start()
{
}
 2de:	c3                   	ret    

000002df <strcpy>:

char*
strcpy(char *s, const char *t)
{
 2df:	55                   	push   %ebp
 2e0:	89 e5                	mov    %esp,%ebp
 2e2:	56                   	push   %esi
 2e3:	53                   	push   %ebx
 2e4:	8b 45 08             	mov    0x8(%ebp),%eax
 2e7:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 2ea:	89 c2                	mov    %eax,%edx
 2ec:	89 cb                	mov    %ecx,%ebx
 2ee:	41                   	inc    %ecx
 2ef:	89 d6                	mov    %edx,%esi
 2f1:	42                   	inc    %edx
 2f2:	8a 1b                	mov    (%ebx),%bl
 2f4:	88 1e                	mov    %bl,(%esi)
 2f6:	84 db                	test   %bl,%bl
 2f8:	75 f2                	jne    2ec <strcpy+0xd>
    ;
  return os;
}
 2fa:	5b                   	pop    %ebx
 2fb:	5e                   	pop    %esi
 2fc:	5d                   	pop    %ebp
 2fd:	c3                   	ret    

000002fe <strcmp>:

int
strcmp(const char *p, const char *q)
{
 2fe:	55                   	push   %ebp
 2ff:	89 e5                	mov    %esp,%ebp
 301:	8b 4d 08             	mov    0x8(%ebp),%ecx
 304:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
 307:	eb 02                	jmp    30b <strcmp+0xd>
    p++, q++;
 309:	41                   	inc    %ecx
 30a:	42                   	inc    %edx
  while(*p && *p == *q)
 30b:	8a 01                	mov    (%ecx),%al
 30d:	84 c0                	test   %al,%al
 30f:	74 04                	je     315 <strcmp+0x17>
 311:	3a 02                	cmp    (%edx),%al
 313:	74 f4                	je     309 <strcmp+0xb>
  return (uchar)*p - (uchar)*q;
 315:	0f b6 c0             	movzbl %al,%eax
 318:	0f b6 12             	movzbl (%edx),%edx
 31b:	29 d0                	sub    %edx,%eax
}
 31d:	5d                   	pop    %ebp
 31e:	c3                   	ret    

0000031f <strlen>:

uint
strlen(const char *s)
{
 31f:	55                   	push   %ebp
 320:	89 e5                	mov    %esp,%ebp
 322:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
 325:	b8 00 00 00 00       	mov    $0x0,%eax
 32a:	eb 01                	jmp    32d <strlen+0xe>
 32c:	40                   	inc    %eax
 32d:	80 3c 01 00          	cmpb   $0x0,(%ecx,%eax,1)
 331:	75 f9                	jne    32c <strlen+0xd>
    ;
  return n;
}
 333:	5d                   	pop    %ebp
 334:	c3                   	ret    

00000335 <memset>:

void*
memset(void *dst, int c, uint n)
{
 335:	55                   	push   %ebp
 336:	89 e5                	mov    %esp,%ebp
 338:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 339:	8b 7d 08             	mov    0x8(%ebp),%edi
 33c:	8b 4d 10             	mov    0x10(%ebp),%ecx
 33f:	8b 45 0c             	mov    0xc(%ebp),%eax
 342:	fc                   	cld    
 343:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 345:	8b 45 08             	mov    0x8(%ebp),%eax
 348:	8b 7d fc             	mov    -0x4(%ebp),%edi
 34b:	c9                   	leave  
 34c:	c3                   	ret    

0000034d <strchr>:

char*
strchr(const char *s, char c)
{
 34d:	55                   	push   %ebp
 34e:	89 e5                	mov    %esp,%ebp
 350:	8b 45 08             	mov    0x8(%ebp),%eax
 353:	8a 4d 0c             	mov    0xc(%ebp),%cl
  for(; *s; s++)
 356:	eb 01                	jmp    359 <strchr+0xc>
 358:	40                   	inc    %eax
 359:	8a 10                	mov    (%eax),%dl
 35b:	84 d2                	test   %dl,%dl
 35d:	74 06                	je     365 <strchr+0x18>
    if(*s == c)
 35f:	38 ca                	cmp    %cl,%dl
 361:	75 f5                	jne    358 <strchr+0xb>
 363:	eb 05                	jmp    36a <strchr+0x1d>
      return (char*)s;
  return 0;
 365:	b8 00 00 00 00       	mov    $0x0,%eax
}
 36a:	5d                   	pop    %ebp
 36b:	c3                   	ret    

0000036c <gets>:

char*
gets(char *buf, int max)
{
 36c:	55                   	push   %ebp
 36d:	89 e5                	mov    %esp,%ebp
 36f:	57                   	push   %edi
 370:	56                   	push   %esi
 371:	53                   	push   %ebx
 372:	83 ec 1c             	sub    $0x1c,%esp
 375:	8b 7d 08             	mov    0x8(%ebp),%edi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 378:	bb 00 00 00 00       	mov    $0x0,%ebx
 37d:	89 de                	mov    %ebx,%esi
 37f:	43                   	inc    %ebx
 380:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 383:	7d 2b                	jge    3b0 <gets+0x44>
    cc = read(0, &c, 1);
 385:	83 ec 04             	sub    $0x4,%esp
 388:	6a 01                	push   $0x1
 38a:	8d 45 e7             	lea    -0x19(%ebp),%eax
 38d:	50                   	push   %eax
 38e:	6a 00                	push   $0x0
 390:	e8 e3 00 00 00       	call   478 <read>
    if(cc < 1)
 395:	83 c4 10             	add    $0x10,%esp
 398:	85 c0                	test   %eax,%eax
 39a:	7e 14                	jle    3b0 <gets+0x44>
      break;
    buf[i++] = c;
 39c:	8a 45 e7             	mov    -0x19(%ebp),%al
 39f:	88 04 37             	mov    %al,(%edi,%esi,1)
    if(c == '\n' || c == '\r')
 3a2:	3c 0a                	cmp    $0xa,%al
 3a4:	74 08                	je     3ae <gets+0x42>
 3a6:	3c 0d                	cmp    $0xd,%al
 3a8:	75 d3                	jne    37d <gets+0x11>
    buf[i++] = c;
 3aa:	89 de                	mov    %ebx,%esi
 3ac:	eb 02                	jmp    3b0 <gets+0x44>
 3ae:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 3b0:	c6 04 37 00          	movb   $0x0,(%edi,%esi,1)
  return buf;
}
 3b4:	89 f8                	mov    %edi,%eax
 3b6:	8d 65 f4             	lea    -0xc(%ebp),%esp
 3b9:	5b                   	pop    %ebx
 3ba:	5e                   	pop    %esi
 3bb:	5f                   	pop    %edi
 3bc:	5d                   	pop    %ebp
 3bd:	c3                   	ret    

000003be <stat>:

int
stat(const char *n, struct stat *st)
{
 3be:	55                   	push   %ebp
 3bf:	89 e5                	mov    %esp,%ebp
 3c1:	56                   	push   %esi
 3c2:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3c3:	83 ec 08             	sub    $0x8,%esp
 3c6:	6a 00                	push   $0x0
 3c8:	ff 75 08             	push   0x8(%ebp)
 3cb:	e8 d0 00 00 00       	call   4a0 <open>
  if(fd < 0)
 3d0:	83 c4 10             	add    $0x10,%esp
 3d3:	85 c0                	test   %eax,%eax
 3d5:	78 24                	js     3fb <stat+0x3d>
 3d7:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 3d9:	83 ec 08             	sub    $0x8,%esp
 3dc:	ff 75 0c             	push   0xc(%ebp)
 3df:	50                   	push   %eax
 3e0:	e8 d3 00 00 00       	call   4b8 <fstat>
 3e5:	89 c6                	mov    %eax,%esi
  close(fd);
 3e7:	89 1c 24             	mov    %ebx,(%esp)
 3ea:	e8 99 00 00 00       	call   488 <close>
  return r;
 3ef:	83 c4 10             	add    $0x10,%esp
}
 3f2:	89 f0                	mov    %esi,%eax
 3f4:	8d 65 f8             	lea    -0x8(%ebp),%esp
 3f7:	5b                   	pop    %ebx
 3f8:	5e                   	pop    %esi
 3f9:	5d                   	pop    %ebp
 3fa:	c3                   	ret    
    return -1;
 3fb:	be ff ff ff ff       	mov    $0xffffffff,%esi
 400:	eb f0                	jmp    3f2 <stat+0x34>

00000402 <atoi>:

int
atoi(const char *s)
{
 402:	55                   	push   %ebp
 403:	89 e5                	mov    %esp,%ebp
 405:	53                   	push   %ebx
 406:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
 409:	ba 00 00 00 00       	mov    $0x0,%edx
  while('0' <= *s && *s <= '9')
 40e:	eb 0e                	jmp    41e <atoi+0x1c>
    n = n*10 + *s++ - '0';
 410:	8d 14 92             	lea    (%edx,%edx,4),%edx
 413:	8d 1c 12             	lea    (%edx,%edx,1),%ebx
 416:	41                   	inc    %ecx
 417:	0f be c0             	movsbl %al,%eax
 41a:	8d 54 18 d0          	lea    -0x30(%eax,%ebx,1),%edx
  while('0' <= *s && *s <= '9')
 41e:	8a 01                	mov    (%ecx),%al
 420:	8d 58 d0             	lea    -0x30(%eax),%ebx
 423:	80 fb 09             	cmp    $0x9,%bl
 426:	76 e8                	jbe    410 <atoi+0xe>
  return n;
}
 428:	89 d0                	mov    %edx,%eax
 42a:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 42d:	c9                   	leave  
 42e:	c3                   	ret    

0000042f <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 42f:	55                   	push   %ebp
 430:	89 e5                	mov    %esp,%ebp
 432:	56                   	push   %esi
 433:	53                   	push   %ebx
 434:	8b 45 08             	mov    0x8(%ebp),%eax
 437:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 43a:	8b 55 10             	mov    0x10(%ebp),%edx
  char *dst;
  const char *src;

  dst = vdst;
 43d:	89 c1                	mov    %eax,%ecx
  src = vsrc;
  while(n-- > 0)
 43f:	eb 0c                	jmp    44d <memmove+0x1e>
    *dst++ = *src++;
 441:	8a 13                	mov    (%ebx),%dl
 443:	88 11                	mov    %dl,(%ecx)
 445:	8d 5b 01             	lea    0x1(%ebx),%ebx
 448:	8d 49 01             	lea    0x1(%ecx),%ecx
  while(n-- > 0)
 44b:	89 f2                	mov    %esi,%edx
 44d:	8d 72 ff             	lea    -0x1(%edx),%esi
 450:	85 d2                	test   %edx,%edx
 452:	7f ed                	jg     441 <memmove+0x12>
  return vdst;
}
 454:	5b                   	pop    %ebx
 455:	5e                   	pop    %esi
 456:	5d                   	pop    %ebp
 457:	c3                   	ret    

00000458 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 458:	b8 01 00 00 00       	mov    $0x1,%eax
 45d:	cd 40                	int    $0x40
 45f:	c3                   	ret    

00000460 <exit>:
SYSCALL(exit)
 460:	b8 02 00 00 00       	mov    $0x2,%eax
 465:	cd 40                	int    $0x40
 467:	c3                   	ret    

00000468 <wait>:
SYSCALL(wait)
 468:	b8 03 00 00 00       	mov    $0x3,%eax
 46d:	cd 40                	int    $0x40
 46f:	c3                   	ret    

00000470 <pipe>:
SYSCALL(pipe)
 470:	b8 04 00 00 00       	mov    $0x4,%eax
 475:	cd 40                	int    $0x40
 477:	c3                   	ret    

00000478 <read>:
SYSCALL(read)
 478:	b8 05 00 00 00       	mov    $0x5,%eax
 47d:	cd 40                	int    $0x40
 47f:	c3                   	ret    

00000480 <write>:
SYSCALL(write)
 480:	b8 10 00 00 00       	mov    $0x10,%eax
 485:	cd 40                	int    $0x40
 487:	c3                   	ret    

00000488 <close>:
SYSCALL(close)
 488:	b8 15 00 00 00       	mov    $0x15,%eax
 48d:	cd 40                	int    $0x40
 48f:	c3                   	ret    

00000490 <kill>:
SYSCALL(kill)
 490:	b8 06 00 00 00       	mov    $0x6,%eax
 495:	cd 40                	int    $0x40
 497:	c3                   	ret    

00000498 <exec>:
SYSCALL(exec)
 498:	b8 07 00 00 00       	mov    $0x7,%eax
 49d:	cd 40                	int    $0x40
 49f:	c3                   	ret    

000004a0 <open>:
SYSCALL(open)
 4a0:	b8 0f 00 00 00       	mov    $0xf,%eax
 4a5:	cd 40                	int    $0x40
 4a7:	c3                   	ret    

000004a8 <mknod>:
SYSCALL(mknod)
 4a8:	b8 11 00 00 00       	mov    $0x11,%eax
 4ad:	cd 40                	int    $0x40
 4af:	c3                   	ret    

000004b0 <unlink>:
SYSCALL(unlink)
 4b0:	b8 12 00 00 00       	mov    $0x12,%eax
 4b5:	cd 40                	int    $0x40
 4b7:	c3                   	ret    

000004b8 <fstat>:
SYSCALL(fstat)
 4b8:	b8 08 00 00 00       	mov    $0x8,%eax
 4bd:	cd 40                	int    $0x40
 4bf:	c3                   	ret    

000004c0 <link>:
SYSCALL(link)
 4c0:	b8 13 00 00 00       	mov    $0x13,%eax
 4c5:	cd 40                	int    $0x40
 4c7:	c3                   	ret    

000004c8 <mkdir>:
SYSCALL(mkdir)
 4c8:	b8 14 00 00 00       	mov    $0x14,%eax
 4cd:	cd 40                	int    $0x40
 4cf:	c3                   	ret    

000004d0 <chdir>:
SYSCALL(chdir)
 4d0:	b8 09 00 00 00       	mov    $0x9,%eax
 4d5:	cd 40                	int    $0x40
 4d7:	c3                   	ret    

000004d8 <dup>:
SYSCALL(dup)
 4d8:	b8 0a 00 00 00       	mov    $0xa,%eax
 4dd:	cd 40                	int    $0x40
 4df:	c3                   	ret    

000004e0 <getpid>:
SYSCALL(getpid)
 4e0:	b8 0b 00 00 00       	mov    $0xb,%eax
 4e5:	cd 40                	int    $0x40
 4e7:	c3                   	ret    

000004e8 <sbrk>:
SYSCALL(sbrk)
 4e8:	b8 0c 00 00 00       	mov    $0xc,%eax
 4ed:	cd 40                	int    $0x40
 4ef:	c3                   	ret    

000004f0 <sleep>:
SYSCALL(sleep)
 4f0:	b8 0d 00 00 00       	mov    $0xd,%eax
 4f5:	cd 40                	int    $0x40
 4f7:	c3                   	ret    

000004f8 <uptime>:
SYSCALL(uptime)
 4f8:	b8 0e 00 00 00       	mov    $0xe,%eax
 4fd:	cd 40                	int    $0x40
 4ff:	c3                   	ret    

00000500 <date>:
SYSCALL(date)
 500:	b8 16 00 00 00       	mov    $0x16,%eax
 505:	cd 40                	int    $0x40
 507:	c3                   	ret    

00000508 <dup2>:
SYSCALL(dup2)
 508:	b8 17 00 00 00       	mov    $0x17,%eax
 50d:	cd 40                	int    $0x40
 50f:	c3                   	ret    

00000510 <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 510:	55                   	push   %ebp
 511:	89 e5                	mov    %esp,%ebp
 513:	83 ec 1c             	sub    $0x1c,%esp
 516:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 519:	6a 01                	push   $0x1
 51b:	8d 55 f4             	lea    -0xc(%ebp),%edx
 51e:	52                   	push   %edx
 51f:	50                   	push   %eax
 520:	e8 5b ff ff ff       	call   480 <write>
}
 525:	83 c4 10             	add    $0x10,%esp
 528:	c9                   	leave  
 529:	c3                   	ret    

0000052a <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 52a:	55                   	push   %ebp
 52b:	89 e5                	mov    %esp,%ebp
 52d:	57                   	push   %edi
 52e:	56                   	push   %esi
 52f:	53                   	push   %ebx
 530:	83 ec 2c             	sub    $0x2c,%esp
 533:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 536:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 538:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 53c:	74 04                	je     542 <printint+0x18>
 53e:	85 d2                	test   %edx,%edx
 540:	78 3c                	js     57e <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 542:	89 d1                	mov    %edx,%ecx
  neg = 0;
 544:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 54b:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 550:	89 c8                	mov    %ecx,%eax
 552:	ba 00 00 00 00       	mov    $0x0,%edx
 557:	f7 f6                	div    %esi
 559:	89 df                	mov    %ebx,%edi
 55b:	43                   	inc    %ebx
 55c:	8a 92 b0 07 00 00    	mov    0x7b0(%edx),%dl
 562:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 566:	89 ca                	mov    %ecx,%edx
 568:	89 c1                	mov    %eax,%ecx
 56a:	39 d6                	cmp    %edx,%esi
 56c:	76 e2                	jbe    550 <printint+0x26>
  if(neg)
 56e:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 572:	74 24                	je     598 <printint+0x6e>
    buf[i++] = '-';
 574:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 579:	8d 5f 02             	lea    0x2(%edi),%ebx
 57c:	eb 1a                	jmp    598 <printint+0x6e>
    x = -xx;
 57e:	89 d1                	mov    %edx,%ecx
 580:	f7 d9                	neg    %ecx
    neg = 1;
 582:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 589:	eb c0                	jmp    54b <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 58b:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 590:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 593:	e8 78 ff ff ff       	call   510 <putc>
  while(--i >= 0)
 598:	4b                   	dec    %ebx
 599:	79 f0                	jns    58b <printint+0x61>
}
 59b:	83 c4 2c             	add    $0x2c,%esp
 59e:	5b                   	pop    %ebx
 59f:	5e                   	pop    %esi
 5a0:	5f                   	pop    %edi
 5a1:	5d                   	pop    %ebp
 5a2:	c3                   	ret    

000005a3 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 5a3:	55                   	push   %ebp
 5a4:	89 e5                	mov    %esp,%ebp
 5a6:	57                   	push   %edi
 5a7:	56                   	push   %esi
 5a8:	53                   	push   %ebx
 5a9:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 5ac:	8d 45 10             	lea    0x10(%ebp),%eax
 5af:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 5b2:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 5b7:	bb 00 00 00 00       	mov    $0x0,%ebx
 5bc:	eb 12                	jmp    5d0 <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 5be:	89 fa                	mov    %edi,%edx
 5c0:	8b 45 08             	mov    0x8(%ebp),%eax
 5c3:	e8 48 ff ff ff       	call   510 <putc>
 5c8:	eb 05                	jmp    5cf <printf+0x2c>
      }
    } else if(state == '%'){
 5ca:	83 fe 25             	cmp    $0x25,%esi
 5cd:	74 22                	je     5f1 <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 5cf:	43                   	inc    %ebx
 5d0:	8b 45 0c             	mov    0xc(%ebp),%eax
 5d3:	8a 04 18             	mov    (%eax,%ebx,1),%al
 5d6:	84 c0                	test   %al,%al
 5d8:	0f 84 1d 01 00 00    	je     6fb <printf+0x158>
    c = fmt[i] & 0xff;
 5de:	0f be f8             	movsbl %al,%edi
 5e1:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 5e4:	85 f6                	test   %esi,%esi
 5e6:	75 e2                	jne    5ca <printf+0x27>
      if(c == '%'){
 5e8:	83 f8 25             	cmp    $0x25,%eax
 5eb:	75 d1                	jne    5be <printf+0x1b>
        state = '%';
 5ed:	89 c6                	mov    %eax,%esi
 5ef:	eb de                	jmp    5cf <printf+0x2c>
      if(c == 'd'){
 5f1:	83 f8 25             	cmp    $0x25,%eax
 5f4:	0f 84 cc 00 00 00    	je     6c6 <printf+0x123>
 5fa:	0f 8c da 00 00 00    	jl     6da <printf+0x137>
 600:	83 f8 78             	cmp    $0x78,%eax
 603:	0f 8f d1 00 00 00    	jg     6da <printf+0x137>
 609:	83 f8 63             	cmp    $0x63,%eax
 60c:	0f 8c c8 00 00 00    	jl     6da <printf+0x137>
 612:	83 e8 63             	sub    $0x63,%eax
 615:	83 f8 15             	cmp    $0x15,%eax
 618:	0f 87 bc 00 00 00    	ja     6da <printf+0x137>
 61e:	ff 24 85 58 07 00 00 	jmp    *0x758(,%eax,4)
        printint(fd, *ap, 10, 1);
 625:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 628:	8b 17                	mov    (%edi),%edx
 62a:	83 ec 0c             	sub    $0xc,%esp
 62d:	6a 01                	push   $0x1
 62f:	b9 0a 00 00 00       	mov    $0xa,%ecx
 634:	8b 45 08             	mov    0x8(%ebp),%eax
 637:	e8 ee fe ff ff       	call   52a <printint>
        ap++;
 63c:	83 c7 04             	add    $0x4,%edi
 63f:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 642:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 645:	be 00 00 00 00       	mov    $0x0,%esi
 64a:	eb 83                	jmp    5cf <printf+0x2c>
        printint(fd, *ap, 16, 0);
 64c:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 64f:	8b 17                	mov    (%edi),%edx
 651:	83 ec 0c             	sub    $0xc,%esp
 654:	6a 00                	push   $0x0
 656:	b9 10 00 00 00       	mov    $0x10,%ecx
 65b:	8b 45 08             	mov    0x8(%ebp),%eax
 65e:	e8 c7 fe ff ff       	call   52a <printint>
        ap++;
 663:	83 c7 04             	add    $0x4,%edi
 666:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 669:	83 c4 10             	add    $0x10,%esp
      state = 0;
 66c:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 671:	e9 59 ff ff ff       	jmp    5cf <printf+0x2c>
        s = (char*)*ap;
 676:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 679:	8b 30                	mov    (%eax),%esi
        ap++;
 67b:	83 c0 04             	add    $0x4,%eax
 67e:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 681:	85 f6                	test   %esi,%esi
 683:	75 13                	jne    698 <printf+0xf5>
          s = "(null)";
 685:	be 4e 07 00 00       	mov    $0x74e,%esi
 68a:	eb 0c                	jmp    698 <printf+0xf5>
          putc(fd, *s);
 68c:	0f be d2             	movsbl %dl,%edx
 68f:	8b 45 08             	mov    0x8(%ebp),%eax
 692:	e8 79 fe ff ff       	call   510 <putc>
          s++;
 697:	46                   	inc    %esi
        while(*s != 0){
 698:	8a 16                	mov    (%esi),%dl
 69a:	84 d2                	test   %dl,%dl
 69c:	75 ee                	jne    68c <printf+0xe9>
      state = 0;
 69e:	be 00 00 00 00       	mov    $0x0,%esi
 6a3:	e9 27 ff ff ff       	jmp    5cf <printf+0x2c>
        putc(fd, *ap);
 6a8:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 6ab:	0f be 17             	movsbl (%edi),%edx
 6ae:	8b 45 08             	mov    0x8(%ebp),%eax
 6b1:	e8 5a fe ff ff       	call   510 <putc>
        ap++;
 6b6:	83 c7 04             	add    $0x4,%edi
 6b9:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 6bc:	be 00 00 00 00       	mov    $0x0,%esi
 6c1:	e9 09 ff ff ff       	jmp    5cf <printf+0x2c>
        putc(fd, c);
 6c6:	89 fa                	mov    %edi,%edx
 6c8:	8b 45 08             	mov    0x8(%ebp),%eax
 6cb:	e8 40 fe ff ff       	call   510 <putc>
      state = 0;
 6d0:	be 00 00 00 00       	mov    $0x0,%esi
 6d5:	e9 f5 fe ff ff       	jmp    5cf <printf+0x2c>
        putc(fd, '%');
 6da:	ba 25 00 00 00       	mov    $0x25,%edx
 6df:	8b 45 08             	mov    0x8(%ebp),%eax
 6e2:	e8 29 fe ff ff       	call   510 <putc>
        putc(fd, c);
 6e7:	89 fa                	mov    %edi,%edx
 6e9:	8b 45 08             	mov    0x8(%ebp),%eax
 6ec:	e8 1f fe ff ff       	call   510 <putc>
      state = 0;
 6f1:	be 00 00 00 00       	mov    $0x0,%esi
 6f6:	e9 d4 fe ff ff       	jmp    5cf <printf+0x2c>
    }
  }
}
 6fb:	8d 65 f4             	lea    -0xc(%ebp),%esp
 6fe:	5b                   	pop    %ebx
 6ff:	5e                   	pop    %esi
 700:	5f                   	pop    %edi
 701:	5d                   	pop    %ebp
 702:	c3                   	ret    
