
rm:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <main>:
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	57                   	push   %edi
   e:	56                   	push   %esi
   f:	53                   	push   %ebx
  10:	51                   	push   %ecx
  11:	83 ec 18             	sub    $0x18,%esp
  14:	8b 01                	mov    (%ecx),%eax
  16:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  19:	8b 79 04             	mov    0x4(%ecx),%edi
  int i;

  if(argc < 2){
  1c:	83 f8 01             	cmp    $0x1,%eax
  1f:	7e 07                	jle    28 <main+0x28>
    printf(2, "Usage: rm files...\n");
    exit();
  }

  for(i = 1; i < argc; i++){
  21:	bb 01 00 00 00       	mov    $0x1,%ebx
  26:	eb 15                	jmp    3d <main+0x3d>
    printf(2, "Usage: rm files...\n");
  28:	83 ec 08             	sub    $0x8,%esp
  2b:	68 1c 03 00 00       	push   $0x31c
  30:	6a 02                	push   $0x2
  32:	e8 83 01 00 00       	call   1ba <printf>
    exit();
  37:	e8 3b 00 00 00       	call   77 <exit>
  for(i = 1; i < argc; i++){
  3c:	43                   	inc    %ebx
  3d:	3b 5d e4             	cmp    -0x1c(%ebp),%ebx
  40:	7d 28                	jge    6a <main+0x6a>
    if(unlink(argv[i]) < 0){
  42:	8d 34 9f             	lea    (%edi,%ebx,4),%esi
  45:	83 ec 0c             	sub    $0xc,%esp
  48:	ff 36                	push   (%esi)
  4a:	e8 78 00 00 00       	call   c7 <unlink>
  4f:	83 c4 10             	add    $0x10,%esp
  52:	85 c0                	test   %eax,%eax
  54:	79 e6                	jns    3c <main+0x3c>
      printf(2, "rm: %s failed to delete\n", argv[i]);
  56:	83 ec 04             	sub    $0x4,%esp
  59:	ff 36                	push   (%esi)
  5b:	68 30 03 00 00       	push   $0x330
  60:	6a 02                	push   $0x2
  62:	e8 53 01 00 00       	call   1ba <printf>
      break;
  67:	83 c4 10             	add    $0x10,%esp
    }
  }

  exit();
  6a:	e8 08 00 00 00       	call   77 <exit>

0000006f <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
  6f:	b8 01 00 00 00       	mov    $0x1,%eax
  74:	cd 40                	int    $0x40
  76:	c3                   	ret    

00000077 <exit>:
SYSCALL(exit)
  77:	b8 02 00 00 00       	mov    $0x2,%eax
  7c:	cd 40                	int    $0x40
  7e:	c3                   	ret    

0000007f <wait>:
SYSCALL(wait)
  7f:	b8 03 00 00 00       	mov    $0x3,%eax
  84:	cd 40                	int    $0x40
  86:	c3                   	ret    

00000087 <pipe>:
SYSCALL(pipe)
  87:	b8 04 00 00 00       	mov    $0x4,%eax
  8c:	cd 40                	int    $0x40
  8e:	c3                   	ret    

0000008f <read>:
SYSCALL(read)
  8f:	b8 05 00 00 00       	mov    $0x5,%eax
  94:	cd 40                	int    $0x40
  96:	c3                   	ret    

00000097 <write>:
SYSCALL(write)
  97:	b8 10 00 00 00       	mov    $0x10,%eax
  9c:	cd 40                	int    $0x40
  9e:	c3                   	ret    

0000009f <close>:
SYSCALL(close)
  9f:	b8 15 00 00 00       	mov    $0x15,%eax
  a4:	cd 40                	int    $0x40
  a6:	c3                   	ret    

000000a7 <kill>:
SYSCALL(kill)
  a7:	b8 06 00 00 00       	mov    $0x6,%eax
  ac:	cd 40                	int    $0x40
  ae:	c3                   	ret    

000000af <exec>:
SYSCALL(exec)
  af:	b8 07 00 00 00       	mov    $0x7,%eax
  b4:	cd 40                	int    $0x40
  b6:	c3                   	ret    

000000b7 <open>:
SYSCALL(open)
  b7:	b8 0f 00 00 00       	mov    $0xf,%eax
  bc:	cd 40                	int    $0x40
  be:	c3                   	ret    

000000bf <mknod>:
SYSCALL(mknod)
  bf:	b8 11 00 00 00       	mov    $0x11,%eax
  c4:	cd 40                	int    $0x40
  c6:	c3                   	ret    

000000c7 <unlink>:
SYSCALL(unlink)
  c7:	b8 12 00 00 00       	mov    $0x12,%eax
  cc:	cd 40                	int    $0x40
  ce:	c3                   	ret    

000000cf <fstat>:
SYSCALL(fstat)
  cf:	b8 08 00 00 00       	mov    $0x8,%eax
  d4:	cd 40                	int    $0x40
  d6:	c3                   	ret    

000000d7 <link>:
SYSCALL(link)
  d7:	b8 13 00 00 00       	mov    $0x13,%eax
  dc:	cd 40                	int    $0x40
  de:	c3                   	ret    

000000df <mkdir>:
SYSCALL(mkdir)
  df:	b8 14 00 00 00       	mov    $0x14,%eax
  e4:	cd 40                	int    $0x40
  e6:	c3                   	ret    

000000e7 <chdir>:
SYSCALL(chdir)
  e7:	b8 09 00 00 00       	mov    $0x9,%eax
  ec:	cd 40                	int    $0x40
  ee:	c3                   	ret    

000000ef <dup>:
SYSCALL(dup)
  ef:	b8 0a 00 00 00       	mov    $0xa,%eax
  f4:	cd 40                	int    $0x40
  f6:	c3                   	ret    

000000f7 <getpid>:
SYSCALL(getpid)
  f7:	b8 0b 00 00 00       	mov    $0xb,%eax
  fc:	cd 40                	int    $0x40
  fe:	c3                   	ret    

000000ff <sbrk>:
SYSCALL(sbrk)
  ff:	b8 0c 00 00 00       	mov    $0xc,%eax
 104:	cd 40                	int    $0x40
 106:	c3                   	ret    

00000107 <sleep>:
SYSCALL(sleep)
 107:	b8 0d 00 00 00       	mov    $0xd,%eax
 10c:	cd 40                	int    $0x40
 10e:	c3                   	ret    

0000010f <uptime>:
SYSCALL(uptime)
 10f:	b8 0e 00 00 00       	mov    $0xe,%eax
 114:	cd 40                	int    $0x40
 116:	c3                   	ret    

00000117 <date>:
SYSCALL(date)
 117:	b8 16 00 00 00       	mov    $0x16,%eax
 11c:	cd 40                	int    $0x40
 11e:	c3                   	ret    

0000011f <dup2>:
SYSCALL(dup2)
 11f:	b8 17 00 00 00       	mov    $0x17,%eax
 124:	cd 40                	int    $0x40
 126:	c3                   	ret    

00000127 <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 127:	55                   	push   %ebp
 128:	89 e5                	mov    %esp,%ebp
 12a:	83 ec 1c             	sub    $0x1c,%esp
 12d:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 130:	6a 01                	push   $0x1
 132:	8d 55 f4             	lea    -0xc(%ebp),%edx
 135:	52                   	push   %edx
 136:	50                   	push   %eax
 137:	e8 5b ff ff ff       	call   97 <write>
}
 13c:	83 c4 10             	add    $0x10,%esp
 13f:	c9                   	leave  
 140:	c3                   	ret    

00000141 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 141:	55                   	push   %ebp
 142:	89 e5                	mov    %esp,%ebp
 144:	57                   	push   %edi
 145:	56                   	push   %esi
 146:	53                   	push   %ebx
 147:	83 ec 2c             	sub    $0x2c,%esp
 14a:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 14d:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 14f:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 153:	74 04                	je     159 <printint+0x18>
 155:	85 d2                	test   %edx,%edx
 157:	78 3c                	js     195 <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 159:	89 d1                	mov    %edx,%ecx
  neg = 0;
 15b:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 162:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 167:	89 c8                	mov    %ecx,%eax
 169:	ba 00 00 00 00       	mov    $0x0,%edx
 16e:	f7 f6                	div    %esi
 170:	89 df                	mov    %ebx,%edi
 172:	43                   	inc    %ebx
 173:	8a 92 a8 03 00 00    	mov    0x3a8(%edx),%dl
 179:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 17d:	89 ca                	mov    %ecx,%edx
 17f:	89 c1                	mov    %eax,%ecx
 181:	39 d6                	cmp    %edx,%esi
 183:	76 e2                	jbe    167 <printint+0x26>
  if(neg)
 185:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 189:	74 24                	je     1af <printint+0x6e>
    buf[i++] = '-';
 18b:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 190:	8d 5f 02             	lea    0x2(%edi),%ebx
 193:	eb 1a                	jmp    1af <printint+0x6e>
    x = -xx;
 195:	89 d1                	mov    %edx,%ecx
 197:	f7 d9                	neg    %ecx
    neg = 1;
 199:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 1a0:	eb c0                	jmp    162 <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 1a2:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 1a7:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 1aa:	e8 78 ff ff ff       	call   127 <putc>
  while(--i >= 0)
 1af:	4b                   	dec    %ebx
 1b0:	79 f0                	jns    1a2 <printint+0x61>
}
 1b2:	83 c4 2c             	add    $0x2c,%esp
 1b5:	5b                   	pop    %ebx
 1b6:	5e                   	pop    %esi
 1b7:	5f                   	pop    %edi
 1b8:	5d                   	pop    %ebp
 1b9:	c3                   	ret    

000001ba <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 1ba:	55                   	push   %ebp
 1bb:	89 e5                	mov    %esp,%ebp
 1bd:	57                   	push   %edi
 1be:	56                   	push   %esi
 1bf:	53                   	push   %ebx
 1c0:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 1c3:	8d 45 10             	lea    0x10(%ebp),%eax
 1c6:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 1c9:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 1ce:	bb 00 00 00 00       	mov    $0x0,%ebx
 1d3:	eb 12                	jmp    1e7 <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 1d5:	89 fa                	mov    %edi,%edx
 1d7:	8b 45 08             	mov    0x8(%ebp),%eax
 1da:	e8 48 ff ff ff       	call   127 <putc>
 1df:	eb 05                	jmp    1e6 <printf+0x2c>
      }
    } else if(state == '%'){
 1e1:	83 fe 25             	cmp    $0x25,%esi
 1e4:	74 22                	je     208 <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 1e6:	43                   	inc    %ebx
 1e7:	8b 45 0c             	mov    0xc(%ebp),%eax
 1ea:	8a 04 18             	mov    (%eax,%ebx,1),%al
 1ed:	84 c0                	test   %al,%al
 1ef:	0f 84 1d 01 00 00    	je     312 <printf+0x158>
    c = fmt[i] & 0xff;
 1f5:	0f be f8             	movsbl %al,%edi
 1f8:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 1fb:	85 f6                	test   %esi,%esi
 1fd:	75 e2                	jne    1e1 <printf+0x27>
      if(c == '%'){
 1ff:	83 f8 25             	cmp    $0x25,%eax
 202:	75 d1                	jne    1d5 <printf+0x1b>
        state = '%';
 204:	89 c6                	mov    %eax,%esi
 206:	eb de                	jmp    1e6 <printf+0x2c>
      if(c == 'd'){
 208:	83 f8 25             	cmp    $0x25,%eax
 20b:	0f 84 cc 00 00 00    	je     2dd <printf+0x123>
 211:	0f 8c da 00 00 00    	jl     2f1 <printf+0x137>
 217:	83 f8 78             	cmp    $0x78,%eax
 21a:	0f 8f d1 00 00 00    	jg     2f1 <printf+0x137>
 220:	83 f8 63             	cmp    $0x63,%eax
 223:	0f 8c c8 00 00 00    	jl     2f1 <printf+0x137>
 229:	83 e8 63             	sub    $0x63,%eax
 22c:	83 f8 15             	cmp    $0x15,%eax
 22f:	0f 87 bc 00 00 00    	ja     2f1 <printf+0x137>
 235:	ff 24 85 50 03 00 00 	jmp    *0x350(,%eax,4)
        printint(fd, *ap, 10, 1);
 23c:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 23f:	8b 17                	mov    (%edi),%edx
 241:	83 ec 0c             	sub    $0xc,%esp
 244:	6a 01                	push   $0x1
 246:	b9 0a 00 00 00       	mov    $0xa,%ecx
 24b:	8b 45 08             	mov    0x8(%ebp),%eax
 24e:	e8 ee fe ff ff       	call   141 <printint>
        ap++;
 253:	83 c7 04             	add    $0x4,%edi
 256:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 259:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 25c:	be 00 00 00 00       	mov    $0x0,%esi
 261:	eb 83                	jmp    1e6 <printf+0x2c>
        printint(fd, *ap, 16, 0);
 263:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 266:	8b 17                	mov    (%edi),%edx
 268:	83 ec 0c             	sub    $0xc,%esp
 26b:	6a 00                	push   $0x0
 26d:	b9 10 00 00 00       	mov    $0x10,%ecx
 272:	8b 45 08             	mov    0x8(%ebp),%eax
 275:	e8 c7 fe ff ff       	call   141 <printint>
        ap++;
 27a:	83 c7 04             	add    $0x4,%edi
 27d:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 280:	83 c4 10             	add    $0x10,%esp
      state = 0;
 283:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 288:	e9 59 ff ff ff       	jmp    1e6 <printf+0x2c>
        s = (char*)*ap;
 28d:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 290:	8b 30                	mov    (%eax),%esi
        ap++;
 292:	83 c0 04             	add    $0x4,%eax
 295:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 298:	85 f6                	test   %esi,%esi
 29a:	75 13                	jne    2af <printf+0xf5>
          s = "(null)";
 29c:	be 49 03 00 00       	mov    $0x349,%esi
 2a1:	eb 0c                	jmp    2af <printf+0xf5>
          putc(fd, *s);
 2a3:	0f be d2             	movsbl %dl,%edx
 2a6:	8b 45 08             	mov    0x8(%ebp),%eax
 2a9:	e8 79 fe ff ff       	call   127 <putc>
          s++;
 2ae:	46                   	inc    %esi
        while(*s != 0){
 2af:	8a 16                	mov    (%esi),%dl
 2b1:	84 d2                	test   %dl,%dl
 2b3:	75 ee                	jne    2a3 <printf+0xe9>
      state = 0;
 2b5:	be 00 00 00 00       	mov    $0x0,%esi
 2ba:	e9 27 ff ff ff       	jmp    1e6 <printf+0x2c>
        putc(fd, *ap);
 2bf:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 2c2:	0f be 17             	movsbl (%edi),%edx
 2c5:	8b 45 08             	mov    0x8(%ebp),%eax
 2c8:	e8 5a fe ff ff       	call   127 <putc>
        ap++;
 2cd:	83 c7 04             	add    $0x4,%edi
 2d0:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 2d3:	be 00 00 00 00       	mov    $0x0,%esi
 2d8:	e9 09 ff ff ff       	jmp    1e6 <printf+0x2c>
        putc(fd, c);
 2dd:	89 fa                	mov    %edi,%edx
 2df:	8b 45 08             	mov    0x8(%ebp),%eax
 2e2:	e8 40 fe ff ff       	call   127 <putc>
      state = 0;
 2e7:	be 00 00 00 00       	mov    $0x0,%esi
 2ec:	e9 f5 fe ff ff       	jmp    1e6 <printf+0x2c>
        putc(fd, '%');
 2f1:	ba 25 00 00 00       	mov    $0x25,%edx
 2f6:	8b 45 08             	mov    0x8(%ebp),%eax
 2f9:	e8 29 fe ff ff       	call   127 <putc>
        putc(fd, c);
 2fe:	89 fa                	mov    %edi,%edx
 300:	8b 45 08             	mov    0x8(%ebp),%eax
 303:	e8 1f fe ff ff       	call   127 <putc>
      state = 0;
 308:	be 00 00 00 00       	mov    $0x0,%esi
 30d:	e9 d4 fe ff ff       	jmp    1e6 <printf+0x2c>
    }
  }
}
 312:	8d 65 f4             	lea    -0xc(%ebp),%esp
 315:	5b                   	pop    %ebx
 316:	5e                   	pop    %esi
 317:	5f                   	pop    %edi
 318:	5d                   	pop    %ebp
 319:	c3                   	ret    
