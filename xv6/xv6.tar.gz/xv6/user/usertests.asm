
usertests:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <iputtest>:
int stdout = 1;

// does chdir() call iput(p->cwd) in a transaction?
void
iputtest(void)
{
       0:	55                   	push   %ebp
       1:	89 e5                	mov    %esp,%ebp
       3:	83 ec 10             	sub    $0x10,%esp
  printf(stdout, "iput test\n");
       6:	68 0c 3b 00 00       	push   $0x3b0c
       b:	ff 35 20 5b 00 00    	push   0x5b20
      11:	e8 bc 37 00 00       	call   37d2 <printf>

  if(mkdir("iputdir") < 0){
      16:	c7 04 24 9f 3a 00 00 	movl   $0x3a9f,(%esp)
      1d:	e8 d5 36 00 00       	call   36f7 <mkdir>
      22:	83 c4 10             	add    $0x10,%esp
      25:	85 c0                	test   %eax,%eax
      27:	78 54                	js     7d <iputtest+0x7d>
    printf(stdout, "mkdir failed\n");
    exit();
  }
  if(chdir("iputdir") < 0){
      29:	83 ec 0c             	sub    $0xc,%esp
      2c:	68 9f 3a 00 00       	push   $0x3a9f
      31:	e8 c9 36 00 00       	call   36ff <chdir>
      36:	83 c4 10             	add    $0x10,%esp
      39:	85 c0                	test   %eax,%eax
      3b:	78 58                	js     95 <iputtest+0x95>
    printf(stdout, "chdir iputdir failed\n");
    exit();
  }
  if(unlink("../iputdir") < 0){
      3d:	83 ec 0c             	sub    $0xc,%esp
      40:	68 9c 3a 00 00       	push   $0x3a9c
      45:	e8 95 36 00 00       	call   36df <unlink>
      4a:	83 c4 10             	add    $0x10,%esp
      4d:	85 c0                	test   %eax,%eax
      4f:	78 5c                	js     ad <iputtest+0xad>
    printf(stdout, "unlink ../iputdir failed\n");
    exit();
  }
  if(chdir("/") < 0){
      51:	83 ec 0c             	sub    $0xc,%esp
      54:	68 c1 3a 00 00       	push   $0x3ac1
      59:	e8 a1 36 00 00       	call   36ff <chdir>
      5e:	83 c4 10             	add    $0x10,%esp
      61:	85 c0                	test   %eax,%eax
      63:	78 60                	js     c5 <iputtest+0xc5>
    printf(stdout, "chdir / failed\n");
    exit();
  }
  printf(stdout, "iput test ok\n");
      65:	83 ec 08             	sub    $0x8,%esp
      68:	68 44 3b 00 00       	push   $0x3b44
      6d:	ff 35 20 5b 00 00    	push   0x5b20
      73:	e8 5a 37 00 00       	call   37d2 <printf>
}
      78:	83 c4 10             	add    $0x10,%esp
      7b:	c9                   	leave  
      7c:	c3                   	ret    
    printf(stdout, "mkdir failed\n");
      7d:	83 ec 08             	sub    $0x8,%esp
      80:	68 78 3a 00 00       	push   $0x3a78
      85:	ff 35 20 5b 00 00    	push   0x5b20
      8b:	e8 42 37 00 00       	call   37d2 <printf>
    exit();
      90:	e8 fa 35 00 00       	call   368f <exit>
    printf(stdout, "chdir iputdir failed\n");
      95:	83 ec 08             	sub    $0x8,%esp
      98:	68 86 3a 00 00       	push   $0x3a86
      9d:	ff 35 20 5b 00 00    	push   0x5b20
      a3:	e8 2a 37 00 00       	call   37d2 <printf>
    exit();
      a8:	e8 e2 35 00 00       	call   368f <exit>
    printf(stdout, "unlink ../iputdir failed\n");
      ad:	83 ec 08             	sub    $0x8,%esp
      b0:	68 a7 3a 00 00       	push   $0x3aa7
      b5:	ff 35 20 5b 00 00    	push   0x5b20
      bb:	e8 12 37 00 00       	call   37d2 <printf>
    exit();
      c0:	e8 ca 35 00 00       	call   368f <exit>
    printf(stdout, "chdir / failed\n");
      c5:	83 ec 08             	sub    $0x8,%esp
      c8:	68 c3 3a 00 00       	push   $0x3ac3
      cd:	ff 35 20 5b 00 00    	push   0x5b20
      d3:	e8 fa 36 00 00       	call   37d2 <printf>
    exit();
      d8:	e8 b2 35 00 00       	call   368f <exit>

000000dd <exitiputtest>:

// does exit() call iput(p->cwd) in a transaction?
void
exitiputtest(void)
{
      dd:	55                   	push   %ebp
      de:	89 e5                	mov    %esp,%ebp
      e0:	83 ec 10             	sub    $0x10,%esp
  int pid;

  printf(stdout, "exitiput test\n");
      e3:	68 d3 3a 00 00       	push   $0x3ad3
      e8:	ff 35 20 5b 00 00    	push   0x5b20
      ee:	e8 df 36 00 00       	call   37d2 <printf>

  pid = fork();
      f3:	e8 8f 35 00 00       	call   3687 <fork>
  if(pid < 0){
      f8:	83 c4 10             	add    $0x10,%esp
      fb:	85 c0                	test   %eax,%eax
      fd:	78 47                	js     146 <exitiputtest+0x69>
    printf(stdout, "fork failed\n");
    exit();
  }
  if(pid == 0){
      ff:	0f 85 a1 00 00 00    	jne    1a6 <exitiputtest+0xc9>
    if(mkdir("iputdir") < 0){
     105:	83 ec 0c             	sub    $0xc,%esp
     108:	68 9f 3a 00 00       	push   $0x3a9f
     10d:	e8 e5 35 00 00       	call   36f7 <mkdir>
     112:	83 c4 10             	add    $0x10,%esp
     115:	85 c0                	test   %eax,%eax
     117:	78 45                	js     15e <exitiputtest+0x81>
      printf(stdout, "mkdir failed\n");
      exit();
    }
    if(chdir("iputdir") < 0){
     119:	83 ec 0c             	sub    $0xc,%esp
     11c:	68 9f 3a 00 00       	push   $0x3a9f
     121:	e8 d9 35 00 00       	call   36ff <chdir>
     126:	83 c4 10             	add    $0x10,%esp
     129:	85 c0                	test   %eax,%eax
     12b:	78 49                	js     176 <exitiputtest+0x99>
      printf(stdout, "child chdir failed\n");
      exit();
    }
    if(unlink("../iputdir") < 0){
     12d:	83 ec 0c             	sub    $0xc,%esp
     130:	68 9c 3a 00 00       	push   $0x3a9c
     135:	e8 a5 35 00 00       	call   36df <unlink>
     13a:	83 c4 10             	add    $0x10,%esp
     13d:	85 c0                	test   %eax,%eax
     13f:	78 4d                	js     18e <exitiputtest+0xb1>
      printf(stdout, "unlink ../iputdir failed\n");
      exit();
    }
    exit();
     141:	e8 49 35 00 00       	call   368f <exit>
    printf(stdout, "fork failed\n");
     146:	83 ec 08             	sub    $0x8,%esp
     149:	68 b9 49 00 00       	push   $0x49b9
     14e:	ff 35 20 5b 00 00    	push   0x5b20
     154:	e8 79 36 00 00       	call   37d2 <printf>
    exit();
     159:	e8 31 35 00 00       	call   368f <exit>
      printf(stdout, "mkdir failed\n");
     15e:	83 ec 08             	sub    $0x8,%esp
     161:	68 78 3a 00 00       	push   $0x3a78
     166:	ff 35 20 5b 00 00    	push   0x5b20
     16c:	e8 61 36 00 00       	call   37d2 <printf>
      exit();
     171:	e8 19 35 00 00       	call   368f <exit>
      printf(stdout, "child chdir failed\n");
     176:	83 ec 08             	sub    $0x8,%esp
     179:	68 e2 3a 00 00       	push   $0x3ae2
     17e:	ff 35 20 5b 00 00    	push   0x5b20
     184:	e8 49 36 00 00       	call   37d2 <printf>
      exit();
     189:	e8 01 35 00 00       	call   368f <exit>
      printf(stdout, "unlink ../iputdir failed\n");
     18e:	83 ec 08             	sub    $0x8,%esp
     191:	68 a7 3a 00 00       	push   $0x3aa7
     196:	ff 35 20 5b 00 00    	push   0x5b20
     19c:	e8 31 36 00 00       	call   37d2 <printf>
      exit();
     1a1:	e8 e9 34 00 00       	call   368f <exit>
  }
  wait();
     1a6:	e8 ec 34 00 00       	call   3697 <wait>
  printf(stdout, "exitiput test ok\n");
     1ab:	83 ec 08             	sub    $0x8,%esp
     1ae:	68 f6 3a 00 00       	push   $0x3af6
     1b3:	ff 35 20 5b 00 00    	push   0x5b20
     1b9:	e8 14 36 00 00       	call   37d2 <printf>
}
     1be:	83 c4 10             	add    $0x10,%esp
     1c1:	c9                   	leave  
     1c2:	c3                   	ret    

000001c3 <openiputtest>:
//      for(i = 0; i < 10000; i++)
//        yield();
//    }
void
openiputtest(void)
{
     1c3:	55                   	push   %ebp
     1c4:	89 e5                	mov    %esp,%ebp
     1c6:	83 ec 10             	sub    $0x10,%esp
  int pid;

  printf(stdout, "openiput test\n");
     1c9:	68 08 3b 00 00       	push   $0x3b08
     1ce:	ff 35 20 5b 00 00    	push   0x5b20
     1d4:	e8 f9 35 00 00       	call   37d2 <printf>
  if(mkdir("oidir") < 0){
     1d9:	c7 04 24 17 3b 00 00 	movl   $0x3b17,(%esp)
     1e0:	e8 12 35 00 00       	call   36f7 <mkdir>
     1e5:	83 c4 10             	add    $0x10,%esp
     1e8:	85 c0                	test   %eax,%eax
     1ea:	78 39                	js     225 <openiputtest+0x62>
    printf(stdout, "mkdir oidir failed\n");
    exit();
  }
  pid = fork();
     1ec:	e8 96 34 00 00       	call   3687 <fork>
  if(pid < 0){
     1f1:	85 c0                	test   %eax,%eax
     1f3:	78 48                	js     23d <openiputtest+0x7a>
    printf(stdout, "fork failed\n");
    exit();
  }
  if(pid == 0){
     1f5:	75 63                	jne    25a <openiputtest+0x97>
    int fd = open("oidir", O_RDWR);
     1f7:	83 ec 08             	sub    $0x8,%esp
     1fa:	6a 02                	push   $0x2
     1fc:	68 17 3b 00 00       	push   $0x3b17
     201:	e8 c9 34 00 00       	call   36cf <open>
    if(fd >= 0){
     206:	83 c4 10             	add    $0x10,%esp
     209:	85 c0                	test   %eax,%eax
     20b:	78 48                	js     255 <openiputtest+0x92>
      printf(stdout, "open directory for write succeeded\n");
     20d:	83 ec 08             	sub    $0x8,%esp
     210:	68 9c 4a 00 00       	push   $0x4a9c
     215:	ff 35 20 5b 00 00    	push   0x5b20
     21b:	e8 b2 35 00 00       	call   37d2 <printf>
      exit();
     220:	e8 6a 34 00 00       	call   368f <exit>
    printf(stdout, "mkdir oidir failed\n");
     225:	83 ec 08             	sub    $0x8,%esp
     228:	68 1d 3b 00 00       	push   $0x3b1d
     22d:	ff 35 20 5b 00 00    	push   0x5b20
     233:	e8 9a 35 00 00       	call   37d2 <printf>
    exit();
     238:	e8 52 34 00 00       	call   368f <exit>
    printf(stdout, "fork failed\n");
     23d:	83 ec 08             	sub    $0x8,%esp
     240:	68 b9 49 00 00       	push   $0x49b9
     245:	ff 35 20 5b 00 00    	push   0x5b20
     24b:	e8 82 35 00 00       	call   37d2 <printf>
    exit();
     250:	e8 3a 34 00 00       	call   368f <exit>
    }
    exit();
     255:	e8 35 34 00 00       	call   368f <exit>
  }
  sleep(1);
     25a:	83 ec 0c             	sub    $0xc,%esp
     25d:	6a 01                	push   $0x1
     25f:	e8 bb 34 00 00       	call   371f <sleep>
  if(unlink("oidir") != 0){
     264:	c7 04 24 17 3b 00 00 	movl   $0x3b17,(%esp)
     26b:	e8 6f 34 00 00       	call   36df <unlink>
     270:	83 c4 10             	add    $0x10,%esp
     273:	85 c0                	test   %eax,%eax
     275:	75 1d                	jne    294 <openiputtest+0xd1>
    printf(stdout, "unlink failed\n");
    exit();
  }
  wait();
     277:	e8 1b 34 00 00       	call   3697 <wait>
  printf(stdout, "openiput test ok\n");
     27c:	83 ec 08             	sub    $0x8,%esp
     27f:	68 40 3b 00 00       	push   $0x3b40
     284:	ff 35 20 5b 00 00    	push   0x5b20
     28a:	e8 43 35 00 00       	call   37d2 <printf>
}
     28f:	83 c4 10             	add    $0x10,%esp
     292:	c9                   	leave  
     293:	c3                   	ret    
    printf(stdout, "unlink failed\n");
     294:	83 ec 08             	sub    $0x8,%esp
     297:	68 31 3b 00 00       	push   $0x3b31
     29c:	ff 35 20 5b 00 00    	push   0x5b20
     2a2:	e8 2b 35 00 00       	call   37d2 <printf>
    exit();
     2a7:	e8 e3 33 00 00       	call   368f <exit>

000002ac <opentest>:

// simple file system tests

void
opentest(void)
{
     2ac:	55                   	push   %ebp
     2ad:	89 e5                	mov    %esp,%ebp
     2af:	83 ec 10             	sub    $0x10,%esp
  int fd;

  printf(stdout, "open test\n");
     2b2:	68 52 3b 00 00       	push   $0x3b52
     2b7:	ff 35 20 5b 00 00    	push   0x5b20
     2bd:	e8 10 35 00 00       	call   37d2 <printf>
  fd = open("echo", 0);
     2c2:	83 c4 08             	add    $0x8,%esp
     2c5:	6a 00                	push   $0x0
     2c7:	68 5d 3b 00 00       	push   $0x3b5d
     2cc:	e8 fe 33 00 00       	call   36cf <open>
  if(fd < 0){
     2d1:	83 c4 10             	add    $0x10,%esp
     2d4:	85 c0                	test   %eax,%eax
     2d6:	78 37                	js     30f <opentest+0x63>
    printf(stdout, "open echo failed!\n");
    exit();
  }
  close(fd);
     2d8:	83 ec 0c             	sub    $0xc,%esp
     2db:	50                   	push   %eax
     2dc:	e8 d6 33 00 00       	call   36b7 <close>
  fd = open("doesnotexist", 0);
     2e1:	83 c4 08             	add    $0x8,%esp
     2e4:	6a 00                	push   $0x0
     2e6:	68 75 3b 00 00       	push   $0x3b75
     2eb:	e8 df 33 00 00       	call   36cf <open>
  if(fd >= 0){
     2f0:	83 c4 10             	add    $0x10,%esp
     2f3:	85 c0                	test   %eax,%eax
     2f5:	79 30                	jns    327 <opentest+0x7b>
    printf(stdout, "open doesnotexist succeeded!\n");
    exit();
  }
  printf(stdout, "open test ok\n");
     2f7:	83 ec 08             	sub    $0x8,%esp
     2fa:	68 a0 3b 00 00       	push   $0x3ba0
     2ff:	ff 35 20 5b 00 00    	push   0x5b20
     305:	e8 c8 34 00 00       	call   37d2 <printf>
}
     30a:	83 c4 10             	add    $0x10,%esp
     30d:	c9                   	leave  
     30e:	c3                   	ret    
    printf(stdout, "open echo failed!\n");
     30f:	83 ec 08             	sub    $0x8,%esp
     312:	68 62 3b 00 00       	push   $0x3b62
     317:	ff 35 20 5b 00 00    	push   0x5b20
     31d:	e8 b0 34 00 00       	call   37d2 <printf>
    exit();
     322:	e8 68 33 00 00       	call   368f <exit>
    printf(stdout, "open doesnotexist succeeded!\n");
     327:	83 ec 08             	sub    $0x8,%esp
     32a:	68 82 3b 00 00       	push   $0x3b82
     32f:	ff 35 20 5b 00 00    	push   0x5b20
     335:	e8 98 34 00 00       	call   37d2 <printf>
    exit();
     33a:	e8 50 33 00 00       	call   368f <exit>

0000033f <writetest>:

void
writetest(void)
{
     33f:	55                   	push   %ebp
     340:	89 e5                	mov    %esp,%ebp
     342:	56                   	push   %esi
     343:	53                   	push   %ebx
  int fd;
  int i;

  printf(stdout, "small file test\n");
     344:	83 ec 08             	sub    $0x8,%esp
     347:	68 ae 3b 00 00       	push   $0x3bae
     34c:	ff 35 20 5b 00 00    	push   0x5b20
     352:	e8 7b 34 00 00       	call   37d2 <printf>
  fd = open("small", O_CREATE|O_RDWR);
     357:	83 c4 08             	add    $0x8,%esp
     35a:	68 02 02 00 00       	push   $0x202
     35f:	68 bf 3b 00 00       	push   $0x3bbf
     364:	e8 66 33 00 00       	call   36cf <open>
  if(fd >= 0){
     369:	83 c4 10             	add    $0x10,%esp
     36c:	85 c0                	test   %eax,%eax
     36e:	78 55                	js     3c5 <writetest+0x86>
     370:	89 c6                	mov    %eax,%esi
    printf(stdout, "creat small succeeded; ok\n");
     372:	83 ec 08             	sub    $0x8,%esp
     375:	68 c5 3b 00 00       	push   $0x3bc5
     37a:	ff 35 20 5b 00 00    	push   0x5b20
     380:	e8 4d 34 00 00       	call   37d2 <printf>
  } else {
    printf(stdout, "error: creat small failed!\n");
    exit();
  }
  for(i = 0; i < 100; i++){
     385:	83 c4 10             	add    $0x10,%esp
     388:	bb 00 00 00 00       	mov    $0x0,%ebx
     38d:	83 fb 63             	cmp    $0x63,%ebx
     390:	7f 7d                	jg     40f <writetest+0xd0>
    if(write(fd, "aaaaaaaaaa", 10) != 10){
     392:	83 ec 04             	sub    $0x4,%esp
     395:	6a 0a                	push   $0xa
     397:	68 fc 3b 00 00       	push   $0x3bfc
     39c:	56                   	push   %esi
     39d:	e8 0d 33 00 00       	call   36af <write>
     3a2:	83 c4 10             	add    $0x10,%esp
     3a5:	83 f8 0a             	cmp    $0xa,%eax
     3a8:	75 33                	jne    3dd <writetest+0x9e>
      printf(stdout, "error: write aa %d new file failed\n", i);
      exit();
    }
    if(write(fd, "bbbbbbbbbb", 10) != 10){
     3aa:	83 ec 04             	sub    $0x4,%esp
     3ad:	6a 0a                	push   $0xa
     3af:	68 07 3c 00 00       	push   $0x3c07
     3b4:	56                   	push   %esi
     3b5:	e8 f5 32 00 00       	call   36af <write>
     3ba:	83 c4 10             	add    $0x10,%esp
     3bd:	83 f8 0a             	cmp    $0xa,%eax
     3c0:	75 34                	jne    3f6 <writetest+0xb7>
  for(i = 0; i < 100; i++){
     3c2:	43                   	inc    %ebx
     3c3:	eb c8                	jmp    38d <writetest+0x4e>
    printf(stdout, "error: creat small failed!\n");
     3c5:	83 ec 08             	sub    $0x8,%esp
     3c8:	68 e0 3b 00 00       	push   $0x3be0
     3cd:	ff 35 20 5b 00 00    	push   0x5b20
     3d3:	e8 fa 33 00 00       	call   37d2 <printf>
    exit();
     3d8:	e8 b2 32 00 00       	call   368f <exit>
      printf(stdout, "error: write aa %d new file failed\n", i);
     3dd:	83 ec 04             	sub    $0x4,%esp
     3e0:	53                   	push   %ebx
     3e1:	68 c0 4a 00 00       	push   $0x4ac0
     3e6:	ff 35 20 5b 00 00    	push   0x5b20
     3ec:	e8 e1 33 00 00       	call   37d2 <printf>
      exit();
     3f1:	e8 99 32 00 00       	call   368f <exit>
      printf(stdout, "error: write bb %d new file failed\n", i);
     3f6:	83 ec 04             	sub    $0x4,%esp
     3f9:	53                   	push   %ebx
     3fa:	68 e4 4a 00 00       	push   $0x4ae4
     3ff:	ff 35 20 5b 00 00    	push   0x5b20
     405:	e8 c8 33 00 00       	call   37d2 <printf>
      exit();
     40a:	e8 80 32 00 00       	call   368f <exit>
    }
  }
  printf(stdout, "writes ok\n");
     40f:	83 ec 08             	sub    $0x8,%esp
     412:	68 12 3c 00 00       	push   $0x3c12
     417:	ff 35 20 5b 00 00    	push   0x5b20
     41d:	e8 b0 33 00 00       	call   37d2 <printf>
  close(fd);
     422:	89 34 24             	mov    %esi,(%esp)
     425:	e8 8d 32 00 00       	call   36b7 <close>
  fd = open("small", O_RDONLY);
     42a:	83 c4 08             	add    $0x8,%esp
     42d:	6a 00                	push   $0x0
     42f:	68 bf 3b 00 00       	push   $0x3bbf
     434:	e8 96 32 00 00       	call   36cf <open>
     439:	89 c3                	mov    %eax,%ebx
  if(fd >= 0){
     43b:	83 c4 10             	add    $0x10,%esp
     43e:	85 c0                	test   %eax,%eax
     440:	78 7b                	js     4bd <writetest+0x17e>
    printf(stdout, "open small succeeded ok\n");
     442:	83 ec 08             	sub    $0x8,%esp
     445:	68 1d 3c 00 00       	push   $0x3c1d
     44a:	ff 35 20 5b 00 00    	push   0x5b20
     450:	e8 7d 33 00 00       	call   37d2 <printf>
  } else {
    printf(stdout, "error: open small failed!\n");
    exit();
  }
  i = read(fd, buf, 2000);
     455:	83 c4 0c             	add    $0xc,%esp
     458:	68 d0 07 00 00       	push   $0x7d0
     45d:	68 60 82 00 00       	push   $0x8260
     462:	53                   	push   %ebx
     463:	e8 3f 32 00 00       	call   36a7 <read>
  if(i == 2000){
     468:	83 c4 10             	add    $0x10,%esp
     46b:	3d d0 07 00 00       	cmp    $0x7d0,%eax
     470:	75 63                	jne    4d5 <writetest+0x196>
    printf(stdout, "read succeeded ok\n");
     472:	83 ec 08             	sub    $0x8,%esp
     475:	68 51 3c 00 00       	push   $0x3c51
     47a:	ff 35 20 5b 00 00    	push   0x5b20
     480:	e8 4d 33 00 00       	call   37d2 <printf>
  } else {
    printf(stdout, "read failed\n");
    exit();
  }
  close(fd);
     485:	89 1c 24             	mov    %ebx,(%esp)
     488:	e8 2a 32 00 00       	call   36b7 <close>

  if(unlink("small") < 0){
     48d:	c7 04 24 bf 3b 00 00 	movl   $0x3bbf,(%esp)
     494:	e8 46 32 00 00       	call   36df <unlink>
     499:	83 c4 10             	add    $0x10,%esp
     49c:	85 c0                	test   %eax,%eax
     49e:	78 4d                	js     4ed <writetest+0x1ae>
    printf(stdout, "unlink small failed\n");
    exit();
  }
  printf(stdout, "small file test ok\n");
     4a0:	83 ec 08             	sub    $0x8,%esp
     4a3:	68 79 3c 00 00       	push   $0x3c79
     4a8:	ff 35 20 5b 00 00    	push   0x5b20
     4ae:	e8 1f 33 00 00       	call   37d2 <printf>
}
     4b3:	83 c4 10             	add    $0x10,%esp
     4b6:	8d 65 f8             	lea    -0x8(%ebp),%esp
     4b9:	5b                   	pop    %ebx
     4ba:	5e                   	pop    %esi
     4bb:	5d                   	pop    %ebp
     4bc:	c3                   	ret    
    printf(stdout, "error: open small failed!\n");
     4bd:	83 ec 08             	sub    $0x8,%esp
     4c0:	68 36 3c 00 00       	push   $0x3c36
     4c5:	ff 35 20 5b 00 00    	push   0x5b20
     4cb:	e8 02 33 00 00       	call   37d2 <printf>
    exit();
     4d0:	e8 ba 31 00 00       	call   368f <exit>
    printf(stdout, "read failed\n");
     4d5:	83 ec 08             	sub    $0x8,%esp
     4d8:	68 7d 3f 00 00       	push   $0x3f7d
     4dd:	ff 35 20 5b 00 00    	push   0x5b20
     4e3:	e8 ea 32 00 00       	call   37d2 <printf>
    exit();
     4e8:	e8 a2 31 00 00       	call   368f <exit>
    printf(stdout, "unlink small failed\n");
     4ed:	83 ec 08             	sub    $0x8,%esp
     4f0:	68 64 3c 00 00       	push   $0x3c64
     4f5:	ff 35 20 5b 00 00    	push   0x5b20
     4fb:	e8 d2 32 00 00       	call   37d2 <printf>
    exit();
     500:	e8 8a 31 00 00       	call   368f <exit>

00000505 <writetest1>:

void
writetest1(void)
{
     505:	55                   	push   %ebp
     506:	89 e5                	mov    %esp,%ebp
     508:	56                   	push   %esi
     509:	53                   	push   %ebx
  int i, fd, n;

  printf(stdout, "big files test\n");
     50a:	83 ec 08             	sub    $0x8,%esp
     50d:	68 8d 3c 00 00       	push   $0x3c8d
     512:	ff 35 20 5b 00 00    	push   0x5b20
     518:	e8 b5 32 00 00       	call   37d2 <printf>

  fd = open("big", O_CREATE|O_RDWR);
     51d:	83 c4 08             	add    $0x8,%esp
     520:	68 02 02 00 00       	push   $0x202
     525:	68 07 3d 00 00       	push   $0x3d07
     52a:	e8 a0 31 00 00       	call   36cf <open>
  if(fd < 0){
     52f:	83 c4 10             	add    $0x10,%esp
     532:	85 c0                	test   %eax,%eax
     534:	78 35                	js     56b <writetest1+0x66>
     536:	89 c6                	mov    %eax,%esi
    printf(stdout, "error: creat big failed!\n");
    exit();
  }

  for(i = 0; i < MAXFILE; i++){
     538:	bb 00 00 00 00       	mov    $0x0,%ebx
     53d:	81 fb 8b 00 00 00    	cmp    $0x8b,%ebx
     543:	77 57                	ja     59c <writetest1+0x97>
    ((int*)buf)[0] = i;
     545:	89 1d 60 82 00 00    	mov    %ebx,0x8260
    if(write(fd, buf, 512) != 512){
     54b:	83 ec 04             	sub    $0x4,%esp
     54e:	68 00 02 00 00       	push   $0x200
     553:	68 60 82 00 00       	push   $0x8260
     558:	56                   	push   %esi
     559:	e8 51 31 00 00       	call   36af <write>
     55e:	83 c4 10             	add    $0x10,%esp
     561:	3d 00 02 00 00       	cmp    $0x200,%eax
     566:	75 1b                	jne    583 <writetest1+0x7e>
  for(i = 0; i < MAXFILE; i++){
     568:	43                   	inc    %ebx
     569:	eb d2                	jmp    53d <writetest1+0x38>
    printf(stdout, "error: creat big failed!\n");
     56b:	83 ec 08             	sub    $0x8,%esp
     56e:	68 9d 3c 00 00       	push   $0x3c9d
     573:	ff 35 20 5b 00 00    	push   0x5b20
     579:	e8 54 32 00 00       	call   37d2 <printf>
    exit();
     57e:	e8 0c 31 00 00       	call   368f <exit>
      printf(stdout, "error: write big file failed\n", i);
     583:	83 ec 04             	sub    $0x4,%esp
     586:	53                   	push   %ebx
     587:	68 b7 3c 00 00       	push   $0x3cb7
     58c:	ff 35 20 5b 00 00    	push   0x5b20
     592:	e8 3b 32 00 00       	call   37d2 <printf>
      exit();
     597:	e8 f3 30 00 00       	call   368f <exit>
    }
  }

  close(fd);
     59c:	83 ec 0c             	sub    $0xc,%esp
     59f:	56                   	push   %esi
     5a0:	e8 12 31 00 00       	call   36b7 <close>

  fd = open("big", O_RDONLY);
     5a5:	83 c4 08             	add    $0x8,%esp
     5a8:	6a 00                	push   $0x0
     5aa:	68 07 3d 00 00       	push   $0x3d07
     5af:	e8 1b 31 00 00       	call   36cf <open>
     5b4:	89 c6                	mov    %eax,%esi
  if(fd < 0){
     5b6:	83 c4 10             	add    $0x10,%esp
     5b9:	85 c0                	test   %eax,%eax
     5bb:	78 3a                	js     5f7 <writetest1+0xf2>
    printf(stdout, "error: open big failed!\n");
    exit();
  }

  n = 0;
     5bd:	bb 00 00 00 00       	mov    $0x0,%ebx
  for(;;){
    i = read(fd, buf, 512);
     5c2:	83 ec 04             	sub    $0x4,%esp
     5c5:	68 00 02 00 00       	push   $0x200
     5ca:	68 60 82 00 00       	push   $0x8260
     5cf:	56                   	push   %esi
     5d0:	e8 d2 30 00 00       	call   36a7 <read>
    if(i == 0){
     5d5:	83 c4 10             	add    $0x10,%esp
     5d8:	85 c0                	test   %eax,%eax
     5da:	74 33                	je     60f <writetest1+0x10a>
      if(n == MAXFILE - 1){
        printf(stdout, "read only %d blocks from big", n);
        exit();
      }
      break;
    } else if(i != 512){
     5dc:	3d 00 02 00 00       	cmp    $0x200,%eax
     5e1:	0f 85 82 00 00 00    	jne    669 <writetest1+0x164>
      printf(stdout, "read failed %d\n", i);
      exit();
    }
    if(((int*)buf)[0] != n){
     5e7:	a1 60 82 00 00       	mov    0x8260,%eax
     5ec:	39 d8                	cmp    %ebx,%eax
     5ee:	0f 85 8e 00 00 00    	jne    682 <writetest1+0x17d>
      printf(stdout, "read content of block %d is %d\n",
             n, ((int*)buf)[0]);
      exit();
    }
    n++;
     5f4:	43                   	inc    %ebx
    i = read(fd, buf, 512);
     5f5:	eb cb                	jmp    5c2 <writetest1+0xbd>
    printf(stdout, "error: open big failed!\n");
     5f7:	83 ec 08             	sub    $0x8,%esp
     5fa:	68 d5 3c 00 00       	push   $0x3cd5
     5ff:	ff 35 20 5b 00 00    	push   0x5b20
     605:	e8 c8 31 00 00       	call   37d2 <printf>
    exit();
     60a:	e8 80 30 00 00       	call   368f <exit>
      if(n == MAXFILE - 1){
     60f:	81 fb 8b 00 00 00    	cmp    $0x8b,%ebx
     615:	74 39                	je     650 <writetest1+0x14b>
  }
  close(fd);
     617:	83 ec 0c             	sub    $0xc,%esp
     61a:	56                   	push   %esi
     61b:	e8 97 30 00 00       	call   36b7 <close>
  if(unlink("big") < 0){
     620:	c7 04 24 07 3d 00 00 	movl   $0x3d07,(%esp)
     627:	e8 b3 30 00 00       	call   36df <unlink>
     62c:	83 c4 10             	add    $0x10,%esp
     62f:	85 c0                	test   %eax,%eax
     631:	78 66                	js     699 <writetest1+0x194>
    printf(stdout, "unlink big failed\n");
    exit();
  }
  printf(stdout, "big files ok\n");
     633:	83 ec 08             	sub    $0x8,%esp
     636:	68 2e 3d 00 00       	push   $0x3d2e
     63b:	ff 35 20 5b 00 00    	push   0x5b20
     641:	e8 8c 31 00 00       	call   37d2 <printf>
}
     646:	83 c4 10             	add    $0x10,%esp
     649:	8d 65 f8             	lea    -0x8(%ebp),%esp
     64c:	5b                   	pop    %ebx
     64d:	5e                   	pop    %esi
     64e:	5d                   	pop    %ebp
     64f:	c3                   	ret    
        printf(stdout, "read only %d blocks from big", n);
     650:	83 ec 04             	sub    $0x4,%esp
     653:	53                   	push   %ebx
     654:	68 ee 3c 00 00       	push   $0x3cee
     659:	ff 35 20 5b 00 00    	push   0x5b20
     65f:	e8 6e 31 00 00       	call   37d2 <printf>
        exit();
     664:	e8 26 30 00 00       	call   368f <exit>
      printf(stdout, "read failed %d\n", i);
     669:	83 ec 04             	sub    $0x4,%esp
     66c:	50                   	push   %eax
     66d:	68 0b 3d 00 00       	push   $0x3d0b
     672:	ff 35 20 5b 00 00    	push   0x5b20
     678:	e8 55 31 00 00       	call   37d2 <printf>
      exit();
     67d:	e8 0d 30 00 00       	call   368f <exit>
      printf(stdout, "read content of block %d is %d\n",
     682:	50                   	push   %eax
     683:	53                   	push   %ebx
     684:	68 08 4b 00 00       	push   $0x4b08
     689:	ff 35 20 5b 00 00    	push   0x5b20
     68f:	e8 3e 31 00 00       	call   37d2 <printf>
      exit();
     694:	e8 f6 2f 00 00       	call   368f <exit>
    printf(stdout, "unlink big failed\n");
     699:	83 ec 08             	sub    $0x8,%esp
     69c:	68 1b 3d 00 00       	push   $0x3d1b
     6a1:	ff 35 20 5b 00 00    	push   0x5b20
     6a7:	e8 26 31 00 00       	call   37d2 <printf>
    exit();
     6ac:	e8 de 2f 00 00       	call   368f <exit>

000006b1 <createtest>:

void
createtest(void)
{
     6b1:	55                   	push   %ebp
     6b2:	89 e5                	mov    %esp,%ebp
     6b4:	53                   	push   %ebx
     6b5:	83 ec 0c             	sub    $0xc,%esp
  int i, fd;

  printf(stdout, "many creates, followed by unlink test\n");
     6b8:	68 28 4b 00 00       	push   $0x4b28
     6bd:	ff 35 20 5b 00 00    	push   0x5b20
     6c3:	e8 0a 31 00 00       	call   37d2 <printf>

  name[0] = 'a';
     6c8:	c6 05 50 82 00 00 61 	movb   $0x61,0x8250
  name[2] = '\0';
     6cf:	c6 05 52 82 00 00 00 	movb   $0x0,0x8252
  for(i = 0; i < 52; i++){
     6d6:	83 c4 10             	add    $0x10,%esp
     6d9:	bb 00 00 00 00       	mov    $0x0,%ebx
     6de:	eb 26                	jmp    706 <createtest+0x55>
    name[1] = '0' + i;
     6e0:	8d 43 30             	lea    0x30(%ebx),%eax
     6e3:	a2 51 82 00 00       	mov    %al,0x8251
    fd = open(name, O_CREATE|O_RDWR);
     6e8:	83 ec 08             	sub    $0x8,%esp
     6eb:	68 02 02 00 00       	push   $0x202
     6f0:	68 50 82 00 00       	push   $0x8250
     6f5:	e8 d5 2f 00 00       	call   36cf <open>
    close(fd);
     6fa:	89 04 24             	mov    %eax,(%esp)
     6fd:	e8 b5 2f 00 00       	call   36b7 <close>
  for(i = 0; i < 52; i++){
     702:	43                   	inc    %ebx
     703:	83 c4 10             	add    $0x10,%esp
     706:	83 fb 33             	cmp    $0x33,%ebx
     709:	7e d5                	jle    6e0 <createtest+0x2f>
  }
  name[0] = 'a';
     70b:	c6 05 50 82 00 00 61 	movb   $0x61,0x8250
  name[2] = '\0';
     712:	c6 05 52 82 00 00 00 	movb   $0x0,0x8252
  for(i = 0; i < 52; i++){
     719:	bb 00 00 00 00       	mov    $0x0,%ebx
     71e:	eb 19                	jmp    739 <createtest+0x88>
    name[1] = '0' + i;
     720:	8d 43 30             	lea    0x30(%ebx),%eax
     723:	a2 51 82 00 00       	mov    %al,0x8251
    unlink(name);
     728:	83 ec 0c             	sub    $0xc,%esp
     72b:	68 50 82 00 00       	push   $0x8250
     730:	e8 aa 2f 00 00       	call   36df <unlink>
  for(i = 0; i < 52; i++){
     735:	43                   	inc    %ebx
     736:	83 c4 10             	add    $0x10,%esp
     739:	83 fb 33             	cmp    $0x33,%ebx
     73c:	7e e2                	jle    720 <createtest+0x6f>
  }
  printf(stdout, "many creates, followed by unlink; ok\n");
     73e:	83 ec 08             	sub    $0x8,%esp
     741:	68 50 4b 00 00       	push   $0x4b50
     746:	ff 35 20 5b 00 00    	push   0x5b20
     74c:	e8 81 30 00 00       	call   37d2 <printf>
}
     751:	83 c4 10             	add    $0x10,%esp
     754:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     757:	c9                   	leave  
     758:	c3                   	ret    

00000759 <dirtest>:

void dirtest(void)
{
     759:	55                   	push   %ebp
     75a:	89 e5                	mov    %esp,%ebp
     75c:	83 ec 10             	sub    $0x10,%esp
  printf(stdout, "mkdir test\n");
     75f:	68 3c 3d 00 00       	push   $0x3d3c
     764:	ff 35 20 5b 00 00    	push   0x5b20
     76a:	e8 63 30 00 00       	call   37d2 <printf>

  if(mkdir("dir0") < 0){
     76f:	c7 04 24 48 3d 00 00 	movl   $0x3d48,(%esp)
     776:	e8 7c 2f 00 00       	call   36f7 <mkdir>
     77b:	83 c4 10             	add    $0x10,%esp
     77e:	85 c0                	test   %eax,%eax
     780:	78 54                	js     7d6 <dirtest+0x7d>
    printf(stdout, "mkdir failed\n");
    exit();
  }

  if(chdir("dir0") < 0){
     782:	83 ec 0c             	sub    $0xc,%esp
     785:	68 48 3d 00 00       	push   $0x3d48
     78a:	e8 70 2f 00 00       	call   36ff <chdir>
     78f:	83 c4 10             	add    $0x10,%esp
     792:	85 c0                	test   %eax,%eax
     794:	78 58                	js     7ee <dirtest+0x95>
    printf(stdout, "chdir dir0 failed\n");
    exit();
  }

  if(chdir("..") < 0){
     796:	83 ec 0c             	sub    $0xc,%esp
     799:	68 ed 42 00 00       	push   $0x42ed
     79e:	e8 5c 2f 00 00       	call   36ff <chdir>
     7a3:	83 c4 10             	add    $0x10,%esp
     7a6:	85 c0                	test   %eax,%eax
     7a8:	78 5c                	js     806 <dirtest+0xad>
    printf(stdout, "chdir .. failed\n");
    exit();
  }

  if(unlink("dir0") < 0){
     7aa:	83 ec 0c             	sub    $0xc,%esp
     7ad:	68 48 3d 00 00       	push   $0x3d48
     7b2:	e8 28 2f 00 00       	call   36df <unlink>
     7b7:	83 c4 10             	add    $0x10,%esp
     7ba:	85 c0                	test   %eax,%eax
     7bc:	78 60                	js     81e <dirtest+0xc5>
    printf(stdout, "unlink dir0 failed\n");
    exit();
  }
  printf(stdout, "mkdir test ok\n");
     7be:	83 ec 08             	sub    $0x8,%esp
     7c1:	68 85 3d 00 00       	push   $0x3d85
     7c6:	ff 35 20 5b 00 00    	push   0x5b20
     7cc:	e8 01 30 00 00       	call   37d2 <printf>
}
     7d1:	83 c4 10             	add    $0x10,%esp
     7d4:	c9                   	leave  
     7d5:	c3                   	ret    
    printf(stdout, "mkdir failed\n");
     7d6:	83 ec 08             	sub    $0x8,%esp
     7d9:	68 78 3a 00 00       	push   $0x3a78
     7de:	ff 35 20 5b 00 00    	push   0x5b20
     7e4:	e8 e9 2f 00 00       	call   37d2 <printf>
    exit();
     7e9:	e8 a1 2e 00 00       	call   368f <exit>
    printf(stdout, "chdir dir0 failed\n");
     7ee:	83 ec 08             	sub    $0x8,%esp
     7f1:	68 4d 3d 00 00       	push   $0x3d4d
     7f6:	ff 35 20 5b 00 00    	push   0x5b20
     7fc:	e8 d1 2f 00 00       	call   37d2 <printf>
    exit();
     801:	e8 89 2e 00 00       	call   368f <exit>
    printf(stdout, "chdir .. failed\n");
     806:	83 ec 08             	sub    $0x8,%esp
     809:	68 60 3d 00 00       	push   $0x3d60
     80e:	ff 35 20 5b 00 00    	push   0x5b20
     814:	e8 b9 2f 00 00       	call   37d2 <printf>
    exit();
     819:	e8 71 2e 00 00       	call   368f <exit>
    printf(stdout, "unlink dir0 failed\n");
     81e:	83 ec 08             	sub    $0x8,%esp
     821:	68 71 3d 00 00       	push   $0x3d71
     826:	ff 35 20 5b 00 00    	push   0x5b20
     82c:	e8 a1 2f 00 00       	call   37d2 <printf>
    exit();
     831:	e8 59 2e 00 00       	call   368f <exit>

00000836 <exectest>:

void
exectest(void)
{
     836:	55                   	push   %ebp
     837:	89 e5                	mov    %esp,%ebp
     839:	83 ec 10             	sub    $0x10,%esp
  printf(stdout, "exec test\n");
     83c:	68 94 3d 00 00       	push   $0x3d94
     841:	ff 35 20 5b 00 00    	push   0x5b20
     847:	e8 86 2f 00 00       	call   37d2 <printf>
  if(exec("echo", echoargv) < 0){
     84c:	83 c4 08             	add    $0x8,%esp
     84f:	68 24 5b 00 00       	push   $0x5b24
     854:	68 5d 3b 00 00       	push   $0x3b5d
     859:	e8 69 2e 00 00       	call   36c7 <exec>
     85e:	83 c4 10             	add    $0x10,%esp
     861:	85 c0                	test   %eax,%eax
     863:	78 02                	js     867 <exectest+0x31>
    printf(stdout, "exec echo failed\n");
    exit();
  }
}
     865:	c9                   	leave  
     866:	c3                   	ret    
    printf(stdout, "exec echo failed\n");
     867:	83 ec 08             	sub    $0x8,%esp
     86a:	68 9f 3d 00 00       	push   $0x3d9f
     86f:	ff 35 20 5b 00 00    	push   0x5b20
     875:	e8 58 2f 00 00       	call   37d2 <printf>
    exit();
     87a:	e8 10 2e 00 00       	call   368f <exit>

0000087f <pipe1>:

// simple fork and pipe read/write

void
pipe1(void)
{
     87f:	55                   	push   %ebp
     880:	89 e5                	mov    %esp,%ebp
     882:	57                   	push   %edi
     883:	56                   	push   %esi
     884:	53                   	push   %ebx
     885:	83 ec 38             	sub    $0x38,%esp
  int fds[2], pid;
  int seq, i, n, cc, total;

  if(pipe(fds) != 0){
     888:	8d 45 e0             	lea    -0x20(%ebp),%eax
     88b:	50                   	push   %eax
     88c:	e8 0e 2e 00 00       	call   369f <pipe>
     891:	83 c4 10             	add    $0x10,%esp
     894:	85 c0                	test   %eax,%eax
     896:	75 72                	jne    90a <pipe1+0x8b>
     898:	89 c6                	mov    %eax,%esi
    printf(1, "pipe() failed\n");
    exit();
  }
  pid = fork();
     89a:	e8 e8 2d 00 00       	call   3687 <fork>
     89f:	89 c7                	mov    %eax,%edi
  seq = 0;
  if(pid == 0){
     8a1:	85 c0                	test   %eax,%eax
     8a3:	74 79                	je     91e <pipe1+0x9f>
        printf(1, "pipe1 oops 1\n");
        exit();
      }
    }
    exit();
  } else if(pid > 0){
     8a5:	0f 8e 5c 01 00 00    	jle    a07 <pipe1+0x188>
    close(fds[1]);
     8ab:	83 ec 0c             	sub    $0xc,%esp
     8ae:	ff 75 e4             	push   -0x1c(%ebp)
     8b1:	e8 01 2e 00 00       	call   36b7 <close>
    total = 0;
    cc = 1;
    while((n = read(fds[0], buf, cc)) > 0){
     8b6:	83 c4 10             	add    $0x10,%esp
    total = 0;
     8b9:	89 75 d0             	mov    %esi,-0x30(%ebp)
  seq = 0;
     8bc:	89 f3                	mov    %esi,%ebx
    cc = 1;
     8be:	c7 45 d4 01 00 00 00 	movl   $0x1,-0x2c(%ebp)
    while((n = read(fds[0], buf, cc)) > 0){
     8c5:	83 ec 04             	sub    $0x4,%esp
     8c8:	ff 75 d4             	push   -0x2c(%ebp)
     8cb:	68 60 82 00 00       	push   $0x8260
     8d0:	ff 75 e0             	push   -0x20(%ebp)
     8d3:	e8 cf 2d 00 00       	call   36a7 <read>
     8d8:	89 c7                	mov    %eax,%edi
     8da:	83 c4 10             	add    $0x10,%esp
     8dd:	85 c0                	test   %eax,%eax
     8df:	0f 8e de 00 00 00    	jle    9c3 <pipe1+0x144>
      for(i = 0; i < n; i++){
     8e5:	89 f0                	mov    %esi,%eax
     8e7:	89 d9                	mov    %ebx,%ecx
     8e9:	39 f8                	cmp    %edi,%eax
     8eb:	0f 8d ae 00 00 00    	jge    99f <pipe1+0x120>
        if((buf[i] & 0xff) != (seq++ & 0xff)){
     8f1:	0f be 98 60 82 00 00 	movsbl 0x8260(%eax),%ebx
     8f8:	8d 51 01             	lea    0x1(%ecx),%edx
     8fb:	31 cb                	xor    %ecx,%ebx
     8fd:	84 db                	test   %bl,%bl
     8ff:	0f 85 80 00 00 00    	jne    985 <pipe1+0x106>
      for(i = 0; i < n; i++){
     905:	40                   	inc    %eax
        if((buf[i] & 0xff) != (seq++ & 0xff)){
     906:	89 d1                	mov    %edx,%ecx
     908:	eb df                	jmp    8e9 <pipe1+0x6a>
    printf(1, "pipe() failed\n");
     90a:	83 ec 08             	sub    $0x8,%esp
     90d:	68 b1 3d 00 00       	push   $0x3db1
     912:	6a 01                	push   $0x1
     914:	e8 b9 2e 00 00       	call   37d2 <printf>
    exit();
     919:	e8 71 2d 00 00       	call   368f <exit>
    close(fds[0]);
     91e:	83 ec 0c             	sub    $0xc,%esp
     921:	ff 75 e0             	push   -0x20(%ebp)
     924:	e8 8e 2d 00 00       	call   36b7 <close>
    for(n = 0; n < 5; n++){
     929:	83 c4 10             	add    $0x10,%esp
     92c:	89 fe                	mov    %edi,%esi
  seq = 0;
     92e:	89 fb                	mov    %edi,%ebx
    for(n = 0; n < 5; n++){
     930:	eb 31                	jmp    963 <pipe1+0xe4>
        buf[i] = seq++;
     932:	88 98 60 82 00 00    	mov    %bl,0x8260(%eax)
      for(i = 0; i < 1033; i++)
     938:	40                   	inc    %eax
        buf[i] = seq++;
     939:	8d 5b 01             	lea    0x1(%ebx),%ebx
      for(i = 0; i < 1033; i++)
     93c:	3d 08 04 00 00       	cmp    $0x408,%eax
     941:	7e ef                	jle    932 <pipe1+0xb3>
      if(write(fds[1], buf, 1033) != 1033){
     943:	83 ec 04             	sub    $0x4,%esp
     946:	68 09 04 00 00       	push   $0x409
     94b:	68 60 82 00 00       	push   $0x8260
     950:	ff 75 e4             	push   -0x1c(%ebp)
     953:	e8 57 2d 00 00       	call   36af <write>
     958:	83 c4 10             	add    $0x10,%esp
     95b:	3d 09 04 00 00       	cmp    $0x409,%eax
     960:	75 0a                	jne    96c <pipe1+0xed>
    for(n = 0; n < 5; n++){
     962:	46                   	inc    %esi
     963:	83 fe 04             	cmp    $0x4,%esi
     966:	7f 18                	jg     980 <pipe1+0x101>
      for(i = 0; i < 1033; i++)
     968:	89 f8                	mov    %edi,%eax
     96a:	eb d0                	jmp    93c <pipe1+0xbd>
        printf(1, "pipe1 oops 1\n");
     96c:	83 ec 08             	sub    $0x8,%esp
     96f:	68 c0 3d 00 00       	push   $0x3dc0
     974:	6a 01                	push   $0x1
     976:	e8 57 2e 00 00       	call   37d2 <printf>
        exit();
     97b:	e8 0f 2d 00 00       	call   368f <exit>
    exit();
     980:	e8 0a 2d 00 00       	call   368f <exit>
          printf(1, "pipe1 oops 2\n");
     985:	83 ec 08             	sub    $0x8,%esp
     988:	68 ce 3d 00 00       	push   $0x3dce
     98d:	6a 01                	push   $0x1
     98f:	e8 3e 2e 00 00       	call   37d2 <printf>
          return;
     994:	83 c4 10             	add    $0x10,%esp
  } else {
    printf(1, "fork() failed\n");
    exit();
  }
  printf(1, "pipe1 ok\n");
}
     997:	8d 65 f4             	lea    -0xc(%ebp),%esp
     99a:	5b                   	pop    %ebx
     99b:	5e                   	pop    %esi
     99c:	5f                   	pop    %edi
     99d:	5d                   	pop    %ebp
     99e:	c3                   	ret    
      total += n;
     99f:	89 cb                	mov    %ecx,%ebx
     9a1:	01 7d d0             	add    %edi,-0x30(%ebp)
      cc = cc * 2;
     9a4:	8b 45 d4             	mov    -0x2c(%ebp),%eax
     9a7:	01 c0                	add    %eax,%eax
     9a9:	89 45 d4             	mov    %eax,-0x2c(%ebp)
      if(cc > sizeof(buf))
     9ac:	3d 00 20 00 00       	cmp    $0x2000,%eax
     9b1:	0f 86 0e ff ff ff    	jbe    8c5 <pipe1+0x46>
        cc = sizeof(buf);
     9b7:	c7 45 d4 00 20 00 00 	movl   $0x2000,-0x2c(%ebp)
     9be:	e9 02 ff ff ff       	jmp    8c5 <pipe1+0x46>
    if(total != 5 * 1033){
     9c3:	81 7d d0 2d 14 00 00 	cmpl   $0x142d,-0x30(%ebp)
     9ca:	75 24                	jne    9f0 <pipe1+0x171>
    close(fds[0]);
     9cc:	83 ec 0c             	sub    $0xc,%esp
     9cf:	ff 75 e0             	push   -0x20(%ebp)
     9d2:	e8 e0 2c 00 00       	call   36b7 <close>
    wait();
     9d7:	e8 bb 2c 00 00       	call   3697 <wait>
  printf(1, "pipe1 ok\n");
     9dc:	83 c4 08             	add    $0x8,%esp
     9df:	68 f3 3d 00 00       	push   $0x3df3
     9e4:	6a 01                	push   $0x1
     9e6:	e8 e7 2d 00 00       	call   37d2 <printf>
     9eb:	83 c4 10             	add    $0x10,%esp
     9ee:	eb a7                	jmp    997 <pipe1+0x118>
      printf(1, "pipe1 oops 3 total %d\n", total);
     9f0:	83 ec 04             	sub    $0x4,%esp
     9f3:	ff 75 d0             	push   -0x30(%ebp)
     9f6:	68 dc 3d 00 00       	push   $0x3ddc
     9fb:	6a 01                	push   $0x1
     9fd:	e8 d0 2d 00 00       	call   37d2 <printf>
      exit();
     a02:	e8 88 2c 00 00       	call   368f <exit>
    printf(1, "fork() failed\n");
     a07:	83 ec 08             	sub    $0x8,%esp
     a0a:	68 fd 3d 00 00       	push   $0x3dfd
     a0f:	6a 01                	push   $0x1
     a11:	e8 bc 2d 00 00       	call   37d2 <printf>
    exit();
     a16:	e8 74 2c 00 00       	call   368f <exit>

00000a1b <preempt>:

// meant to be run w/ at most two CPUs
void
preempt(void)
{
     a1b:	55                   	push   %ebp
     a1c:	89 e5                	mov    %esp,%ebp
     a1e:	57                   	push   %edi
     a1f:	56                   	push   %esi
     a20:	53                   	push   %ebx
     a21:	83 ec 24             	sub    $0x24,%esp
  int pid1, pid2, pid3;
  int pfds[2];

  printf(1, "preempt: ");
     a24:	68 0c 3e 00 00       	push   $0x3e0c
     a29:	6a 01                	push   $0x1
     a2b:	e8 a2 2d 00 00       	call   37d2 <printf>
  pid1 = fork();
     a30:	e8 52 2c 00 00       	call   3687 <fork>
  if(pid1 == 0)
     a35:	83 c4 10             	add    $0x10,%esp
     a38:	85 c0                	test   %eax,%eax
     a3a:	75 02                	jne    a3e <preempt+0x23>
    for(;;)
     a3c:	eb fe                	jmp    a3c <preempt+0x21>
     a3e:	89 c3                	mov    %eax,%ebx
      ;

  pid2 = fork();
     a40:	e8 42 2c 00 00       	call   3687 <fork>
     a45:	89 c6                	mov    %eax,%esi
  if(pid2 == 0)
     a47:	85 c0                	test   %eax,%eax
     a49:	75 02                	jne    a4d <preempt+0x32>
    for(;;)
     a4b:	eb fe                	jmp    a4b <preempt+0x30>
      ;

  pipe(pfds);
     a4d:	83 ec 0c             	sub    $0xc,%esp
     a50:	8d 45 e0             	lea    -0x20(%ebp),%eax
     a53:	50                   	push   %eax
     a54:	e8 46 2c 00 00       	call   369f <pipe>
  pid3 = fork();
     a59:	e8 29 2c 00 00       	call   3687 <fork>
     a5e:	89 c7                	mov    %eax,%edi
  if(pid3 == 0){
     a60:	83 c4 10             	add    $0x10,%esp
     a63:	85 c0                	test   %eax,%eax
     a65:	75 49                	jne    ab0 <preempt+0x95>
    close(pfds[0]);
     a67:	83 ec 0c             	sub    $0xc,%esp
     a6a:	ff 75 e0             	push   -0x20(%ebp)
     a6d:	e8 45 2c 00 00       	call   36b7 <close>
    if(write(pfds[1], "x", 1) != 1)
     a72:	83 c4 0c             	add    $0xc,%esp
     a75:	6a 01                	push   $0x1
     a77:	68 d1 43 00 00       	push   $0x43d1
     a7c:	ff 75 e4             	push   -0x1c(%ebp)
     a7f:	e8 2b 2c 00 00       	call   36af <write>
     a84:	83 c4 10             	add    $0x10,%esp
     a87:	83 f8 01             	cmp    $0x1,%eax
     a8a:	75 10                	jne    a9c <preempt+0x81>
      printf(1, "preempt write error");
    close(pfds[1]);
     a8c:	83 ec 0c             	sub    $0xc,%esp
     a8f:	ff 75 e4             	push   -0x1c(%ebp)
     a92:	e8 20 2c 00 00       	call   36b7 <close>
     a97:	83 c4 10             	add    $0x10,%esp
    for(;;)
     a9a:	eb fe                	jmp    a9a <preempt+0x7f>
      printf(1, "preempt write error");
     a9c:	83 ec 08             	sub    $0x8,%esp
     a9f:	68 16 3e 00 00       	push   $0x3e16
     aa4:	6a 01                	push   $0x1
     aa6:	e8 27 2d 00 00       	call   37d2 <printf>
     aab:	83 c4 10             	add    $0x10,%esp
     aae:	eb dc                	jmp    a8c <preempt+0x71>
      ;
  }

  close(pfds[1]);
     ab0:	83 ec 0c             	sub    $0xc,%esp
     ab3:	ff 75 e4             	push   -0x1c(%ebp)
     ab6:	e8 fc 2b 00 00       	call   36b7 <close>
  if(read(pfds[0], buf, sizeof(buf)) != 1){
     abb:	83 c4 0c             	add    $0xc,%esp
     abe:	68 00 20 00 00       	push   $0x2000
     ac3:	68 60 82 00 00       	push   $0x8260
     ac8:	ff 75 e0             	push   -0x20(%ebp)
     acb:	e8 d7 2b 00 00       	call   36a7 <read>
     ad0:	83 c4 10             	add    $0x10,%esp
     ad3:	83 f8 01             	cmp    $0x1,%eax
     ad6:	74 1a                	je     af2 <preempt+0xd7>
    printf(1, "preempt read error");
     ad8:	83 ec 08             	sub    $0x8,%esp
     adb:	68 2a 3e 00 00       	push   $0x3e2a
     ae0:	6a 01                	push   $0x1
     ae2:	e8 eb 2c 00 00       	call   37d2 <printf>
    return;
     ae7:	83 c4 10             	add    $0x10,%esp
  printf(1, "wait... ");
  wait();
  wait();
  wait();
  printf(1, "preempt ok\n");
}
     aea:	8d 65 f4             	lea    -0xc(%ebp),%esp
     aed:	5b                   	pop    %ebx
     aee:	5e                   	pop    %esi
     aef:	5f                   	pop    %edi
     af0:	5d                   	pop    %ebp
     af1:	c3                   	ret    
  close(pfds[0]);
     af2:	83 ec 0c             	sub    $0xc,%esp
     af5:	ff 75 e0             	push   -0x20(%ebp)
     af8:	e8 ba 2b 00 00       	call   36b7 <close>
  printf(1, "kill... ");
     afd:	83 c4 08             	add    $0x8,%esp
     b00:	68 3d 3e 00 00       	push   $0x3e3d
     b05:	6a 01                	push   $0x1
     b07:	e8 c6 2c 00 00       	call   37d2 <printf>
  kill(pid1);
     b0c:	89 1c 24             	mov    %ebx,(%esp)
     b0f:	e8 ab 2b 00 00       	call   36bf <kill>
  kill(pid2);
     b14:	89 34 24             	mov    %esi,(%esp)
     b17:	e8 a3 2b 00 00       	call   36bf <kill>
  kill(pid3);
     b1c:	89 3c 24             	mov    %edi,(%esp)
     b1f:	e8 9b 2b 00 00       	call   36bf <kill>
  printf(1, "wait... ");
     b24:	83 c4 08             	add    $0x8,%esp
     b27:	68 46 3e 00 00       	push   $0x3e46
     b2c:	6a 01                	push   $0x1
     b2e:	e8 9f 2c 00 00       	call   37d2 <printf>
  wait();
     b33:	e8 5f 2b 00 00       	call   3697 <wait>
  wait();
     b38:	e8 5a 2b 00 00       	call   3697 <wait>
  wait();
     b3d:	e8 55 2b 00 00       	call   3697 <wait>
  printf(1, "preempt ok\n");
     b42:	83 c4 08             	add    $0x8,%esp
     b45:	68 4f 3e 00 00       	push   $0x3e4f
     b4a:	6a 01                	push   $0x1
     b4c:	e8 81 2c 00 00       	call   37d2 <printf>
     b51:	83 c4 10             	add    $0x10,%esp
     b54:	eb 94                	jmp    aea <preempt+0xcf>

00000b56 <exitwait>:

// try to find any races between exit and wait
void
exitwait(void)
{
     b56:	55                   	push   %ebp
     b57:	89 e5                	mov    %esp,%ebp
     b59:	56                   	push   %esi
     b5a:	53                   	push   %ebx
  int i, pid;

  for(i = 0; i < 100; i++){
     b5b:	be 00 00 00 00       	mov    $0x0,%esi
     b60:	83 fe 63             	cmp    $0x63,%esi
     b63:	7f 4b                	jg     bb0 <exitwait+0x5a>
    pid = fork();
     b65:	e8 1d 2b 00 00       	call   3687 <fork>
     b6a:	89 c3                	mov    %eax,%ebx
    if(pid < 0){
     b6c:	85 c0                	test   %eax,%eax
     b6e:	78 0e                	js     b7e <exitwait+0x28>
      printf(1, "fork failed\n");
      return;
    }
    if(pid){
     b70:	74 39                	je     bab <exitwait+0x55>
      if(wait() != pid){
     b72:	e8 20 2b 00 00       	call   3697 <wait>
     b77:	39 d8                	cmp    %ebx,%eax
     b79:	75 1c                	jne    b97 <exitwait+0x41>
  for(i = 0; i < 100; i++){
     b7b:	46                   	inc    %esi
     b7c:	eb e2                	jmp    b60 <exitwait+0xa>
      printf(1, "fork failed\n");
     b7e:	83 ec 08             	sub    $0x8,%esp
     b81:	68 b9 49 00 00       	push   $0x49b9
     b86:	6a 01                	push   $0x1
     b88:	e8 45 2c 00 00       	call   37d2 <printf>
      return;
     b8d:	83 c4 10             	add    $0x10,%esp
    } else {
      exit();
    }
  }
  printf(1, "exitwait ok\n");
}
     b90:	8d 65 f8             	lea    -0x8(%ebp),%esp
     b93:	5b                   	pop    %ebx
     b94:	5e                   	pop    %esi
     b95:	5d                   	pop    %ebp
     b96:	c3                   	ret    
        printf(1, "wait wrong pid\n");
     b97:	83 ec 08             	sub    $0x8,%esp
     b9a:	68 5b 3e 00 00       	push   $0x3e5b
     b9f:	6a 01                	push   $0x1
     ba1:	e8 2c 2c 00 00       	call   37d2 <printf>
        return;
     ba6:	83 c4 10             	add    $0x10,%esp
     ba9:	eb e5                	jmp    b90 <exitwait+0x3a>
      exit();
     bab:	e8 df 2a 00 00       	call   368f <exit>
  printf(1, "exitwait ok\n");
     bb0:	83 ec 08             	sub    $0x8,%esp
     bb3:	68 6b 3e 00 00       	push   $0x3e6b
     bb8:	6a 01                	push   $0x1
     bba:	e8 13 2c 00 00       	call   37d2 <printf>
     bbf:	83 c4 10             	add    $0x10,%esp
     bc2:	eb cc                	jmp    b90 <exitwait+0x3a>

00000bc4 <mem>:

void
mem(void)
{
     bc4:	55                   	push   %ebp
     bc5:	89 e5                	mov    %esp,%ebp
     bc7:	57                   	push   %edi
     bc8:	56                   	push   %esi
     bc9:	53                   	push   %ebx
     bca:	83 ec 14             	sub    $0x14,%esp
  void *m1, *m2;
  int pid, ppid;

  printf(1, "mem test\n");
     bcd:	68 78 3e 00 00       	push   $0x3e78
     bd2:	6a 01                	push   $0x1
     bd4:	e8 f9 2b 00 00       	call   37d2 <printf>
  ppid = getpid();
     bd9:	e8 31 2b 00 00       	call   370f <getpid>
     bde:	89 c6                	mov    %eax,%esi
  if((pid = fork()) == 0){
     be0:	e8 a2 2a 00 00       	call   3687 <fork>
     be5:	83 c4 10             	add    $0x10,%esp
     be8:	85 c0                	test   %eax,%eax
     bea:	0f 85 82 00 00 00    	jne    c72 <mem+0xae>
    m1 = 0;
     bf0:	bb 00 00 00 00       	mov    $0x0,%ebx
     bf5:	eb 04                	jmp    bfb <mem+0x37>
    while((m2 = malloc(10001)) != 0){
      *(char**)m2 = m1;
     bf7:	89 18                	mov    %ebx,(%eax)
      m1 = m2;
     bf9:	89 c3                	mov    %eax,%ebx
    while((m2 = malloc(10001)) != 0){
     bfb:	83 ec 0c             	sub    $0xc,%esp
     bfe:	68 11 27 00 00       	push   $0x2711
     c03:	e8 ea 2d 00 00       	call   39f2 <malloc>
     c08:	83 c4 10             	add    $0x10,%esp
     c0b:	85 c0                	test   %eax,%eax
     c0d:	75 e8                	jne    bf7 <mem+0x33>
     c0f:	eb 10                	jmp    c21 <mem+0x5d>
    }
    while(m1){
      m2 = *(char**)m1;
     c11:	8b 3b                	mov    (%ebx),%edi
      free(m1);
     c13:	83 ec 0c             	sub    $0xc,%esp
     c16:	53                   	push   %ebx
     c17:	e8 16 2d 00 00       	call   3932 <free>
     c1c:	83 c4 10             	add    $0x10,%esp
      m1 = m2;
     c1f:	89 fb                	mov    %edi,%ebx
    while(m1){
     c21:	85 db                	test   %ebx,%ebx
     c23:	75 ec                	jne    c11 <mem+0x4d>
    }
    m1 = malloc(1024*20);
     c25:	83 ec 0c             	sub    $0xc,%esp
     c28:	68 00 50 00 00       	push   $0x5000
     c2d:	e8 c0 2d 00 00       	call   39f2 <malloc>
    if(m1 == 0){
     c32:	83 c4 10             	add    $0x10,%esp
     c35:	85 c0                	test   %eax,%eax
     c37:	74 1d                	je     c56 <mem+0x92>
      printf(1, "couldn't allocate mem?!!\n");
      kill(ppid);
      exit();
    }
    free(m1);
     c39:	83 ec 0c             	sub    $0xc,%esp
     c3c:	50                   	push   %eax
     c3d:	e8 f0 2c 00 00       	call   3932 <free>
    printf(1, "mem ok\n");
     c42:	83 c4 08             	add    $0x8,%esp
     c45:	68 9c 3e 00 00       	push   $0x3e9c
     c4a:	6a 01                	push   $0x1
     c4c:	e8 81 2b 00 00       	call   37d2 <printf>
    exit();
     c51:	e8 39 2a 00 00       	call   368f <exit>
      printf(1, "couldn't allocate mem?!!\n");
     c56:	83 ec 08             	sub    $0x8,%esp
     c59:	68 82 3e 00 00       	push   $0x3e82
     c5e:	6a 01                	push   $0x1
     c60:	e8 6d 2b 00 00       	call   37d2 <printf>
      kill(ppid);
     c65:	89 34 24             	mov    %esi,(%esp)
     c68:	e8 52 2a 00 00       	call   36bf <kill>
      exit();
     c6d:	e8 1d 2a 00 00       	call   368f <exit>
  } else {
    wait();
     c72:	e8 20 2a 00 00       	call   3697 <wait>
  }
}
     c77:	8d 65 f4             	lea    -0xc(%ebp),%esp
     c7a:	5b                   	pop    %ebx
     c7b:	5e                   	pop    %esi
     c7c:	5f                   	pop    %edi
     c7d:	5d                   	pop    %ebp
     c7e:	c3                   	ret    

00000c7f <sharedfd>:

// two processes write to the same file descriptor
// is the offset shared? does inode locking work?
void
sharedfd(void)
{
     c7f:	55                   	push   %ebp
     c80:	89 e5                	mov    %esp,%ebp
     c82:	57                   	push   %edi
     c83:	56                   	push   %esi
     c84:	53                   	push   %ebx
     c85:	83 ec 24             	sub    $0x24,%esp
  int fd, pid, i, n, nc, np;
  char buf[10];

  printf(1, "sharedfd test\n");
     c88:	68 a4 3e 00 00       	push   $0x3ea4
     c8d:	6a 01                	push   $0x1
     c8f:	e8 3e 2b 00 00       	call   37d2 <printf>

  unlink("sharedfd");
     c94:	c7 04 24 b3 3e 00 00 	movl   $0x3eb3,(%esp)
     c9b:	e8 3f 2a 00 00       	call   36df <unlink>
  fd = open("sharedfd", O_CREATE|O_RDWR);
     ca0:	83 c4 08             	add    $0x8,%esp
     ca3:	68 02 02 00 00       	push   $0x202
     ca8:	68 b3 3e 00 00       	push   $0x3eb3
     cad:	e8 1d 2a 00 00       	call   36cf <open>
  if(fd < 0){
     cb2:	83 c4 10             	add    $0x10,%esp
     cb5:	85 c0                	test   %eax,%eax
     cb7:	78 4b                	js     d04 <sharedfd+0x85>
     cb9:	89 c6                	mov    %eax,%esi
    printf(1, "fstests: cannot open sharedfd for writing");
    return;
  }
  pid = fork();
     cbb:	e8 c7 29 00 00       	call   3687 <fork>
     cc0:	89 c7                	mov    %eax,%edi
  memset(buf, pid==0?'c':'p', sizeof(buf));
     cc2:	85 c0                	test   %eax,%eax
     cc4:	75 55                	jne    d1b <sharedfd+0x9c>
     cc6:	b8 63 00 00 00       	mov    $0x63,%eax
     ccb:	83 ec 04             	sub    $0x4,%esp
     cce:	6a 0a                	push   $0xa
     cd0:	50                   	push   %eax
     cd1:	8d 45 de             	lea    -0x22(%ebp),%eax
     cd4:	50                   	push   %eax
     cd5:	e8 8a 28 00 00       	call   3564 <memset>
  for(i = 0; i < 1000; i++){
     cda:	83 c4 10             	add    $0x10,%esp
     cdd:	bb 00 00 00 00       	mov    $0x0,%ebx
     ce2:	81 fb e7 03 00 00    	cmp    $0x3e7,%ebx
     ce8:	7f 4a                	jg     d34 <sharedfd+0xb5>
    if(write(fd, buf, sizeof(buf)) != sizeof(buf)){
     cea:	83 ec 04             	sub    $0x4,%esp
     ced:	6a 0a                	push   $0xa
     cef:	8d 45 de             	lea    -0x22(%ebp),%eax
     cf2:	50                   	push   %eax
     cf3:	56                   	push   %esi
     cf4:	e8 b6 29 00 00       	call   36af <write>
     cf9:	83 c4 10             	add    $0x10,%esp
     cfc:	83 f8 0a             	cmp    $0xa,%eax
     cff:	75 21                	jne    d22 <sharedfd+0xa3>
  for(i = 0; i < 1000; i++){
     d01:	43                   	inc    %ebx
     d02:	eb de                	jmp    ce2 <sharedfd+0x63>
    printf(1, "fstests: cannot open sharedfd for writing");
     d04:	83 ec 08             	sub    $0x8,%esp
     d07:	68 78 4b 00 00       	push   $0x4b78
     d0c:	6a 01                	push   $0x1
     d0e:	e8 bf 2a 00 00       	call   37d2 <printf>
    return;
     d13:	83 c4 10             	add    $0x10,%esp
     d16:	e9 d5 00 00 00       	jmp    df0 <sharedfd+0x171>
  memset(buf, pid==0?'c':'p', sizeof(buf));
     d1b:	b8 70 00 00 00       	mov    $0x70,%eax
     d20:	eb a9                	jmp    ccb <sharedfd+0x4c>
      printf(1, "fstests: write sharedfd failed\n");
     d22:	83 ec 08             	sub    $0x8,%esp
     d25:	68 a4 4b 00 00       	push   $0x4ba4
     d2a:	6a 01                	push   $0x1
     d2c:	e8 a1 2a 00 00       	call   37d2 <printf>
      break;
     d31:	83 c4 10             	add    $0x10,%esp
    }
  }
  if(pid == 0)
     d34:	85 ff                	test   %edi,%edi
     d36:	74 4d                	je     d85 <sharedfd+0x106>
    exit();
  else
    wait();
     d38:	e8 5a 29 00 00       	call   3697 <wait>
  close(fd);
     d3d:	83 ec 0c             	sub    $0xc,%esp
     d40:	56                   	push   %esi
     d41:	e8 71 29 00 00       	call   36b7 <close>
  fd = open("sharedfd", 0);
     d46:	83 c4 08             	add    $0x8,%esp
     d49:	6a 00                	push   $0x0
     d4b:	68 b3 3e 00 00       	push   $0x3eb3
     d50:	e8 7a 29 00 00       	call   36cf <open>
     d55:	89 c7                	mov    %eax,%edi
  if(fd < 0){
     d57:	83 c4 10             	add    $0x10,%esp
     d5a:	85 c0                	test   %eax,%eax
     d5c:	78 2c                	js     d8a <sharedfd+0x10b>
    printf(1, "fstests: cannot open sharedfd for reading\n");
    return;
  }
  nc = np = 0;
     d5e:	be 00 00 00 00       	mov    $0x0,%esi
     d63:	bb 00 00 00 00       	mov    $0x0,%ebx
  while((n = read(fd, buf, sizeof(buf))) > 0){
     d68:	83 ec 04             	sub    $0x4,%esp
     d6b:	6a 0a                	push   $0xa
     d6d:	8d 45 de             	lea    -0x22(%ebp),%eax
     d70:	50                   	push   %eax
     d71:	57                   	push   %edi
     d72:	e8 30 29 00 00       	call   36a7 <read>
     d77:	83 c4 10             	add    $0x10,%esp
     d7a:	85 c0                	test   %eax,%eax
     d7c:	7e 38                	jle    db6 <sharedfd+0x137>
    for(i = 0; i < sizeof(buf); i++){
     d7e:	ba 00 00 00 00       	mov    $0x0,%edx
     d83:	eb 1e                	jmp    da3 <sharedfd+0x124>
    exit();
     d85:	e8 05 29 00 00       	call   368f <exit>
    printf(1, "fstests: cannot open sharedfd for reading\n");
     d8a:	83 ec 08             	sub    $0x8,%esp
     d8d:	68 c4 4b 00 00       	push   $0x4bc4
     d92:	6a 01                	push   $0x1
     d94:	e8 39 2a 00 00       	call   37d2 <printf>
    return;
     d99:	83 c4 10             	add    $0x10,%esp
     d9c:	eb 52                	jmp    df0 <sharedfd+0x171>
      if(buf[i] == 'c')
        nc++;
      if(buf[i] == 'p')
     d9e:	3c 70                	cmp    $0x70,%al
     da0:	74 11                	je     db3 <sharedfd+0x134>
    for(i = 0; i < sizeof(buf); i++){
     da2:	42                   	inc    %edx
     da3:	83 fa 09             	cmp    $0x9,%edx
     da6:	77 c0                	ja     d68 <sharedfd+0xe9>
      if(buf[i] == 'c')
     da8:	8a 44 15 de          	mov    -0x22(%ebp,%edx,1),%al
     dac:	3c 63                	cmp    $0x63,%al
     dae:	75 ee                	jne    d9e <sharedfd+0x11f>
        nc++;
     db0:	43                   	inc    %ebx
     db1:	eb eb                	jmp    d9e <sharedfd+0x11f>
        np++;
     db3:	46                   	inc    %esi
     db4:	eb ec                	jmp    da2 <sharedfd+0x123>
    }
  }
  close(fd);
     db6:	83 ec 0c             	sub    $0xc,%esp
     db9:	57                   	push   %edi
     dba:	e8 f8 28 00 00       	call   36b7 <close>
  unlink("sharedfd");
     dbf:	c7 04 24 b3 3e 00 00 	movl   $0x3eb3,(%esp)
     dc6:	e8 14 29 00 00       	call   36df <unlink>
  if(nc == 10000 && np == 10000){
     dcb:	83 c4 10             	add    $0x10,%esp
     dce:	81 fb 10 27 00 00    	cmp    $0x2710,%ebx
     dd4:	75 22                	jne    df8 <sharedfd+0x179>
     dd6:	81 fe 10 27 00 00    	cmp    $0x2710,%esi
     ddc:	75 1a                	jne    df8 <sharedfd+0x179>
    printf(1, "sharedfd ok\n");
     dde:	83 ec 08             	sub    $0x8,%esp
     de1:	68 bc 3e 00 00       	push   $0x3ebc
     de6:	6a 01                	push   $0x1
     de8:	e8 e5 29 00 00       	call   37d2 <printf>
     ded:	83 c4 10             	add    $0x10,%esp
  } else {
    printf(1, "sharedfd oops %d %d\n", nc, np);
    exit();
  }
}
     df0:	8d 65 f4             	lea    -0xc(%ebp),%esp
     df3:	5b                   	pop    %ebx
     df4:	5e                   	pop    %esi
     df5:	5f                   	pop    %edi
     df6:	5d                   	pop    %ebp
     df7:	c3                   	ret    
    printf(1, "sharedfd oops %d %d\n", nc, np);
     df8:	56                   	push   %esi
     df9:	53                   	push   %ebx
     dfa:	68 c9 3e 00 00       	push   $0x3ec9
     dff:	6a 01                	push   $0x1
     e01:	e8 cc 29 00 00       	call   37d2 <printf>
    exit();
     e06:	e8 84 28 00 00       	call   368f <exit>

00000e0b <fourfiles>:

// four processes write different files at the same
// time, to test block allocation.
void
fourfiles(void)
{
     e0b:	55                   	push   %ebp
     e0c:	89 e5                	mov    %esp,%ebp
     e0e:	57                   	push   %edi
     e0f:	56                   	push   %esi
     e10:	53                   	push   %ebx
     e11:	83 ec 34             	sub    $0x34,%esp
  int fd, pid, i, j, n, total, pi;
  char *names[] = { "f0", "f1", "f2", "f3" };
     e14:	8d 7d d8             	lea    -0x28(%ebp),%edi
     e17:	be 10 52 00 00       	mov    $0x5210,%esi
     e1c:	b9 04 00 00 00       	mov    $0x4,%ecx
     e21:	f3 a5                	rep movsl %ds:(%esi),%es:(%edi)
  char *fname;

  printf(1, "fourfiles test\n");
     e23:	68 de 3e 00 00       	push   $0x3ede
     e28:	6a 01                	push   $0x1
     e2a:	e8 a3 29 00 00       	call   37d2 <printf>

  for(pi = 0; pi < 4; pi++){
     e2f:	83 c4 10             	add    $0x10,%esp
     e32:	be 00 00 00 00       	mov    $0x0,%esi
     e37:	eb 43                	jmp    e7c <fourfiles+0x71>
    fname = names[pi];
    unlink(fname);

    pid = fork();
    if(pid < 0){
      printf(1, "fork failed\n");
     e39:	83 ec 08             	sub    $0x8,%esp
     e3c:	68 b9 49 00 00       	push   $0x49b9
     e41:	6a 01                	push   $0x1
     e43:	e8 8a 29 00 00       	call   37d2 <printf>
      exit();
     e48:	e8 42 28 00 00       	call   368f <exit>
    }

    if(pid == 0){
      fd = open(fname, O_CREATE | O_RDWR);
      if(fd < 0){
        printf(1, "create failed\n");
     e4d:	83 ec 08             	sub    $0x8,%esp
     e50:	68 7f 41 00 00       	push   $0x417f
     e55:	6a 01                	push   $0x1
     e57:	e8 76 29 00 00       	call   37d2 <printf>
        exit();
     e5c:	e8 2e 28 00 00       	call   368f <exit>
      }

      memset(buf, '0'+pi, 512);
      for(i = 0; i < 12; i++){
        if((n = write(fd, buf, 500)) != 500){
          printf(1, "write failed %d\n", n);
     e61:	83 ec 04             	sub    $0x4,%esp
     e64:	50                   	push   %eax
     e65:	68 ee 3e 00 00       	push   $0x3eee
     e6a:	6a 01                	push   $0x1
     e6c:	e8 61 29 00 00       	call   37d2 <printf>
          exit();
     e71:	e8 19 28 00 00       	call   368f <exit>
        }
      }
      exit();
     e76:	e8 14 28 00 00       	call   368f <exit>
  for(pi = 0; pi < 4; pi++){
     e7b:	46                   	inc    %esi
     e7c:	83 fe 03             	cmp    $0x3,%esi
     e7f:	7f 76                	jg     ef7 <fourfiles+0xec>
    fname = names[pi];
     e81:	8b 7c b5 d8          	mov    -0x28(%ebp,%esi,4),%edi
    unlink(fname);
     e85:	83 ec 0c             	sub    $0xc,%esp
     e88:	57                   	push   %edi
     e89:	e8 51 28 00 00       	call   36df <unlink>
    pid = fork();
     e8e:	e8 f4 27 00 00       	call   3687 <fork>
    if(pid < 0){
     e93:	83 c4 10             	add    $0x10,%esp
     e96:	85 c0                	test   %eax,%eax
     e98:	78 9f                	js     e39 <fourfiles+0x2e>
    if(pid == 0){
     e9a:	75 df                	jne    e7b <fourfiles+0x70>
      fd = open(fname, O_CREATE | O_RDWR);
     e9c:	89 c3                	mov    %eax,%ebx
     e9e:	83 ec 08             	sub    $0x8,%esp
     ea1:	68 02 02 00 00       	push   $0x202
     ea6:	57                   	push   %edi
     ea7:	e8 23 28 00 00       	call   36cf <open>
     eac:	89 c7                	mov    %eax,%edi
      if(fd < 0){
     eae:	83 c4 10             	add    $0x10,%esp
     eb1:	85 c0                	test   %eax,%eax
     eb3:	78 98                	js     e4d <fourfiles+0x42>
      memset(buf, '0'+pi, 512);
     eb5:	83 ec 04             	sub    $0x4,%esp
     eb8:	68 00 02 00 00       	push   $0x200
     ebd:	83 c6 30             	add    $0x30,%esi
     ec0:	56                   	push   %esi
     ec1:	68 60 82 00 00       	push   $0x8260
     ec6:	e8 99 26 00 00       	call   3564 <memset>
      for(i = 0; i < 12; i++){
     ecb:	83 c4 10             	add    $0x10,%esp
     ece:	83 fb 0b             	cmp    $0xb,%ebx
     ed1:	7f a3                	jg     e76 <fourfiles+0x6b>
        if((n = write(fd, buf, 500)) != 500){
     ed3:	83 ec 04             	sub    $0x4,%esp
     ed6:	68 f4 01 00 00       	push   $0x1f4
     edb:	68 60 82 00 00       	push   $0x8260
     ee0:	57                   	push   %edi
     ee1:	e8 c9 27 00 00       	call   36af <write>
     ee6:	83 c4 10             	add    $0x10,%esp
     ee9:	3d f4 01 00 00       	cmp    $0x1f4,%eax
     eee:	0f 85 6d ff ff ff    	jne    e61 <fourfiles+0x56>
      for(i = 0; i < 12; i++){
     ef4:	43                   	inc    %ebx
     ef5:	eb d7                	jmp    ece <fourfiles+0xc3>
    }
  }

  for(pi = 0; pi < 4; pi++){
     ef7:	bb 00 00 00 00       	mov    $0x0,%ebx
     efc:	eb 06                	jmp    f04 <fourfiles+0xf9>
    wait();
     efe:	e8 94 27 00 00       	call   3697 <wait>
  for(pi = 0; pi < 4; pi++){
     f03:	43                   	inc    %ebx
     f04:	83 fb 03             	cmp    $0x3,%ebx
     f07:	7e f5                	jle    efe <fourfiles+0xf3>
  }

  for(i = 0; i < 2; i++){
     f09:	bb 00 00 00 00       	mov    $0x0,%ebx
     f0e:	eb 71                	jmp    f81 <fourfiles+0x176>
    fd = open(fname, 0);
    total = 0;
    while((n = read(fd, buf, sizeof(buf))) > 0){
      for(j = 0; j < n; j++){
        if(buf[j] != '0'+i){
          printf(1, "wrong char\n");
     f10:	83 ec 08             	sub    $0x8,%esp
     f13:	68 ff 3e 00 00       	push   $0x3eff
     f18:	6a 01                	push   $0x1
     f1a:	e8 b3 28 00 00       	call   37d2 <printf>
          exit();
     f1f:	e8 6b 27 00 00       	call   368f <exit>
        }
      }
      total += n;
     f24:	01 7d d4             	add    %edi,-0x2c(%ebp)
    while((n = read(fd, buf, sizeof(buf))) > 0){
     f27:	83 ec 04             	sub    $0x4,%esp
     f2a:	68 00 20 00 00       	push   $0x2000
     f2f:	68 60 82 00 00       	push   $0x8260
     f34:	56                   	push   %esi
     f35:	e8 6d 27 00 00       	call   36a7 <read>
     f3a:	89 c7                	mov    %eax,%edi
     f3c:	83 c4 10             	add    $0x10,%esp
     f3f:	85 c0                	test   %eax,%eax
     f41:	7e 1a                	jle    f5d <fourfiles+0x152>
      for(j = 0; j < n; j++){
     f43:	b8 00 00 00 00       	mov    $0x0,%eax
     f48:	39 f8                	cmp    %edi,%eax
     f4a:	7d d8                	jge    f24 <fourfiles+0x119>
        if(buf[j] != '0'+i){
     f4c:	0f be 88 60 82 00 00 	movsbl 0x8260(%eax),%ecx
     f53:	8d 53 30             	lea    0x30(%ebx),%edx
     f56:	39 d1                	cmp    %edx,%ecx
     f58:	75 b6                	jne    f10 <fourfiles+0x105>
      for(j = 0; j < n; j++){
     f5a:	40                   	inc    %eax
     f5b:	eb eb                	jmp    f48 <fourfiles+0x13d>
    }
    close(fd);
     f5d:	83 ec 0c             	sub    $0xc,%esp
     f60:	56                   	push   %esi
     f61:	e8 51 27 00 00       	call   36b7 <close>
    if(total != 12*500){
     f66:	83 c4 10             	add    $0x10,%esp
     f69:	81 7d d4 70 17 00 00 	cmpl   $0x1770,-0x2c(%ebp)
     f70:	75 34                	jne    fa6 <fourfiles+0x19b>
      printf(1, "wrong length %d\n", total);
      exit();
    }
    unlink(fname);
     f72:	83 ec 0c             	sub    $0xc,%esp
     f75:	ff 75 d0             	push   -0x30(%ebp)
     f78:	e8 62 27 00 00       	call   36df <unlink>
  for(i = 0; i < 2; i++){
     f7d:	43                   	inc    %ebx
     f7e:	83 c4 10             	add    $0x10,%esp
     f81:	83 fb 01             	cmp    $0x1,%ebx
     f84:	7f 37                	jg     fbd <fourfiles+0x1b2>
    fname = names[i];
     f86:	8b 44 9d d8          	mov    -0x28(%ebp,%ebx,4),%eax
     f8a:	89 45 d0             	mov    %eax,-0x30(%ebp)
    fd = open(fname, 0);
     f8d:	83 ec 08             	sub    $0x8,%esp
     f90:	6a 00                	push   $0x0
     f92:	50                   	push   %eax
     f93:	e8 37 27 00 00       	call   36cf <open>
     f98:	89 c6                	mov    %eax,%esi
    while((n = read(fd, buf, sizeof(buf))) > 0){
     f9a:	83 c4 10             	add    $0x10,%esp
    total = 0;
     f9d:	c7 45 d4 00 00 00 00 	movl   $0x0,-0x2c(%ebp)
    while((n = read(fd, buf, sizeof(buf))) > 0){
     fa4:	eb 81                	jmp    f27 <fourfiles+0x11c>
      printf(1, "wrong length %d\n", total);
     fa6:	83 ec 04             	sub    $0x4,%esp
     fa9:	ff 75 d4             	push   -0x2c(%ebp)
     fac:	68 0b 3f 00 00       	push   $0x3f0b
     fb1:	6a 01                	push   $0x1
     fb3:	e8 1a 28 00 00       	call   37d2 <printf>
      exit();
     fb8:	e8 d2 26 00 00       	call   368f <exit>
  }

  printf(1, "fourfiles ok\n");
     fbd:	83 ec 08             	sub    $0x8,%esp
     fc0:	68 1c 3f 00 00       	push   $0x3f1c
     fc5:	6a 01                	push   $0x1
     fc7:	e8 06 28 00 00       	call   37d2 <printf>
}
     fcc:	83 c4 10             	add    $0x10,%esp
     fcf:	8d 65 f4             	lea    -0xc(%ebp),%esp
     fd2:	5b                   	pop    %ebx
     fd3:	5e                   	pop    %esi
     fd4:	5f                   	pop    %edi
     fd5:	5d                   	pop    %ebp
     fd6:	c3                   	ret    

00000fd7 <createdelete>:

// four processes create and delete different files in same directory
void
createdelete(void)
{
     fd7:	55                   	push   %ebp
     fd8:	89 e5                	mov    %esp,%ebp
     fda:	56                   	push   %esi
     fdb:	53                   	push   %ebx
     fdc:	83 ec 28             	sub    $0x28,%esp
  enum { N = 20 };
  int pid, i, fd, pi;
  char name[32];

  printf(1, "createdelete test\n");
     fdf:	68 30 3f 00 00       	push   $0x3f30
     fe4:	6a 01                	push   $0x1
     fe6:	e8 e7 27 00 00       	call   37d2 <printf>

  for(pi = 0; pi < 4; pi++){
     feb:	83 c4 10             	add    $0x10,%esp
     fee:	be 00 00 00 00       	mov    $0x0,%esi
     ff3:	83 fe 03             	cmp    $0x3,%esi
     ff6:	0f 8f b8 00 00 00    	jg     10b4 <createdelete+0xdd>
    pid = fork();
     ffc:	e8 86 26 00 00       	call   3687 <fork>
    1001:	89 c3                	mov    %eax,%ebx
    if(pid < 0){
    1003:	85 c0                	test   %eax,%eax
    1005:	78 05                	js     100c <createdelete+0x35>
      printf(1, "fork failed\n");
      exit();
    }

    if(pid == 0){
    1007:	74 17                	je     1020 <createdelete+0x49>
  for(pi = 0; pi < 4; pi++){
    1009:	46                   	inc    %esi
    100a:	eb e7                	jmp    ff3 <createdelete+0x1c>
      printf(1, "fork failed\n");
    100c:	83 ec 08             	sub    $0x8,%esp
    100f:	68 b9 49 00 00       	push   $0x49b9
    1014:	6a 01                	push   $0x1
    1016:	e8 b7 27 00 00       	call   37d2 <printf>
      exit();
    101b:	e8 6f 26 00 00       	call   368f <exit>
      name[0] = 'p' + pi;
    1020:	8d 46 70             	lea    0x70(%esi),%eax
    1023:	88 45 d8             	mov    %al,-0x28(%ebp)
      name[2] = '\0';
    1026:	c6 45 da 00          	movb   $0x0,-0x26(%ebp)
      for(i = 0; i < N; i++){
    102a:	eb 15                	jmp    1041 <createdelete+0x6a>
        name[1] = '0' + i;
        fd = open(name, O_CREATE | O_RDWR);
        if(fd < 0){
          printf(1, "create failed\n");
    102c:	83 ec 08             	sub    $0x8,%esp
    102f:	68 7f 41 00 00       	push   $0x417f
    1034:	6a 01                	push   $0x1
    1036:	e8 97 27 00 00       	call   37d2 <printf>
          exit();
    103b:	e8 4f 26 00 00       	call   368f <exit>
      for(i = 0; i < N; i++){
    1040:	43                   	inc    %ebx
    1041:	83 fb 13             	cmp    $0x13,%ebx
    1044:	7f 69                	jg     10af <createdelete+0xd8>
        name[1] = '0' + i;
    1046:	8d 43 30             	lea    0x30(%ebx),%eax
    1049:	88 45 d9             	mov    %al,-0x27(%ebp)
        fd = open(name, O_CREATE | O_RDWR);
    104c:	83 ec 08             	sub    $0x8,%esp
    104f:	68 02 02 00 00       	push   $0x202
    1054:	8d 45 d8             	lea    -0x28(%ebp),%eax
    1057:	50                   	push   %eax
    1058:	e8 72 26 00 00       	call   36cf <open>
        if(fd < 0){
    105d:	83 c4 10             	add    $0x10,%esp
    1060:	85 c0                	test   %eax,%eax
    1062:	78 c8                	js     102c <createdelete+0x55>
        }
        close(fd);
    1064:	83 ec 0c             	sub    $0xc,%esp
    1067:	50                   	push   %eax
    1068:	e8 4a 26 00 00       	call   36b7 <close>
        if(i > 0 && (i % 2 ) == 0){
    106d:	83 c4 10             	add    $0x10,%esp
    1070:	85 db                	test   %ebx,%ebx
    1072:	7e cc                	jle    1040 <createdelete+0x69>
    1074:	f6 c3 01             	test   $0x1,%bl
    1077:	75 c7                	jne    1040 <createdelete+0x69>
          name[1] = '0' + (i / 2);
    1079:	89 d8                	mov    %ebx,%eax
    107b:	c1 e8 1f             	shr    $0x1f,%eax
    107e:	01 d8                	add    %ebx,%eax
    1080:	d1 f8                	sar    %eax
    1082:	83 c0 30             	add    $0x30,%eax
    1085:	88 45 d9             	mov    %al,-0x27(%ebp)
          if(unlink(name) < 0){
    1088:	83 ec 0c             	sub    $0xc,%esp
    108b:	8d 45 d8             	lea    -0x28(%ebp),%eax
    108e:	50                   	push   %eax
    108f:	e8 4b 26 00 00       	call   36df <unlink>
    1094:	83 c4 10             	add    $0x10,%esp
    1097:	85 c0                	test   %eax,%eax
    1099:	79 a5                	jns    1040 <createdelete+0x69>
            printf(1, "unlink failed\n");
    109b:	83 ec 08             	sub    $0x8,%esp
    109e:	68 31 3b 00 00       	push   $0x3b31
    10a3:	6a 01                	push   $0x1
    10a5:	e8 28 27 00 00       	call   37d2 <printf>
            exit();
    10aa:	e8 e0 25 00 00       	call   368f <exit>
          }
        }
      }
      exit();
    10af:	e8 db 25 00 00       	call   368f <exit>
    }
  }

  for(pi = 0; pi < 4; pi++){
    10b4:	bb 00 00 00 00       	mov    $0x0,%ebx
    10b9:	83 fb 03             	cmp    $0x3,%ebx
    10bc:	7f 08                	jg     10c6 <createdelete+0xef>
    wait();
    10be:	e8 d4 25 00 00       	call   3697 <wait>
  for(pi = 0; pi < 4; pi++){
    10c3:	43                   	inc    %ebx
    10c4:	eb f3                	jmp    10b9 <createdelete+0xe2>
  }

  name[0] = name[1] = name[2] = 0;
    10c6:	c6 45 da 00          	movb   $0x0,-0x26(%ebp)
    10ca:	c6 45 d9 00          	movb   $0x0,-0x27(%ebp)
    10ce:	c6 45 d8 00          	movb   $0x0,-0x28(%ebp)
  for(i = 0; i < N; i++){
    10d2:	be 00 00 00 00       	mov    $0x0,%esi
    10d7:	e9 81 00 00 00       	jmp    115d <createdelete+0x186>
    for(pi = 0; pi < 4; pi++){
      name[0] = 'p' + pi;
      name[1] = '0' + i;
      fd = open(name, 0);
      if((i == 0 || i >= N/2) && fd < 0){
    10dc:	85 c0                	test   %eax,%eax
    10de:	78 3a                	js     111a <createdelete+0x143>
        printf(1, "oops createdelete %s didn't exist\n", name);
        exit();
      } else if((i >= 1 && i < N/2) && fd >= 0){
    10e0:	8d 56 ff             	lea    -0x1(%esi),%edx
    10e3:	83 fa 08             	cmp    $0x8,%edx
    10e6:	76 4a                	jbe    1132 <createdelete+0x15b>
        printf(1, "oops createdelete %s did exist\n", name);
        exit();
      }
      if(fd >= 0)
    10e8:	85 c0                	test   %eax,%eax
    10ea:	79 62                	jns    114e <createdelete+0x177>
    for(pi = 0; pi < 4; pi++){
    10ec:	43                   	inc    %ebx
    10ed:	83 fb 03             	cmp    $0x3,%ebx
    10f0:	7f 6a                	jg     115c <createdelete+0x185>
      name[0] = 'p' + pi;
    10f2:	8d 43 70             	lea    0x70(%ebx),%eax
    10f5:	88 45 d8             	mov    %al,-0x28(%ebp)
      name[1] = '0' + i;
    10f8:	8d 46 30             	lea    0x30(%esi),%eax
    10fb:	88 45 d9             	mov    %al,-0x27(%ebp)
      fd = open(name, 0);
    10fe:	83 ec 08             	sub    $0x8,%esp
    1101:	6a 00                	push   $0x0
    1103:	8d 45 d8             	lea    -0x28(%ebp),%eax
    1106:	50                   	push   %eax
    1107:	e8 c3 25 00 00       	call   36cf <open>
      if((i == 0 || i >= N/2) && fd < 0){
    110c:	83 c4 10             	add    $0x10,%esp
    110f:	85 f6                	test   %esi,%esi
    1111:	74 c9                	je     10dc <createdelete+0x105>
    1113:	83 fe 09             	cmp    $0x9,%esi
    1116:	7e c8                	jle    10e0 <createdelete+0x109>
    1118:	eb c2                	jmp    10dc <createdelete+0x105>
        printf(1, "oops createdelete %s didn't exist\n", name);
    111a:	83 ec 04             	sub    $0x4,%esp
    111d:	8d 45 d8             	lea    -0x28(%ebp),%eax
    1120:	50                   	push   %eax
    1121:	68 f0 4b 00 00       	push   $0x4bf0
    1126:	6a 01                	push   $0x1
    1128:	e8 a5 26 00 00       	call   37d2 <printf>
        exit();
    112d:	e8 5d 25 00 00       	call   368f <exit>
      } else if((i >= 1 && i < N/2) && fd >= 0){
    1132:	85 c0                	test   %eax,%eax
    1134:	78 b2                	js     10e8 <createdelete+0x111>
        printf(1, "oops createdelete %s did exist\n", name);
    1136:	83 ec 04             	sub    $0x4,%esp
    1139:	8d 45 d8             	lea    -0x28(%ebp),%eax
    113c:	50                   	push   %eax
    113d:	68 14 4c 00 00       	push   $0x4c14
    1142:	6a 01                	push   $0x1
    1144:	e8 89 26 00 00       	call   37d2 <printf>
        exit();
    1149:	e8 41 25 00 00       	call   368f <exit>
        close(fd);
    114e:	83 ec 0c             	sub    $0xc,%esp
    1151:	50                   	push   %eax
    1152:	e8 60 25 00 00       	call   36b7 <close>
    1157:	83 c4 10             	add    $0x10,%esp
    115a:	eb 90                	jmp    10ec <createdelete+0x115>
  for(i = 0; i < N; i++){
    115c:	46                   	inc    %esi
    115d:	83 fe 13             	cmp    $0x13,%esi
    1160:	7f 07                	jg     1169 <createdelete+0x192>
    for(pi = 0; pi < 4; pi++){
    1162:	bb 00 00 00 00       	mov    $0x0,%ebx
    1167:	eb 84                	jmp    10ed <createdelete+0x116>
    }
  }

  for(i = 0; i < N; i++){
    1169:	be 00 00 00 00       	mov    $0x0,%esi
    116e:	eb 22                	jmp    1192 <createdelete+0x1bb>
    for(pi = 0; pi < 4; pi++){
      name[0] = 'p' + i;
    1170:	8d 46 70             	lea    0x70(%esi),%eax
    1173:	88 45 d8             	mov    %al,-0x28(%ebp)
      name[1] = '0' + i;
    1176:	8d 46 30             	lea    0x30(%esi),%eax
    1179:	88 45 d9             	mov    %al,-0x27(%ebp)
      unlink(name);
    117c:	83 ec 0c             	sub    $0xc,%esp
    117f:	8d 45 d8             	lea    -0x28(%ebp),%eax
    1182:	50                   	push   %eax
    1183:	e8 57 25 00 00       	call   36df <unlink>
    for(pi = 0; pi < 4; pi++){
    1188:	43                   	inc    %ebx
    1189:	83 c4 10             	add    $0x10,%esp
    118c:	83 fb 03             	cmp    $0x3,%ebx
    118f:	7e df                	jle    1170 <createdelete+0x199>
  for(i = 0; i < N; i++){
    1191:	46                   	inc    %esi
    1192:	83 fe 13             	cmp    $0x13,%esi
    1195:	7f 07                	jg     119e <createdelete+0x1c7>
    for(pi = 0; pi < 4; pi++){
    1197:	bb 00 00 00 00       	mov    $0x0,%ebx
    119c:	eb ee                	jmp    118c <createdelete+0x1b5>
    }
  }

  printf(1, "createdelete ok\n");
    119e:	83 ec 08             	sub    $0x8,%esp
    11a1:	68 43 3f 00 00       	push   $0x3f43
    11a6:	6a 01                	push   $0x1
    11a8:	e8 25 26 00 00       	call   37d2 <printf>
}
    11ad:	83 c4 10             	add    $0x10,%esp
    11b0:	8d 65 f8             	lea    -0x8(%ebp),%esp
    11b3:	5b                   	pop    %ebx
    11b4:	5e                   	pop    %esi
    11b5:	5d                   	pop    %ebp
    11b6:	c3                   	ret    

000011b7 <unlinkread>:

// can I unlink a file and still read it?
void
unlinkread(void)
{
    11b7:	55                   	push   %ebp
    11b8:	89 e5                	mov    %esp,%ebp
    11ba:	56                   	push   %esi
    11bb:	53                   	push   %ebx
  int fd, fd1;

  printf(1, "unlinkread test\n");
    11bc:	83 ec 08             	sub    $0x8,%esp
    11bf:	68 54 3f 00 00       	push   $0x3f54
    11c4:	6a 01                	push   $0x1
    11c6:	e8 07 26 00 00       	call   37d2 <printf>
  fd = open("unlinkread", O_CREATE | O_RDWR);
    11cb:	83 c4 08             	add    $0x8,%esp
    11ce:	68 02 02 00 00       	push   $0x202
    11d3:	68 65 3f 00 00       	push   $0x3f65
    11d8:	e8 f2 24 00 00       	call   36cf <open>
  if(fd < 0){
    11dd:	83 c4 10             	add    $0x10,%esp
    11e0:	85 c0                	test   %eax,%eax
    11e2:	0f 88 f0 00 00 00    	js     12d8 <unlinkread+0x121>
    11e8:	89 c3                	mov    %eax,%ebx
    printf(1, "create unlinkread failed\n");
    exit();
  }
  write(fd, "hello", 5);
    11ea:	83 ec 04             	sub    $0x4,%esp
    11ed:	6a 05                	push   $0x5
    11ef:	68 8a 3f 00 00       	push   $0x3f8a
    11f4:	50                   	push   %eax
    11f5:	e8 b5 24 00 00       	call   36af <write>
  close(fd);
    11fa:	89 1c 24             	mov    %ebx,(%esp)
    11fd:	e8 b5 24 00 00       	call   36b7 <close>

  fd = open("unlinkread", O_RDWR);
    1202:	83 c4 08             	add    $0x8,%esp
    1205:	6a 02                	push   $0x2
    1207:	68 65 3f 00 00       	push   $0x3f65
    120c:	e8 be 24 00 00       	call   36cf <open>
    1211:	89 c3                	mov    %eax,%ebx
  if(fd < 0){
    1213:	83 c4 10             	add    $0x10,%esp
    1216:	85 c0                	test   %eax,%eax
    1218:	0f 88 ce 00 00 00    	js     12ec <unlinkread+0x135>
    printf(1, "open unlinkread failed\n");
    exit();
  }
  if(unlink("unlinkread") != 0){
    121e:	83 ec 0c             	sub    $0xc,%esp
    1221:	68 65 3f 00 00       	push   $0x3f65
    1226:	e8 b4 24 00 00       	call   36df <unlink>
    122b:	83 c4 10             	add    $0x10,%esp
    122e:	85 c0                	test   %eax,%eax
    1230:	0f 85 ca 00 00 00    	jne    1300 <unlinkread+0x149>
    printf(1, "unlink unlinkread failed\n");
    exit();
  }

  fd1 = open("unlinkread", O_CREATE | O_RDWR);
    1236:	83 ec 08             	sub    $0x8,%esp
    1239:	68 02 02 00 00       	push   $0x202
    123e:	68 65 3f 00 00       	push   $0x3f65
    1243:	e8 87 24 00 00       	call   36cf <open>
    1248:	89 c6                	mov    %eax,%esi
  write(fd1, "yyy", 3);
    124a:	83 c4 0c             	add    $0xc,%esp
    124d:	6a 03                	push   $0x3
    124f:	68 c2 3f 00 00       	push   $0x3fc2
    1254:	50                   	push   %eax
    1255:	e8 55 24 00 00       	call   36af <write>
  close(fd1);
    125a:	89 34 24             	mov    %esi,(%esp)
    125d:	e8 55 24 00 00       	call   36b7 <close>

  if(read(fd, buf, sizeof(buf)) != 5){
    1262:	83 c4 0c             	add    $0xc,%esp
    1265:	68 00 20 00 00       	push   $0x2000
    126a:	68 60 82 00 00       	push   $0x8260
    126f:	53                   	push   %ebx
    1270:	e8 32 24 00 00       	call   36a7 <read>
    1275:	83 c4 10             	add    $0x10,%esp
    1278:	83 f8 05             	cmp    $0x5,%eax
    127b:	0f 85 93 00 00 00    	jne    1314 <unlinkread+0x15d>
    printf(1, "unlinkread read failed");
    exit();
  }
  if(buf[0] != 'h'){
    1281:	80 3d 60 82 00 00 68 	cmpb   $0x68,0x8260
    1288:	0f 85 9a 00 00 00    	jne    1328 <unlinkread+0x171>
    printf(1, "unlinkread wrong data\n");
    exit();
  }
  if(write(fd, buf, 10) != 10){
    128e:	83 ec 04             	sub    $0x4,%esp
    1291:	6a 0a                	push   $0xa
    1293:	68 60 82 00 00       	push   $0x8260
    1298:	53                   	push   %ebx
    1299:	e8 11 24 00 00       	call   36af <write>
    129e:	83 c4 10             	add    $0x10,%esp
    12a1:	83 f8 0a             	cmp    $0xa,%eax
    12a4:	0f 85 92 00 00 00    	jne    133c <unlinkread+0x185>
    printf(1, "unlinkread write failed\n");
    exit();
  }
  close(fd);
    12aa:	83 ec 0c             	sub    $0xc,%esp
    12ad:	53                   	push   %ebx
    12ae:	e8 04 24 00 00       	call   36b7 <close>
  unlink("unlinkread");
    12b3:	c7 04 24 65 3f 00 00 	movl   $0x3f65,(%esp)
    12ba:	e8 20 24 00 00       	call   36df <unlink>
  printf(1, "unlinkread ok\n");
    12bf:	83 c4 08             	add    $0x8,%esp
    12c2:	68 0d 40 00 00       	push   $0x400d
    12c7:	6a 01                	push   $0x1
    12c9:	e8 04 25 00 00       	call   37d2 <printf>
}
    12ce:	83 c4 10             	add    $0x10,%esp
    12d1:	8d 65 f8             	lea    -0x8(%ebp),%esp
    12d4:	5b                   	pop    %ebx
    12d5:	5e                   	pop    %esi
    12d6:	5d                   	pop    %ebp
    12d7:	c3                   	ret    
    printf(1, "create unlinkread failed\n");
    12d8:	83 ec 08             	sub    $0x8,%esp
    12db:	68 70 3f 00 00       	push   $0x3f70
    12e0:	6a 01                	push   $0x1
    12e2:	e8 eb 24 00 00       	call   37d2 <printf>
    exit();
    12e7:	e8 a3 23 00 00       	call   368f <exit>
    printf(1, "open unlinkread failed\n");
    12ec:	83 ec 08             	sub    $0x8,%esp
    12ef:	68 90 3f 00 00       	push   $0x3f90
    12f4:	6a 01                	push   $0x1
    12f6:	e8 d7 24 00 00       	call   37d2 <printf>
    exit();
    12fb:	e8 8f 23 00 00       	call   368f <exit>
    printf(1, "unlink unlinkread failed\n");
    1300:	83 ec 08             	sub    $0x8,%esp
    1303:	68 a8 3f 00 00       	push   $0x3fa8
    1308:	6a 01                	push   $0x1
    130a:	e8 c3 24 00 00       	call   37d2 <printf>
    exit();
    130f:	e8 7b 23 00 00       	call   368f <exit>
    printf(1, "unlinkread read failed");
    1314:	83 ec 08             	sub    $0x8,%esp
    1317:	68 c6 3f 00 00       	push   $0x3fc6
    131c:	6a 01                	push   $0x1
    131e:	e8 af 24 00 00       	call   37d2 <printf>
    exit();
    1323:	e8 67 23 00 00       	call   368f <exit>
    printf(1, "unlinkread wrong data\n");
    1328:	83 ec 08             	sub    $0x8,%esp
    132b:	68 dd 3f 00 00       	push   $0x3fdd
    1330:	6a 01                	push   $0x1
    1332:	e8 9b 24 00 00       	call   37d2 <printf>
    exit();
    1337:	e8 53 23 00 00       	call   368f <exit>
    printf(1, "unlinkread write failed\n");
    133c:	83 ec 08             	sub    $0x8,%esp
    133f:	68 f4 3f 00 00       	push   $0x3ff4
    1344:	6a 01                	push   $0x1
    1346:	e8 87 24 00 00       	call   37d2 <printf>
    exit();
    134b:	e8 3f 23 00 00       	call   368f <exit>

00001350 <linktest>:

void
linktest(void)
{
    1350:	55                   	push   %ebp
    1351:	89 e5                	mov    %esp,%ebp
    1353:	53                   	push   %ebx
    1354:	83 ec 0c             	sub    $0xc,%esp
  int fd;

  printf(1, "linktest\n");
    1357:	68 1c 40 00 00       	push   $0x401c
    135c:	6a 01                	push   $0x1
    135e:	e8 6f 24 00 00       	call   37d2 <printf>

  unlink("lf1");
    1363:	c7 04 24 26 40 00 00 	movl   $0x4026,(%esp)
    136a:	e8 70 23 00 00       	call   36df <unlink>
  unlink("lf2");
    136f:	c7 04 24 2a 40 00 00 	movl   $0x402a,(%esp)
    1376:	e8 64 23 00 00       	call   36df <unlink>

  fd = open("lf1", O_CREATE|O_RDWR);
    137b:	83 c4 08             	add    $0x8,%esp
    137e:	68 02 02 00 00       	push   $0x202
    1383:	68 26 40 00 00       	push   $0x4026
    1388:	e8 42 23 00 00       	call   36cf <open>
  if(fd < 0){
    138d:	83 c4 10             	add    $0x10,%esp
    1390:	85 c0                	test   %eax,%eax
    1392:	0f 88 2a 01 00 00    	js     14c2 <linktest+0x172>
    1398:	89 c3                	mov    %eax,%ebx
    printf(1, "create lf1 failed\n");
    exit();
  }
  if(write(fd, "hello", 5) != 5){
    139a:	83 ec 04             	sub    $0x4,%esp
    139d:	6a 05                	push   $0x5
    139f:	68 8a 3f 00 00       	push   $0x3f8a
    13a4:	50                   	push   %eax
    13a5:	e8 05 23 00 00       	call   36af <write>
    13aa:	83 c4 10             	add    $0x10,%esp
    13ad:	83 f8 05             	cmp    $0x5,%eax
    13b0:	0f 85 20 01 00 00    	jne    14d6 <linktest+0x186>
    printf(1, "write lf1 failed\n");
    exit();
  }
  close(fd);
    13b6:	83 ec 0c             	sub    $0xc,%esp
    13b9:	53                   	push   %ebx
    13ba:	e8 f8 22 00 00       	call   36b7 <close>

  if(link("lf1", "lf2") < 0){
    13bf:	83 c4 08             	add    $0x8,%esp
    13c2:	68 2a 40 00 00       	push   $0x402a
    13c7:	68 26 40 00 00       	push   $0x4026
    13cc:	e8 1e 23 00 00       	call   36ef <link>
    13d1:	83 c4 10             	add    $0x10,%esp
    13d4:	85 c0                	test   %eax,%eax
    13d6:	0f 88 0e 01 00 00    	js     14ea <linktest+0x19a>
    printf(1, "link lf1 lf2 failed\n");
    exit();
  }
  unlink("lf1");
    13dc:	83 ec 0c             	sub    $0xc,%esp
    13df:	68 26 40 00 00       	push   $0x4026
    13e4:	e8 f6 22 00 00       	call   36df <unlink>

  if(open("lf1", 0) >= 0){
    13e9:	83 c4 08             	add    $0x8,%esp
    13ec:	6a 00                	push   $0x0
    13ee:	68 26 40 00 00       	push   $0x4026
    13f3:	e8 d7 22 00 00       	call   36cf <open>
    13f8:	83 c4 10             	add    $0x10,%esp
    13fb:	85 c0                	test   %eax,%eax
    13fd:	0f 89 fb 00 00 00    	jns    14fe <linktest+0x1ae>
    printf(1, "unlinked lf1 but it is still there!\n");
    exit();
  }

  fd = open("lf2", 0);
    1403:	83 ec 08             	sub    $0x8,%esp
    1406:	6a 00                	push   $0x0
    1408:	68 2a 40 00 00       	push   $0x402a
    140d:	e8 bd 22 00 00       	call   36cf <open>
    1412:	89 c3                	mov    %eax,%ebx
  if(fd < 0){
    1414:	83 c4 10             	add    $0x10,%esp
    1417:	85 c0                	test   %eax,%eax
    1419:	0f 88 f3 00 00 00    	js     1512 <linktest+0x1c2>
    printf(1, "open lf2 failed\n");
    exit();
  }
  if(read(fd, buf, sizeof(buf)) != 5){
    141f:	83 ec 04             	sub    $0x4,%esp
    1422:	68 00 20 00 00       	push   $0x2000
    1427:	68 60 82 00 00       	push   $0x8260
    142c:	50                   	push   %eax
    142d:	e8 75 22 00 00       	call   36a7 <read>
    1432:	83 c4 10             	add    $0x10,%esp
    1435:	83 f8 05             	cmp    $0x5,%eax
    1438:	0f 85 e8 00 00 00    	jne    1526 <linktest+0x1d6>
    printf(1, "read lf2 failed\n");
    exit();
  }
  close(fd);
    143e:	83 ec 0c             	sub    $0xc,%esp
    1441:	53                   	push   %ebx
    1442:	e8 70 22 00 00       	call   36b7 <close>

  if(link("lf2", "lf2") >= 0){
    1447:	83 c4 08             	add    $0x8,%esp
    144a:	68 2a 40 00 00       	push   $0x402a
    144f:	68 2a 40 00 00       	push   $0x402a
    1454:	e8 96 22 00 00       	call   36ef <link>
    1459:	83 c4 10             	add    $0x10,%esp
    145c:	85 c0                	test   %eax,%eax
    145e:	0f 89 d6 00 00 00    	jns    153a <linktest+0x1ea>
    printf(1, "link lf2 lf2 succeeded! oops\n");
    exit();
  }

  unlink("lf2");
    1464:	83 ec 0c             	sub    $0xc,%esp
    1467:	68 2a 40 00 00       	push   $0x402a
    146c:	e8 6e 22 00 00       	call   36df <unlink>
  if(link("lf2", "lf1") >= 0){
    1471:	83 c4 08             	add    $0x8,%esp
    1474:	68 26 40 00 00       	push   $0x4026
    1479:	68 2a 40 00 00       	push   $0x402a
    147e:	e8 6c 22 00 00       	call   36ef <link>
    1483:	83 c4 10             	add    $0x10,%esp
    1486:	85 c0                	test   %eax,%eax
    1488:	0f 89 c0 00 00 00    	jns    154e <linktest+0x1fe>
    printf(1, "link non-existant succeeded! oops\n");
    exit();
  }

  if(link(".", "lf1") >= 0){
    148e:	83 ec 08             	sub    $0x8,%esp
    1491:	68 26 40 00 00       	push   $0x4026
    1496:	68 ee 42 00 00       	push   $0x42ee
    149b:	e8 4f 22 00 00       	call   36ef <link>
    14a0:	83 c4 10             	add    $0x10,%esp
    14a3:	85 c0                	test   %eax,%eax
    14a5:	0f 89 b7 00 00 00    	jns    1562 <linktest+0x212>
    printf(1, "link . lf1 succeeded! oops\n");
    exit();
  }

  printf(1, "linktest ok\n");
    14ab:	83 ec 08             	sub    $0x8,%esp
    14ae:	68 c4 40 00 00       	push   $0x40c4
    14b3:	6a 01                	push   $0x1
    14b5:	e8 18 23 00 00       	call   37d2 <printf>
}
    14ba:	83 c4 10             	add    $0x10,%esp
    14bd:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    14c0:	c9                   	leave  
    14c1:	c3                   	ret    
    printf(1, "create lf1 failed\n");
    14c2:	83 ec 08             	sub    $0x8,%esp
    14c5:	68 2e 40 00 00       	push   $0x402e
    14ca:	6a 01                	push   $0x1
    14cc:	e8 01 23 00 00       	call   37d2 <printf>
    exit();
    14d1:	e8 b9 21 00 00       	call   368f <exit>
    printf(1, "write lf1 failed\n");
    14d6:	83 ec 08             	sub    $0x8,%esp
    14d9:	68 41 40 00 00       	push   $0x4041
    14de:	6a 01                	push   $0x1
    14e0:	e8 ed 22 00 00       	call   37d2 <printf>
    exit();
    14e5:	e8 a5 21 00 00       	call   368f <exit>
    printf(1, "link lf1 lf2 failed\n");
    14ea:	83 ec 08             	sub    $0x8,%esp
    14ed:	68 53 40 00 00       	push   $0x4053
    14f2:	6a 01                	push   $0x1
    14f4:	e8 d9 22 00 00       	call   37d2 <printf>
    exit();
    14f9:	e8 91 21 00 00       	call   368f <exit>
    printf(1, "unlinked lf1 but it is still there!\n");
    14fe:	83 ec 08             	sub    $0x8,%esp
    1501:	68 34 4c 00 00       	push   $0x4c34
    1506:	6a 01                	push   $0x1
    1508:	e8 c5 22 00 00       	call   37d2 <printf>
    exit();
    150d:	e8 7d 21 00 00       	call   368f <exit>
    printf(1, "open lf2 failed\n");
    1512:	83 ec 08             	sub    $0x8,%esp
    1515:	68 68 40 00 00       	push   $0x4068
    151a:	6a 01                	push   $0x1
    151c:	e8 b1 22 00 00       	call   37d2 <printf>
    exit();
    1521:	e8 69 21 00 00       	call   368f <exit>
    printf(1, "read lf2 failed\n");
    1526:	83 ec 08             	sub    $0x8,%esp
    1529:	68 79 40 00 00       	push   $0x4079
    152e:	6a 01                	push   $0x1
    1530:	e8 9d 22 00 00       	call   37d2 <printf>
    exit();
    1535:	e8 55 21 00 00       	call   368f <exit>
    printf(1, "link lf2 lf2 succeeded! oops\n");
    153a:	83 ec 08             	sub    $0x8,%esp
    153d:	68 8a 40 00 00       	push   $0x408a
    1542:	6a 01                	push   $0x1
    1544:	e8 89 22 00 00       	call   37d2 <printf>
    exit();
    1549:	e8 41 21 00 00       	call   368f <exit>
    printf(1, "link non-existant succeeded! oops\n");
    154e:	83 ec 08             	sub    $0x8,%esp
    1551:	68 5c 4c 00 00       	push   $0x4c5c
    1556:	6a 01                	push   $0x1
    1558:	e8 75 22 00 00       	call   37d2 <printf>
    exit();
    155d:	e8 2d 21 00 00       	call   368f <exit>
    printf(1, "link . lf1 succeeded! oops\n");
    1562:	83 ec 08             	sub    $0x8,%esp
    1565:	68 a8 40 00 00       	push   $0x40a8
    156a:	6a 01                	push   $0x1
    156c:	e8 61 22 00 00       	call   37d2 <printf>
    exit();
    1571:	e8 19 21 00 00       	call   368f <exit>

00001576 <concreate>:

// test concurrent create/link/unlink of the same file
void
concreate(void)
{
    1576:	55                   	push   %ebp
    1577:	89 e5                	mov    %esp,%ebp
    1579:	57                   	push   %edi
    157a:	56                   	push   %esi
    157b:	53                   	push   %ebx
    157c:	83 ec 54             	sub    $0x54,%esp
  struct {
    ushort inum;
    char name[14];
  } de;

  printf(1, "concreate test\n");
    157f:	68 d1 40 00 00       	push   $0x40d1
    1584:	6a 01                	push   $0x1
    1586:	e8 47 22 00 00       	call   37d2 <printf>
  file[0] = 'C';
    158b:	c6 45 e5 43          	movb   $0x43,-0x1b(%ebp)
  file[2] = '\0';
    158f:	c6 45 e7 00          	movb   $0x0,-0x19(%ebp)
  for(i = 0; i < 40; i++){
    1593:	83 c4 10             	add    $0x10,%esp
    1596:	bb 00 00 00 00       	mov    $0x0,%ebx
    159b:	eb 41                	jmp    15de <concreate+0x68>
    file[1] = '0' + i;
    unlink(file);
    pid = fork();
    if(pid && (i % 3) == 1){
      link("C0", file);
    } else if(pid == 0 && (i % 5) == 1){
    159d:	85 f6                	test   %esi,%esi
    159f:	75 0f                	jne    15b0 <concreate+0x3a>
    15a1:	b9 05 00 00 00       	mov    $0x5,%ecx
    15a6:	89 d8                	mov    %ebx,%eax
    15a8:	99                   	cltd   
    15a9:	f7 f9                	idiv   %ecx
    15ab:	83 fa 01             	cmp    $0x1,%edx
    15ae:	74 78                	je     1628 <concreate+0xb2>
      link("C0", file);
    } else {
      fd = open(file, O_CREATE | O_RDWR);
    15b0:	83 ec 08             	sub    $0x8,%esp
    15b3:	68 02 02 00 00       	push   $0x202
    15b8:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    15bb:	50                   	push   %eax
    15bc:	e8 0e 21 00 00       	call   36cf <open>
      if(fd < 0){
    15c1:	83 c4 10             	add    $0x10,%esp
    15c4:	85 c0                	test   %eax,%eax
    15c6:	78 76                	js     163e <concreate+0xc8>
        printf(1, "concreate create %s failed\n", file);
        exit();
      }
      close(fd);
    15c8:	83 ec 0c             	sub    $0xc,%esp
    15cb:	50                   	push   %eax
    15cc:	e8 e6 20 00 00       	call   36b7 <close>
    15d1:	83 c4 10             	add    $0x10,%esp
    }
    if(pid == 0)
    15d4:	85 f6                	test   %esi,%esi
    15d6:	74 7e                	je     1656 <concreate+0xe0>
      exit();
    else
      wait();
    15d8:	e8 ba 20 00 00       	call   3697 <wait>
  for(i = 0; i < 40; i++){
    15dd:	43                   	inc    %ebx
    15de:	83 fb 27             	cmp    $0x27,%ebx
    15e1:	7f 78                	jg     165b <concreate+0xe5>
    file[1] = '0' + i;
    15e3:	8d 43 30             	lea    0x30(%ebx),%eax
    15e6:	88 45 e6             	mov    %al,-0x1a(%ebp)
    unlink(file);
    15e9:	83 ec 0c             	sub    $0xc,%esp
    15ec:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    15ef:	50                   	push   %eax
    15f0:	e8 ea 20 00 00       	call   36df <unlink>
    pid = fork();
    15f5:	e8 8d 20 00 00       	call   3687 <fork>
    15fa:	89 c6                	mov    %eax,%esi
    if(pid && (i % 3) == 1){
    15fc:	83 c4 10             	add    $0x10,%esp
    15ff:	85 c0                	test   %eax,%eax
    1601:	74 9a                	je     159d <concreate+0x27>
    1603:	b9 03 00 00 00       	mov    $0x3,%ecx
    1608:	89 d8                	mov    %ebx,%eax
    160a:	99                   	cltd   
    160b:	f7 f9                	idiv   %ecx
    160d:	83 fa 01             	cmp    $0x1,%edx
    1610:	75 8b                	jne    159d <concreate+0x27>
      link("C0", file);
    1612:	83 ec 08             	sub    $0x8,%esp
    1615:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    1618:	50                   	push   %eax
    1619:	68 e1 40 00 00       	push   $0x40e1
    161e:	e8 cc 20 00 00       	call   36ef <link>
    1623:	83 c4 10             	add    $0x10,%esp
    1626:	eb ac                	jmp    15d4 <concreate+0x5e>
      link("C0", file);
    1628:	83 ec 08             	sub    $0x8,%esp
    162b:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    162e:	50                   	push   %eax
    162f:	68 e1 40 00 00       	push   $0x40e1
    1634:	e8 b6 20 00 00       	call   36ef <link>
    1639:	83 c4 10             	add    $0x10,%esp
    163c:	eb 96                	jmp    15d4 <concreate+0x5e>
        printf(1, "concreate create %s failed\n", file);
    163e:	83 ec 04             	sub    $0x4,%esp
    1641:	8d 45 e5             	lea    -0x1b(%ebp),%eax
    1644:	50                   	push   %eax
    1645:	68 e4 40 00 00       	push   $0x40e4
    164a:	6a 01                	push   $0x1
    164c:	e8 81 21 00 00       	call   37d2 <printf>
        exit();
    1651:	e8 39 20 00 00       	call   368f <exit>
      exit();
    1656:	e8 34 20 00 00       	call   368f <exit>
  }

  memset(fa, 0, sizeof(fa));
    165b:	83 ec 04             	sub    $0x4,%esp
    165e:	6a 28                	push   $0x28
    1660:	6a 00                	push   $0x0
    1662:	8d 45 bd             	lea    -0x43(%ebp),%eax
    1665:	50                   	push   %eax
    1666:	e8 f9 1e 00 00       	call   3564 <memset>
  fd = open(".", 0);
    166b:	83 c4 08             	add    $0x8,%esp
    166e:	6a 00                	push   $0x0
    1670:	68 ee 42 00 00       	push   $0x42ee
    1675:	e8 55 20 00 00       	call   36cf <open>
    167a:	89 c3                	mov    %eax,%ebx
  n = 0;
  while(read(fd, &de, sizeof(de)) > 0){
    167c:	83 c4 10             	add    $0x10,%esp
  n = 0;
    167f:	be 00 00 00 00       	mov    $0x0,%esi
  while(read(fd, &de, sizeof(de)) > 0){
    1684:	83 ec 04             	sub    $0x4,%esp
    1687:	6a 10                	push   $0x10
    1689:	8d 45 ac             	lea    -0x54(%ebp),%eax
    168c:	50                   	push   %eax
    168d:	53                   	push   %ebx
    168e:	e8 14 20 00 00       	call   36a7 <read>
    1693:	83 c4 10             	add    $0x10,%esp
    1696:	85 c0                	test   %eax,%eax
    1698:	7e 5e                	jle    16f8 <concreate+0x182>
    if(de.inum == 0)
    169a:	66 83 7d ac 00       	cmpw   $0x0,-0x54(%ebp)
    169f:	74 e3                	je     1684 <concreate+0x10e>
      continue;
    if(de.name[0] == 'C' && de.name[2] == '\0'){
    16a1:	80 7d ae 43          	cmpb   $0x43,-0x52(%ebp)
    16a5:	75 dd                	jne    1684 <concreate+0x10e>
    16a7:	80 7d b0 00          	cmpb   $0x0,-0x50(%ebp)
    16ab:	75 d7                	jne    1684 <concreate+0x10e>
      i = de.name[1] - '0';
    16ad:	0f be 45 af          	movsbl -0x51(%ebp),%eax
    16b1:	83 e8 30             	sub    $0x30,%eax
      if(i < 0 || i >= sizeof(fa)){
    16b4:	83 f8 27             	cmp    $0x27,%eax
    16b7:	77 0f                	ja     16c8 <concreate+0x152>
        printf(1, "concreate weird file %s\n", de.name);
        exit();
      }
      if(fa[i]){
    16b9:	80 7c 05 bd 00       	cmpb   $0x0,-0x43(%ebp,%eax,1)
    16be:	75 20                	jne    16e0 <concreate+0x16a>
        printf(1, "concreate duplicate file %s\n", de.name);
        exit();
      }
      fa[i] = 1;
    16c0:	c6 44 05 bd 01       	movb   $0x1,-0x43(%ebp,%eax,1)
      n++;
    16c5:	46                   	inc    %esi
    16c6:	eb bc                	jmp    1684 <concreate+0x10e>
        printf(1, "concreate weird file %s\n", de.name);
    16c8:	83 ec 04             	sub    $0x4,%esp
    16cb:	8d 45 ae             	lea    -0x52(%ebp),%eax
    16ce:	50                   	push   %eax
    16cf:	68 00 41 00 00       	push   $0x4100
    16d4:	6a 01                	push   $0x1
    16d6:	e8 f7 20 00 00       	call   37d2 <printf>
        exit();
    16db:	e8 af 1f 00 00       	call   368f <exit>
        printf(1, "concreate duplicate file %s\n", de.name);
    16e0:	83 ec 04             	sub    $0x4,%esp
    16e3:	8d 45 ae             	lea    -0x52(%ebp),%eax
    16e6:	50                   	push   %eax
    16e7:	68 19 41 00 00       	push   $0x4119
    16ec:	6a 01                	push   $0x1
    16ee:	e8 df 20 00 00       	call   37d2 <printf>
        exit();
    16f3:	e8 97 1f 00 00       	call   368f <exit>
    }
  }
  close(fd);
    16f8:	83 ec 0c             	sub    $0xc,%esp
    16fb:	53                   	push   %ebx
    16fc:	e8 b6 1f 00 00       	call   36b7 <close>

  if(n != 40){
    1701:	83 c4 10             	add    $0x10,%esp
    1704:	83 fe 28             	cmp    $0x28,%esi
    1707:	75 07                	jne    1710 <concreate+0x19a>
    printf(1, "concreate not enough files in directory listing\n");
    exit();
  }

  for(i = 0; i < 40; i++){
    1709:	bb 00 00 00 00       	mov    $0x0,%ebx
    170e:	eb 5d                	jmp    176d <concreate+0x1f7>
    printf(1, "concreate not enough files in directory listing\n");
    1710:	83 ec 08             	sub    $0x8,%esp
    1713:	68 80 4c 00 00       	push   $0x4c80
    1718:	6a 01                	push   $0x1
    171a:	e8 b3 20 00 00       	call   37d2 <printf>
    exit();
    171f:	e8 6b 1f 00 00       	call   368f <exit>
    file[1] = '0' + i;
    pid = fork();
    if(pid < 0){
      printf(1, "fork failed\n");
    1724:	83 ec 08             	sub    $0x8,%esp
    1727:	68 b9 49 00 00       	push   $0x49b9
    172c:	6a 01                	push   $0x1
    172e:	e8 9f 20 00 00       	call   37d2 <printf>
      exit();
    1733:	e8 57 1f 00 00       	call   368f <exit>
      close(open(file, 0));
      close(open(file, 0));
      close(open(file, 0));
      close(open(file, 0));
    } else {
      unlink(file);
    1738:	83 ec 0c             	sub    $0xc,%esp
    173b:	8d 7d e5             	lea    -0x1b(%ebp),%edi
    173e:	57                   	push   %edi
    173f:	e8 9b 1f 00 00       	call   36df <unlink>
      unlink(file);
    1744:	89 3c 24             	mov    %edi,(%esp)
    1747:	e8 93 1f 00 00       	call   36df <unlink>
      unlink(file);
    174c:	89 3c 24             	mov    %edi,(%esp)
    174f:	e8 8b 1f 00 00       	call   36df <unlink>
      unlink(file);
    1754:	89 3c 24             	mov    %edi,(%esp)
    1757:	e8 83 1f 00 00       	call   36df <unlink>
    175c:	83 c4 10             	add    $0x10,%esp
    }
    if(pid == 0)
    175f:	85 f6                	test   %esi,%esi
    1761:	0f 84 92 00 00 00    	je     17f9 <concreate+0x283>
      exit();
    else
      wait();
    1767:	e8 2b 1f 00 00       	call   3697 <wait>
  for(i = 0; i < 40; i++){
    176c:	43                   	inc    %ebx
    176d:	83 fb 27             	cmp    $0x27,%ebx
    1770:	0f 8f 88 00 00 00    	jg     17fe <concreate+0x288>
    file[1] = '0' + i;
    1776:	8d 43 30             	lea    0x30(%ebx),%eax
    1779:	88 45 e6             	mov    %al,-0x1a(%ebp)
    pid = fork();
    177c:	e8 06 1f 00 00       	call   3687 <fork>
    1781:	89 c6                	mov    %eax,%esi
    if(pid < 0){
    1783:	85 c0                	test   %eax,%eax
    1785:	78 9d                	js     1724 <concreate+0x1ae>
    if(((i % 3) == 0 && pid == 0) ||
    1787:	b9 03 00 00 00       	mov    $0x3,%ecx
    178c:	89 d8                	mov    %ebx,%eax
    178e:	99                   	cltd   
    178f:	f7 f9                	idiv   %ecx
    1791:	85 d2                	test   %edx,%edx
    1793:	75 04                	jne    1799 <concreate+0x223>
    1795:	85 f6                	test   %esi,%esi
    1797:	74 09                	je     17a2 <concreate+0x22c>
    1799:	83 fa 01             	cmp    $0x1,%edx
    179c:	75 9a                	jne    1738 <concreate+0x1c2>
       ((i % 3) == 1 && pid != 0)){
    179e:	85 f6                	test   %esi,%esi
    17a0:	74 96                	je     1738 <concreate+0x1c2>
      close(open(file, 0));
    17a2:	83 ec 08             	sub    $0x8,%esp
    17a5:	6a 00                	push   $0x0
    17a7:	8d 7d e5             	lea    -0x1b(%ebp),%edi
    17aa:	57                   	push   %edi
    17ab:	e8 1f 1f 00 00       	call   36cf <open>
    17b0:	89 04 24             	mov    %eax,(%esp)
    17b3:	e8 ff 1e 00 00       	call   36b7 <close>
      close(open(file, 0));
    17b8:	83 c4 08             	add    $0x8,%esp
    17bb:	6a 00                	push   $0x0
    17bd:	57                   	push   %edi
    17be:	e8 0c 1f 00 00       	call   36cf <open>
    17c3:	89 04 24             	mov    %eax,(%esp)
    17c6:	e8 ec 1e 00 00       	call   36b7 <close>
      close(open(file, 0));
    17cb:	83 c4 08             	add    $0x8,%esp
    17ce:	6a 00                	push   $0x0
    17d0:	57                   	push   %edi
    17d1:	e8 f9 1e 00 00       	call   36cf <open>
    17d6:	89 04 24             	mov    %eax,(%esp)
    17d9:	e8 d9 1e 00 00       	call   36b7 <close>
      close(open(file, 0));
    17de:	83 c4 08             	add    $0x8,%esp
    17e1:	6a 00                	push   $0x0
    17e3:	57                   	push   %edi
    17e4:	e8 e6 1e 00 00       	call   36cf <open>
    17e9:	89 04 24             	mov    %eax,(%esp)
    17ec:	e8 c6 1e 00 00       	call   36b7 <close>
    17f1:	83 c4 10             	add    $0x10,%esp
    17f4:	e9 66 ff ff ff       	jmp    175f <concreate+0x1e9>
      exit();
    17f9:	e8 91 1e 00 00       	call   368f <exit>
  }

  printf(1, "concreate ok\n");
    17fe:	83 ec 08             	sub    $0x8,%esp
    1801:	68 36 41 00 00       	push   $0x4136
    1806:	6a 01                	push   $0x1
    1808:	e8 c5 1f 00 00       	call   37d2 <printf>
}
    180d:	83 c4 10             	add    $0x10,%esp
    1810:	8d 65 f4             	lea    -0xc(%ebp),%esp
    1813:	5b                   	pop    %ebx
    1814:	5e                   	pop    %esi
    1815:	5f                   	pop    %edi
    1816:	5d                   	pop    %ebp
    1817:	c3                   	ret    

00001818 <linkunlink>:

// another concurrent link/unlink/create test,
// to look for deadlocks.
void
linkunlink()
{
    1818:	55                   	push   %ebp
    1819:	89 e5                	mov    %esp,%ebp
    181b:	57                   	push   %edi
    181c:	56                   	push   %esi
    181d:	53                   	push   %ebx
    181e:	83 ec 14             	sub    $0x14,%esp
  int pid, i;

  printf(1, "linkunlink test\n");
    1821:	68 44 41 00 00       	push   $0x4144
    1826:	6a 01                	push   $0x1
    1828:	e8 a5 1f 00 00       	call   37d2 <printf>

  unlink("x");
    182d:	c7 04 24 d1 43 00 00 	movl   $0x43d1,(%esp)
    1834:	e8 a6 1e 00 00       	call   36df <unlink>
  pid = fork();
    1839:	e8 49 1e 00 00       	call   3687 <fork>
  if(pid < 0){
    183e:	83 c4 10             	add    $0x10,%esp
    1841:	85 c0                	test   %eax,%eax
    1843:	78 10                	js     1855 <linkunlink+0x3d>
    1845:	89 c7                	mov    %eax,%edi
    printf(1, "fork failed\n");
    exit();
  }

  unsigned int x = (pid ? 1 : 97);
    1847:	74 20                	je     1869 <linkunlink+0x51>
    1849:	bb 01 00 00 00       	mov    $0x1,%ebx
    184e:	be 00 00 00 00       	mov    $0x0,%esi
    1853:	eb 39                	jmp    188e <linkunlink+0x76>
    printf(1, "fork failed\n");
    1855:	83 ec 08             	sub    $0x8,%esp
    1858:	68 b9 49 00 00       	push   $0x49b9
    185d:	6a 01                	push   $0x1
    185f:	e8 6e 1f 00 00       	call   37d2 <printf>
    exit();
    1864:	e8 26 1e 00 00       	call   368f <exit>
  unsigned int x = (pid ? 1 : 97);
    1869:	bb 61 00 00 00       	mov    $0x61,%ebx
    186e:	eb de                	jmp    184e <linkunlink+0x36>
  for(i = 0; i < 100; i++){
    x = x * 1103515245 + 12345;
    if((x % 3) == 0){
      close(open("x", O_RDWR | O_CREATE));
    1870:	83 ec 08             	sub    $0x8,%esp
    1873:	68 02 02 00 00       	push   $0x202
    1878:	68 d1 43 00 00       	push   $0x43d1
    187d:	e8 4d 1e 00 00       	call   36cf <open>
    1882:	89 04 24             	mov    %eax,(%esp)
    1885:	e8 2d 1e 00 00       	call   36b7 <close>
    188a:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < 100; i++){
    188d:	46                   	inc    %esi
    188e:	83 fe 63             	cmp    $0x63,%esi
    1891:	7f 68                	jg     18fb <linkunlink+0xe3>
    x = x * 1103515245 + 12345;
    1893:	89 d8                	mov    %ebx,%eax
    1895:	c1 e0 09             	shl    $0x9,%eax
    1898:	29 d8                	sub    %ebx,%eax
    189a:	8d 14 83             	lea    (%ebx,%eax,4),%edx
    189d:	89 d0                	mov    %edx,%eax
    189f:	c1 e0 09             	shl    $0x9,%eax
    18a2:	29 d0                	sub    %edx,%eax
    18a4:	01 c0                	add    %eax,%eax
    18a6:	01 d8                	add    %ebx,%eax
    18a8:	89 c2                	mov    %eax,%edx
    18aa:	c1 e2 05             	shl    $0x5,%edx
    18ad:	01 d0                	add    %edx,%eax
    18af:	c1 e0 02             	shl    $0x2,%eax
    18b2:	29 d8                	sub    %ebx,%eax
    18b4:	8d 9c 83 39 30 00 00 	lea    0x3039(%ebx,%eax,4),%ebx
    if((x % 3) == 0){
    18bb:	b9 03 00 00 00       	mov    $0x3,%ecx
    18c0:	89 d8                	mov    %ebx,%eax
    18c2:	ba 00 00 00 00       	mov    $0x0,%edx
    18c7:	f7 f1                	div    %ecx
    18c9:	85 d2                	test   %edx,%edx
    18cb:	74 a3                	je     1870 <linkunlink+0x58>
    } else if((x % 3) == 1){
    18cd:	83 fa 01             	cmp    $0x1,%edx
    18d0:	74 12                	je     18e4 <linkunlink+0xcc>
      link("cat", "x");
    } else {
      unlink("x");
    18d2:	83 ec 0c             	sub    $0xc,%esp
    18d5:	68 d1 43 00 00       	push   $0x43d1
    18da:	e8 00 1e 00 00       	call   36df <unlink>
    18df:	83 c4 10             	add    $0x10,%esp
    18e2:	eb a9                	jmp    188d <linkunlink+0x75>
      link("cat", "x");
    18e4:	83 ec 08             	sub    $0x8,%esp
    18e7:	68 d1 43 00 00       	push   $0x43d1
    18ec:	68 55 41 00 00       	push   $0x4155
    18f1:	e8 f9 1d 00 00       	call   36ef <link>
    18f6:	83 c4 10             	add    $0x10,%esp
    18f9:	eb 92                	jmp    188d <linkunlink+0x75>
    }
  }

  if(pid)
    18fb:	85 ff                	test   %edi,%edi
    18fd:	74 1c                	je     191b <linkunlink+0x103>
    wait();
    18ff:	e8 93 1d 00 00       	call   3697 <wait>
  else
    exit();

  printf(1, "linkunlink ok\n");
    1904:	83 ec 08             	sub    $0x8,%esp
    1907:	68 59 41 00 00       	push   $0x4159
    190c:	6a 01                	push   $0x1
    190e:	e8 bf 1e 00 00       	call   37d2 <printf>
}
    1913:	8d 65 f4             	lea    -0xc(%ebp),%esp
    1916:	5b                   	pop    %ebx
    1917:	5e                   	pop    %esi
    1918:	5f                   	pop    %edi
    1919:	5d                   	pop    %ebp
    191a:	c3                   	ret    
    exit();
    191b:	e8 6f 1d 00 00       	call   368f <exit>

00001920 <bigdir>:

// directory that uses indirect blocks
void
bigdir(void)
{
    1920:	55                   	push   %ebp
    1921:	89 e5                	mov    %esp,%ebp
    1923:	53                   	push   %ebx
    1924:	83 ec 1c             	sub    $0x1c,%esp
  int i, fd;
  char name[10];

  printf(1, "bigdir test\n");
    1927:	68 68 41 00 00       	push   $0x4168
    192c:	6a 01                	push   $0x1
    192e:	e8 9f 1e 00 00       	call   37d2 <printf>
  unlink("bd");
    1933:	c7 04 24 75 41 00 00 	movl   $0x4175,(%esp)
    193a:	e8 a0 1d 00 00       	call   36df <unlink>

  fd = open("bd", O_CREATE);
    193f:	83 c4 08             	add    $0x8,%esp
    1942:	68 00 02 00 00       	push   $0x200
    1947:	68 75 41 00 00       	push   $0x4175
    194c:	e8 7e 1d 00 00       	call   36cf <open>
  if(fd < 0){
    1951:	83 c4 10             	add    $0x10,%esp
    1954:	85 c0                	test   %eax,%eax
    1956:	78 13                	js     196b <bigdir+0x4b>
    printf(1, "bigdir create failed\n");
    exit();
  }
  close(fd);
    1958:	83 ec 0c             	sub    $0xc,%esp
    195b:	50                   	push   %eax
    195c:	e8 56 1d 00 00       	call   36b7 <close>

  for(i = 0; i < 500; i++){
    1961:	83 c4 10             	add    $0x10,%esp
    1964:	bb 00 00 00 00       	mov    $0x0,%ebx
    1969:	eb 3c                	jmp    19a7 <bigdir+0x87>
    printf(1, "bigdir create failed\n");
    196b:	83 ec 08             	sub    $0x8,%esp
    196e:	68 78 41 00 00       	push   $0x4178
    1973:	6a 01                	push   $0x1
    1975:	e8 58 1e 00 00       	call   37d2 <printf>
    exit();
    197a:	e8 10 1d 00 00       	call   368f <exit>
    name[0] = 'x';
    name[1] = '0' + (i / 64);
    197f:	8d 43 3f             	lea    0x3f(%ebx),%eax
    1982:	eb 35                	jmp    19b9 <bigdir+0x99>
    name[2] = '0' + (i % 64);
    1984:	83 c0 30             	add    $0x30,%eax
    1987:	88 45 f0             	mov    %al,-0x10(%ebp)
    name[3] = '\0';
    198a:	c6 45 f1 00          	movb   $0x0,-0xf(%ebp)
    if(link("bd", name) != 0){
    198e:	83 ec 08             	sub    $0x8,%esp
    1991:	8d 45 ee             	lea    -0x12(%ebp),%eax
    1994:	50                   	push   %eax
    1995:	68 75 41 00 00       	push   $0x4175
    199a:	e8 50 1d 00 00       	call   36ef <link>
    199f:	83 c4 10             	add    $0x10,%esp
    19a2:	85 c0                	test   %eax,%eax
    19a4:	75 2c                	jne    19d2 <bigdir+0xb2>
  for(i = 0; i < 500; i++){
    19a6:	43                   	inc    %ebx
    19a7:	81 fb f3 01 00 00    	cmp    $0x1f3,%ebx
    19ad:	7f 37                	jg     19e6 <bigdir+0xc6>
    name[0] = 'x';
    19af:	c6 45 ee 78          	movb   $0x78,-0x12(%ebp)
    name[1] = '0' + (i / 64);
    19b3:	89 d8                	mov    %ebx,%eax
    19b5:	85 db                	test   %ebx,%ebx
    19b7:	78 c6                	js     197f <bigdir+0x5f>
    19b9:	c1 f8 06             	sar    $0x6,%eax
    19bc:	83 c0 30             	add    $0x30,%eax
    19bf:	88 45 ef             	mov    %al,-0x11(%ebp)
    name[2] = '0' + (i % 64);
    19c2:	89 d8                	mov    %ebx,%eax
    19c4:	25 3f 00 00 80       	and    $0x8000003f,%eax
    19c9:	79 b9                	jns    1984 <bigdir+0x64>
    19cb:	48                   	dec    %eax
    19cc:	83 c8 c0             	or     $0xffffffc0,%eax
    19cf:	40                   	inc    %eax
    19d0:	eb b2                	jmp    1984 <bigdir+0x64>
      printf(1, "bigdir link failed\n");
    19d2:	83 ec 08             	sub    $0x8,%esp
    19d5:	68 8e 41 00 00       	push   $0x418e
    19da:	6a 01                	push   $0x1
    19dc:	e8 f1 1d 00 00       	call   37d2 <printf>
      exit();
    19e1:	e8 a9 1c 00 00       	call   368f <exit>
    }
  }

  unlink("bd");
    19e6:	83 ec 0c             	sub    $0xc,%esp
    19e9:	68 75 41 00 00       	push   $0x4175
    19ee:	e8 ec 1c 00 00       	call   36df <unlink>
  for(i = 0; i < 500; i++){
    19f3:	83 c4 10             	add    $0x10,%esp
    19f6:	bb 00 00 00 00       	mov    $0x0,%ebx
    19fb:	eb 23                	jmp    1a20 <bigdir+0x100>
    name[0] = 'x';
    name[1] = '0' + (i / 64);
    19fd:	8d 43 3f             	lea    0x3f(%ebx),%eax
    1a00:	eb 30                	jmp    1a32 <bigdir+0x112>
    name[2] = '0' + (i % 64);
    1a02:	83 c0 30             	add    $0x30,%eax
    1a05:	88 45 f0             	mov    %al,-0x10(%ebp)
    name[3] = '\0';
    1a08:	c6 45 f1 00          	movb   $0x0,-0xf(%ebp)
    if(unlink(name) != 0){
    1a0c:	83 ec 0c             	sub    $0xc,%esp
    1a0f:	8d 45 ee             	lea    -0x12(%ebp),%eax
    1a12:	50                   	push   %eax
    1a13:	e8 c7 1c 00 00       	call   36df <unlink>
    1a18:	83 c4 10             	add    $0x10,%esp
    1a1b:	85 c0                	test   %eax,%eax
    1a1d:	75 2c                	jne    1a4b <bigdir+0x12b>
  for(i = 0; i < 500; i++){
    1a1f:	43                   	inc    %ebx
    1a20:	81 fb f3 01 00 00    	cmp    $0x1f3,%ebx
    1a26:	7f 37                	jg     1a5f <bigdir+0x13f>
    name[0] = 'x';
    1a28:	c6 45 ee 78          	movb   $0x78,-0x12(%ebp)
    name[1] = '0' + (i / 64);
    1a2c:	89 d8                	mov    %ebx,%eax
    1a2e:	85 db                	test   %ebx,%ebx
    1a30:	78 cb                	js     19fd <bigdir+0xdd>
    1a32:	c1 f8 06             	sar    $0x6,%eax
    1a35:	83 c0 30             	add    $0x30,%eax
    1a38:	88 45 ef             	mov    %al,-0x11(%ebp)
    name[2] = '0' + (i % 64);
    1a3b:	89 d8                	mov    %ebx,%eax
    1a3d:	25 3f 00 00 80       	and    $0x8000003f,%eax
    1a42:	79 be                	jns    1a02 <bigdir+0xe2>
    1a44:	48                   	dec    %eax
    1a45:	83 c8 c0             	or     $0xffffffc0,%eax
    1a48:	40                   	inc    %eax
    1a49:	eb b7                	jmp    1a02 <bigdir+0xe2>
      printf(1, "bigdir unlink failed");
    1a4b:	83 ec 08             	sub    $0x8,%esp
    1a4e:	68 a2 41 00 00       	push   $0x41a2
    1a53:	6a 01                	push   $0x1
    1a55:	e8 78 1d 00 00       	call   37d2 <printf>
      exit();
    1a5a:	e8 30 1c 00 00       	call   368f <exit>
    }
  }

  printf(1, "bigdir ok\n");
    1a5f:	83 ec 08             	sub    $0x8,%esp
    1a62:	68 b7 41 00 00       	push   $0x41b7
    1a67:	6a 01                	push   $0x1
    1a69:	e8 64 1d 00 00       	call   37d2 <printf>
}
    1a6e:	83 c4 10             	add    $0x10,%esp
    1a71:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    1a74:	c9                   	leave  
    1a75:	c3                   	ret    

00001a76 <subdir>:

void
subdir(void)
{
    1a76:	55                   	push   %ebp
    1a77:	89 e5                	mov    %esp,%ebp
    1a79:	53                   	push   %ebx
    1a7a:	83 ec 0c             	sub    $0xc,%esp
  int fd, cc;

  printf(1, "subdir test\n");
    1a7d:	68 c2 41 00 00       	push   $0x41c2
    1a82:	6a 01                	push   $0x1
    1a84:	e8 49 1d 00 00       	call   37d2 <printf>

  unlink("ff");
    1a89:	c7 04 24 4b 42 00 00 	movl   $0x424b,(%esp)
    1a90:	e8 4a 1c 00 00       	call   36df <unlink>
  if(mkdir("dd") != 0){
    1a95:	c7 04 24 e8 42 00 00 	movl   $0x42e8,(%esp)
    1a9c:	e8 56 1c 00 00       	call   36f7 <mkdir>
    1aa1:	83 c4 10             	add    $0x10,%esp
    1aa4:	85 c0                	test   %eax,%eax
    1aa6:	0f 85 14 04 00 00    	jne    1ec0 <subdir+0x44a>
    printf(1, "subdir mkdir dd failed\n");
    exit();
  }

  fd = open("dd/ff", O_CREATE | O_RDWR);
    1aac:	83 ec 08             	sub    $0x8,%esp
    1aaf:	68 02 02 00 00       	push   $0x202
    1ab4:	68 21 42 00 00       	push   $0x4221
    1ab9:	e8 11 1c 00 00       	call   36cf <open>
    1abe:	89 c3                	mov    %eax,%ebx
  if(fd < 0){
    1ac0:	83 c4 10             	add    $0x10,%esp
    1ac3:	85 c0                	test   %eax,%eax
    1ac5:	0f 88 09 04 00 00    	js     1ed4 <subdir+0x45e>
    printf(1, "create dd/ff failed\n");
    exit();
  }
  write(fd, "ff", 2);
    1acb:	83 ec 04             	sub    $0x4,%esp
    1ace:	6a 02                	push   $0x2
    1ad0:	68 4b 42 00 00       	push   $0x424b
    1ad5:	50                   	push   %eax
    1ad6:	e8 d4 1b 00 00       	call   36af <write>
  close(fd);
    1adb:	89 1c 24             	mov    %ebx,(%esp)
    1ade:	e8 d4 1b 00 00       	call   36b7 <close>

  if(unlink("dd") >= 0){
    1ae3:	c7 04 24 e8 42 00 00 	movl   $0x42e8,(%esp)
    1aea:	e8 f0 1b 00 00       	call   36df <unlink>
    1aef:	83 c4 10             	add    $0x10,%esp
    1af2:	85 c0                	test   %eax,%eax
    1af4:	0f 89 ee 03 00 00    	jns    1ee8 <subdir+0x472>
    printf(1, "unlink dd (non-empty dir) succeeded!\n");
    exit();
  }

  if(mkdir("/dd/dd") != 0){
    1afa:	83 ec 0c             	sub    $0xc,%esp
    1afd:	68 fc 41 00 00       	push   $0x41fc
    1b02:	e8 f0 1b 00 00       	call   36f7 <mkdir>
    1b07:	83 c4 10             	add    $0x10,%esp
    1b0a:	85 c0                	test   %eax,%eax
    1b0c:	0f 85 ea 03 00 00    	jne    1efc <subdir+0x486>
    printf(1, "subdir mkdir dd/dd failed\n");
    exit();
  }

  fd = open("dd/dd/ff", O_CREATE | O_RDWR);
    1b12:	83 ec 08             	sub    $0x8,%esp
    1b15:	68 02 02 00 00       	push   $0x202
    1b1a:	68 1e 42 00 00       	push   $0x421e
    1b1f:	e8 ab 1b 00 00       	call   36cf <open>
    1b24:	89 c3                	mov    %eax,%ebx
  if(fd < 0){
    1b26:	83 c4 10             	add    $0x10,%esp
    1b29:	85 c0                	test   %eax,%eax
    1b2b:	0f 88 df 03 00 00    	js     1f10 <subdir+0x49a>
    printf(1, "create dd/dd/ff failed\n");
    exit();
  }
  write(fd, "FF", 2);
    1b31:	83 ec 04             	sub    $0x4,%esp
    1b34:	6a 02                	push   $0x2
    1b36:	68 3f 42 00 00       	push   $0x423f
    1b3b:	50                   	push   %eax
    1b3c:	e8 6e 1b 00 00       	call   36af <write>
  close(fd);
    1b41:	89 1c 24             	mov    %ebx,(%esp)
    1b44:	e8 6e 1b 00 00       	call   36b7 <close>

  fd = open("dd/dd/../ff", 0);
    1b49:	83 c4 08             	add    $0x8,%esp
    1b4c:	6a 00                	push   $0x0
    1b4e:	68 42 42 00 00       	push   $0x4242
    1b53:	e8 77 1b 00 00       	call   36cf <open>
    1b58:	89 c3                	mov    %eax,%ebx
  if(fd < 0){
    1b5a:	83 c4 10             	add    $0x10,%esp
    1b5d:	85 c0                	test   %eax,%eax
    1b5f:	0f 88 bf 03 00 00    	js     1f24 <subdir+0x4ae>
    printf(1, "open dd/dd/../ff failed\n");
    exit();
  }
  cc = read(fd, buf, sizeof(buf));
    1b65:	83 ec 04             	sub    $0x4,%esp
    1b68:	68 00 20 00 00       	push   $0x2000
    1b6d:	68 60 82 00 00       	push   $0x8260
    1b72:	50                   	push   %eax
    1b73:	e8 2f 1b 00 00       	call   36a7 <read>
  if(cc != 2 || buf[0] != 'f'){
    1b78:	83 c4 10             	add    $0x10,%esp
    1b7b:	83 f8 02             	cmp    $0x2,%eax
    1b7e:	0f 85 b4 03 00 00    	jne    1f38 <subdir+0x4c2>
    1b84:	80 3d 60 82 00 00 66 	cmpb   $0x66,0x8260
    1b8b:	0f 85 a7 03 00 00    	jne    1f38 <subdir+0x4c2>
    printf(1, "dd/dd/../ff wrong content\n");
    exit();
  }
  close(fd);
    1b91:	83 ec 0c             	sub    $0xc,%esp
    1b94:	53                   	push   %ebx
    1b95:	e8 1d 1b 00 00       	call   36b7 <close>

  if(link("dd/dd/ff", "dd/dd/ffff") != 0){
    1b9a:	83 c4 08             	add    $0x8,%esp
    1b9d:	68 82 42 00 00       	push   $0x4282
    1ba2:	68 1e 42 00 00       	push   $0x421e
    1ba7:	e8 43 1b 00 00       	call   36ef <link>
    1bac:	83 c4 10             	add    $0x10,%esp
    1baf:	85 c0                	test   %eax,%eax
    1bb1:	0f 85 95 03 00 00    	jne    1f4c <subdir+0x4d6>
    printf(1, "link dd/dd/ff dd/dd/ffff failed\n");
    exit();
  }

  if(unlink("dd/dd/ff") != 0){
    1bb7:	83 ec 0c             	sub    $0xc,%esp
    1bba:	68 1e 42 00 00       	push   $0x421e
    1bbf:	e8 1b 1b 00 00       	call   36df <unlink>
    1bc4:	83 c4 10             	add    $0x10,%esp
    1bc7:	85 c0                	test   %eax,%eax
    1bc9:	0f 85 91 03 00 00    	jne    1f60 <subdir+0x4ea>
    printf(1, "unlink dd/dd/ff failed\n");
    exit();
  }
  if(open("dd/dd/ff", O_RDONLY) >= 0){
    1bcf:	83 ec 08             	sub    $0x8,%esp
    1bd2:	6a 00                	push   $0x0
    1bd4:	68 1e 42 00 00       	push   $0x421e
    1bd9:	e8 f1 1a 00 00       	call   36cf <open>
    1bde:	83 c4 10             	add    $0x10,%esp
    1be1:	85 c0                	test   %eax,%eax
    1be3:	0f 89 8b 03 00 00    	jns    1f74 <subdir+0x4fe>
    printf(1, "open (unlinked) dd/dd/ff succeeded\n");
    exit();
  }

  if(chdir("dd") != 0){
    1be9:	83 ec 0c             	sub    $0xc,%esp
    1bec:	68 e8 42 00 00       	push   $0x42e8
    1bf1:	e8 09 1b 00 00       	call   36ff <chdir>
    1bf6:	83 c4 10             	add    $0x10,%esp
    1bf9:	85 c0                	test   %eax,%eax
    1bfb:	0f 85 87 03 00 00    	jne    1f88 <subdir+0x512>
    printf(1, "chdir dd failed\n");
    exit();
  }
  if(chdir("dd/../../dd") != 0){
    1c01:	83 ec 0c             	sub    $0xc,%esp
    1c04:	68 b6 42 00 00       	push   $0x42b6
    1c09:	e8 f1 1a 00 00       	call   36ff <chdir>
    1c0e:	83 c4 10             	add    $0x10,%esp
    1c11:	85 c0                	test   %eax,%eax
    1c13:	0f 85 83 03 00 00    	jne    1f9c <subdir+0x526>
    printf(1, "chdir dd/../../dd failed\n");
    exit();
  }
  if(chdir("dd/../../../dd") != 0){
    1c19:	83 ec 0c             	sub    $0xc,%esp
    1c1c:	68 dc 42 00 00       	push   $0x42dc
    1c21:	e8 d9 1a 00 00       	call   36ff <chdir>
    1c26:	83 c4 10             	add    $0x10,%esp
    1c29:	85 c0                	test   %eax,%eax
    1c2b:	0f 85 7f 03 00 00    	jne    1fb0 <subdir+0x53a>
    printf(1, "chdir dd/../../dd failed\n");
    exit();
  }
  if(chdir("./..") != 0){
    1c31:	83 ec 0c             	sub    $0xc,%esp
    1c34:	68 eb 42 00 00       	push   $0x42eb
    1c39:	e8 c1 1a 00 00       	call   36ff <chdir>
    1c3e:	83 c4 10             	add    $0x10,%esp
    1c41:	85 c0                	test   %eax,%eax
    1c43:	0f 85 7b 03 00 00    	jne    1fc4 <subdir+0x54e>
    printf(1, "chdir ./.. failed\n");
    exit();
  }

  fd = open("dd/dd/ffff", 0);
    1c49:	83 ec 08             	sub    $0x8,%esp
    1c4c:	6a 00                	push   $0x0
    1c4e:	68 82 42 00 00       	push   $0x4282
    1c53:	e8 77 1a 00 00       	call   36cf <open>
    1c58:	89 c3                	mov    %eax,%ebx
  if(fd < 0){
    1c5a:	83 c4 10             	add    $0x10,%esp
    1c5d:	85 c0                	test   %eax,%eax
    1c5f:	0f 88 73 03 00 00    	js     1fd8 <subdir+0x562>
    printf(1, "open dd/dd/ffff failed\n");
    exit();
  }
  if(read(fd, buf, sizeof(buf)) != 2){
    1c65:	83 ec 04             	sub    $0x4,%esp
    1c68:	68 00 20 00 00       	push   $0x2000
    1c6d:	68 60 82 00 00       	push   $0x8260
    1c72:	50                   	push   %eax
    1c73:	e8 2f 1a 00 00       	call   36a7 <read>
    1c78:	83 c4 10             	add    $0x10,%esp
    1c7b:	83 f8 02             	cmp    $0x2,%eax
    1c7e:	0f 85 68 03 00 00    	jne    1fec <subdir+0x576>
    printf(1, "read dd/dd/ffff wrong len\n");
    exit();
  }
  close(fd);
    1c84:	83 ec 0c             	sub    $0xc,%esp
    1c87:	53                   	push   %ebx
    1c88:	e8 2a 1a 00 00       	call   36b7 <close>

  if(open("dd/dd/ff", O_RDONLY) >= 0){
    1c8d:	83 c4 08             	add    $0x8,%esp
    1c90:	6a 00                	push   $0x0
    1c92:	68 1e 42 00 00       	push   $0x421e
    1c97:	e8 33 1a 00 00       	call   36cf <open>
    1c9c:	83 c4 10             	add    $0x10,%esp
    1c9f:	85 c0                	test   %eax,%eax
    1ca1:	0f 89 59 03 00 00    	jns    2000 <subdir+0x58a>
    printf(1, "open (unlinked) dd/dd/ff succeeded!\n");
    exit();
  }

  if(open("dd/ff/ff", O_CREATE|O_RDWR) >= 0){
    1ca7:	83 ec 08             	sub    $0x8,%esp
    1caa:	68 02 02 00 00       	push   $0x202
    1caf:	68 36 43 00 00       	push   $0x4336
    1cb4:	e8 16 1a 00 00       	call   36cf <open>
    1cb9:	83 c4 10             	add    $0x10,%esp
    1cbc:	85 c0                	test   %eax,%eax
    1cbe:	0f 89 50 03 00 00    	jns    2014 <subdir+0x59e>
    printf(1, "create dd/ff/ff succeeded!\n");
    exit();
  }
  if(open("dd/xx/ff", O_CREATE|O_RDWR) >= 0){
    1cc4:	83 ec 08             	sub    $0x8,%esp
    1cc7:	68 02 02 00 00       	push   $0x202
    1ccc:	68 5b 43 00 00       	push   $0x435b
    1cd1:	e8 f9 19 00 00       	call   36cf <open>
    1cd6:	83 c4 10             	add    $0x10,%esp
    1cd9:	85 c0                	test   %eax,%eax
    1cdb:	0f 89 47 03 00 00    	jns    2028 <subdir+0x5b2>
    printf(1, "create dd/xx/ff succeeded!\n");
    exit();
  }
  if(open("dd", O_CREATE) >= 0){
    1ce1:	83 ec 08             	sub    $0x8,%esp
    1ce4:	68 00 02 00 00       	push   $0x200
    1ce9:	68 e8 42 00 00       	push   $0x42e8
    1cee:	e8 dc 19 00 00       	call   36cf <open>
    1cf3:	83 c4 10             	add    $0x10,%esp
    1cf6:	85 c0                	test   %eax,%eax
    1cf8:	0f 89 3e 03 00 00    	jns    203c <subdir+0x5c6>
    printf(1, "create dd succeeded!\n");
    exit();
  }
  if(open("dd", O_RDWR) >= 0){
    1cfe:	83 ec 08             	sub    $0x8,%esp
    1d01:	6a 02                	push   $0x2
    1d03:	68 e8 42 00 00       	push   $0x42e8
    1d08:	e8 c2 19 00 00       	call   36cf <open>
    1d0d:	83 c4 10             	add    $0x10,%esp
    1d10:	85 c0                	test   %eax,%eax
    1d12:	0f 89 38 03 00 00    	jns    2050 <subdir+0x5da>
    printf(1, "open dd rdwr succeeded!\n");
    exit();
  }
  if(open("dd", O_WRONLY) >= 0){
    1d18:	83 ec 08             	sub    $0x8,%esp
    1d1b:	6a 01                	push   $0x1
    1d1d:	68 e8 42 00 00       	push   $0x42e8
    1d22:	e8 a8 19 00 00       	call   36cf <open>
    1d27:	83 c4 10             	add    $0x10,%esp
    1d2a:	85 c0                	test   %eax,%eax
    1d2c:	0f 89 32 03 00 00    	jns    2064 <subdir+0x5ee>
    printf(1, "open dd wronly succeeded!\n");
    exit();
  }
  if(link("dd/ff/ff", "dd/dd/xx") == 0){
    1d32:	83 ec 08             	sub    $0x8,%esp
    1d35:	68 ca 43 00 00       	push   $0x43ca
    1d3a:	68 36 43 00 00       	push   $0x4336
    1d3f:	e8 ab 19 00 00       	call   36ef <link>
    1d44:	83 c4 10             	add    $0x10,%esp
    1d47:	85 c0                	test   %eax,%eax
    1d49:	0f 84 29 03 00 00    	je     2078 <subdir+0x602>
    printf(1, "link dd/ff/ff dd/dd/xx succeeded!\n");
    exit();
  }
  if(link("dd/xx/ff", "dd/dd/xx") == 0){
    1d4f:	83 ec 08             	sub    $0x8,%esp
    1d52:	68 ca 43 00 00       	push   $0x43ca
    1d57:	68 5b 43 00 00       	push   $0x435b
    1d5c:	e8 8e 19 00 00       	call   36ef <link>
    1d61:	83 c4 10             	add    $0x10,%esp
    1d64:	85 c0                	test   %eax,%eax
    1d66:	0f 84 20 03 00 00    	je     208c <subdir+0x616>
    printf(1, "link dd/xx/ff dd/dd/xx succeeded!\n");
    exit();
  }
  if(link("dd/ff", "dd/dd/ffff") == 0){
    1d6c:	83 ec 08             	sub    $0x8,%esp
    1d6f:	68 82 42 00 00       	push   $0x4282
    1d74:	68 21 42 00 00       	push   $0x4221
    1d79:	e8 71 19 00 00       	call   36ef <link>
    1d7e:	83 c4 10             	add    $0x10,%esp
    1d81:	85 c0                	test   %eax,%eax
    1d83:	0f 84 17 03 00 00    	je     20a0 <subdir+0x62a>
    printf(1, "link dd/ff dd/dd/ffff succeeded!\n");
    exit();
  }
  if(mkdir("dd/ff/ff") == 0){
    1d89:	83 ec 0c             	sub    $0xc,%esp
    1d8c:	68 36 43 00 00       	push   $0x4336
    1d91:	e8 61 19 00 00       	call   36f7 <mkdir>
    1d96:	83 c4 10             	add    $0x10,%esp
    1d99:	85 c0                	test   %eax,%eax
    1d9b:	0f 84 13 03 00 00    	je     20b4 <subdir+0x63e>
    printf(1, "mkdir dd/ff/ff succeeded!\n");
    exit();
  }
  if(mkdir("dd/xx/ff") == 0){
    1da1:	83 ec 0c             	sub    $0xc,%esp
    1da4:	68 5b 43 00 00       	push   $0x435b
    1da9:	e8 49 19 00 00       	call   36f7 <mkdir>
    1dae:	83 c4 10             	add    $0x10,%esp
    1db1:	85 c0                	test   %eax,%eax
    1db3:	0f 84 0f 03 00 00    	je     20c8 <subdir+0x652>
    printf(1, "mkdir dd/xx/ff succeeded!\n");
    exit();
  }
  if(mkdir("dd/dd/ffff") == 0){
    1db9:	83 ec 0c             	sub    $0xc,%esp
    1dbc:	68 82 42 00 00       	push   $0x4282
    1dc1:	e8 31 19 00 00       	call   36f7 <mkdir>
    1dc6:	83 c4 10             	add    $0x10,%esp
    1dc9:	85 c0                	test   %eax,%eax
    1dcb:	0f 84 0b 03 00 00    	je     20dc <subdir+0x666>
    printf(1, "mkdir dd/dd/ffff succeeded!\n");
    exit();
  }
  if(unlink("dd/xx/ff") == 0){
    1dd1:	83 ec 0c             	sub    $0xc,%esp
    1dd4:	68 5b 43 00 00       	push   $0x435b
    1dd9:	e8 01 19 00 00       	call   36df <unlink>
    1dde:	83 c4 10             	add    $0x10,%esp
    1de1:	85 c0                	test   %eax,%eax
    1de3:	0f 84 07 03 00 00    	je     20f0 <subdir+0x67a>
    printf(1, "unlink dd/xx/ff succeeded!\n");
    exit();
  }
  if(unlink("dd/ff/ff") == 0){
    1de9:	83 ec 0c             	sub    $0xc,%esp
    1dec:	68 36 43 00 00       	push   $0x4336
    1df1:	e8 e9 18 00 00       	call   36df <unlink>
    1df6:	83 c4 10             	add    $0x10,%esp
    1df9:	85 c0                	test   %eax,%eax
    1dfb:	0f 84 03 03 00 00    	je     2104 <subdir+0x68e>
    printf(1, "unlink dd/ff/ff succeeded!\n");
    exit();
  }
  if(chdir("dd/ff") == 0){
    1e01:	83 ec 0c             	sub    $0xc,%esp
    1e04:	68 21 42 00 00       	push   $0x4221
    1e09:	e8 f1 18 00 00       	call   36ff <chdir>
    1e0e:	83 c4 10             	add    $0x10,%esp
    1e11:	85 c0                	test   %eax,%eax
    1e13:	0f 84 ff 02 00 00    	je     2118 <subdir+0x6a2>
    printf(1, "chdir dd/ff succeeded!\n");
    exit();
  }
  if(chdir("dd/xx") == 0){
    1e19:	83 ec 0c             	sub    $0xc,%esp
    1e1c:	68 cd 43 00 00       	push   $0x43cd
    1e21:	e8 d9 18 00 00       	call   36ff <chdir>
    1e26:	83 c4 10             	add    $0x10,%esp
    1e29:	85 c0                	test   %eax,%eax
    1e2b:	0f 84 fb 02 00 00    	je     212c <subdir+0x6b6>
    printf(1, "chdir dd/xx succeeded!\n");
    exit();
  }

  if(unlink("dd/dd/ffff") != 0){
    1e31:	83 ec 0c             	sub    $0xc,%esp
    1e34:	68 82 42 00 00       	push   $0x4282
    1e39:	e8 a1 18 00 00       	call   36df <unlink>
    1e3e:	83 c4 10             	add    $0x10,%esp
    1e41:	85 c0                	test   %eax,%eax
    1e43:	0f 85 f7 02 00 00    	jne    2140 <subdir+0x6ca>
    printf(1, "unlink dd/dd/ff failed\n");
    exit();
  }
  if(unlink("dd/ff") != 0){
    1e49:	83 ec 0c             	sub    $0xc,%esp
    1e4c:	68 21 42 00 00       	push   $0x4221
    1e51:	e8 89 18 00 00       	call   36df <unlink>
    1e56:	83 c4 10             	add    $0x10,%esp
    1e59:	85 c0                	test   %eax,%eax
    1e5b:	0f 85 f3 02 00 00    	jne    2154 <subdir+0x6de>
    printf(1, "unlink dd/ff failed\n");
    exit();
  }
  if(unlink("dd") == 0){
    1e61:	83 ec 0c             	sub    $0xc,%esp
    1e64:	68 e8 42 00 00       	push   $0x42e8
    1e69:	e8 71 18 00 00       	call   36df <unlink>
    1e6e:	83 c4 10             	add    $0x10,%esp
    1e71:	85 c0                	test   %eax,%eax
    1e73:	0f 84 ef 02 00 00    	je     2168 <subdir+0x6f2>
    printf(1, "unlink non-empty dd succeeded!\n");
    exit();
  }
  if(unlink("dd/dd") < 0){
    1e79:	83 ec 0c             	sub    $0xc,%esp
    1e7c:	68 fd 41 00 00       	push   $0x41fd
    1e81:	e8 59 18 00 00       	call   36df <unlink>
    1e86:	83 c4 10             	add    $0x10,%esp
    1e89:	85 c0                	test   %eax,%eax
    1e8b:	0f 88 eb 02 00 00    	js     217c <subdir+0x706>
    printf(1, "unlink dd/dd failed\n");
    exit();
  }
  if(unlink("dd") < 0){
    1e91:	83 ec 0c             	sub    $0xc,%esp
    1e94:	68 e8 42 00 00       	push   $0x42e8
    1e99:	e8 41 18 00 00       	call   36df <unlink>
    1e9e:	83 c4 10             	add    $0x10,%esp
    1ea1:	85 c0                	test   %eax,%eax
    1ea3:	0f 88 e7 02 00 00    	js     2190 <subdir+0x71a>
    printf(1, "unlink dd failed\n");
    exit();
  }

  printf(1, "subdir ok\n");
    1ea9:	83 ec 08             	sub    $0x8,%esp
    1eac:	68 ca 44 00 00       	push   $0x44ca
    1eb1:	6a 01                	push   $0x1
    1eb3:	e8 1a 19 00 00       	call   37d2 <printf>
}
    1eb8:	83 c4 10             	add    $0x10,%esp
    1ebb:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    1ebe:	c9                   	leave  
    1ebf:	c3                   	ret    
    printf(1, "subdir mkdir dd failed\n");
    1ec0:	83 ec 08             	sub    $0x8,%esp
    1ec3:	68 cf 41 00 00       	push   $0x41cf
    1ec8:	6a 01                	push   $0x1
    1eca:	e8 03 19 00 00       	call   37d2 <printf>
    exit();
    1ecf:	e8 bb 17 00 00       	call   368f <exit>
    printf(1, "create dd/ff failed\n");
    1ed4:	83 ec 08             	sub    $0x8,%esp
    1ed7:	68 e7 41 00 00       	push   $0x41e7
    1edc:	6a 01                	push   $0x1
    1ede:	e8 ef 18 00 00       	call   37d2 <printf>
    exit();
    1ee3:	e8 a7 17 00 00       	call   368f <exit>
    printf(1, "unlink dd (non-empty dir) succeeded!\n");
    1ee8:	83 ec 08             	sub    $0x8,%esp
    1eeb:	68 b4 4c 00 00       	push   $0x4cb4
    1ef0:	6a 01                	push   $0x1
    1ef2:	e8 db 18 00 00       	call   37d2 <printf>
    exit();
    1ef7:	e8 93 17 00 00       	call   368f <exit>
    printf(1, "subdir mkdir dd/dd failed\n");
    1efc:	83 ec 08             	sub    $0x8,%esp
    1eff:	68 03 42 00 00       	push   $0x4203
    1f04:	6a 01                	push   $0x1
    1f06:	e8 c7 18 00 00       	call   37d2 <printf>
    exit();
    1f0b:	e8 7f 17 00 00       	call   368f <exit>
    printf(1, "create dd/dd/ff failed\n");
    1f10:	83 ec 08             	sub    $0x8,%esp
    1f13:	68 27 42 00 00       	push   $0x4227
    1f18:	6a 01                	push   $0x1
    1f1a:	e8 b3 18 00 00       	call   37d2 <printf>
    exit();
    1f1f:	e8 6b 17 00 00       	call   368f <exit>
    printf(1, "open dd/dd/../ff failed\n");
    1f24:	83 ec 08             	sub    $0x8,%esp
    1f27:	68 4e 42 00 00       	push   $0x424e
    1f2c:	6a 01                	push   $0x1
    1f2e:	e8 9f 18 00 00       	call   37d2 <printf>
    exit();
    1f33:	e8 57 17 00 00       	call   368f <exit>
    printf(1, "dd/dd/../ff wrong content\n");
    1f38:	83 ec 08             	sub    $0x8,%esp
    1f3b:	68 67 42 00 00       	push   $0x4267
    1f40:	6a 01                	push   $0x1
    1f42:	e8 8b 18 00 00       	call   37d2 <printf>
    exit();
    1f47:	e8 43 17 00 00       	call   368f <exit>
    printf(1, "link dd/dd/ff dd/dd/ffff failed\n");
    1f4c:	83 ec 08             	sub    $0x8,%esp
    1f4f:	68 dc 4c 00 00       	push   $0x4cdc
    1f54:	6a 01                	push   $0x1
    1f56:	e8 77 18 00 00       	call   37d2 <printf>
    exit();
    1f5b:	e8 2f 17 00 00       	call   368f <exit>
    printf(1, "unlink dd/dd/ff failed\n");
    1f60:	83 ec 08             	sub    $0x8,%esp
    1f63:	68 8d 42 00 00       	push   $0x428d
    1f68:	6a 01                	push   $0x1
    1f6a:	e8 63 18 00 00       	call   37d2 <printf>
    exit();
    1f6f:	e8 1b 17 00 00       	call   368f <exit>
    printf(1, "open (unlinked) dd/dd/ff succeeded\n");
    1f74:	83 ec 08             	sub    $0x8,%esp
    1f77:	68 00 4d 00 00       	push   $0x4d00
    1f7c:	6a 01                	push   $0x1
    1f7e:	e8 4f 18 00 00       	call   37d2 <printf>
    exit();
    1f83:	e8 07 17 00 00       	call   368f <exit>
    printf(1, "chdir dd failed\n");
    1f88:	83 ec 08             	sub    $0x8,%esp
    1f8b:	68 a5 42 00 00       	push   $0x42a5
    1f90:	6a 01                	push   $0x1
    1f92:	e8 3b 18 00 00       	call   37d2 <printf>
    exit();
    1f97:	e8 f3 16 00 00       	call   368f <exit>
    printf(1, "chdir dd/../../dd failed\n");
    1f9c:	83 ec 08             	sub    $0x8,%esp
    1f9f:	68 c2 42 00 00       	push   $0x42c2
    1fa4:	6a 01                	push   $0x1
    1fa6:	e8 27 18 00 00       	call   37d2 <printf>
    exit();
    1fab:	e8 df 16 00 00       	call   368f <exit>
    printf(1, "chdir dd/../../dd failed\n");
    1fb0:	83 ec 08             	sub    $0x8,%esp
    1fb3:	68 c2 42 00 00       	push   $0x42c2
    1fb8:	6a 01                	push   $0x1
    1fba:	e8 13 18 00 00       	call   37d2 <printf>
    exit();
    1fbf:	e8 cb 16 00 00       	call   368f <exit>
    printf(1, "chdir ./.. failed\n");
    1fc4:	83 ec 08             	sub    $0x8,%esp
    1fc7:	68 f0 42 00 00       	push   $0x42f0
    1fcc:	6a 01                	push   $0x1
    1fce:	e8 ff 17 00 00       	call   37d2 <printf>
    exit();
    1fd3:	e8 b7 16 00 00       	call   368f <exit>
    printf(1, "open dd/dd/ffff failed\n");
    1fd8:	83 ec 08             	sub    $0x8,%esp
    1fdb:	68 03 43 00 00       	push   $0x4303
    1fe0:	6a 01                	push   $0x1
    1fe2:	e8 eb 17 00 00       	call   37d2 <printf>
    exit();
    1fe7:	e8 a3 16 00 00       	call   368f <exit>
    printf(1, "read dd/dd/ffff wrong len\n");
    1fec:	83 ec 08             	sub    $0x8,%esp
    1fef:	68 1b 43 00 00       	push   $0x431b
    1ff4:	6a 01                	push   $0x1
    1ff6:	e8 d7 17 00 00       	call   37d2 <printf>
    exit();
    1ffb:	e8 8f 16 00 00       	call   368f <exit>
    printf(1, "open (unlinked) dd/dd/ff succeeded!\n");
    2000:	83 ec 08             	sub    $0x8,%esp
    2003:	68 24 4d 00 00       	push   $0x4d24
    2008:	6a 01                	push   $0x1
    200a:	e8 c3 17 00 00       	call   37d2 <printf>
    exit();
    200f:	e8 7b 16 00 00       	call   368f <exit>
    printf(1, "create dd/ff/ff succeeded!\n");
    2014:	83 ec 08             	sub    $0x8,%esp
    2017:	68 3f 43 00 00       	push   $0x433f
    201c:	6a 01                	push   $0x1
    201e:	e8 af 17 00 00       	call   37d2 <printf>
    exit();
    2023:	e8 67 16 00 00       	call   368f <exit>
    printf(1, "create dd/xx/ff succeeded!\n");
    2028:	83 ec 08             	sub    $0x8,%esp
    202b:	68 64 43 00 00       	push   $0x4364
    2030:	6a 01                	push   $0x1
    2032:	e8 9b 17 00 00       	call   37d2 <printf>
    exit();
    2037:	e8 53 16 00 00       	call   368f <exit>
    printf(1, "create dd succeeded!\n");
    203c:	83 ec 08             	sub    $0x8,%esp
    203f:	68 80 43 00 00       	push   $0x4380
    2044:	6a 01                	push   $0x1
    2046:	e8 87 17 00 00       	call   37d2 <printf>
    exit();
    204b:	e8 3f 16 00 00       	call   368f <exit>
    printf(1, "open dd rdwr succeeded!\n");
    2050:	83 ec 08             	sub    $0x8,%esp
    2053:	68 96 43 00 00       	push   $0x4396
    2058:	6a 01                	push   $0x1
    205a:	e8 73 17 00 00       	call   37d2 <printf>
    exit();
    205f:	e8 2b 16 00 00       	call   368f <exit>
    printf(1, "open dd wronly succeeded!\n");
    2064:	83 ec 08             	sub    $0x8,%esp
    2067:	68 af 43 00 00       	push   $0x43af
    206c:	6a 01                	push   $0x1
    206e:	e8 5f 17 00 00       	call   37d2 <printf>
    exit();
    2073:	e8 17 16 00 00       	call   368f <exit>
    printf(1, "link dd/ff/ff dd/dd/xx succeeded!\n");
    2078:	83 ec 08             	sub    $0x8,%esp
    207b:	68 4c 4d 00 00       	push   $0x4d4c
    2080:	6a 01                	push   $0x1
    2082:	e8 4b 17 00 00       	call   37d2 <printf>
    exit();
    2087:	e8 03 16 00 00       	call   368f <exit>
    printf(1, "link dd/xx/ff dd/dd/xx succeeded!\n");
    208c:	83 ec 08             	sub    $0x8,%esp
    208f:	68 70 4d 00 00       	push   $0x4d70
    2094:	6a 01                	push   $0x1
    2096:	e8 37 17 00 00       	call   37d2 <printf>
    exit();
    209b:	e8 ef 15 00 00       	call   368f <exit>
    printf(1, "link dd/ff dd/dd/ffff succeeded!\n");
    20a0:	83 ec 08             	sub    $0x8,%esp
    20a3:	68 94 4d 00 00       	push   $0x4d94
    20a8:	6a 01                	push   $0x1
    20aa:	e8 23 17 00 00       	call   37d2 <printf>
    exit();
    20af:	e8 db 15 00 00       	call   368f <exit>
    printf(1, "mkdir dd/ff/ff succeeded!\n");
    20b4:	83 ec 08             	sub    $0x8,%esp
    20b7:	68 d3 43 00 00       	push   $0x43d3
    20bc:	6a 01                	push   $0x1
    20be:	e8 0f 17 00 00       	call   37d2 <printf>
    exit();
    20c3:	e8 c7 15 00 00       	call   368f <exit>
    printf(1, "mkdir dd/xx/ff succeeded!\n");
    20c8:	83 ec 08             	sub    $0x8,%esp
    20cb:	68 ee 43 00 00       	push   $0x43ee
    20d0:	6a 01                	push   $0x1
    20d2:	e8 fb 16 00 00       	call   37d2 <printf>
    exit();
    20d7:	e8 b3 15 00 00       	call   368f <exit>
    printf(1, "mkdir dd/dd/ffff succeeded!\n");
    20dc:	83 ec 08             	sub    $0x8,%esp
    20df:	68 09 44 00 00       	push   $0x4409
    20e4:	6a 01                	push   $0x1
    20e6:	e8 e7 16 00 00       	call   37d2 <printf>
    exit();
    20eb:	e8 9f 15 00 00       	call   368f <exit>
    printf(1, "unlink dd/xx/ff succeeded!\n");
    20f0:	83 ec 08             	sub    $0x8,%esp
    20f3:	68 26 44 00 00       	push   $0x4426
    20f8:	6a 01                	push   $0x1
    20fa:	e8 d3 16 00 00       	call   37d2 <printf>
    exit();
    20ff:	e8 8b 15 00 00       	call   368f <exit>
    printf(1, "unlink dd/ff/ff succeeded!\n");
    2104:	83 ec 08             	sub    $0x8,%esp
    2107:	68 42 44 00 00       	push   $0x4442
    210c:	6a 01                	push   $0x1
    210e:	e8 bf 16 00 00       	call   37d2 <printf>
    exit();
    2113:	e8 77 15 00 00       	call   368f <exit>
    printf(1, "chdir dd/ff succeeded!\n");
    2118:	83 ec 08             	sub    $0x8,%esp
    211b:	68 5e 44 00 00       	push   $0x445e
    2120:	6a 01                	push   $0x1
    2122:	e8 ab 16 00 00       	call   37d2 <printf>
    exit();
    2127:	e8 63 15 00 00       	call   368f <exit>
    printf(1, "chdir dd/xx succeeded!\n");
    212c:	83 ec 08             	sub    $0x8,%esp
    212f:	68 76 44 00 00       	push   $0x4476
    2134:	6a 01                	push   $0x1
    2136:	e8 97 16 00 00       	call   37d2 <printf>
    exit();
    213b:	e8 4f 15 00 00       	call   368f <exit>
    printf(1, "unlink dd/dd/ff failed\n");
    2140:	83 ec 08             	sub    $0x8,%esp
    2143:	68 8d 42 00 00       	push   $0x428d
    2148:	6a 01                	push   $0x1
    214a:	e8 83 16 00 00       	call   37d2 <printf>
    exit();
    214f:	e8 3b 15 00 00       	call   368f <exit>
    printf(1, "unlink dd/ff failed\n");
    2154:	83 ec 08             	sub    $0x8,%esp
    2157:	68 8e 44 00 00       	push   $0x448e
    215c:	6a 01                	push   $0x1
    215e:	e8 6f 16 00 00       	call   37d2 <printf>
    exit();
    2163:	e8 27 15 00 00       	call   368f <exit>
    printf(1, "unlink non-empty dd succeeded!\n");
    2168:	83 ec 08             	sub    $0x8,%esp
    216b:	68 b8 4d 00 00       	push   $0x4db8
    2170:	6a 01                	push   $0x1
    2172:	e8 5b 16 00 00       	call   37d2 <printf>
    exit();
    2177:	e8 13 15 00 00       	call   368f <exit>
    printf(1, "unlink dd/dd failed\n");
    217c:	83 ec 08             	sub    $0x8,%esp
    217f:	68 a3 44 00 00       	push   $0x44a3
    2184:	6a 01                	push   $0x1
    2186:	e8 47 16 00 00       	call   37d2 <printf>
    exit();
    218b:	e8 ff 14 00 00       	call   368f <exit>
    printf(1, "unlink dd failed\n");
    2190:	83 ec 08             	sub    $0x8,%esp
    2193:	68 b8 44 00 00       	push   $0x44b8
    2198:	6a 01                	push   $0x1
    219a:	e8 33 16 00 00       	call   37d2 <printf>
    exit();
    219f:	e8 eb 14 00 00       	call   368f <exit>

000021a4 <bigwrite>:

// test writes that are larger than the log.
void
bigwrite(void)
{
    21a4:	55                   	push   %ebp
    21a5:	89 e5                	mov    %esp,%ebp
    21a7:	57                   	push   %edi
    21a8:	56                   	push   %esi
    21a9:	53                   	push   %ebx
    21aa:	83 ec 14             	sub    $0x14,%esp
  int fd, sz;

  printf(1, "bigwrite test\n");
    21ad:	68 d5 44 00 00       	push   $0x44d5
    21b2:	6a 01                	push   $0x1
    21b4:	e8 19 16 00 00       	call   37d2 <printf>

  unlink("bigwrite");
    21b9:	c7 04 24 e4 44 00 00 	movl   $0x44e4,(%esp)
    21c0:	e8 1a 15 00 00       	call   36df <unlink>
  for(sz = 499; sz < 12*512; sz += 471){
    21c5:	83 c4 10             	add    $0x10,%esp
    21c8:	be f3 01 00 00       	mov    $0x1f3,%esi
    21cd:	eb 45                	jmp    2214 <bigwrite+0x70>
    fd = open("bigwrite", O_CREATE | O_RDWR);
    if(fd < 0){
      printf(1, "cannot create bigwrite\n");
    21cf:	83 ec 08             	sub    $0x8,%esp
    21d2:	68 ed 44 00 00       	push   $0x44ed
    21d7:	6a 01                	push   $0x1
    21d9:	e8 f4 15 00 00       	call   37d2 <printf>
      exit();
    21de:	e8 ac 14 00 00       	call   368f <exit>
    }
    int i;
    for(i = 0; i < 2; i++){
      int cc = write(fd, buf, sz);
      if(cc != sz){
        printf(1, "write(%d) ret %d\n", sz, cc);
    21e3:	50                   	push   %eax
    21e4:	56                   	push   %esi
    21e5:	68 05 45 00 00       	push   $0x4505
    21ea:	6a 01                	push   $0x1
    21ec:	e8 e1 15 00 00       	call   37d2 <printf>
        exit();
    21f1:	e8 99 14 00 00       	call   368f <exit>
      }
    }
    close(fd);
    21f6:	83 ec 0c             	sub    $0xc,%esp
    21f9:	57                   	push   %edi
    21fa:	e8 b8 14 00 00       	call   36b7 <close>
    unlink("bigwrite");
    21ff:	c7 04 24 e4 44 00 00 	movl   $0x44e4,(%esp)
    2206:	e8 d4 14 00 00       	call   36df <unlink>
  for(sz = 499; sz < 12*512; sz += 471){
    220b:	81 c6 d7 01 00 00    	add    $0x1d7,%esi
    2211:	83 c4 10             	add    $0x10,%esp
    2214:	81 fe ff 17 00 00    	cmp    $0x17ff,%esi
    221a:	7f 3e                	jg     225a <bigwrite+0xb6>
    fd = open("bigwrite", O_CREATE | O_RDWR);
    221c:	83 ec 08             	sub    $0x8,%esp
    221f:	68 02 02 00 00       	push   $0x202
    2224:	68 e4 44 00 00       	push   $0x44e4
    2229:	e8 a1 14 00 00       	call   36cf <open>
    222e:	89 c7                	mov    %eax,%edi
    if(fd < 0){
    2230:	83 c4 10             	add    $0x10,%esp
    2233:	85 c0                	test   %eax,%eax
    2235:	78 98                	js     21cf <bigwrite+0x2b>
    for(i = 0; i < 2; i++){
    2237:	bb 00 00 00 00       	mov    $0x0,%ebx
    223c:	83 fb 01             	cmp    $0x1,%ebx
    223f:	7f b5                	jg     21f6 <bigwrite+0x52>
      int cc = write(fd, buf, sz);
    2241:	83 ec 04             	sub    $0x4,%esp
    2244:	56                   	push   %esi
    2245:	68 60 82 00 00       	push   $0x8260
    224a:	57                   	push   %edi
    224b:	e8 5f 14 00 00       	call   36af <write>
      if(cc != sz){
    2250:	83 c4 10             	add    $0x10,%esp
    2253:	39 c6                	cmp    %eax,%esi
    2255:	75 8c                	jne    21e3 <bigwrite+0x3f>
    for(i = 0; i < 2; i++){
    2257:	43                   	inc    %ebx
    2258:	eb e2                	jmp    223c <bigwrite+0x98>
  }

  printf(1, "bigwrite ok\n");
    225a:	83 ec 08             	sub    $0x8,%esp
    225d:	68 17 45 00 00       	push   $0x4517
    2262:	6a 01                	push   $0x1
    2264:	e8 69 15 00 00       	call   37d2 <printf>
}
    2269:	83 c4 10             	add    $0x10,%esp
    226c:	8d 65 f4             	lea    -0xc(%ebp),%esp
    226f:	5b                   	pop    %ebx
    2270:	5e                   	pop    %esi
    2271:	5f                   	pop    %edi
    2272:	5d                   	pop    %ebp
    2273:	c3                   	ret    

00002274 <bigfile>:

void
bigfile(void)
{
    2274:	55                   	push   %ebp
    2275:	89 e5                	mov    %esp,%ebp
    2277:	57                   	push   %edi
    2278:	56                   	push   %esi
    2279:	53                   	push   %ebx
    227a:	83 ec 14             	sub    $0x14,%esp
  int fd, i, total, cc;

  printf(1, "bigfile test\n");
    227d:	68 24 45 00 00       	push   $0x4524
    2282:	6a 01                	push   $0x1
    2284:	e8 49 15 00 00       	call   37d2 <printf>

  unlink("bigfile");
    2289:	c7 04 24 40 45 00 00 	movl   $0x4540,(%esp)
    2290:	e8 4a 14 00 00       	call   36df <unlink>
  fd = open("bigfile", O_CREATE | O_RDWR);
    2295:	83 c4 08             	add    $0x8,%esp
    2298:	68 02 02 00 00       	push   $0x202
    229d:	68 40 45 00 00       	push   $0x4540
    22a2:	e8 28 14 00 00       	call   36cf <open>
  if(fd < 0){
    22a7:	83 c4 10             	add    $0x10,%esp
    22aa:	85 c0                	test   %eax,%eax
    22ac:	78 3f                	js     22ed <bigfile+0x79>
    22ae:	89 c6                	mov    %eax,%esi
    printf(1, "cannot create bigfile");
    exit();
  }
  for(i = 0; i < 20; i++){
    22b0:	bb 00 00 00 00       	mov    $0x0,%ebx
    22b5:	83 fb 13             	cmp    $0x13,%ebx
    22b8:	7f 5b                	jg     2315 <bigfile+0xa1>
    memset(buf, i, 600);
    22ba:	83 ec 04             	sub    $0x4,%esp
    22bd:	68 58 02 00 00       	push   $0x258
    22c2:	53                   	push   %ebx
    22c3:	68 60 82 00 00       	push   $0x8260
    22c8:	e8 97 12 00 00       	call   3564 <memset>
    if(write(fd, buf, 600) != 600){
    22cd:	83 c4 0c             	add    $0xc,%esp
    22d0:	68 58 02 00 00       	push   $0x258
    22d5:	68 60 82 00 00       	push   $0x8260
    22da:	56                   	push   %esi
    22db:	e8 cf 13 00 00       	call   36af <write>
    22e0:	83 c4 10             	add    $0x10,%esp
    22e3:	3d 58 02 00 00       	cmp    $0x258,%eax
    22e8:	75 17                	jne    2301 <bigfile+0x8d>
  for(i = 0; i < 20; i++){
    22ea:	43                   	inc    %ebx
    22eb:	eb c8                	jmp    22b5 <bigfile+0x41>
    printf(1, "cannot create bigfile");
    22ed:	83 ec 08             	sub    $0x8,%esp
    22f0:	68 32 45 00 00       	push   $0x4532
    22f5:	6a 01                	push   $0x1
    22f7:	e8 d6 14 00 00       	call   37d2 <printf>
    exit();
    22fc:	e8 8e 13 00 00       	call   368f <exit>
      printf(1, "write bigfile failed\n");
    2301:	83 ec 08             	sub    $0x8,%esp
    2304:	68 48 45 00 00       	push   $0x4548
    2309:	6a 01                	push   $0x1
    230b:	e8 c2 14 00 00       	call   37d2 <printf>
      exit();
    2310:	e8 7a 13 00 00       	call   368f <exit>
    }
  }
  close(fd);
    2315:	83 ec 0c             	sub    $0xc,%esp
    2318:	56                   	push   %esi
    2319:	e8 99 13 00 00       	call   36b7 <close>

  fd = open("bigfile", 0);
    231e:	83 c4 08             	add    $0x8,%esp
    2321:	6a 00                	push   $0x0
    2323:	68 40 45 00 00       	push   $0x4540
    2328:	e8 a2 13 00 00       	call   36cf <open>
    232d:	89 c7                	mov    %eax,%edi
  if(fd < 0){
    232f:	83 c4 10             	add    $0x10,%esp
    2332:	85 c0                	test   %eax,%eax
    2334:	78 51                	js     2387 <bigfile+0x113>
    printf(1, "cannot open bigfile\n");
    exit();
  }
  total = 0;
    2336:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; ; i++){
    233b:	bb 00 00 00 00       	mov    $0x0,%ebx
    cc = read(fd, buf, 300);
    2340:	83 ec 04             	sub    $0x4,%esp
    2343:	68 2c 01 00 00       	push   $0x12c
    2348:	68 60 82 00 00       	push   $0x8260
    234d:	57                   	push   %edi
    234e:	e8 54 13 00 00       	call   36a7 <read>
    if(cc < 0){
    2353:	83 c4 10             	add    $0x10,%esp
    2356:	85 c0                	test   %eax,%eax
    2358:	78 41                	js     239b <bigfile+0x127>
      printf(1, "read bigfile failed\n");
      exit();
    }
    if(cc == 0)
    235a:	74 7b                	je     23d7 <bigfile+0x163>
      break;
    if(cc != 300){
    235c:	3d 2c 01 00 00       	cmp    $0x12c,%eax
    2361:	75 4c                	jne    23af <bigfile+0x13b>
      printf(1, "short read bigfile\n");
      exit();
    }
    if(buf[0] != i/2 || buf[299] != i/2){
    2363:	0f be 0d 60 82 00 00 	movsbl 0x8260,%ecx
    236a:	89 da                	mov    %ebx,%edx
    236c:	c1 ea 1f             	shr    $0x1f,%edx
    236f:	01 da                	add    %ebx,%edx
    2371:	d1 fa                	sar    %edx
    2373:	39 d1                	cmp    %edx,%ecx
    2375:	75 4c                	jne    23c3 <bigfile+0x14f>
    2377:	0f be 0d 8b 83 00 00 	movsbl 0x838b,%ecx
    237e:	39 ca                	cmp    %ecx,%edx
    2380:	75 41                	jne    23c3 <bigfile+0x14f>
      printf(1, "read bigfile wrong data\n");
      exit();
    }
    total += cc;
    2382:	01 c6                	add    %eax,%esi
  for(i = 0; ; i++){
    2384:	43                   	inc    %ebx
    cc = read(fd, buf, 300);
    2385:	eb b9                	jmp    2340 <bigfile+0xcc>
    printf(1, "cannot open bigfile\n");
    2387:	83 ec 08             	sub    $0x8,%esp
    238a:	68 5e 45 00 00       	push   $0x455e
    238f:	6a 01                	push   $0x1
    2391:	e8 3c 14 00 00       	call   37d2 <printf>
    exit();
    2396:	e8 f4 12 00 00       	call   368f <exit>
      printf(1, "read bigfile failed\n");
    239b:	83 ec 08             	sub    $0x8,%esp
    239e:	68 73 45 00 00       	push   $0x4573
    23a3:	6a 01                	push   $0x1
    23a5:	e8 28 14 00 00       	call   37d2 <printf>
      exit();
    23aa:	e8 e0 12 00 00       	call   368f <exit>
      printf(1, "short read bigfile\n");
    23af:	83 ec 08             	sub    $0x8,%esp
    23b2:	68 88 45 00 00       	push   $0x4588
    23b7:	6a 01                	push   $0x1
    23b9:	e8 14 14 00 00       	call   37d2 <printf>
      exit();
    23be:	e8 cc 12 00 00       	call   368f <exit>
      printf(1, "read bigfile wrong data\n");
    23c3:	83 ec 08             	sub    $0x8,%esp
    23c6:	68 9c 45 00 00       	push   $0x459c
    23cb:	6a 01                	push   $0x1
    23cd:	e8 00 14 00 00       	call   37d2 <printf>
      exit();
    23d2:	e8 b8 12 00 00       	call   368f <exit>
  }
  close(fd);
    23d7:	83 ec 0c             	sub    $0xc,%esp
    23da:	57                   	push   %edi
    23db:	e8 d7 12 00 00       	call   36b7 <close>
  if(total != 20*600){
    23e0:	83 c4 10             	add    $0x10,%esp
    23e3:	81 fe e0 2e 00 00    	cmp    $0x2ee0,%esi
    23e9:	75 27                	jne    2412 <bigfile+0x19e>
    printf(1, "read bigfile wrong total\n");
    exit();
  }
  unlink("bigfile");
    23eb:	83 ec 0c             	sub    $0xc,%esp
    23ee:	68 40 45 00 00       	push   $0x4540
    23f3:	e8 e7 12 00 00       	call   36df <unlink>

  printf(1, "bigfile test ok\n");
    23f8:	83 c4 08             	add    $0x8,%esp
    23fb:	68 cf 45 00 00       	push   $0x45cf
    2400:	6a 01                	push   $0x1
    2402:	e8 cb 13 00 00       	call   37d2 <printf>
}
    2407:	83 c4 10             	add    $0x10,%esp
    240a:	8d 65 f4             	lea    -0xc(%ebp),%esp
    240d:	5b                   	pop    %ebx
    240e:	5e                   	pop    %esi
    240f:	5f                   	pop    %edi
    2410:	5d                   	pop    %ebp
    2411:	c3                   	ret    
    printf(1, "read bigfile wrong total\n");
    2412:	83 ec 08             	sub    $0x8,%esp
    2415:	68 b5 45 00 00       	push   $0x45b5
    241a:	6a 01                	push   $0x1
    241c:	e8 b1 13 00 00       	call   37d2 <printf>
    exit();
    2421:	e8 69 12 00 00       	call   368f <exit>

00002426 <fourteen>:

void
fourteen(void)
{
    2426:	55                   	push   %ebp
    2427:	89 e5                	mov    %esp,%ebp
    2429:	83 ec 10             	sub    $0x10,%esp
  int fd;

  // DIRSIZ is 14.
  printf(1, "fourteen test\n");
    242c:	68 e0 45 00 00       	push   $0x45e0
    2431:	6a 01                	push   $0x1
    2433:	e8 9a 13 00 00       	call   37d2 <printf>

  if(mkdir("12345678901234") != 0){
    2438:	c7 04 24 1b 46 00 00 	movl   $0x461b,(%esp)
    243f:	e8 b3 12 00 00       	call   36f7 <mkdir>
    2444:	83 c4 10             	add    $0x10,%esp
    2447:	85 c0                	test   %eax,%eax
    2449:	0f 85 9c 00 00 00    	jne    24eb <fourteen+0xc5>
    printf(1, "mkdir 12345678901234 failed\n");
    exit();
  }
  if(mkdir("12345678901234/123456789012345") != 0){
    244f:	83 ec 0c             	sub    $0xc,%esp
    2452:	68 d8 4d 00 00       	push   $0x4dd8
    2457:	e8 9b 12 00 00       	call   36f7 <mkdir>
    245c:	83 c4 10             	add    $0x10,%esp
    245f:	85 c0                	test   %eax,%eax
    2461:	0f 85 98 00 00 00    	jne    24ff <fourteen+0xd9>
    printf(1, "mkdir 12345678901234/123456789012345 failed\n");
    exit();
  }
  fd = open("123456789012345/123456789012345/123456789012345", O_CREATE);
    2467:	83 ec 08             	sub    $0x8,%esp
    246a:	68 00 02 00 00       	push   $0x200
    246f:	68 28 4e 00 00       	push   $0x4e28
    2474:	e8 56 12 00 00       	call   36cf <open>
  if(fd < 0){
    2479:	83 c4 10             	add    $0x10,%esp
    247c:	85 c0                	test   %eax,%eax
    247e:	0f 88 8f 00 00 00    	js     2513 <fourteen+0xed>
    printf(1, "create 123456789012345/123456789012345/123456789012345 failed\n");
    exit();
  }
  close(fd);
    2484:	83 ec 0c             	sub    $0xc,%esp
    2487:	50                   	push   %eax
    2488:	e8 2a 12 00 00       	call   36b7 <close>
  fd = open("12345678901234/12345678901234/12345678901234", 0);
    248d:	83 c4 08             	add    $0x8,%esp
    2490:	6a 00                	push   $0x0
    2492:	68 98 4e 00 00       	push   $0x4e98
    2497:	e8 33 12 00 00       	call   36cf <open>
  if(fd < 0){
    249c:	83 c4 10             	add    $0x10,%esp
    249f:	85 c0                	test   %eax,%eax
    24a1:	0f 88 80 00 00 00    	js     2527 <fourteen+0x101>
    printf(1, "open 12345678901234/12345678901234/12345678901234 failed\n");
    exit();
  }
  close(fd);
    24a7:	83 ec 0c             	sub    $0xc,%esp
    24aa:	50                   	push   %eax
    24ab:	e8 07 12 00 00       	call   36b7 <close>

  if(mkdir("12345678901234/12345678901234") == 0){
    24b0:	c7 04 24 0c 46 00 00 	movl   $0x460c,(%esp)
    24b7:	e8 3b 12 00 00       	call   36f7 <mkdir>
    24bc:	83 c4 10             	add    $0x10,%esp
    24bf:	85 c0                	test   %eax,%eax
    24c1:	74 78                	je     253b <fourteen+0x115>
    printf(1, "mkdir 12345678901234/12345678901234 succeeded!\n");
    exit();
  }
  if(mkdir("123456789012345/12345678901234") == 0){
    24c3:	83 ec 0c             	sub    $0xc,%esp
    24c6:	68 34 4f 00 00       	push   $0x4f34
    24cb:	e8 27 12 00 00       	call   36f7 <mkdir>
    24d0:	83 c4 10             	add    $0x10,%esp
    24d3:	85 c0                	test   %eax,%eax
    24d5:	74 78                	je     254f <fourteen+0x129>
    printf(1, "mkdir 12345678901234/123456789012345 succeeded!\n");
    exit();
  }

  printf(1, "fourteen ok\n");
    24d7:	83 ec 08             	sub    $0x8,%esp
    24da:	68 2a 46 00 00       	push   $0x462a
    24df:	6a 01                	push   $0x1
    24e1:	e8 ec 12 00 00       	call   37d2 <printf>
}
    24e6:	83 c4 10             	add    $0x10,%esp
    24e9:	c9                   	leave  
    24ea:	c3                   	ret    
    printf(1, "mkdir 12345678901234 failed\n");
    24eb:	83 ec 08             	sub    $0x8,%esp
    24ee:	68 ef 45 00 00       	push   $0x45ef
    24f3:	6a 01                	push   $0x1
    24f5:	e8 d8 12 00 00       	call   37d2 <printf>
    exit();
    24fa:	e8 90 11 00 00       	call   368f <exit>
    printf(1, "mkdir 12345678901234/123456789012345 failed\n");
    24ff:	83 ec 08             	sub    $0x8,%esp
    2502:	68 f8 4d 00 00       	push   $0x4df8
    2507:	6a 01                	push   $0x1
    2509:	e8 c4 12 00 00       	call   37d2 <printf>
    exit();
    250e:	e8 7c 11 00 00       	call   368f <exit>
    printf(1, "create 123456789012345/123456789012345/123456789012345 failed\n");
    2513:	83 ec 08             	sub    $0x8,%esp
    2516:	68 58 4e 00 00       	push   $0x4e58
    251b:	6a 01                	push   $0x1
    251d:	e8 b0 12 00 00       	call   37d2 <printf>
    exit();
    2522:	e8 68 11 00 00       	call   368f <exit>
    printf(1, "open 12345678901234/12345678901234/12345678901234 failed\n");
    2527:	83 ec 08             	sub    $0x8,%esp
    252a:	68 c8 4e 00 00       	push   $0x4ec8
    252f:	6a 01                	push   $0x1
    2531:	e8 9c 12 00 00       	call   37d2 <printf>
    exit();
    2536:	e8 54 11 00 00       	call   368f <exit>
    printf(1, "mkdir 12345678901234/12345678901234 succeeded!\n");
    253b:	83 ec 08             	sub    $0x8,%esp
    253e:	68 04 4f 00 00       	push   $0x4f04
    2543:	6a 01                	push   $0x1
    2545:	e8 88 12 00 00       	call   37d2 <printf>
    exit();
    254a:	e8 40 11 00 00       	call   368f <exit>
    printf(1, "mkdir 12345678901234/123456789012345 succeeded!\n");
    254f:	83 ec 08             	sub    $0x8,%esp
    2552:	68 54 4f 00 00       	push   $0x4f54
    2557:	6a 01                	push   $0x1
    2559:	e8 74 12 00 00       	call   37d2 <printf>
    exit();
    255e:	e8 2c 11 00 00       	call   368f <exit>

00002563 <rmdot>:

void
rmdot(void)
{
    2563:	55                   	push   %ebp
    2564:	89 e5                	mov    %esp,%ebp
    2566:	83 ec 10             	sub    $0x10,%esp
  printf(1, "rmdot test\n");
    2569:	68 37 46 00 00       	push   $0x4637
    256e:	6a 01                	push   $0x1
    2570:	e8 5d 12 00 00       	call   37d2 <printf>
  if(mkdir("dots") != 0){
    2575:	c7 04 24 43 46 00 00 	movl   $0x4643,(%esp)
    257c:	e8 76 11 00 00       	call   36f7 <mkdir>
    2581:	83 c4 10             	add    $0x10,%esp
    2584:	85 c0                	test   %eax,%eax
    2586:	0f 85 bc 00 00 00    	jne    2648 <rmdot+0xe5>
    printf(1, "mkdir dots failed\n");
    exit();
  }
  if(chdir("dots") != 0){
    258c:	83 ec 0c             	sub    $0xc,%esp
    258f:	68 43 46 00 00       	push   $0x4643
    2594:	e8 66 11 00 00       	call   36ff <chdir>
    2599:	83 c4 10             	add    $0x10,%esp
    259c:	85 c0                	test   %eax,%eax
    259e:	0f 85 b8 00 00 00    	jne    265c <rmdot+0xf9>
    printf(1, "chdir dots failed\n");
    exit();
  }
  if(unlink(".") == 0){
    25a4:	83 ec 0c             	sub    $0xc,%esp
    25a7:	68 ee 42 00 00       	push   $0x42ee
    25ac:	e8 2e 11 00 00       	call   36df <unlink>
    25b1:	83 c4 10             	add    $0x10,%esp
    25b4:	85 c0                	test   %eax,%eax
    25b6:	0f 84 b4 00 00 00    	je     2670 <rmdot+0x10d>
    printf(1, "rm . worked!\n");
    exit();
  }
  if(unlink("..") == 0){
    25bc:	83 ec 0c             	sub    $0xc,%esp
    25bf:	68 ed 42 00 00       	push   $0x42ed
    25c4:	e8 16 11 00 00       	call   36df <unlink>
    25c9:	83 c4 10             	add    $0x10,%esp
    25cc:	85 c0                	test   %eax,%eax
    25ce:	0f 84 b0 00 00 00    	je     2684 <rmdot+0x121>
    printf(1, "rm .. worked!\n");
    exit();
  }
  if(chdir("/") != 0){
    25d4:	83 ec 0c             	sub    $0xc,%esp
    25d7:	68 c1 3a 00 00       	push   $0x3ac1
    25dc:	e8 1e 11 00 00       	call   36ff <chdir>
    25e1:	83 c4 10             	add    $0x10,%esp
    25e4:	85 c0                	test   %eax,%eax
    25e6:	0f 85 ac 00 00 00    	jne    2698 <rmdot+0x135>
    printf(1, "chdir / failed\n");
    exit();
  }
  if(unlink("dots/.") == 0){
    25ec:	83 ec 0c             	sub    $0xc,%esp
    25ef:	68 8b 46 00 00       	push   $0x468b
    25f4:	e8 e6 10 00 00       	call   36df <unlink>
    25f9:	83 c4 10             	add    $0x10,%esp
    25fc:	85 c0                	test   %eax,%eax
    25fe:	0f 84 a8 00 00 00    	je     26ac <rmdot+0x149>
    printf(1, "unlink dots/. worked!\n");
    exit();
  }
  if(unlink("dots/..") == 0){
    2604:	83 ec 0c             	sub    $0xc,%esp
    2607:	68 a9 46 00 00       	push   $0x46a9
    260c:	e8 ce 10 00 00       	call   36df <unlink>
    2611:	83 c4 10             	add    $0x10,%esp
    2614:	85 c0                	test   %eax,%eax
    2616:	0f 84 a4 00 00 00    	je     26c0 <rmdot+0x15d>
    printf(1, "unlink dots/.. worked!\n");
    exit();
  }
  if(unlink("dots") != 0){
    261c:	83 ec 0c             	sub    $0xc,%esp
    261f:	68 43 46 00 00       	push   $0x4643
    2624:	e8 b6 10 00 00       	call   36df <unlink>
    2629:	83 c4 10             	add    $0x10,%esp
    262c:	85 c0                	test   %eax,%eax
    262e:	0f 85 a0 00 00 00    	jne    26d4 <rmdot+0x171>
    printf(1, "unlink dots failed!\n");
    exit();
  }
  printf(1, "rmdot ok\n");
    2634:	83 ec 08             	sub    $0x8,%esp
    2637:	68 de 46 00 00       	push   $0x46de
    263c:	6a 01                	push   $0x1
    263e:	e8 8f 11 00 00       	call   37d2 <printf>
}
    2643:	83 c4 10             	add    $0x10,%esp
    2646:	c9                   	leave  
    2647:	c3                   	ret    
    printf(1, "mkdir dots failed\n");
    2648:	83 ec 08             	sub    $0x8,%esp
    264b:	68 48 46 00 00       	push   $0x4648
    2650:	6a 01                	push   $0x1
    2652:	e8 7b 11 00 00       	call   37d2 <printf>
    exit();
    2657:	e8 33 10 00 00       	call   368f <exit>
    printf(1, "chdir dots failed\n");
    265c:	83 ec 08             	sub    $0x8,%esp
    265f:	68 5b 46 00 00       	push   $0x465b
    2664:	6a 01                	push   $0x1
    2666:	e8 67 11 00 00       	call   37d2 <printf>
    exit();
    266b:	e8 1f 10 00 00       	call   368f <exit>
    printf(1, "rm . worked!\n");
    2670:	83 ec 08             	sub    $0x8,%esp
    2673:	68 6e 46 00 00       	push   $0x466e
    2678:	6a 01                	push   $0x1
    267a:	e8 53 11 00 00       	call   37d2 <printf>
    exit();
    267f:	e8 0b 10 00 00       	call   368f <exit>
    printf(1, "rm .. worked!\n");
    2684:	83 ec 08             	sub    $0x8,%esp
    2687:	68 7c 46 00 00       	push   $0x467c
    268c:	6a 01                	push   $0x1
    268e:	e8 3f 11 00 00       	call   37d2 <printf>
    exit();
    2693:	e8 f7 0f 00 00       	call   368f <exit>
    printf(1, "chdir / failed\n");
    2698:	83 ec 08             	sub    $0x8,%esp
    269b:	68 c3 3a 00 00       	push   $0x3ac3
    26a0:	6a 01                	push   $0x1
    26a2:	e8 2b 11 00 00       	call   37d2 <printf>
    exit();
    26a7:	e8 e3 0f 00 00       	call   368f <exit>
    printf(1, "unlink dots/. worked!\n");
    26ac:	83 ec 08             	sub    $0x8,%esp
    26af:	68 92 46 00 00       	push   $0x4692
    26b4:	6a 01                	push   $0x1
    26b6:	e8 17 11 00 00       	call   37d2 <printf>
    exit();
    26bb:	e8 cf 0f 00 00       	call   368f <exit>
    printf(1, "unlink dots/.. worked!\n");
    26c0:	83 ec 08             	sub    $0x8,%esp
    26c3:	68 b1 46 00 00       	push   $0x46b1
    26c8:	6a 01                	push   $0x1
    26ca:	e8 03 11 00 00       	call   37d2 <printf>
    exit();
    26cf:	e8 bb 0f 00 00       	call   368f <exit>
    printf(1, "unlink dots failed!\n");
    26d4:	83 ec 08             	sub    $0x8,%esp
    26d7:	68 c9 46 00 00       	push   $0x46c9
    26dc:	6a 01                	push   $0x1
    26de:	e8 ef 10 00 00       	call   37d2 <printf>
    exit();
    26e3:	e8 a7 0f 00 00       	call   368f <exit>

000026e8 <dirfile>:

void
dirfile(void)
{
    26e8:	55                   	push   %ebp
    26e9:	89 e5                	mov    %esp,%ebp
    26eb:	53                   	push   %ebx
    26ec:	83 ec 0c             	sub    $0xc,%esp
  int fd;

  printf(1, "dir vs file\n");
    26ef:	68 e8 46 00 00       	push   $0x46e8
    26f4:	6a 01                	push   $0x1
    26f6:	e8 d7 10 00 00       	call   37d2 <printf>

  fd = open("dirfile", O_CREATE);
    26fb:	83 c4 08             	add    $0x8,%esp
    26fe:	68 00 02 00 00       	push   $0x200
    2703:	68 f5 46 00 00       	push   $0x46f5
    2708:	e8 c2 0f 00 00       	call   36cf <open>
  if(fd < 0){
    270d:	83 c4 10             	add    $0x10,%esp
    2710:	85 c0                	test   %eax,%eax
    2712:	0f 88 22 01 00 00    	js     283a <dirfile+0x152>
    printf(1, "create dirfile failed\n");
    exit();
  }
  close(fd);
    2718:	83 ec 0c             	sub    $0xc,%esp
    271b:	50                   	push   %eax
    271c:	e8 96 0f 00 00       	call   36b7 <close>
  if(chdir("dirfile") == 0){
    2721:	c7 04 24 f5 46 00 00 	movl   $0x46f5,(%esp)
    2728:	e8 d2 0f 00 00       	call   36ff <chdir>
    272d:	83 c4 10             	add    $0x10,%esp
    2730:	85 c0                	test   %eax,%eax
    2732:	0f 84 16 01 00 00    	je     284e <dirfile+0x166>
    printf(1, "chdir dirfile succeeded!\n");
    exit();
  }
  fd = open("dirfile/xx", 0);
    2738:	83 ec 08             	sub    $0x8,%esp
    273b:	6a 00                	push   $0x0
    273d:	68 2e 47 00 00       	push   $0x472e
    2742:	e8 88 0f 00 00       	call   36cf <open>
  if(fd >= 0){
    2747:	83 c4 10             	add    $0x10,%esp
    274a:	85 c0                	test   %eax,%eax
    274c:	0f 89 10 01 00 00    	jns    2862 <dirfile+0x17a>
    printf(1, "create dirfile/xx succeeded!\n");
    exit();
  }
  fd = open("dirfile/xx", O_CREATE);
    2752:	83 ec 08             	sub    $0x8,%esp
    2755:	68 00 02 00 00       	push   $0x200
    275a:	68 2e 47 00 00       	push   $0x472e
    275f:	e8 6b 0f 00 00       	call   36cf <open>
  if(fd >= 0){
    2764:	83 c4 10             	add    $0x10,%esp
    2767:	85 c0                	test   %eax,%eax
    2769:	0f 89 07 01 00 00    	jns    2876 <dirfile+0x18e>
    printf(1, "create dirfile/xx succeeded!\n");
    exit();
  }
  if(mkdir("dirfile/xx") == 0){
    276f:	83 ec 0c             	sub    $0xc,%esp
    2772:	68 2e 47 00 00       	push   $0x472e
    2777:	e8 7b 0f 00 00       	call   36f7 <mkdir>
    277c:	83 c4 10             	add    $0x10,%esp
    277f:	85 c0                	test   %eax,%eax
    2781:	0f 84 03 01 00 00    	je     288a <dirfile+0x1a2>
    printf(1, "mkdir dirfile/xx succeeded!\n");
    exit();
  }
  if(unlink("dirfile/xx") == 0){
    2787:	83 ec 0c             	sub    $0xc,%esp
    278a:	68 2e 47 00 00       	push   $0x472e
    278f:	e8 4b 0f 00 00       	call   36df <unlink>
    2794:	83 c4 10             	add    $0x10,%esp
    2797:	85 c0                	test   %eax,%eax
    2799:	0f 84 ff 00 00 00    	je     289e <dirfile+0x1b6>
    printf(1, "unlink dirfile/xx succeeded!\n");
    exit();
  }
  if(link("README", "dirfile/xx") == 0){
    279f:	83 ec 08             	sub    $0x8,%esp
    27a2:	68 2e 47 00 00       	push   $0x472e
    27a7:	68 92 47 00 00       	push   $0x4792
    27ac:	e8 3e 0f 00 00       	call   36ef <link>
    27b1:	83 c4 10             	add    $0x10,%esp
    27b4:	85 c0                	test   %eax,%eax
    27b6:	0f 84 f6 00 00 00    	je     28b2 <dirfile+0x1ca>
    printf(1, "link to dirfile/xx succeeded!\n");
    exit();
  }
  if(unlink("dirfile") != 0){
    27bc:	83 ec 0c             	sub    $0xc,%esp
    27bf:	68 f5 46 00 00       	push   $0x46f5
    27c4:	e8 16 0f 00 00       	call   36df <unlink>
    27c9:	83 c4 10             	add    $0x10,%esp
    27cc:	85 c0                	test   %eax,%eax
    27ce:	0f 85 f2 00 00 00    	jne    28c6 <dirfile+0x1de>
    printf(1, "unlink dirfile failed!\n");
    exit();
  }

  fd = open(".", O_RDWR);
    27d4:	83 ec 08             	sub    $0x8,%esp
    27d7:	6a 02                	push   $0x2
    27d9:	68 ee 42 00 00       	push   $0x42ee
    27de:	e8 ec 0e 00 00       	call   36cf <open>
  if(fd >= 0){
    27e3:	83 c4 10             	add    $0x10,%esp
    27e6:	85 c0                	test   %eax,%eax
    27e8:	0f 89 ec 00 00 00    	jns    28da <dirfile+0x1f2>
    printf(1, "open . for writing succeeded!\n");
    exit();
  }
  fd = open(".", 0);
    27ee:	83 ec 08             	sub    $0x8,%esp
    27f1:	6a 00                	push   $0x0
    27f3:	68 ee 42 00 00       	push   $0x42ee
    27f8:	e8 d2 0e 00 00       	call   36cf <open>
    27fd:	89 c3                	mov    %eax,%ebx
  if(write(fd, "x", 1) > 0){
    27ff:	83 c4 0c             	add    $0xc,%esp
    2802:	6a 01                	push   $0x1
    2804:	68 d1 43 00 00       	push   $0x43d1
    2809:	50                   	push   %eax
    280a:	e8 a0 0e 00 00       	call   36af <write>
    280f:	83 c4 10             	add    $0x10,%esp
    2812:	85 c0                	test   %eax,%eax
    2814:	0f 8f d4 00 00 00    	jg     28ee <dirfile+0x206>
    printf(1, "write . succeeded!\n");
    exit();
  }
  close(fd);
    281a:	83 ec 0c             	sub    $0xc,%esp
    281d:	53                   	push   %ebx
    281e:	e8 94 0e 00 00       	call   36b7 <close>

  printf(1, "dir vs file OK\n");
    2823:	83 c4 08             	add    $0x8,%esp
    2826:	68 c5 47 00 00       	push   $0x47c5
    282b:	6a 01                	push   $0x1
    282d:	e8 a0 0f 00 00       	call   37d2 <printf>
}
    2832:	83 c4 10             	add    $0x10,%esp
    2835:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    2838:	c9                   	leave  
    2839:	c3                   	ret    
    printf(1, "create dirfile failed\n");
    283a:	83 ec 08             	sub    $0x8,%esp
    283d:	68 fd 46 00 00       	push   $0x46fd
    2842:	6a 01                	push   $0x1
    2844:	e8 89 0f 00 00       	call   37d2 <printf>
    exit();
    2849:	e8 41 0e 00 00       	call   368f <exit>
    printf(1, "chdir dirfile succeeded!\n");
    284e:	83 ec 08             	sub    $0x8,%esp
    2851:	68 14 47 00 00       	push   $0x4714
    2856:	6a 01                	push   $0x1
    2858:	e8 75 0f 00 00       	call   37d2 <printf>
    exit();
    285d:	e8 2d 0e 00 00       	call   368f <exit>
    printf(1, "create dirfile/xx succeeded!\n");
    2862:	83 ec 08             	sub    $0x8,%esp
    2865:	68 39 47 00 00       	push   $0x4739
    286a:	6a 01                	push   $0x1
    286c:	e8 61 0f 00 00       	call   37d2 <printf>
    exit();
    2871:	e8 19 0e 00 00       	call   368f <exit>
    printf(1, "create dirfile/xx succeeded!\n");
    2876:	83 ec 08             	sub    $0x8,%esp
    2879:	68 39 47 00 00       	push   $0x4739
    287e:	6a 01                	push   $0x1
    2880:	e8 4d 0f 00 00       	call   37d2 <printf>
    exit();
    2885:	e8 05 0e 00 00       	call   368f <exit>
    printf(1, "mkdir dirfile/xx succeeded!\n");
    288a:	83 ec 08             	sub    $0x8,%esp
    288d:	68 57 47 00 00       	push   $0x4757
    2892:	6a 01                	push   $0x1
    2894:	e8 39 0f 00 00       	call   37d2 <printf>
    exit();
    2899:	e8 f1 0d 00 00       	call   368f <exit>
    printf(1, "unlink dirfile/xx succeeded!\n");
    289e:	83 ec 08             	sub    $0x8,%esp
    28a1:	68 74 47 00 00       	push   $0x4774
    28a6:	6a 01                	push   $0x1
    28a8:	e8 25 0f 00 00       	call   37d2 <printf>
    exit();
    28ad:	e8 dd 0d 00 00       	call   368f <exit>
    printf(1, "link to dirfile/xx succeeded!\n");
    28b2:	83 ec 08             	sub    $0x8,%esp
    28b5:	68 88 4f 00 00       	push   $0x4f88
    28ba:	6a 01                	push   $0x1
    28bc:	e8 11 0f 00 00       	call   37d2 <printf>
    exit();
    28c1:	e8 c9 0d 00 00       	call   368f <exit>
    printf(1, "unlink dirfile failed!\n");
    28c6:	83 ec 08             	sub    $0x8,%esp
    28c9:	68 99 47 00 00       	push   $0x4799
    28ce:	6a 01                	push   $0x1
    28d0:	e8 fd 0e 00 00       	call   37d2 <printf>
    exit();
    28d5:	e8 b5 0d 00 00       	call   368f <exit>
    printf(1, "open . for writing succeeded!\n");
    28da:	83 ec 08             	sub    $0x8,%esp
    28dd:	68 a8 4f 00 00       	push   $0x4fa8
    28e2:	6a 01                	push   $0x1
    28e4:	e8 e9 0e 00 00       	call   37d2 <printf>
    exit();
    28e9:	e8 a1 0d 00 00       	call   368f <exit>
    printf(1, "write . succeeded!\n");
    28ee:	83 ec 08             	sub    $0x8,%esp
    28f1:	68 b1 47 00 00       	push   $0x47b1
    28f6:	6a 01                	push   $0x1
    28f8:	e8 d5 0e 00 00       	call   37d2 <printf>
    exit();
    28fd:	e8 8d 0d 00 00       	call   368f <exit>

00002902 <iref>:

// test that iput() is called at the end of _namei()
void
iref(void)
{
    2902:	55                   	push   %ebp
    2903:	89 e5                	mov    %esp,%ebp
    2905:	53                   	push   %ebx
    2906:	83 ec 0c             	sub    $0xc,%esp
  int i, fd;

  printf(1, "empty file name\n");
    2909:	68 d5 47 00 00       	push   $0x47d5
    290e:	6a 01                	push   $0x1
    2910:	e8 bd 0e 00 00       	call   37d2 <printf>

  // the 50 is NINODE
  for(i = 0; i < 50 + 1; i++){
    2915:	83 c4 10             	add    $0x10,%esp
    2918:	bb 00 00 00 00       	mov    $0x0,%ebx
    291d:	eb 47                	jmp    2966 <iref+0x64>
    if(mkdir("irefd") != 0){
      printf(1, "mkdir irefd failed\n");
    291f:	83 ec 08             	sub    $0x8,%esp
    2922:	68 ec 47 00 00       	push   $0x47ec
    2927:	6a 01                	push   $0x1
    2929:	e8 a4 0e 00 00       	call   37d2 <printf>
      exit();
    292e:	e8 5c 0d 00 00       	call   368f <exit>
    }
    if(chdir("irefd") != 0){
      printf(1, "chdir irefd failed\n");
    2933:	83 ec 08             	sub    $0x8,%esp
    2936:	68 00 48 00 00       	push   $0x4800
    293b:	6a 01                	push   $0x1
    293d:	e8 90 0e 00 00       	call   37d2 <printf>
      exit();
    2942:	e8 48 0d 00 00       	call   368f <exit>

    mkdir("");
    link("README", "");
    fd = open("", O_CREATE);
    if(fd >= 0)
      close(fd);
    2947:	83 ec 0c             	sub    $0xc,%esp
    294a:	50                   	push   %eax
    294b:	e8 67 0d 00 00       	call   36b7 <close>
    2950:	83 c4 10             	add    $0x10,%esp
    2953:	eb 7e                	jmp    29d3 <iref+0xd1>
    fd = open("xx", O_CREATE);
    if(fd >= 0)
      close(fd);
    unlink("xx");
    2955:	83 ec 0c             	sub    $0xc,%esp
    2958:	68 d0 43 00 00       	push   $0x43d0
    295d:	e8 7d 0d 00 00       	call   36df <unlink>
  for(i = 0; i < 50 + 1; i++){
    2962:	43                   	inc    %ebx
    2963:	83 c4 10             	add    $0x10,%esp
    2966:	83 fb 32             	cmp    $0x32,%ebx
    2969:	0f 8f 92 00 00 00    	jg     2a01 <iref+0xff>
    if(mkdir("irefd") != 0){
    296f:	83 ec 0c             	sub    $0xc,%esp
    2972:	68 e6 47 00 00       	push   $0x47e6
    2977:	e8 7b 0d 00 00       	call   36f7 <mkdir>
    297c:	83 c4 10             	add    $0x10,%esp
    297f:	85 c0                	test   %eax,%eax
    2981:	75 9c                	jne    291f <iref+0x1d>
    if(chdir("irefd") != 0){
    2983:	83 ec 0c             	sub    $0xc,%esp
    2986:	68 e6 47 00 00       	push   $0x47e6
    298b:	e8 6f 0d 00 00       	call   36ff <chdir>
    2990:	83 c4 10             	add    $0x10,%esp
    2993:	85 c0                	test   %eax,%eax
    2995:	75 9c                	jne    2933 <iref+0x31>
    mkdir("");
    2997:	83 ec 0c             	sub    $0xc,%esp
    299a:	68 9b 3e 00 00       	push   $0x3e9b
    299f:	e8 53 0d 00 00       	call   36f7 <mkdir>
    link("README", "");
    29a4:	83 c4 08             	add    $0x8,%esp
    29a7:	68 9b 3e 00 00       	push   $0x3e9b
    29ac:	68 92 47 00 00       	push   $0x4792
    29b1:	e8 39 0d 00 00       	call   36ef <link>
    fd = open("", O_CREATE);
    29b6:	83 c4 08             	add    $0x8,%esp
    29b9:	68 00 02 00 00       	push   $0x200
    29be:	68 9b 3e 00 00       	push   $0x3e9b
    29c3:	e8 07 0d 00 00       	call   36cf <open>
    if(fd >= 0)
    29c8:	83 c4 10             	add    $0x10,%esp
    29cb:	85 c0                	test   %eax,%eax
    29cd:	0f 89 74 ff ff ff    	jns    2947 <iref+0x45>
    fd = open("xx", O_CREATE);
    29d3:	83 ec 08             	sub    $0x8,%esp
    29d6:	68 00 02 00 00       	push   $0x200
    29db:	68 d0 43 00 00       	push   $0x43d0
    29e0:	e8 ea 0c 00 00       	call   36cf <open>
    if(fd >= 0)
    29e5:	83 c4 10             	add    $0x10,%esp
    29e8:	85 c0                	test   %eax,%eax
    29ea:	0f 88 65 ff ff ff    	js     2955 <iref+0x53>
      close(fd);
    29f0:	83 ec 0c             	sub    $0xc,%esp
    29f3:	50                   	push   %eax
    29f4:	e8 be 0c 00 00       	call   36b7 <close>
    29f9:	83 c4 10             	add    $0x10,%esp
    29fc:	e9 54 ff ff ff       	jmp    2955 <iref+0x53>
  }

  chdir("/");
    2a01:	83 ec 0c             	sub    $0xc,%esp
    2a04:	68 c1 3a 00 00       	push   $0x3ac1
    2a09:	e8 f1 0c 00 00       	call   36ff <chdir>
  printf(1, "empty file name OK\n");
    2a0e:	83 c4 08             	add    $0x8,%esp
    2a11:	68 14 48 00 00       	push   $0x4814
    2a16:	6a 01                	push   $0x1
    2a18:	e8 b5 0d 00 00       	call   37d2 <printf>
}
    2a1d:	83 c4 10             	add    $0x10,%esp
    2a20:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    2a23:	c9                   	leave  
    2a24:	c3                   	ret    

00002a25 <forktest>:
// test that fork fails gracefully
// the forktest binary also does this, but it runs out of proc entries first.
// inside the bigger usertests binary, we run out of memory first.
void
forktest(void)
{
    2a25:	55                   	push   %ebp
    2a26:	89 e5                	mov    %esp,%ebp
    2a28:	53                   	push   %ebx
    2a29:	83 ec 0c             	sub    $0xc,%esp
  int n, pid;

  printf(1, "fork test\n");
    2a2c:	68 28 48 00 00       	push   $0x4828
    2a31:	6a 01                	push   $0x1
    2a33:	e8 9a 0d 00 00       	call   37d2 <printf>

  for(n=0; n<1000; n++){
    2a38:	83 c4 10             	add    $0x10,%esp
    2a3b:	bb 00 00 00 00       	mov    $0x0,%ebx
    2a40:	81 fb e7 03 00 00    	cmp    $0x3e7,%ebx
    2a46:	7f 13                	jg     2a5b <forktest+0x36>
    pid = fork();
    2a48:	e8 3a 0c 00 00       	call   3687 <fork>
    if(pid < 0)
    2a4d:	85 c0                	test   %eax,%eax
    2a4f:	78 0a                	js     2a5b <forktest+0x36>
      break;
    if(pid == 0)
    2a51:	74 03                	je     2a56 <forktest+0x31>
  for(n=0; n<1000; n++){
    2a53:	43                   	inc    %ebx
    2a54:	eb ea                	jmp    2a40 <forktest+0x1b>
      exit();
    2a56:	e8 34 0c 00 00       	call   368f <exit>
  }

  if(n == 1000){
    2a5b:	81 fb e8 03 00 00    	cmp    $0x3e8,%ebx
    2a61:	74 10                	je     2a73 <forktest+0x4e>
    printf(1, "fork claimed to work 1000 times!\n");
    exit();
  }

  for(; n > 0; n--){
    2a63:	85 db                	test   %ebx,%ebx
    2a65:	7e 34                	jle    2a9b <forktest+0x76>
    if(wait() < 0){
    2a67:	e8 2b 0c 00 00       	call   3697 <wait>
    2a6c:	85 c0                	test   %eax,%eax
    2a6e:	78 17                	js     2a87 <forktest+0x62>
  for(; n > 0; n--){
    2a70:	4b                   	dec    %ebx
    2a71:	eb f0                	jmp    2a63 <forktest+0x3e>
    printf(1, "fork claimed to work 1000 times!\n");
    2a73:	83 ec 08             	sub    $0x8,%esp
    2a76:	68 c8 4f 00 00       	push   $0x4fc8
    2a7b:	6a 01                	push   $0x1
    2a7d:	e8 50 0d 00 00       	call   37d2 <printf>
    exit();
    2a82:	e8 08 0c 00 00       	call   368f <exit>
      printf(1, "wait stopped early\n");
    2a87:	83 ec 08             	sub    $0x8,%esp
    2a8a:	68 33 48 00 00       	push   $0x4833
    2a8f:	6a 01                	push   $0x1
    2a91:	e8 3c 0d 00 00       	call   37d2 <printf>
      exit();
    2a96:	e8 f4 0b 00 00       	call   368f <exit>
    }
  }

  if(wait() != -1){
    2a9b:	e8 f7 0b 00 00       	call   3697 <wait>
    2aa0:	83 f8 ff             	cmp    $0xffffffff,%eax
    2aa3:	75 17                	jne    2abc <forktest+0x97>
    printf(1, "wait got too many\n");
    exit();
  }

  printf(1, "fork test OK\n");
    2aa5:	83 ec 08             	sub    $0x8,%esp
    2aa8:	68 5a 48 00 00       	push   $0x485a
    2aad:	6a 01                	push   $0x1
    2aaf:	e8 1e 0d 00 00       	call   37d2 <printf>
}
    2ab4:	83 c4 10             	add    $0x10,%esp
    2ab7:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    2aba:	c9                   	leave  
    2abb:	c3                   	ret    
    printf(1, "wait got too many\n");
    2abc:	83 ec 08             	sub    $0x8,%esp
    2abf:	68 47 48 00 00       	push   $0x4847
    2ac4:	6a 01                	push   $0x1
    2ac6:	e8 07 0d 00 00       	call   37d2 <printf>
    exit();
    2acb:	e8 bf 0b 00 00       	call   368f <exit>

00002ad0 <sbrktest>:

void
sbrktest(void)
{
    2ad0:	55                   	push   %ebp
    2ad1:	89 e5                	mov    %esp,%ebp
    2ad3:	57                   	push   %edi
    2ad4:	56                   	push   %esi
    2ad5:	53                   	push   %ebx
    2ad6:	83 ec 54             	sub    $0x54,%esp
  int fds[2], pid, pids[10], ppid;
  char *a, *b, *c, *lastaddr, *oldbrk, *p, scratch;
  uint amt;

  printf(stdout, "sbrk test\n");
    2ad9:	68 68 48 00 00       	push   $0x4868
    2ade:	ff 35 20 5b 00 00    	push   0x5b20
    2ae4:	e8 e9 0c 00 00       	call   37d2 <printf>
  oldbrk = sbrk(0);
    2ae9:	c7 04 24 00 00 00 00 	movl   $0x0,(%esp)
    2af0:	e8 22 0c 00 00       	call   3717 <sbrk>
    2af5:	89 c7                	mov    %eax,%edi

  // can one sbrk() less than a page?
  a = sbrk(0);
    2af7:	c7 04 24 00 00 00 00 	movl   $0x0,(%esp)
    2afe:	e8 14 0c 00 00       	call   3717 <sbrk>
    2b03:	89 c6                	mov    %eax,%esi
  int i;
  for(i = 0; i < 5000; i++){
    2b05:	83 c4 10             	add    $0x10,%esp
    2b08:	bb 00 00 00 00       	mov    $0x0,%ebx
    2b0d:	81 fb 87 13 00 00    	cmp    $0x1387,%ebx
    2b13:	7f 38                	jg     2b4d <sbrktest+0x7d>
    b = sbrk(1);
    2b15:	83 ec 0c             	sub    $0xc,%esp
    2b18:	6a 01                	push   $0x1
    2b1a:	e8 f8 0b 00 00       	call   3717 <sbrk>
    if(b != a){
    2b1f:	83 c4 10             	add    $0x10,%esp
    2b22:	39 c6                	cmp    %eax,%esi
    2b24:	75 09                	jne    2b2f <sbrktest+0x5f>
      printf(stdout, "sbrk test failed %d %x %x\n", i, a, b);
      exit();
    }
    *b = 1;
    2b26:	c6 00 01             	movb   $0x1,(%eax)
    a = b + 1;
    2b29:	8d 70 01             	lea    0x1(%eax),%esi
  for(i = 0; i < 5000; i++){
    2b2c:	43                   	inc    %ebx
    2b2d:	eb de                	jmp    2b0d <sbrktest+0x3d>
      printf(stdout, "sbrk test failed %d %x %x\n", i, a, b);
    2b2f:	83 ec 0c             	sub    $0xc,%esp
    2b32:	50                   	push   %eax
    2b33:	56                   	push   %esi
    2b34:	53                   	push   %ebx
    2b35:	68 73 48 00 00       	push   $0x4873
    2b3a:	ff 35 20 5b 00 00    	push   0x5b20
    2b40:	e8 8d 0c 00 00       	call   37d2 <printf>
      exit();
    2b45:	83 c4 20             	add    $0x20,%esp
    2b48:	e8 42 0b 00 00       	call   368f <exit>
  }
  pid = fork();
    2b4d:	e8 35 0b 00 00       	call   3687 <fork>
    2b52:	89 c3                	mov    %eax,%ebx
  if(pid < 0){
    2b54:	85 c0                	test   %eax,%eax
    2b56:	0f 88 51 01 00 00    	js     2cad <sbrktest+0x1dd>
    printf(stdout, "sbrk test fork failed\n");
    exit();
  }
  c = sbrk(1);
    2b5c:	83 ec 0c             	sub    $0xc,%esp
    2b5f:	6a 01                	push   $0x1
    2b61:	e8 b1 0b 00 00       	call   3717 <sbrk>
  c = sbrk(1);
    2b66:	c7 04 24 01 00 00 00 	movl   $0x1,(%esp)
    2b6d:	e8 a5 0b 00 00       	call   3717 <sbrk>
  if(c != a + 1){
    2b72:	46                   	inc    %esi
    2b73:	83 c4 10             	add    $0x10,%esp
    2b76:	39 c6                	cmp    %eax,%esi
    2b78:	0f 85 47 01 00 00    	jne    2cc5 <sbrktest+0x1f5>
    printf(stdout, "sbrk test failed post-fork\n");
    exit();
  }
  if(pid == 0)
    2b7e:	85 db                	test   %ebx,%ebx
    2b80:	0f 84 57 01 00 00    	je     2cdd <sbrktest+0x20d>
    exit();
  wait();
    2b86:	e8 0c 0b 00 00       	call   3697 <wait>

  // can one grow address space to something big?
#define BIG (100*1024*1024)
  a = sbrk(0);
    2b8b:	83 ec 0c             	sub    $0xc,%esp
    2b8e:	6a 00                	push   $0x0
    2b90:	e8 82 0b 00 00       	call   3717 <sbrk>
    2b95:	89 c3                	mov    %eax,%ebx
  amt = (BIG) - (uint)a;
    2b97:	b8 00 00 40 06       	mov    $0x6400000,%eax
    2b9c:	29 d8                	sub    %ebx,%eax
  p = sbrk(amt);
    2b9e:	89 04 24             	mov    %eax,(%esp)
    2ba1:	e8 71 0b 00 00       	call   3717 <sbrk>
  if (p != a) {
    2ba6:	83 c4 10             	add    $0x10,%esp
    2ba9:	39 c3                	cmp    %eax,%ebx
    2bab:	0f 85 31 01 00 00    	jne    2ce2 <sbrktest+0x212>
    printf(stdout, "sbrk test failed to grow big address space; enough phys mem?\n");
    exit();
  }
  lastaddr = (char*) (BIG-1);
  *lastaddr = 99;
    2bb1:	c6 05 ff ff 3f 06 63 	movb   $0x63,0x63fffff

  // can one de-allocate?
  a = sbrk(0);
    2bb8:	83 ec 0c             	sub    $0xc,%esp
    2bbb:	6a 00                	push   $0x0
    2bbd:	e8 55 0b 00 00       	call   3717 <sbrk>
    2bc2:	89 c3                	mov    %eax,%ebx
  c = sbrk(-4096);
    2bc4:	c7 04 24 00 f0 ff ff 	movl   $0xfffff000,(%esp)
    2bcb:	e8 47 0b 00 00       	call   3717 <sbrk>
  if(c == (char*)0xffffffff){
    2bd0:	83 c4 10             	add    $0x10,%esp
    2bd3:	83 f8 ff             	cmp    $0xffffffff,%eax
    2bd6:	0f 84 1e 01 00 00    	je     2cfa <sbrktest+0x22a>
    printf(stdout, "sbrk could not deallocate\n");
    exit();
  }
  c = sbrk(0);
    2bdc:	83 ec 0c             	sub    $0xc,%esp
    2bdf:	6a 00                	push   $0x0
    2be1:	e8 31 0b 00 00       	call   3717 <sbrk>
  if(c != a - 4096){
    2be6:	8d 93 00 f0 ff ff    	lea    -0x1000(%ebx),%edx
    2bec:	83 c4 10             	add    $0x10,%esp
    2bef:	39 c2                	cmp    %eax,%edx
    2bf1:	0f 85 1b 01 00 00    	jne    2d12 <sbrktest+0x242>
    printf(stdout, "sbrk deallocation produced wrong address, a %x c %x\n", a, c);
    exit();
  }

  // can one re-allocate that page?
  a = sbrk(0);
    2bf7:	83 ec 0c             	sub    $0xc,%esp
    2bfa:	6a 00                	push   $0x0
    2bfc:	e8 16 0b 00 00       	call   3717 <sbrk>
    2c01:	89 c3                	mov    %eax,%ebx
  c = sbrk(4096);
    2c03:	c7 04 24 00 10 00 00 	movl   $0x1000,(%esp)
    2c0a:	e8 08 0b 00 00       	call   3717 <sbrk>
    2c0f:	89 c6                	mov    %eax,%esi
  if(c != a || sbrk(0) != a + 4096){
    2c11:	83 c4 10             	add    $0x10,%esp
    2c14:	39 c3                	cmp    %eax,%ebx
    2c16:	0f 85 0d 01 00 00    	jne    2d29 <sbrktest+0x259>
    2c1c:	83 ec 0c             	sub    $0xc,%esp
    2c1f:	6a 00                	push   $0x0
    2c21:	e8 f1 0a 00 00       	call   3717 <sbrk>
    2c26:	8d 93 00 10 00 00    	lea    0x1000(%ebx),%edx
    2c2c:	83 c4 10             	add    $0x10,%esp
    2c2f:	39 c2                	cmp    %eax,%edx
    2c31:	0f 85 f2 00 00 00    	jne    2d29 <sbrktest+0x259>
    printf(stdout, "sbrk re-allocation failed, a %x c %x\n", a, c);
    exit();
  }
  if(*lastaddr == 99){
    2c37:	80 3d ff ff 3f 06 63 	cmpb   $0x63,0x63fffff
    2c3e:	0f 84 fc 00 00 00    	je     2d40 <sbrktest+0x270>
    // should be zero
    printf(stdout, "sbrk de-allocation didn't really deallocate\n");
    exit();
  }

  a = sbrk(0);
    2c44:	83 ec 0c             	sub    $0xc,%esp
    2c47:	6a 00                	push   $0x0
    2c49:	e8 c9 0a 00 00       	call   3717 <sbrk>
    2c4e:	89 c3                	mov    %eax,%ebx
  c = sbrk(-(sbrk(0) - oldbrk));
    2c50:	c7 04 24 00 00 00 00 	movl   $0x0,(%esp)
    2c57:	e8 bb 0a 00 00       	call   3717 <sbrk>
    2c5c:	89 c2                	mov    %eax,%edx
    2c5e:	89 f8                	mov    %edi,%eax
    2c60:	29 d0                	sub    %edx,%eax
    2c62:	89 04 24             	mov    %eax,(%esp)
    2c65:	e8 ad 0a 00 00       	call   3717 <sbrk>
  if(c != a){
    2c6a:	83 c4 10             	add    $0x10,%esp
    2c6d:	39 c3                	cmp    %eax,%ebx
    2c6f:	0f 85 e3 00 00 00    	jne    2d58 <sbrktest+0x288>
    printf(stdout, "sbrk downsize failed, a %x c %x\n", a, c);
    exit();
  }

  // can we read the kernel's memory?
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    2c75:	bb 00 00 00 80       	mov    $0x80000000,%ebx
    2c7a:	81 fb 7f 84 1e 80    	cmp    $0x801e847f,%ebx
    2c80:	0f 87 23 01 00 00    	ja     2da9 <sbrktest+0x2d9>
    ppid = getpid();
    2c86:	e8 84 0a 00 00       	call   370f <getpid>
    2c8b:	89 c6                	mov    %eax,%esi
    pid = fork();
    2c8d:	e8 f5 09 00 00       	call   3687 <fork>
    if(pid < 0){
    2c92:	85 c0                	test   %eax,%eax
    2c94:	0f 88 d5 00 00 00    	js     2d6f <sbrktest+0x29f>
      printf(stdout, "fork failed\n");
      exit();
    }
    if(pid == 0){
    2c9a:	0f 84 e7 00 00 00    	je     2d87 <sbrktest+0x2b7>
      printf(stdout, "oops could read %x = %x\n", a, *a);
      kill(ppid);
      exit();
    }
    wait();
    2ca0:	e8 f2 09 00 00       	call   3697 <wait>
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    2ca5:	81 c3 50 c3 00 00    	add    $0xc350,%ebx
    2cab:	eb cd                	jmp    2c7a <sbrktest+0x1aa>
    printf(stdout, "sbrk test fork failed\n");
    2cad:	83 ec 08             	sub    $0x8,%esp
    2cb0:	68 8e 48 00 00       	push   $0x488e
    2cb5:	ff 35 20 5b 00 00    	push   0x5b20
    2cbb:	e8 12 0b 00 00       	call   37d2 <printf>
    exit();
    2cc0:	e8 ca 09 00 00       	call   368f <exit>
    printf(stdout, "sbrk test failed post-fork\n");
    2cc5:	83 ec 08             	sub    $0x8,%esp
    2cc8:	68 a5 48 00 00       	push   $0x48a5
    2ccd:	ff 35 20 5b 00 00    	push   0x5b20
    2cd3:	e8 fa 0a 00 00       	call   37d2 <printf>
    exit();
    2cd8:	e8 b2 09 00 00       	call   368f <exit>
    exit();
    2cdd:	e8 ad 09 00 00       	call   368f <exit>
    printf(stdout, "sbrk test failed to grow big address space; enough phys mem?\n");
    2ce2:	83 ec 08             	sub    $0x8,%esp
    2ce5:	68 ec 4f 00 00       	push   $0x4fec
    2cea:	ff 35 20 5b 00 00    	push   0x5b20
    2cf0:	e8 dd 0a 00 00       	call   37d2 <printf>
    exit();
    2cf5:	e8 95 09 00 00       	call   368f <exit>
    printf(stdout, "sbrk could not deallocate\n");
    2cfa:	83 ec 08             	sub    $0x8,%esp
    2cfd:	68 c1 48 00 00       	push   $0x48c1
    2d02:	ff 35 20 5b 00 00    	push   0x5b20
    2d08:	e8 c5 0a 00 00       	call   37d2 <printf>
    exit();
    2d0d:	e8 7d 09 00 00       	call   368f <exit>
    printf(stdout, "sbrk deallocation produced wrong address, a %x c %x\n", a, c);
    2d12:	50                   	push   %eax
    2d13:	53                   	push   %ebx
    2d14:	68 2c 50 00 00       	push   $0x502c
    2d19:	ff 35 20 5b 00 00    	push   0x5b20
    2d1f:	e8 ae 0a 00 00       	call   37d2 <printf>
    exit();
    2d24:	e8 66 09 00 00       	call   368f <exit>
    printf(stdout, "sbrk re-allocation failed, a %x c %x\n", a, c);
    2d29:	56                   	push   %esi
    2d2a:	53                   	push   %ebx
    2d2b:	68 64 50 00 00       	push   $0x5064
    2d30:	ff 35 20 5b 00 00    	push   0x5b20
    2d36:	e8 97 0a 00 00       	call   37d2 <printf>
    exit();
    2d3b:	e8 4f 09 00 00       	call   368f <exit>
    printf(stdout, "sbrk de-allocation didn't really deallocate\n");
    2d40:	83 ec 08             	sub    $0x8,%esp
    2d43:	68 8c 50 00 00       	push   $0x508c
    2d48:	ff 35 20 5b 00 00    	push   0x5b20
    2d4e:	e8 7f 0a 00 00       	call   37d2 <printf>
    exit();
    2d53:	e8 37 09 00 00       	call   368f <exit>
    printf(stdout, "sbrk downsize failed, a %x c %x\n", a, c);
    2d58:	50                   	push   %eax
    2d59:	53                   	push   %ebx
    2d5a:	68 bc 50 00 00       	push   $0x50bc
    2d5f:	ff 35 20 5b 00 00    	push   0x5b20
    2d65:	e8 68 0a 00 00       	call   37d2 <printf>
    exit();
    2d6a:	e8 20 09 00 00       	call   368f <exit>
      printf(stdout, "fork failed\n");
    2d6f:	83 ec 08             	sub    $0x8,%esp
    2d72:	68 b9 49 00 00       	push   $0x49b9
    2d77:	ff 35 20 5b 00 00    	push   0x5b20
    2d7d:	e8 50 0a 00 00       	call   37d2 <printf>
      exit();
    2d82:	e8 08 09 00 00       	call   368f <exit>
      printf(stdout, "oops could read %x = %x\n", a, *a);
    2d87:	0f be 03             	movsbl (%ebx),%eax
    2d8a:	50                   	push   %eax
    2d8b:	53                   	push   %ebx
    2d8c:	68 dc 48 00 00       	push   $0x48dc
    2d91:	ff 35 20 5b 00 00    	push   0x5b20
    2d97:	e8 36 0a 00 00       	call   37d2 <printf>
      kill(ppid);
    2d9c:	89 34 24             	mov    %esi,(%esp)
    2d9f:	e8 1b 09 00 00       	call   36bf <kill>
      exit();
    2da4:	e8 e6 08 00 00       	call   368f <exit>
  }

  // if we run the system out of memory, does it clean up the last
  // failed allocation?
  if(pipe(fds) != 0){
    2da9:	83 ec 0c             	sub    $0xc,%esp
    2dac:	8d 45 e0             	lea    -0x20(%ebp),%eax
    2daf:	50                   	push   %eax
    2db0:	e8 ea 08 00 00       	call   369f <pipe>
    2db5:	89 c3                	mov    %eax,%ebx
    2db7:	83 c4 10             	add    $0x10,%esp
    2dba:	85 c0                	test   %eax,%eax
    2dbc:	75 04                	jne    2dc2 <sbrktest+0x2f2>
    printf(1, "pipe() failed\n");
    exit();
  }
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    2dbe:	89 c6                	mov    %eax,%esi
    2dc0:	eb 57                	jmp    2e19 <sbrktest+0x349>
    printf(1, "pipe() failed\n");
    2dc2:	83 ec 08             	sub    $0x8,%esp
    2dc5:	68 b1 3d 00 00       	push   $0x3db1
    2dca:	6a 01                	push   $0x1
    2dcc:	e8 01 0a 00 00       	call   37d2 <printf>
    exit();
    2dd1:	e8 b9 08 00 00       	call   368f <exit>
    if((pids[i] = fork()) == 0){
      // allocate a lot of memory
      sbrk(BIG - (uint)sbrk(0));
    2dd6:	83 ec 0c             	sub    $0xc,%esp
    2dd9:	6a 00                	push   $0x0
    2ddb:	e8 37 09 00 00       	call   3717 <sbrk>
    2de0:	89 c2                	mov    %eax,%edx
    2de2:	b8 00 00 40 06       	mov    $0x6400000,%eax
    2de7:	29 d0                	sub    %edx,%eax
    2de9:	89 04 24             	mov    %eax,(%esp)
    2dec:	e8 26 09 00 00       	call   3717 <sbrk>
      write(fds[1], "x", 1);
    2df1:	83 c4 0c             	add    $0xc,%esp
    2df4:	6a 01                	push   $0x1
    2df6:	68 d1 43 00 00       	push   $0x43d1
    2dfb:	ff 75 e4             	push   -0x1c(%ebp)
    2dfe:	e8 ac 08 00 00       	call   36af <write>
    2e03:	83 c4 10             	add    $0x10,%esp
      // sit around until killed
      for(;;) sleep(1000);
    2e06:	83 ec 0c             	sub    $0xc,%esp
    2e09:	68 e8 03 00 00       	push   $0x3e8
    2e0e:	e8 0c 09 00 00       	call   371f <sleep>
    2e13:	83 c4 10             	add    $0x10,%esp
    2e16:	eb ee                	jmp    2e06 <sbrktest+0x336>
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    2e18:	46                   	inc    %esi
    2e19:	83 fe 09             	cmp    $0x9,%esi
    2e1c:	77 28                	ja     2e46 <sbrktest+0x376>
    if((pids[i] = fork()) == 0){
    2e1e:	e8 64 08 00 00       	call   3687 <fork>
    2e23:	89 44 b5 b8          	mov    %eax,-0x48(%ebp,%esi,4)
    2e27:	85 c0                	test   %eax,%eax
    2e29:	74 ab                	je     2dd6 <sbrktest+0x306>
    }
    if(pids[i] != -1)
    2e2b:	83 f8 ff             	cmp    $0xffffffff,%eax
    2e2e:	74 e8                	je     2e18 <sbrktest+0x348>
      read(fds[0], &scratch, 1);
    2e30:	83 ec 04             	sub    $0x4,%esp
    2e33:	6a 01                	push   $0x1
    2e35:	8d 45 b7             	lea    -0x49(%ebp),%eax
    2e38:	50                   	push   %eax
    2e39:	ff 75 e0             	push   -0x20(%ebp)
    2e3c:	e8 66 08 00 00       	call   36a7 <read>
    2e41:	83 c4 10             	add    $0x10,%esp
    2e44:	eb d2                	jmp    2e18 <sbrktest+0x348>
  }
  // if those failed allocations freed up the pages they did allocate,
  // we'll be able to allocate here
  c = sbrk(4096);
    2e46:	83 ec 0c             	sub    $0xc,%esp
    2e49:	68 00 10 00 00       	push   $0x1000
    2e4e:	e8 c4 08 00 00       	call   3717 <sbrk>
    2e53:	89 c6                	mov    %eax,%esi
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    2e55:	83 c4 10             	add    $0x10,%esp
    2e58:	eb 01                	jmp    2e5b <sbrktest+0x38b>
    2e5a:	43                   	inc    %ebx
    2e5b:	83 fb 09             	cmp    $0x9,%ebx
    2e5e:	77 1c                	ja     2e7c <sbrktest+0x3ac>
    if(pids[i] == -1)
    2e60:	8b 44 9d b8          	mov    -0x48(%ebp,%ebx,4),%eax
    2e64:	83 f8 ff             	cmp    $0xffffffff,%eax
    2e67:	74 f1                	je     2e5a <sbrktest+0x38a>
      continue;
    kill(pids[i]);
    2e69:	83 ec 0c             	sub    $0xc,%esp
    2e6c:	50                   	push   %eax
    2e6d:	e8 4d 08 00 00       	call   36bf <kill>
    wait();
    2e72:	e8 20 08 00 00       	call   3697 <wait>
    2e77:	83 c4 10             	add    $0x10,%esp
    2e7a:	eb de                	jmp    2e5a <sbrktest+0x38a>
  }
  if(c == (char*)0xffffffff){
    2e7c:	83 fe ff             	cmp    $0xffffffff,%esi
    2e7f:	74 2f                	je     2eb0 <sbrktest+0x3e0>
    printf(stdout, "failed sbrk leaked memory\n");
    exit();
  }

  if(sbrk(0) > oldbrk)
    2e81:	83 ec 0c             	sub    $0xc,%esp
    2e84:	6a 00                	push   $0x0
    2e86:	e8 8c 08 00 00       	call   3717 <sbrk>
    2e8b:	83 c4 10             	add    $0x10,%esp
    2e8e:	39 c7                	cmp    %eax,%edi
    2e90:	72 36                	jb     2ec8 <sbrktest+0x3f8>
    sbrk(-(sbrk(0) - oldbrk));

  printf(stdout, "sbrk test OK\n");
    2e92:	83 ec 08             	sub    $0x8,%esp
    2e95:	68 10 49 00 00       	push   $0x4910
    2e9a:	ff 35 20 5b 00 00    	push   0x5b20
    2ea0:	e8 2d 09 00 00       	call   37d2 <printf>
}
    2ea5:	83 c4 10             	add    $0x10,%esp
    2ea8:	8d 65 f4             	lea    -0xc(%ebp),%esp
    2eab:	5b                   	pop    %ebx
    2eac:	5e                   	pop    %esi
    2ead:	5f                   	pop    %edi
    2eae:	5d                   	pop    %ebp
    2eaf:	c3                   	ret    
    printf(stdout, "failed sbrk leaked memory\n");
    2eb0:	83 ec 08             	sub    $0x8,%esp
    2eb3:	68 f5 48 00 00       	push   $0x48f5
    2eb8:	ff 35 20 5b 00 00    	push   0x5b20
    2ebe:	e8 0f 09 00 00       	call   37d2 <printf>
    exit();
    2ec3:	e8 c7 07 00 00       	call   368f <exit>
    sbrk(-(sbrk(0) - oldbrk));
    2ec8:	83 ec 0c             	sub    $0xc,%esp
    2ecb:	6a 00                	push   $0x0
    2ecd:	e8 45 08 00 00       	call   3717 <sbrk>
    2ed2:	29 c7                	sub    %eax,%edi
    2ed4:	89 3c 24             	mov    %edi,(%esp)
    2ed7:	e8 3b 08 00 00       	call   3717 <sbrk>
    2edc:	83 c4 10             	add    $0x10,%esp
    2edf:	eb b1                	jmp    2e92 <sbrktest+0x3c2>

00002ee1 <validateint>:
      "int %2\n\t"
      "mov %%ebx, %%esp" :
      "=a" (res) :
      "a" (SYS_sleep), "n" (T_SYSCALL), "c" (p) :
      "ebx");
}
    2ee1:	c3                   	ret    

00002ee2 <validatetest>:

void
validatetest(void)
{
    2ee2:	55                   	push   %ebp
    2ee3:	89 e5                	mov    %esp,%ebp
    2ee5:	56                   	push   %esi
    2ee6:	53                   	push   %ebx
  int hi, pid;
  uint p;

  printf(stdout, "validate test\n");
    2ee7:	83 ec 08             	sub    $0x8,%esp
    2eea:	68 1e 49 00 00       	push   $0x491e
    2eef:	ff 35 20 5b 00 00    	push   0x5b20
    2ef5:	e8 d8 08 00 00       	call   37d2 <printf>
  hi = 1100*1024;

  for(p = 0; p <= (uint)hi; p += 4096){
    2efa:	83 c4 10             	add    $0x10,%esp
    2efd:	be 00 00 00 00       	mov    $0x0,%esi
    2f02:	81 fe 00 30 11 00    	cmp    $0x113000,%esi
    2f08:	77 69                	ja     2f73 <validatetest+0x91>
    if((pid = fork()) == 0){
    2f0a:	e8 78 07 00 00       	call   3687 <fork>
    2f0f:	89 c3                	mov    %eax,%ebx
    2f11:	85 c0                	test   %eax,%eax
    2f13:	74 41                	je     2f56 <validatetest+0x74>
      // try to crash the kernel by passing in a badly placed integer
      validateint((int*)p);
      exit();
    }
    sleep(0);
    2f15:	83 ec 0c             	sub    $0xc,%esp
    2f18:	6a 00                	push   $0x0
    2f1a:	e8 00 08 00 00       	call   371f <sleep>
    sleep(0);
    2f1f:	c7 04 24 00 00 00 00 	movl   $0x0,(%esp)
    2f26:	e8 f4 07 00 00       	call   371f <sleep>
    kill(pid);
    2f2b:	89 1c 24             	mov    %ebx,(%esp)
    2f2e:	e8 8c 07 00 00       	call   36bf <kill>
    wait();
    2f33:	e8 5f 07 00 00       	call   3697 <wait>

    // try to crash the kernel by passing in a bad string pointer
    if(link("nosuchfile", (char*)p) != -1){
    2f38:	83 c4 08             	add    $0x8,%esp
    2f3b:	56                   	push   %esi
    2f3c:	68 2d 49 00 00       	push   $0x492d
    2f41:	e8 a9 07 00 00       	call   36ef <link>
    2f46:	83 c4 10             	add    $0x10,%esp
    2f49:	83 f8 ff             	cmp    $0xffffffff,%eax
    2f4c:	75 0d                	jne    2f5b <validatetest+0x79>
  for(p = 0; p <= (uint)hi; p += 4096){
    2f4e:	81 c6 00 10 00 00    	add    $0x1000,%esi
    2f54:	eb ac                	jmp    2f02 <validatetest+0x20>
      exit();
    2f56:	e8 34 07 00 00       	call   368f <exit>
      printf(stdout, "link should not succeed\n");
    2f5b:	83 ec 08             	sub    $0x8,%esp
    2f5e:	68 38 49 00 00       	push   $0x4938
    2f63:	ff 35 20 5b 00 00    	push   0x5b20
    2f69:	e8 64 08 00 00       	call   37d2 <printf>
      exit();
    2f6e:	e8 1c 07 00 00       	call   368f <exit>
    }
  }

  printf(stdout, "validate ok\n");
    2f73:	83 ec 08             	sub    $0x8,%esp
    2f76:	68 51 49 00 00       	push   $0x4951
    2f7b:	ff 35 20 5b 00 00    	push   0x5b20
    2f81:	e8 4c 08 00 00       	call   37d2 <printf>
}
    2f86:	83 c4 10             	add    $0x10,%esp
    2f89:	8d 65 f8             	lea    -0x8(%ebp),%esp
    2f8c:	5b                   	pop    %ebx
    2f8d:	5e                   	pop    %esi
    2f8e:	5d                   	pop    %ebp
    2f8f:	c3                   	ret    

00002f90 <bsstest>:

// does unintialized data start out zero?
char uninit[10000];
void
bsstest(void)
{
    2f90:	55                   	push   %ebp
    2f91:	89 e5                	mov    %esp,%ebp
    2f93:	83 ec 10             	sub    $0x10,%esp
  int i;

  printf(stdout, "bss test\n");
    2f96:	68 5e 49 00 00       	push   $0x495e
    2f9b:	ff 35 20 5b 00 00    	push   0x5b20
    2fa1:	e8 2c 08 00 00       	call   37d2 <printf>
  for(i = 0; i < sizeof(uninit); i++){
    2fa6:	83 c4 10             	add    $0x10,%esp
    2fa9:	b8 00 00 00 00       	mov    $0x0,%eax
    2fae:	3d 0f 27 00 00       	cmp    $0x270f,%eax
    2fb3:	77 24                	ja     2fd9 <bsstest+0x49>
    if(uninit[i] != '\0'){
    2fb5:	80 b8 40 5b 00 00 00 	cmpb   $0x0,0x5b40(%eax)
    2fbc:	75 03                	jne    2fc1 <bsstest+0x31>
  for(i = 0; i < sizeof(uninit); i++){
    2fbe:	40                   	inc    %eax
    2fbf:	eb ed                	jmp    2fae <bsstest+0x1e>
      printf(stdout, "bss test failed\n");
    2fc1:	83 ec 08             	sub    $0x8,%esp
    2fc4:	68 68 49 00 00       	push   $0x4968
    2fc9:	ff 35 20 5b 00 00    	push   0x5b20
    2fcf:	e8 fe 07 00 00       	call   37d2 <printf>
      exit();
    2fd4:	e8 b6 06 00 00       	call   368f <exit>
    }
  }
  printf(stdout, "bss test ok\n");
    2fd9:	83 ec 08             	sub    $0x8,%esp
    2fdc:	68 79 49 00 00       	push   $0x4979
    2fe1:	ff 35 20 5b 00 00    	push   0x5b20
    2fe7:	e8 e6 07 00 00       	call   37d2 <printf>
}
    2fec:	83 c4 10             	add    $0x10,%esp
    2fef:	c9                   	leave  
    2ff0:	c3                   	ret    

00002ff1 <bigargtest>:
// does exec return an error if the arguments
// are larger than a page? or does it write
// below the stack and wreck the instructions/data?
void
bigargtest(void)
{
    2ff1:	55                   	push   %ebp
    2ff2:	89 e5                	mov    %esp,%ebp
    2ff4:	83 ec 14             	sub    $0x14,%esp
  int pid, fd;

  unlink("bigarg-ok");
    2ff7:	68 86 49 00 00       	push   $0x4986
    2ffc:	e8 de 06 00 00       	call   36df <unlink>
  pid = fork();
    3001:	e8 81 06 00 00       	call   3687 <fork>
  if(pid == 0){
    3006:	83 c4 10             	add    $0x10,%esp
    3009:	85 c0                	test   %eax,%eax
    300b:	74 4b                	je     3058 <bigargtest+0x67>
    exec("echo", args);
    printf(stdout, "bigarg test ok\n");
    fd = open("bigarg-ok", O_CREATE);
    close(fd);
    exit();
  } else if(pid < 0){
    300d:	0f 88 ab 00 00 00    	js     30be <bigargtest+0xcd>
    printf(stdout, "bigargtest: fork failed\n");
    exit();
  }
  wait();
    3013:	e8 7f 06 00 00       	call   3697 <wait>
  fd = open("bigarg-ok", 0);
    3018:	83 ec 08             	sub    $0x8,%esp
    301b:	6a 00                	push   $0x0
    301d:	68 86 49 00 00       	push   $0x4986
    3022:	e8 a8 06 00 00       	call   36cf <open>
  if(fd < 0){
    3027:	83 c4 10             	add    $0x10,%esp
    302a:	85 c0                	test   %eax,%eax
    302c:	0f 88 a4 00 00 00    	js     30d6 <bigargtest+0xe5>
    printf(stdout, "bigarg test failed!\n");
    exit();
  }
  close(fd);
    3032:	83 ec 0c             	sub    $0xc,%esp
    3035:	50                   	push   %eax
    3036:	e8 7c 06 00 00       	call   36b7 <close>
  unlink("bigarg-ok");
    303b:	c7 04 24 86 49 00 00 	movl   $0x4986,(%esp)
    3042:	e8 98 06 00 00       	call   36df <unlink>
}
    3047:	83 c4 10             	add    $0x10,%esp
    304a:	c9                   	leave  
    304b:	c3                   	ret    
      args[i] = "bigargs test: failed\n                                                                                                                                                                                                       ";
    304c:	c7 04 85 60 a2 00 00 	movl   $0x50e0,0xa260(,%eax,4)
    3053:	e0 50 00 00 
    for(i = 0; i < MAXARG-1; i++)
    3057:	40                   	inc    %eax
    3058:	83 f8 1e             	cmp    $0x1e,%eax
    305b:	7e ef                	jle    304c <bigargtest+0x5b>
    args[MAXARG-1] = 0;
    305d:	c7 05 dc a2 00 00 00 	movl   $0x0,0xa2dc
    3064:	00 00 00 
    printf(stdout, "bigarg test\n");
    3067:	83 ec 08             	sub    $0x8,%esp
    306a:	68 90 49 00 00       	push   $0x4990
    306f:	ff 35 20 5b 00 00    	push   0x5b20
    3075:	e8 58 07 00 00       	call   37d2 <printf>
    exec("echo", args);
    307a:	83 c4 08             	add    $0x8,%esp
    307d:	68 60 a2 00 00       	push   $0xa260
    3082:	68 5d 3b 00 00       	push   $0x3b5d
    3087:	e8 3b 06 00 00       	call   36c7 <exec>
    printf(stdout, "bigarg test ok\n");
    308c:	83 c4 08             	add    $0x8,%esp
    308f:	68 9d 49 00 00       	push   $0x499d
    3094:	ff 35 20 5b 00 00    	push   0x5b20
    309a:	e8 33 07 00 00       	call   37d2 <printf>
    fd = open("bigarg-ok", O_CREATE);
    309f:	83 c4 08             	add    $0x8,%esp
    30a2:	68 00 02 00 00       	push   $0x200
    30a7:	68 86 49 00 00       	push   $0x4986
    30ac:	e8 1e 06 00 00       	call   36cf <open>
    close(fd);
    30b1:	89 04 24             	mov    %eax,(%esp)
    30b4:	e8 fe 05 00 00       	call   36b7 <close>
    exit();
    30b9:	e8 d1 05 00 00       	call   368f <exit>
    printf(stdout, "bigargtest: fork failed\n");
    30be:	83 ec 08             	sub    $0x8,%esp
    30c1:	68 ad 49 00 00       	push   $0x49ad
    30c6:	ff 35 20 5b 00 00    	push   0x5b20
    30cc:	e8 01 07 00 00       	call   37d2 <printf>
    exit();
    30d1:	e8 b9 05 00 00       	call   368f <exit>
    printf(stdout, "bigarg test failed!\n");
    30d6:	83 ec 08             	sub    $0x8,%esp
    30d9:	68 c6 49 00 00       	push   $0x49c6
    30de:	ff 35 20 5b 00 00    	push   0x5b20
    30e4:	e8 e9 06 00 00       	call   37d2 <printf>
    exit();
    30e9:	e8 a1 05 00 00       	call   368f <exit>

000030ee <fsfull>:

// what happens when the file system runs out of blocks?
// answer: balloc panics, so this test is not useful.
void
fsfull()
{
    30ee:	55                   	push   %ebp
    30ef:	89 e5                	mov    %esp,%ebp
    30f1:	57                   	push   %edi
    30f2:	56                   	push   %esi
    30f3:	53                   	push   %ebx
    30f4:	83 ec 54             	sub    $0x54,%esp
  int nfiles;
  int fsblocks = 0;

  printf(1, "fsfull test\n");
    30f7:	68 db 49 00 00       	push   $0x49db
    30fc:	6a 01                	push   $0x1
    30fe:	e8 cf 06 00 00       	call   37d2 <printf>
    3103:	83 c4 10             	add    $0x10,%esp

  for(nfiles = 0; ; nfiles++){
    3106:	bb 00 00 00 00       	mov    $0x0,%ebx
    char name[64];
    name[0] = 'f';
    310b:	c6 45 a8 66          	movb   $0x66,-0x58(%ebp)
    name[1] = '0' + nfiles / 1000;
    310f:	b8 d3 4d 62 10       	mov    $0x10624dd3,%eax
    3114:	f7 eb                	imul   %ebx
    3116:	89 d0                	mov    %edx,%eax
    3118:	c1 f8 06             	sar    $0x6,%eax
    311b:	89 de                	mov    %ebx,%esi
    311d:	c1 fe 1f             	sar    $0x1f,%esi
    3120:	29 f0                	sub    %esi,%eax
    3122:	8d 50 30             	lea    0x30(%eax),%edx
    3125:	88 55 a9             	mov    %dl,-0x57(%ebp)
    name[2] = '0' + (nfiles % 1000) / 100;
    3128:	8d 04 80             	lea    (%eax,%eax,4),%eax
    312b:	8d 04 80             	lea    (%eax,%eax,4),%eax
    312e:	8d 04 80             	lea    (%eax,%eax,4),%eax
    3131:	c1 e0 03             	shl    $0x3,%eax
    3134:	89 df                	mov    %ebx,%edi
    3136:	29 c7                	sub    %eax,%edi
    3138:	b9 1f 85 eb 51       	mov    $0x51eb851f,%ecx
    313d:	89 f8                	mov    %edi,%eax
    313f:	f7 e9                	imul   %ecx
    3141:	c1 fa 05             	sar    $0x5,%edx
    3144:	c1 ff 1f             	sar    $0x1f,%edi
    3147:	29 fa                	sub    %edi,%edx
    3149:	83 c2 30             	add    $0x30,%edx
    314c:	88 55 aa             	mov    %dl,-0x56(%ebp)
    name[3] = '0' + (nfiles % 100) / 10;
    314f:	89 c8                	mov    %ecx,%eax
    3151:	f7 eb                	imul   %ebx
    3153:	89 d1                	mov    %edx,%ecx
    3155:	c1 f9 05             	sar    $0x5,%ecx
    3158:	29 f1                	sub    %esi,%ecx
    315a:	8d 04 89             	lea    (%ecx,%ecx,4),%eax
    315d:	8d 04 80             	lea    (%eax,%eax,4),%eax
    3160:	c1 e0 02             	shl    $0x2,%eax
    3163:	89 d9                	mov    %ebx,%ecx
    3165:	29 c1                	sub    %eax,%ecx
    3167:	bf 67 66 66 66       	mov    $0x66666667,%edi
    316c:	89 c8                	mov    %ecx,%eax
    316e:	f7 ef                	imul   %edi
    3170:	89 d0                	mov    %edx,%eax
    3172:	c1 f8 02             	sar    $0x2,%eax
    3175:	c1 f9 1f             	sar    $0x1f,%ecx
    3178:	29 c8                	sub    %ecx,%eax
    317a:	83 c0 30             	add    $0x30,%eax
    317d:	88 45 ab             	mov    %al,-0x55(%ebp)
    name[4] = '0' + (nfiles % 10);
    3180:	89 f8                	mov    %edi,%eax
    3182:	f7 eb                	imul   %ebx
    3184:	89 d0                	mov    %edx,%eax
    3186:	c1 f8 02             	sar    $0x2,%eax
    3189:	29 f0                	sub    %esi,%eax
    318b:	8d 04 80             	lea    (%eax,%eax,4),%eax
    318e:	8d 14 00             	lea    (%eax,%eax,1),%edx
    3191:	89 d8                	mov    %ebx,%eax
    3193:	29 d0                	sub    %edx,%eax
    3195:	83 c0 30             	add    $0x30,%eax
    3198:	88 45 ac             	mov    %al,-0x54(%ebp)
    name[5] = '\0';
    319b:	c6 45 ad 00          	movb   $0x0,-0x53(%ebp)
    printf(1, "writing %s\n", name);
    319f:	83 ec 04             	sub    $0x4,%esp
    31a2:	8d 75 a8             	lea    -0x58(%ebp),%esi
    31a5:	56                   	push   %esi
    31a6:	68 e8 49 00 00       	push   $0x49e8
    31ab:	6a 01                	push   $0x1
    31ad:	e8 20 06 00 00       	call   37d2 <printf>
    int fd = open(name, O_CREATE|O_RDWR);
    31b2:	83 c4 08             	add    $0x8,%esp
    31b5:	68 02 02 00 00       	push   $0x202
    31ba:	56                   	push   %esi
    31bb:	e8 0f 05 00 00       	call   36cf <open>
    31c0:	89 c6                	mov    %eax,%esi
    if(fd < 0){
    31c2:	83 c4 10             	add    $0x10,%esp
    31c5:	85 c0                	test   %eax,%eax
    31c7:	79 1b                	jns    31e4 <fsfull+0xf6>
      printf(1, "open %s failed\n", name);
    31c9:	83 ec 04             	sub    $0x4,%esp
    31cc:	8d 45 a8             	lea    -0x58(%ebp),%eax
    31cf:	50                   	push   %eax
    31d0:	68 f4 49 00 00       	push   $0x49f4
    31d5:	6a 01                	push   $0x1
    31d7:	e8 f6 05 00 00       	call   37d2 <printf>
      break;
    31dc:	83 c4 10             	add    $0x10,%esp
    31df:	e9 f3 00 00 00       	jmp    32d7 <fsfull+0x1e9>
    }
    int total = 0;
    31e4:	bf 00 00 00 00       	mov    $0x0,%edi
    while(1){
      int cc = write(fd, buf, 512);
    31e9:	83 ec 04             	sub    $0x4,%esp
    31ec:	68 00 02 00 00       	push   $0x200
    31f1:	68 60 82 00 00       	push   $0x8260
    31f6:	56                   	push   %esi
    31f7:	e8 b3 04 00 00       	call   36af <write>
      if(cc < 512)
    31fc:	83 c4 10             	add    $0x10,%esp
    31ff:	3d ff 01 00 00       	cmp    $0x1ff,%eax
    3204:	7e 04                	jle    320a <fsfull+0x11c>
        break;
      total += cc;
    3206:	01 c7                	add    %eax,%edi
    while(1){
    3208:	eb df                	jmp    31e9 <fsfull+0xfb>
      fsblocks++;
    }
    printf(1, "wrote %d bytes\n", total);
    320a:	83 ec 04             	sub    $0x4,%esp
    320d:	57                   	push   %edi
    320e:	68 04 4a 00 00       	push   $0x4a04
    3213:	6a 01                	push   $0x1
    3215:	e8 b8 05 00 00       	call   37d2 <printf>
    close(fd);
    321a:	89 34 24             	mov    %esi,(%esp)
    321d:	e8 95 04 00 00       	call   36b7 <close>
    if(total == 0)
    3222:	83 c4 10             	add    $0x10,%esp
    3225:	85 ff                	test   %edi,%edi
    3227:	0f 84 aa 00 00 00    	je     32d7 <fsfull+0x1e9>
  for(nfiles = 0; ; nfiles++){
    322d:	43                   	inc    %ebx
    322e:	e9 d8 fe ff ff       	jmp    310b <fsfull+0x1d>
      break;
  }

  while(nfiles >= 0){
    char name[64];
    name[0] = 'f';
    3233:	c6 45 a8 66          	movb   $0x66,-0x58(%ebp)
    name[1] = '0' + nfiles / 1000;
    3237:	b8 d3 4d 62 10       	mov    $0x10624dd3,%eax
    323c:	f7 eb                	imul   %ebx
    323e:	89 d0                	mov    %edx,%eax
    3240:	c1 f8 06             	sar    $0x6,%eax
    3243:	89 de                	mov    %ebx,%esi
    3245:	c1 fe 1f             	sar    $0x1f,%esi
    3248:	29 f0                	sub    %esi,%eax
    324a:	8d 50 30             	lea    0x30(%eax),%edx
    324d:	88 55 a9             	mov    %dl,-0x57(%ebp)
    name[2] = '0' + (nfiles % 1000) / 100;
    3250:	8d 04 80             	lea    (%eax,%eax,4),%eax
    3253:	8d 04 80             	lea    (%eax,%eax,4),%eax
    3256:	8d 04 80             	lea    (%eax,%eax,4),%eax
    3259:	c1 e0 03             	shl    $0x3,%eax
    325c:	89 df                	mov    %ebx,%edi
    325e:	29 c7                	sub    %eax,%edi
    3260:	b9 1f 85 eb 51       	mov    $0x51eb851f,%ecx
    3265:	89 f8                	mov    %edi,%eax
    3267:	f7 e9                	imul   %ecx
    3269:	c1 fa 05             	sar    $0x5,%edx
    326c:	c1 ff 1f             	sar    $0x1f,%edi
    326f:	29 fa                	sub    %edi,%edx
    3271:	83 c2 30             	add    $0x30,%edx
    3274:	88 55 aa             	mov    %dl,-0x56(%ebp)
    name[3] = '0' + (nfiles % 100) / 10;
    3277:	89 c8                	mov    %ecx,%eax
    3279:	f7 eb                	imul   %ebx
    327b:	89 d1                	mov    %edx,%ecx
    327d:	c1 f9 05             	sar    $0x5,%ecx
    3280:	29 f1                	sub    %esi,%ecx
    3282:	8d 04 89             	lea    (%ecx,%ecx,4),%eax
    3285:	8d 04 80             	lea    (%eax,%eax,4),%eax
    3288:	c1 e0 02             	shl    $0x2,%eax
    328b:	89 d9                	mov    %ebx,%ecx
    328d:	29 c1                	sub    %eax,%ecx
    328f:	bf 67 66 66 66       	mov    $0x66666667,%edi
    3294:	89 c8                	mov    %ecx,%eax
    3296:	f7 ef                	imul   %edi
    3298:	89 d0                	mov    %edx,%eax
    329a:	c1 f8 02             	sar    $0x2,%eax
    329d:	c1 f9 1f             	sar    $0x1f,%ecx
    32a0:	29 c8                	sub    %ecx,%eax
    32a2:	83 c0 30             	add    $0x30,%eax
    32a5:	88 45 ab             	mov    %al,-0x55(%ebp)
    name[4] = '0' + (nfiles % 10);
    32a8:	89 f8                	mov    %edi,%eax
    32aa:	f7 eb                	imul   %ebx
    32ac:	89 d0                	mov    %edx,%eax
    32ae:	c1 f8 02             	sar    $0x2,%eax
    32b1:	29 f0                	sub    %esi,%eax
    32b3:	8d 04 80             	lea    (%eax,%eax,4),%eax
    32b6:	8d 14 00             	lea    (%eax,%eax,1),%edx
    32b9:	89 d8                	mov    %ebx,%eax
    32bb:	29 d0                	sub    %edx,%eax
    32bd:	83 c0 30             	add    $0x30,%eax
    32c0:	88 45 ac             	mov    %al,-0x54(%ebp)
    name[5] = '\0';
    32c3:	c6 45 ad 00          	movb   $0x0,-0x53(%ebp)
    unlink(name);
    32c7:	83 ec 0c             	sub    $0xc,%esp
    32ca:	8d 45 a8             	lea    -0x58(%ebp),%eax
    32cd:	50                   	push   %eax
    32ce:	e8 0c 04 00 00       	call   36df <unlink>
    nfiles--;
    32d3:	4b                   	dec    %ebx
    32d4:	83 c4 10             	add    $0x10,%esp
  while(nfiles >= 0){
    32d7:	85 db                	test   %ebx,%ebx
    32d9:	0f 89 54 ff ff ff    	jns    3233 <fsfull+0x145>
  }

  printf(1, "fsfull test finished\n");
    32df:	83 ec 08             	sub    $0x8,%esp
    32e2:	68 14 4a 00 00       	push   $0x4a14
    32e7:	6a 01                	push   $0x1
    32e9:	e8 e4 04 00 00       	call   37d2 <printf>
}
    32ee:	83 c4 10             	add    $0x10,%esp
    32f1:	8d 65 f4             	lea    -0xc(%ebp),%esp
    32f4:	5b                   	pop    %ebx
    32f5:	5e                   	pop    %esi
    32f6:	5f                   	pop    %edi
    32f7:	5d                   	pop    %ebp
    32f8:	c3                   	ret    

000032f9 <uio>:

void
uio()
{
    32f9:	55                   	push   %ebp
    32fa:	89 e5                	mov    %esp,%ebp
    32fc:	83 ec 10             	sub    $0x10,%esp

  ushort port = 0;
  uchar val = 0;
  int pid;

  printf(1, "uio test\n");
    32ff:	68 2a 4a 00 00       	push   $0x4a2a
    3304:	6a 01                	push   $0x1
    3306:	e8 c7 04 00 00       	call   37d2 <printf>
  pid = fork();
    330b:	e8 77 03 00 00       	call   3687 <fork>
  if(pid == 0){
    3310:	83 c4 10             	add    $0x10,%esp
    3313:	85 c0                	test   %eax,%eax
    3315:	74 1b                	je     3332 <uio+0x39>
    asm volatile("outb %0,%1"::"a"(val), "d" (port));
    port = RTC_DATA;
    asm volatile("inb %1,%0" : "=a" (val) : "d" (port));
    printf(1, "uio: uio succeeded; test FAILED\n");
    exit();
  } else if(pid < 0){
    3317:	78 3b                	js     3354 <uio+0x5b>
    printf (1, "fork failed\n");
    exit();
  }
  wait();
    3319:	e8 79 03 00 00       	call   3697 <wait>
  printf(1, "uio test done\n");
    331e:	83 ec 08             	sub    $0x8,%esp
    3321:	68 34 4a 00 00       	push   $0x4a34
    3326:	6a 01                	push   $0x1
    3328:	e8 a5 04 00 00       	call   37d2 <printf>
}
    332d:	83 c4 10             	add    $0x10,%esp
    3330:	c9                   	leave  
    3331:	c3                   	ret    
    asm volatile("outb %0,%1"::"a"(val), "d" (port));
    3332:	b0 09                	mov    $0x9,%al
    3334:	ba 70 00 00 00       	mov    $0x70,%edx
    3339:	ee                   	out    %al,(%dx)
    asm volatile("inb %1,%0" : "=a" (val) : "d" (port));
    333a:	ba 71 00 00 00       	mov    $0x71,%edx
    333f:	ec                   	in     (%dx),%al
    printf(1, "uio: uio succeeded; test FAILED\n");
    3340:	83 ec 08             	sub    $0x8,%esp
    3343:	68 c0 51 00 00       	push   $0x51c0
    3348:	6a 01                	push   $0x1
    334a:	e8 83 04 00 00       	call   37d2 <printf>
    exit();
    334f:	e8 3b 03 00 00       	call   368f <exit>
    printf (1, "fork failed\n");
    3354:	83 ec 08             	sub    $0x8,%esp
    3357:	68 b9 49 00 00       	push   $0x49b9
    335c:	6a 01                	push   $0x1
    335e:	e8 6f 04 00 00       	call   37d2 <printf>
    exit();
    3363:	e8 27 03 00 00       	call   368f <exit>

00003368 <argptest>:

void argptest()
{
    3368:	55                   	push   %ebp
    3369:	89 e5                	mov    %esp,%ebp
    336b:	53                   	push   %ebx
    336c:	83 ec 0c             	sub    $0xc,%esp
  int fd;
  fd = open("init", O_RDONLY);
    336f:	6a 00                	push   $0x0
    3371:	68 43 4a 00 00       	push   $0x4a43
    3376:	e8 54 03 00 00       	call   36cf <open>
  if (fd < 0) {
    337b:	83 c4 10             	add    $0x10,%esp
    337e:	85 c0                	test   %eax,%eax
    3380:	78 38                	js     33ba <argptest+0x52>
    3382:	89 c3                	mov    %eax,%ebx
    printf(2, "open failed\n");
    exit();
  }
  read(fd, sbrk(0) - 1, -1);
    3384:	83 ec 0c             	sub    $0xc,%esp
    3387:	6a 00                	push   $0x0
    3389:	e8 89 03 00 00       	call   3717 <sbrk>
    338e:	48                   	dec    %eax
    338f:	83 c4 0c             	add    $0xc,%esp
    3392:	6a ff                	push   $0xffffffff
    3394:	50                   	push   %eax
    3395:	53                   	push   %ebx
    3396:	e8 0c 03 00 00       	call   36a7 <read>
  close(fd);
    339b:	89 1c 24             	mov    %ebx,(%esp)
    339e:	e8 14 03 00 00       	call   36b7 <close>
  printf(1, "arg test passed\n");
    33a3:	83 c4 08             	add    $0x8,%esp
    33a6:	68 55 4a 00 00       	push   $0x4a55
    33ab:	6a 01                	push   $0x1
    33ad:	e8 20 04 00 00       	call   37d2 <printf>
}
    33b2:	83 c4 10             	add    $0x10,%esp
    33b5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    33b8:	c9                   	leave  
    33b9:	c3                   	ret    
    printf(2, "open failed\n");
    33ba:	83 ec 08             	sub    $0x8,%esp
    33bd:	68 48 4a 00 00       	push   $0x4a48
    33c2:	6a 02                	push   $0x2
    33c4:	e8 09 04 00 00       	call   37d2 <printf>
    exit();
    33c9:	e8 c1 02 00 00       	call   368f <exit>

000033ce <rand>:

unsigned long randstate = 1;
unsigned int
rand()
{
  randstate = randstate * 1664525 + 1013904223;
    33ce:	a1 1c 5b 00 00       	mov    0x5b1c,%eax
    33d3:	8d 14 00             	lea    (%eax,%eax,1),%edx
    33d6:	01 c2                	add    %eax,%edx
    33d8:	8d 0c 90             	lea    (%eax,%edx,4),%ecx
    33db:	c1 e1 08             	shl    $0x8,%ecx
    33de:	89 ca                	mov    %ecx,%edx
    33e0:	01 c2                	add    %eax,%edx
    33e2:	8d 14 92             	lea    (%edx,%edx,4),%edx
    33e5:	8d 04 90             	lea    (%eax,%edx,4),%eax
    33e8:	8d 04 80             	lea    (%eax,%eax,4),%eax
    33eb:	8d 84 80 5f f3 6e 3c 	lea    0x3c6ef35f(%eax,%eax,4),%eax
    33f2:	a3 1c 5b 00 00       	mov    %eax,0x5b1c
  return randstate;
}
    33f7:	c3                   	ret    

000033f8 <main>:

int
main(int argc, char *argv[])
{
    33f8:	8d 4c 24 04          	lea    0x4(%esp),%ecx
    33fc:	83 e4 f0             	and    $0xfffffff0,%esp
    33ff:	ff 71 fc             	push   -0x4(%ecx)
    3402:	55                   	push   %ebp
    3403:	89 e5                	mov    %esp,%ebp
    3405:	51                   	push   %ecx
    3406:	83 ec 0c             	sub    $0xc,%esp
  printf(1, "usertests starting\n");
    3409:	68 66 4a 00 00       	push   $0x4a66
    340e:	6a 01                	push   $0x1
    3410:	e8 bd 03 00 00       	call   37d2 <printf>

  if(open("usertests.ran", 0) >= 0){
    3415:	83 c4 08             	add    $0x8,%esp
    3418:	6a 00                	push   $0x0
    341a:	68 7a 4a 00 00       	push   $0x4a7a
    341f:	e8 ab 02 00 00       	call   36cf <open>
    3424:	83 c4 10             	add    $0x10,%esp
    3427:	85 c0                	test   %eax,%eax
    3429:	78 14                	js     343f <main+0x47>
    printf(1, "already ran user tests -- rebuild fs.img\n");
    342b:	83 ec 08             	sub    $0x8,%esp
    342e:	68 e4 51 00 00       	push   $0x51e4
    3433:	6a 01                	push   $0x1
    3435:	e8 98 03 00 00       	call   37d2 <printf>
    exit();
    343a:	e8 50 02 00 00       	call   368f <exit>
  }
  close(open("usertests.ran", O_CREATE));
    343f:	83 ec 08             	sub    $0x8,%esp
    3442:	68 00 02 00 00       	push   $0x200
    3447:	68 7a 4a 00 00       	push   $0x4a7a
    344c:	e8 7e 02 00 00       	call   36cf <open>
    3451:	89 04 24             	mov    %eax,(%esp)
    3454:	e8 5e 02 00 00       	call   36b7 <close>

  argptest();
    3459:	e8 0a ff ff ff       	call   3368 <argptest>
  createdelete();
    345e:	e8 74 db ff ff       	call   fd7 <createdelete>
  linkunlink();
    3463:	e8 b0 e3 ff ff       	call   1818 <linkunlink>
  concreate();
    3468:	e8 09 e1 ff ff       	call   1576 <concreate>
  fourfiles();
    346d:	e8 99 d9 ff ff       	call   e0b <fourfiles>
  sharedfd();
    3472:	e8 08 d8 ff ff       	call   c7f <sharedfd>

  bigargtest();
    3477:	e8 75 fb ff ff       	call   2ff1 <bigargtest>
  bigwrite();
    347c:	e8 23 ed ff ff       	call   21a4 <bigwrite>
  bigargtest();
    3481:	e8 6b fb ff ff       	call   2ff1 <bigargtest>
  bsstest();
    3486:	e8 05 fb ff ff       	call   2f90 <bsstest>
  sbrktest();
    348b:	e8 40 f6 ff ff       	call   2ad0 <sbrktest>
  validatetest();
    3490:	e8 4d fa ff ff       	call   2ee2 <validatetest>

  opentest();
    3495:	e8 12 ce ff ff       	call   2ac <opentest>
  writetest();
    349a:	e8 a0 ce ff ff       	call   33f <writetest>
  writetest1();
    349f:	e8 61 d0 ff ff       	call   505 <writetest1>
  createtest();
    34a4:	e8 08 d2 ff ff       	call   6b1 <createtest>

  openiputtest();
    34a9:	e8 15 cd ff ff       	call   1c3 <openiputtest>
  exitiputtest();
    34ae:	e8 2a cc ff ff       	call   dd <exitiputtest>
  iputtest();
    34b3:	e8 48 cb ff ff       	call   0 <iputtest>

  mem();
    34b8:	e8 07 d7 ff ff       	call   bc4 <mem>
  pipe1();
    34bd:	e8 bd d3 ff ff       	call   87f <pipe1>
  preempt();
    34c2:	e8 54 d5 ff ff       	call   a1b <preempt>
  exitwait();
    34c7:	e8 8a d6 ff ff       	call   b56 <exitwait>

  rmdot();
    34cc:	e8 92 f0 ff ff       	call   2563 <rmdot>
  fourteen();
    34d1:	e8 50 ef ff ff       	call   2426 <fourteen>
  bigfile();
    34d6:	e8 99 ed ff ff       	call   2274 <bigfile>
  subdir();
    34db:	e8 96 e5 ff ff       	call   1a76 <subdir>
  linktest();
    34e0:	e8 6b de ff ff       	call   1350 <linktest>
  unlinkread();
    34e5:	e8 cd dc ff ff       	call   11b7 <unlinkread>
  dirfile();
    34ea:	e8 f9 f1 ff ff       	call   26e8 <dirfile>
  iref();
    34ef:	e8 0e f4 ff ff       	call   2902 <iref>
  forktest();
    34f4:	e8 2c f5 ff ff       	call   2a25 <forktest>
  bigdir(); // slow
    34f9:	e8 22 e4 ff ff       	call   1920 <bigdir>

  uio();
    34fe:	e8 f6 fd ff ff       	call   32f9 <uio>

  exectest();
    3503:	e8 2e d3 ff ff       	call   836 <exectest>

  exit();
    3508:	e8 82 01 00 00       	call   368f <exit>

0000350d <start>:

// Entry point of the library	
void
start()
{
}
    350d:	c3                   	ret    

0000350e <strcpy>:

char*
strcpy(char *s, const char *t)
{
    350e:	55                   	push   %ebp
    350f:	89 e5                	mov    %esp,%ebp
    3511:	56                   	push   %esi
    3512:	53                   	push   %ebx
    3513:	8b 45 08             	mov    0x8(%ebp),%eax
    3516:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
    3519:	89 c2                	mov    %eax,%edx
    351b:	89 cb                	mov    %ecx,%ebx
    351d:	41                   	inc    %ecx
    351e:	89 d6                	mov    %edx,%esi
    3520:	42                   	inc    %edx
    3521:	8a 1b                	mov    (%ebx),%bl
    3523:	88 1e                	mov    %bl,(%esi)
    3525:	84 db                	test   %bl,%bl
    3527:	75 f2                	jne    351b <strcpy+0xd>
    ;
  return os;
}
    3529:	5b                   	pop    %ebx
    352a:	5e                   	pop    %esi
    352b:	5d                   	pop    %ebp
    352c:	c3                   	ret    

0000352d <strcmp>:

int
strcmp(const char *p, const char *q)
{
    352d:	55                   	push   %ebp
    352e:	89 e5                	mov    %esp,%ebp
    3530:	8b 4d 08             	mov    0x8(%ebp),%ecx
    3533:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
    3536:	eb 02                	jmp    353a <strcmp+0xd>
    p++, q++;
    3538:	41                   	inc    %ecx
    3539:	42                   	inc    %edx
  while(*p && *p == *q)
    353a:	8a 01                	mov    (%ecx),%al
    353c:	84 c0                	test   %al,%al
    353e:	74 04                	je     3544 <strcmp+0x17>
    3540:	3a 02                	cmp    (%edx),%al
    3542:	74 f4                	je     3538 <strcmp+0xb>
  return (uchar)*p - (uchar)*q;
    3544:	0f b6 c0             	movzbl %al,%eax
    3547:	0f b6 12             	movzbl (%edx),%edx
    354a:	29 d0                	sub    %edx,%eax
}
    354c:	5d                   	pop    %ebp
    354d:	c3                   	ret    

0000354e <strlen>:

uint
strlen(const char *s)
{
    354e:	55                   	push   %ebp
    354f:	89 e5                	mov    %esp,%ebp
    3551:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
    3554:	b8 00 00 00 00       	mov    $0x0,%eax
    3559:	eb 01                	jmp    355c <strlen+0xe>
    355b:	40                   	inc    %eax
    355c:	80 3c 01 00          	cmpb   $0x0,(%ecx,%eax,1)
    3560:	75 f9                	jne    355b <strlen+0xd>
    ;
  return n;
}
    3562:	5d                   	pop    %ebp
    3563:	c3                   	ret    

00003564 <memset>:

void*
memset(void *dst, int c, uint n)
{
    3564:	55                   	push   %ebp
    3565:	89 e5                	mov    %esp,%ebp
    3567:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
    3568:	8b 7d 08             	mov    0x8(%ebp),%edi
    356b:	8b 4d 10             	mov    0x10(%ebp),%ecx
    356e:	8b 45 0c             	mov    0xc(%ebp),%eax
    3571:	fc                   	cld    
    3572:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
    3574:	8b 45 08             	mov    0x8(%ebp),%eax
    3577:	8b 7d fc             	mov    -0x4(%ebp),%edi
    357a:	c9                   	leave  
    357b:	c3                   	ret    

0000357c <strchr>:

char*
strchr(const char *s, char c)
{
    357c:	55                   	push   %ebp
    357d:	89 e5                	mov    %esp,%ebp
    357f:	8b 45 08             	mov    0x8(%ebp),%eax
    3582:	8a 4d 0c             	mov    0xc(%ebp),%cl
  for(; *s; s++)
    3585:	eb 01                	jmp    3588 <strchr+0xc>
    3587:	40                   	inc    %eax
    3588:	8a 10                	mov    (%eax),%dl
    358a:	84 d2                	test   %dl,%dl
    358c:	74 06                	je     3594 <strchr+0x18>
    if(*s == c)
    358e:	38 ca                	cmp    %cl,%dl
    3590:	75 f5                	jne    3587 <strchr+0xb>
    3592:	eb 05                	jmp    3599 <strchr+0x1d>
      return (char*)s;
  return 0;
    3594:	b8 00 00 00 00       	mov    $0x0,%eax
}
    3599:	5d                   	pop    %ebp
    359a:	c3                   	ret    

0000359b <gets>:

char*
gets(char *buf, int max)
{
    359b:	55                   	push   %ebp
    359c:	89 e5                	mov    %esp,%ebp
    359e:	57                   	push   %edi
    359f:	56                   	push   %esi
    35a0:	53                   	push   %ebx
    35a1:	83 ec 1c             	sub    $0x1c,%esp
    35a4:	8b 7d 08             	mov    0x8(%ebp),%edi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    35a7:	bb 00 00 00 00       	mov    $0x0,%ebx
    35ac:	89 de                	mov    %ebx,%esi
    35ae:	43                   	inc    %ebx
    35af:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
    35b2:	7d 2b                	jge    35df <gets+0x44>
    cc = read(0, &c, 1);
    35b4:	83 ec 04             	sub    $0x4,%esp
    35b7:	6a 01                	push   $0x1
    35b9:	8d 45 e7             	lea    -0x19(%ebp),%eax
    35bc:	50                   	push   %eax
    35bd:	6a 00                	push   $0x0
    35bf:	e8 e3 00 00 00       	call   36a7 <read>
    if(cc < 1)
    35c4:	83 c4 10             	add    $0x10,%esp
    35c7:	85 c0                	test   %eax,%eax
    35c9:	7e 14                	jle    35df <gets+0x44>
      break;
    buf[i++] = c;
    35cb:	8a 45 e7             	mov    -0x19(%ebp),%al
    35ce:	88 04 37             	mov    %al,(%edi,%esi,1)
    if(c == '\n' || c == '\r')
    35d1:	3c 0a                	cmp    $0xa,%al
    35d3:	74 08                	je     35dd <gets+0x42>
    35d5:	3c 0d                	cmp    $0xd,%al
    35d7:	75 d3                	jne    35ac <gets+0x11>
    buf[i++] = c;
    35d9:	89 de                	mov    %ebx,%esi
    35db:	eb 02                	jmp    35df <gets+0x44>
    35dd:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
    35df:	c6 04 37 00          	movb   $0x0,(%edi,%esi,1)
  return buf;
}
    35e3:	89 f8                	mov    %edi,%eax
    35e5:	8d 65 f4             	lea    -0xc(%ebp),%esp
    35e8:	5b                   	pop    %ebx
    35e9:	5e                   	pop    %esi
    35ea:	5f                   	pop    %edi
    35eb:	5d                   	pop    %ebp
    35ec:	c3                   	ret    

000035ed <stat>:

int
stat(const char *n, struct stat *st)
{
    35ed:	55                   	push   %ebp
    35ee:	89 e5                	mov    %esp,%ebp
    35f0:	56                   	push   %esi
    35f1:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
    35f2:	83 ec 08             	sub    $0x8,%esp
    35f5:	6a 00                	push   $0x0
    35f7:	ff 75 08             	push   0x8(%ebp)
    35fa:	e8 d0 00 00 00       	call   36cf <open>
  if(fd < 0)
    35ff:	83 c4 10             	add    $0x10,%esp
    3602:	85 c0                	test   %eax,%eax
    3604:	78 24                	js     362a <stat+0x3d>
    3606:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
    3608:	83 ec 08             	sub    $0x8,%esp
    360b:	ff 75 0c             	push   0xc(%ebp)
    360e:	50                   	push   %eax
    360f:	e8 d3 00 00 00       	call   36e7 <fstat>
    3614:	89 c6                	mov    %eax,%esi
  close(fd);
    3616:	89 1c 24             	mov    %ebx,(%esp)
    3619:	e8 99 00 00 00       	call   36b7 <close>
  return r;
    361e:	83 c4 10             	add    $0x10,%esp
}
    3621:	89 f0                	mov    %esi,%eax
    3623:	8d 65 f8             	lea    -0x8(%ebp),%esp
    3626:	5b                   	pop    %ebx
    3627:	5e                   	pop    %esi
    3628:	5d                   	pop    %ebp
    3629:	c3                   	ret    
    return -1;
    362a:	be ff ff ff ff       	mov    $0xffffffff,%esi
    362f:	eb f0                	jmp    3621 <stat+0x34>

00003631 <atoi>:

int
atoi(const char *s)
{
    3631:	55                   	push   %ebp
    3632:	89 e5                	mov    %esp,%ebp
    3634:	53                   	push   %ebx
    3635:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
    3638:	ba 00 00 00 00       	mov    $0x0,%edx
  while('0' <= *s && *s <= '9')
    363d:	eb 0e                	jmp    364d <atoi+0x1c>
    n = n*10 + *s++ - '0';
    363f:	8d 14 92             	lea    (%edx,%edx,4),%edx
    3642:	8d 1c 12             	lea    (%edx,%edx,1),%ebx
    3645:	41                   	inc    %ecx
    3646:	0f be c0             	movsbl %al,%eax
    3649:	8d 54 18 d0          	lea    -0x30(%eax,%ebx,1),%edx
  while('0' <= *s && *s <= '9')
    364d:	8a 01                	mov    (%ecx),%al
    364f:	8d 58 d0             	lea    -0x30(%eax),%ebx
    3652:	80 fb 09             	cmp    $0x9,%bl
    3655:	76 e8                	jbe    363f <atoi+0xe>
  return n;
}
    3657:	89 d0                	mov    %edx,%eax
    3659:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    365c:	c9                   	leave  
    365d:	c3                   	ret    

0000365e <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
    365e:	55                   	push   %ebp
    365f:	89 e5                	mov    %esp,%ebp
    3661:	56                   	push   %esi
    3662:	53                   	push   %ebx
    3663:	8b 45 08             	mov    0x8(%ebp),%eax
    3666:	8b 5d 0c             	mov    0xc(%ebp),%ebx
    3669:	8b 55 10             	mov    0x10(%ebp),%edx
  char *dst;
  const char *src;

  dst = vdst;
    366c:	89 c1                	mov    %eax,%ecx
  src = vsrc;
  while(n-- > 0)
    366e:	eb 0c                	jmp    367c <memmove+0x1e>
    *dst++ = *src++;
    3670:	8a 13                	mov    (%ebx),%dl
    3672:	88 11                	mov    %dl,(%ecx)
    3674:	8d 5b 01             	lea    0x1(%ebx),%ebx
    3677:	8d 49 01             	lea    0x1(%ecx),%ecx
  while(n-- > 0)
    367a:	89 f2                	mov    %esi,%edx
    367c:	8d 72 ff             	lea    -0x1(%edx),%esi
    367f:	85 d2                	test   %edx,%edx
    3681:	7f ed                	jg     3670 <memmove+0x12>
  return vdst;
}
    3683:	5b                   	pop    %ebx
    3684:	5e                   	pop    %esi
    3685:	5d                   	pop    %ebp
    3686:	c3                   	ret    

00003687 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
    3687:	b8 01 00 00 00       	mov    $0x1,%eax
    368c:	cd 40                	int    $0x40
    368e:	c3                   	ret    

0000368f <exit>:
SYSCALL(exit)
    368f:	b8 02 00 00 00       	mov    $0x2,%eax
    3694:	cd 40                	int    $0x40
    3696:	c3                   	ret    

00003697 <wait>:
SYSCALL(wait)
    3697:	b8 03 00 00 00       	mov    $0x3,%eax
    369c:	cd 40                	int    $0x40
    369e:	c3                   	ret    

0000369f <pipe>:
SYSCALL(pipe)
    369f:	b8 04 00 00 00       	mov    $0x4,%eax
    36a4:	cd 40                	int    $0x40
    36a6:	c3                   	ret    

000036a7 <read>:
SYSCALL(read)
    36a7:	b8 05 00 00 00       	mov    $0x5,%eax
    36ac:	cd 40                	int    $0x40
    36ae:	c3                   	ret    

000036af <write>:
SYSCALL(write)
    36af:	b8 10 00 00 00       	mov    $0x10,%eax
    36b4:	cd 40                	int    $0x40
    36b6:	c3                   	ret    

000036b7 <close>:
SYSCALL(close)
    36b7:	b8 15 00 00 00       	mov    $0x15,%eax
    36bc:	cd 40                	int    $0x40
    36be:	c3                   	ret    

000036bf <kill>:
SYSCALL(kill)
    36bf:	b8 06 00 00 00       	mov    $0x6,%eax
    36c4:	cd 40                	int    $0x40
    36c6:	c3                   	ret    

000036c7 <exec>:
SYSCALL(exec)
    36c7:	b8 07 00 00 00       	mov    $0x7,%eax
    36cc:	cd 40                	int    $0x40
    36ce:	c3                   	ret    

000036cf <open>:
SYSCALL(open)
    36cf:	b8 0f 00 00 00       	mov    $0xf,%eax
    36d4:	cd 40                	int    $0x40
    36d6:	c3                   	ret    

000036d7 <mknod>:
SYSCALL(mknod)
    36d7:	b8 11 00 00 00       	mov    $0x11,%eax
    36dc:	cd 40                	int    $0x40
    36de:	c3                   	ret    

000036df <unlink>:
SYSCALL(unlink)
    36df:	b8 12 00 00 00       	mov    $0x12,%eax
    36e4:	cd 40                	int    $0x40
    36e6:	c3                   	ret    

000036e7 <fstat>:
SYSCALL(fstat)
    36e7:	b8 08 00 00 00       	mov    $0x8,%eax
    36ec:	cd 40                	int    $0x40
    36ee:	c3                   	ret    

000036ef <link>:
SYSCALL(link)
    36ef:	b8 13 00 00 00       	mov    $0x13,%eax
    36f4:	cd 40                	int    $0x40
    36f6:	c3                   	ret    

000036f7 <mkdir>:
SYSCALL(mkdir)
    36f7:	b8 14 00 00 00       	mov    $0x14,%eax
    36fc:	cd 40                	int    $0x40
    36fe:	c3                   	ret    

000036ff <chdir>:
SYSCALL(chdir)
    36ff:	b8 09 00 00 00       	mov    $0x9,%eax
    3704:	cd 40                	int    $0x40
    3706:	c3                   	ret    

00003707 <dup>:
SYSCALL(dup)
    3707:	b8 0a 00 00 00       	mov    $0xa,%eax
    370c:	cd 40                	int    $0x40
    370e:	c3                   	ret    

0000370f <getpid>:
SYSCALL(getpid)
    370f:	b8 0b 00 00 00       	mov    $0xb,%eax
    3714:	cd 40                	int    $0x40
    3716:	c3                   	ret    

00003717 <sbrk>:
SYSCALL(sbrk)
    3717:	b8 0c 00 00 00       	mov    $0xc,%eax
    371c:	cd 40                	int    $0x40
    371e:	c3                   	ret    

0000371f <sleep>:
SYSCALL(sleep)
    371f:	b8 0d 00 00 00       	mov    $0xd,%eax
    3724:	cd 40                	int    $0x40
    3726:	c3                   	ret    

00003727 <uptime>:
SYSCALL(uptime)
    3727:	b8 0e 00 00 00       	mov    $0xe,%eax
    372c:	cd 40                	int    $0x40
    372e:	c3                   	ret    

0000372f <date>:
SYSCALL(date)
    372f:	b8 16 00 00 00       	mov    $0x16,%eax
    3734:	cd 40                	int    $0x40
    3736:	c3                   	ret    

00003737 <dup2>:
SYSCALL(dup2)
    3737:	b8 17 00 00 00       	mov    $0x17,%eax
    373c:	cd 40                	int    $0x40
    373e:	c3                   	ret    

0000373f <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
    373f:	55                   	push   %ebp
    3740:	89 e5                	mov    %esp,%ebp
    3742:	83 ec 1c             	sub    $0x1c,%esp
    3745:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
    3748:	6a 01                	push   $0x1
    374a:	8d 55 f4             	lea    -0xc(%ebp),%edx
    374d:	52                   	push   %edx
    374e:	50                   	push   %eax
    374f:	e8 5b ff ff ff       	call   36af <write>
}
    3754:	83 c4 10             	add    $0x10,%esp
    3757:	c9                   	leave  
    3758:	c3                   	ret    

00003759 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
    3759:	55                   	push   %ebp
    375a:	89 e5                	mov    %esp,%ebp
    375c:	57                   	push   %edi
    375d:	56                   	push   %esi
    375e:	53                   	push   %ebx
    375f:	83 ec 2c             	sub    $0x2c,%esp
    3762:	89 45 d4             	mov    %eax,-0x2c(%ebp)
    3765:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    3767:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
    376b:	74 04                	je     3771 <printint+0x18>
    376d:	85 d2                	test   %edx,%edx
    376f:	78 3c                	js     37ad <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
    3771:	89 d1                	mov    %edx,%ecx
  neg = 0;
    3773:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
    377a:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
    377f:	89 c8                	mov    %ecx,%eax
    3781:	ba 00 00 00 00       	mov    $0x0,%edx
    3786:	f7 f6                	div    %esi
    3788:	89 df                	mov    %ebx,%edi
    378a:	43                   	inc    %ebx
    378b:	8a 92 80 52 00 00    	mov    0x5280(%edx),%dl
    3791:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
    3795:	89 ca                	mov    %ecx,%edx
    3797:	89 c1                	mov    %eax,%ecx
    3799:	39 d6                	cmp    %edx,%esi
    379b:	76 e2                	jbe    377f <printint+0x26>
  if(neg)
    379d:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
    37a1:	74 24                	je     37c7 <printint+0x6e>
    buf[i++] = '-';
    37a3:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
    37a8:	8d 5f 02             	lea    0x2(%edi),%ebx
    37ab:	eb 1a                	jmp    37c7 <printint+0x6e>
    x = -xx;
    37ad:	89 d1                	mov    %edx,%ecx
    37af:	f7 d9                	neg    %ecx
    neg = 1;
    37b1:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
    37b8:	eb c0                	jmp    377a <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
    37ba:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
    37bf:	8b 45 d4             	mov    -0x2c(%ebp),%eax
    37c2:	e8 78 ff ff ff       	call   373f <putc>
  while(--i >= 0)
    37c7:	4b                   	dec    %ebx
    37c8:	79 f0                	jns    37ba <printint+0x61>
}
    37ca:	83 c4 2c             	add    $0x2c,%esp
    37cd:	5b                   	pop    %ebx
    37ce:	5e                   	pop    %esi
    37cf:	5f                   	pop    %edi
    37d0:	5d                   	pop    %ebp
    37d1:	c3                   	ret    

000037d2 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
    37d2:	55                   	push   %ebp
    37d3:	89 e5                	mov    %esp,%ebp
    37d5:	57                   	push   %edi
    37d6:	56                   	push   %esi
    37d7:	53                   	push   %ebx
    37d8:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
    37db:	8d 45 10             	lea    0x10(%ebp),%eax
    37de:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
    37e1:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
    37e6:	bb 00 00 00 00       	mov    $0x0,%ebx
    37eb:	eb 12                	jmp    37ff <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
    37ed:	89 fa                	mov    %edi,%edx
    37ef:	8b 45 08             	mov    0x8(%ebp),%eax
    37f2:	e8 48 ff ff ff       	call   373f <putc>
    37f7:	eb 05                	jmp    37fe <printf+0x2c>
      }
    } else if(state == '%'){
    37f9:	83 fe 25             	cmp    $0x25,%esi
    37fc:	74 22                	je     3820 <printf+0x4e>
  for(i = 0; fmt[i]; i++){
    37fe:	43                   	inc    %ebx
    37ff:	8b 45 0c             	mov    0xc(%ebp),%eax
    3802:	8a 04 18             	mov    (%eax,%ebx,1),%al
    3805:	84 c0                	test   %al,%al
    3807:	0f 84 1d 01 00 00    	je     392a <printf+0x158>
    c = fmt[i] & 0xff;
    380d:	0f be f8             	movsbl %al,%edi
    3810:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
    3813:	85 f6                	test   %esi,%esi
    3815:	75 e2                	jne    37f9 <printf+0x27>
      if(c == '%'){
    3817:	83 f8 25             	cmp    $0x25,%eax
    381a:	75 d1                	jne    37ed <printf+0x1b>
        state = '%';
    381c:	89 c6                	mov    %eax,%esi
    381e:	eb de                	jmp    37fe <printf+0x2c>
      if(c == 'd'){
    3820:	83 f8 25             	cmp    $0x25,%eax
    3823:	0f 84 cc 00 00 00    	je     38f5 <printf+0x123>
    3829:	0f 8c da 00 00 00    	jl     3909 <printf+0x137>
    382f:	83 f8 78             	cmp    $0x78,%eax
    3832:	0f 8f d1 00 00 00    	jg     3909 <printf+0x137>
    3838:	83 f8 63             	cmp    $0x63,%eax
    383b:	0f 8c c8 00 00 00    	jl     3909 <printf+0x137>
    3841:	83 e8 63             	sub    $0x63,%eax
    3844:	83 f8 15             	cmp    $0x15,%eax
    3847:	0f 87 bc 00 00 00    	ja     3909 <printf+0x137>
    384d:	ff 24 85 28 52 00 00 	jmp    *0x5228(,%eax,4)
        printint(fd, *ap, 10, 1);
    3854:	8b 7d e4             	mov    -0x1c(%ebp),%edi
    3857:	8b 17                	mov    (%edi),%edx
    3859:	83 ec 0c             	sub    $0xc,%esp
    385c:	6a 01                	push   $0x1
    385e:	b9 0a 00 00 00       	mov    $0xa,%ecx
    3863:	8b 45 08             	mov    0x8(%ebp),%eax
    3866:	e8 ee fe ff ff       	call   3759 <printint>
        ap++;
    386b:	83 c7 04             	add    $0x4,%edi
    386e:	89 7d e4             	mov    %edi,-0x1c(%ebp)
    3871:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
    3874:	be 00 00 00 00       	mov    $0x0,%esi
    3879:	eb 83                	jmp    37fe <printf+0x2c>
        printint(fd, *ap, 16, 0);
    387b:	8b 7d e4             	mov    -0x1c(%ebp),%edi
    387e:	8b 17                	mov    (%edi),%edx
    3880:	83 ec 0c             	sub    $0xc,%esp
    3883:	6a 00                	push   $0x0
    3885:	b9 10 00 00 00       	mov    $0x10,%ecx
    388a:	8b 45 08             	mov    0x8(%ebp),%eax
    388d:	e8 c7 fe ff ff       	call   3759 <printint>
        ap++;
    3892:	83 c7 04             	add    $0x4,%edi
    3895:	89 7d e4             	mov    %edi,-0x1c(%ebp)
    3898:	83 c4 10             	add    $0x10,%esp
      state = 0;
    389b:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
    38a0:	e9 59 ff ff ff       	jmp    37fe <printf+0x2c>
        s = (char*)*ap;
    38a5:	8b 45 e4             	mov    -0x1c(%ebp),%eax
    38a8:	8b 30                	mov    (%eax),%esi
        ap++;
    38aa:	83 c0 04             	add    $0x4,%eax
    38ad:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
    38b0:	85 f6                	test   %esi,%esi
    38b2:	75 13                	jne    38c7 <printf+0xf5>
          s = "(null)";
    38b4:	be 20 52 00 00       	mov    $0x5220,%esi
    38b9:	eb 0c                	jmp    38c7 <printf+0xf5>
          putc(fd, *s);
    38bb:	0f be d2             	movsbl %dl,%edx
    38be:	8b 45 08             	mov    0x8(%ebp),%eax
    38c1:	e8 79 fe ff ff       	call   373f <putc>
          s++;
    38c6:	46                   	inc    %esi
        while(*s != 0){
    38c7:	8a 16                	mov    (%esi),%dl
    38c9:	84 d2                	test   %dl,%dl
    38cb:	75 ee                	jne    38bb <printf+0xe9>
      state = 0;
    38cd:	be 00 00 00 00       	mov    $0x0,%esi
    38d2:	e9 27 ff ff ff       	jmp    37fe <printf+0x2c>
        putc(fd, *ap);
    38d7:	8b 7d e4             	mov    -0x1c(%ebp),%edi
    38da:	0f be 17             	movsbl (%edi),%edx
    38dd:	8b 45 08             	mov    0x8(%ebp),%eax
    38e0:	e8 5a fe ff ff       	call   373f <putc>
        ap++;
    38e5:	83 c7 04             	add    $0x4,%edi
    38e8:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
    38eb:	be 00 00 00 00       	mov    $0x0,%esi
    38f0:	e9 09 ff ff ff       	jmp    37fe <printf+0x2c>
        putc(fd, c);
    38f5:	89 fa                	mov    %edi,%edx
    38f7:	8b 45 08             	mov    0x8(%ebp),%eax
    38fa:	e8 40 fe ff ff       	call   373f <putc>
      state = 0;
    38ff:	be 00 00 00 00       	mov    $0x0,%esi
    3904:	e9 f5 fe ff ff       	jmp    37fe <printf+0x2c>
        putc(fd, '%');
    3909:	ba 25 00 00 00       	mov    $0x25,%edx
    390e:	8b 45 08             	mov    0x8(%ebp),%eax
    3911:	e8 29 fe ff ff       	call   373f <putc>
        putc(fd, c);
    3916:	89 fa                	mov    %edi,%edx
    3918:	8b 45 08             	mov    0x8(%ebp),%eax
    391b:	e8 1f fe ff ff       	call   373f <putc>
      state = 0;
    3920:	be 00 00 00 00       	mov    $0x0,%esi
    3925:	e9 d4 fe ff ff       	jmp    37fe <printf+0x2c>
    }
  }
}
    392a:	8d 65 f4             	lea    -0xc(%ebp),%esp
    392d:	5b                   	pop    %ebx
    392e:	5e                   	pop    %esi
    392f:	5f                   	pop    %edi
    3930:	5d                   	pop    %ebp
    3931:	c3                   	ret    

00003932 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    3932:	55                   	push   %ebp
    3933:	89 e5                	mov    %esp,%ebp
    3935:	57                   	push   %edi
    3936:	56                   	push   %esi
    3937:	53                   	push   %ebx
    3938:	8b 5d 08             	mov    0x8(%ebp),%ebx
  Header *bp, *p;

  bp = (Header*)ap - 1;
    393b:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    393e:	a1 e0 a2 00 00       	mov    0xa2e0,%eax
    3943:	eb 02                	jmp    3947 <free+0x15>
    3945:	89 d0                	mov    %edx,%eax
    3947:	39 c8                	cmp    %ecx,%eax
    3949:	73 04                	jae    394f <free+0x1d>
    394b:	39 08                	cmp    %ecx,(%eax)
    394d:	77 12                	ja     3961 <free+0x2f>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    394f:	8b 10                	mov    (%eax),%edx
    3951:	39 c2                	cmp    %eax,%edx
    3953:	77 f0                	ja     3945 <free+0x13>
    3955:	39 c8                	cmp    %ecx,%eax
    3957:	72 08                	jb     3961 <free+0x2f>
    3959:	39 ca                	cmp    %ecx,%edx
    395b:	77 04                	ja     3961 <free+0x2f>
    395d:	89 d0                	mov    %edx,%eax
    395f:	eb e6                	jmp    3947 <free+0x15>
      break;
  if(bp + bp->s.size == p->s.ptr){
    3961:	8b 73 fc             	mov    -0x4(%ebx),%esi
    3964:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
    3967:	8b 10                	mov    (%eax),%edx
    3969:	39 d7                	cmp    %edx,%edi
    396b:	74 19                	je     3986 <free+0x54>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
  } else
    bp->s.ptr = p->s.ptr;
    396d:	89 53 f8             	mov    %edx,-0x8(%ebx)
  if(p + p->s.size == bp){
    3970:	8b 50 04             	mov    0x4(%eax),%edx
    3973:	8d 34 d0             	lea    (%eax,%edx,8),%esi
    3976:	39 ce                	cmp    %ecx,%esi
    3978:	74 1b                	je     3995 <free+0x63>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
  } else
    p->s.ptr = bp;
    397a:	89 08                	mov    %ecx,(%eax)
  freep = p;
    397c:	a3 e0 a2 00 00       	mov    %eax,0xa2e0
}
    3981:	5b                   	pop    %ebx
    3982:	5e                   	pop    %esi
    3983:	5f                   	pop    %edi
    3984:	5d                   	pop    %ebp
    3985:	c3                   	ret    
    bp->s.size += p->s.ptr->s.size;
    3986:	03 72 04             	add    0x4(%edx),%esi
    3989:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
    398c:	8b 10                	mov    (%eax),%edx
    398e:	8b 12                	mov    (%edx),%edx
    3990:	89 53 f8             	mov    %edx,-0x8(%ebx)
    3993:	eb db                	jmp    3970 <free+0x3e>
    p->s.size += bp->s.size;
    3995:	03 53 fc             	add    -0x4(%ebx),%edx
    3998:	89 50 04             	mov    %edx,0x4(%eax)
    p->s.ptr = bp->s.ptr;
    399b:	8b 53 f8             	mov    -0x8(%ebx),%edx
    399e:	89 10                	mov    %edx,(%eax)
    39a0:	eb da                	jmp    397c <free+0x4a>

000039a2 <morecore>:

static Header*
morecore(uint nu)
{
    39a2:	55                   	push   %ebp
    39a3:	89 e5                	mov    %esp,%ebp
    39a5:	53                   	push   %ebx
    39a6:	83 ec 04             	sub    $0x4,%esp
    39a9:	89 c3                	mov    %eax,%ebx
  char *p;
  Header *hp;

  if(nu < 4096)
    39ab:	3d ff 0f 00 00       	cmp    $0xfff,%eax
    39b0:	77 05                	ja     39b7 <morecore+0x15>
    nu = 4096;
    39b2:	bb 00 10 00 00       	mov    $0x1000,%ebx
  p = sbrk(nu * sizeof(Header));
    39b7:	8d 04 dd 00 00 00 00 	lea    0x0(,%ebx,8),%eax
    39be:	83 ec 0c             	sub    $0xc,%esp
    39c1:	50                   	push   %eax
    39c2:	e8 50 fd ff ff       	call   3717 <sbrk>
  if(p == (char*)-1)
    39c7:	83 c4 10             	add    $0x10,%esp
    39ca:	83 f8 ff             	cmp    $0xffffffff,%eax
    39cd:	74 1c                	je     39eb <morecore+0x49>
    return 0;
  hp = (Header*)p;
  hp->s.size = nu;
    39cf:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
    39d2:	83 c0 08             	add    $0x8,%eax
    39d5:	83 ec 0c             	sub    $0xc,%esp
    39d8:	50                   	push   %eax
    39d9:	e8 54 ff ff ff       	call   3932 <free>
  return freep;
    39de:	a1 e0 a2 00 00       	mov    0xa2e0,%eax
    39e3:	83 c4 10             	add    $0x10,%esp
}
    39e6:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    39e9:	c9                   	leave  
    39ea:	c3                   	ret    
    return 0;
    39eb:	b8 00 00 00 00       	mov    $0x0,%eax
    39f0:	eb f4                	jmp    39e6 <morecore+0x44>

000039f2 <malloc>:

void*
malloc(uint nbytes)
{
    39f2:	55                   	push   %ebp
    39f3:	89 e5                	mov    %esp,%ebp
    39f5:	53                   	push   %ebx
    39f6:	83 ec 04             	sub    $0x4,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    39f9:	8b 45 08             	mov    0x8(%ebp),%eax
    39fc:	8d 58 07             	lea    0x7(%eax),%ebx
    39ff:	c1 eb 03             	shr    $0x3,%ebx
    3a02:	43                   	inc    %ebx
  if((prevp = freep) == 0){
    3a03:	8b 0d e0 a2 00 00    	mov    0xa2e0,%ecx
    3a09:	85 c9                	test   %ecx,%ecx
    3a0b:	74 04                	je     3a11 <malloc+0x1f>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    3a0d:	8b 01                	mov    (%ecx),%eax
    3a0f:	eb 4a                	jmp    3a5b <malloc+0x69>
    base.s.ptr = freep = prevp = &base;
    3a11:	c7 05 e0 a2 00 00 e4 	movl   $0xa2e4,0xa2e0
    3a18:	a2 00 00 
    3a1b:	c7 05 e4 a2 00 00 e4 	movl   $0xa2e4,0xa2e4
    3a22:	a2 00 00 
    base.s.size = 0;
    3a25:	c7 05 e8 a2 00 00 00 	movl   $0x0,0xa2e8
    3a2c:	00 00 00 
    base.s.ptr = freep = prevp = &base;
    3a2f:	b9 e4 a2 00 00       	mov    $0xa2e4,%ecx
    3a34:	eb d7                	jmp    3a0d <malloc+0x1b>
    if(p->s.size >= nunits){
      if(p->s.size == nunits)
    3a36:	74 19                	je     3a51 <malloc+0x5f>
        prevp->s.ptr = p->s.ptr;
      else {
        p->s.size -= nunits;
    3a38:	29 da                	sub    %ebx,%edx
    3a3a:	89 50 04             	mov    %edx,0x4(%eax)
        p += p->s.size;
    3a3d:	8d 04 d0             	lea    (%eax,%edx,8),%eax
        p->s.size = nunits;
    3a40:	89 58 04             	mov    %ebx,0x4(%eax)
      }
      freep = prevp;
    3a43:	89 0d e0 a2 00 00    	mov    %ecx,0xa2e0
      return (void*)(p + 1);
    3a49:	83 c0 08             	add    $0x8,%eax
    }
    if(p == freep)
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
    3a4c:	8b 5d fc             	mov    -0x4(%ebp),%ebx
    3a4f:	c9                   	leave  
    3a50:	c3                   	ret    
        prevp->s.ptr = p->s.ptr;
    3a51:	8b 10                	mov    (%eax),%edx
    3a53:	89 11                	mov    %edx,(%ecx)
    3a55:	eb ec                	jmp    3a43 <malloc+0x51>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    3a57:	89 c1                	mov    %eax,%ecx
    3a59:	8b 00                	mov    (%eax),%eax
    if(p->s.size >= nunits){
    3a5b:	8b 50 04             	mov    0x4(%eax),%edx
    3a5e:	39 da                	cmp    %ebx,%edx
    3a60:	73 d4                	jae    3a36 <malloc+0x44>
    if(p == freep)
    3a62:	39 05 e0 a2 00 00    	cmp    %eax,0xa2e0
    3a68:	75 ed                	jne    3a57 <malloc+0x65>
      if((p = morecore(nunits)) == 0)
    3a6a:	89 d8                	mov    %ebx,%eax
    3a6c:	e8 31 ff ff ff       	call   39a2 <morecore>
    3a71:	85 c0                	test   %eax,%eax
    3a73:	75 e2                	jne    3a57 <malloc+0x65>
    3a75:	eb d5                	jmp    3a4c <malloc+0x5a>
