
wc:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <wc>:

char buf[512];

void
wc(int fd, char *name)
{
   0:	55                   	push   %ebp
   1:	89 e5                	mov    %esp,%ebp
   3:	57                   	push   %edi
   4:	56                   	push   %esi
   5:	53                   	push   %ebx
   6:	83 ec 1c             	sub    $0x1c,%esp
  int i, n;
  int l, w, c, inword;

  l = w = c = 0;
  inword = 0;
   9:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
  l = w = c = 0;
  10:	be 00 00 00 00       	mov    $0x0,%esi
  15:	c7 45 dc 00 00 00 00 	movl   $0x0,-0x24(%ebp)
  1c:	c7 45 e0 00 00 00 00 	movl   $0x0,-0x20(%ebp)
  while((n = read(fd, buf, sizeof(buf))) > 0){
  23:	83 ec 04             	sub    $0x4,%esp
  26:	68 00 02 00 00       	push   $0x200
  2b:	68 a0 08 00 00       	push   $0x8a0
  30:	ff 75 08             	push   0x8(%ebp)
  33:	e8 bb 02 00 00       	call   2f3 <read>
  38:	89 c7                	mov    %eax,%edi
  3a:	83 c4 10             	add    $0x10,%esp
  3d:	85 c0                	test   %eax,%eax
  3f:	7e 4d                	jle    8e <wc+0x8e>
    for(i=0; i<n; i++){
  41:	bb 00 00 00 00       	mov    $0x0,%ebx
  46:	eb 20                	jmp    68 <wc+0x68>
      c++;
      if(buf[i] == '\n')
        l++;
      if(strchr(" \r\t\n\v", buf[i]))
  48:	83 ec 08             	sub    $0x8,%esp
  4b:	0f be c0             	movsbl %al,%eax
  4e:	50                   	push   %eax
  4f:	68 80 05 00 00       	push   $0x580
  54:	e8 6f 01 00 00       	call   1c8 <strchr>
  59:	83 c4 10             	add    $0x10,%esp
  5c:	85 c0                	test   %eax,%eax
  5e:	74 1c                	je     7c <wc+0x7c>
        inword = 0;
  60:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
    for(i=0; i<n; i++){
  67:	43                   	inc    %ebx
  68:	39 fb                	cmp    %edi,%ebx
  6a:	7d b7                	jge    23 <wc+0x23>
      c++;
  6c:	46                   	inc    %esi
      if(buf[i] == '\n')
  6d:	8a 83 a0 08 00 00    	mov    0x8a0(%ebx),%al
  73:	3c 0a                	cmp    $0xa,%al
  75:	75 d1                	jne    48 <wc+0x48>
        l++;
  77:	ff 45 e0             	incl   -0x20(%ebp)
  7a:	eb cc                	jmp    48 <wc+0x48>
      else if(!inword){
  7c:	83 7d e4 00          	cmpl   $0x0,-0x1c(%ebp)
  80:	75 e5                	jne    67 <wc+0x67>
        w++;
  82:	ff 45 dc             	incl   -0x24(%ebp)
        inword = 1;
  85:	c7 45 e4 01 00 00 00 	movl   $0x1,-0x1c(%ebp)
  8c:	eb d9                	jmp    67 <wc+0x67>
      }
    }
  }
  if(n < 0){
  8e:	78 24                	js     b4 <wc+0xb4>
    printf(1, "wc: read error\n");
    exit();
  }
  printf(1, "%d %d %d %s\n", l, w, c, name);
  90:	83 ec 08             	sub    $0x8,%esp
  93:	ff 75 0c             	push   0xc(%ebp)
  96:	56                   	push   %esi
  97:	ff 75 dc             	push   -0x24(%ebp)
  9a:	ff 75 e0             	push   -0x20(%ebp)
  9d:	68 96 05 00 00       	push   $0x596
  a2:	6a 01                	push   $0x1
  a4:	e8 75 03 00 00       	call   41e <printf>
}
  a9:	83 c4 20             	add    $0x20,%esp
  ac:	8d 65 f4             	lea    -0xc(%ebp),%esp
  af:	5b                   	pop    %ebx
  b0:	5e                   	pop    %esi
  b1:	5f                   	pop    %edi
  b2:	5d                   	pop    %ebp
  b3:	c3                   	ret    
    printf(1, "wc: read error\n");
  b4:	83 ec 08             	sub    $0x8,%esp
  b7:	68 86 05 00 00       	push   $0x586
  bc:	6a 01                	push   $0x1
  be:	e8 5b 03 00 00       	call   41e <printf>
    exit();
  c3:	e8 13 02 00 00       	call   2db <exit>

000000c8 <main>:

int
main(int argc, char *argv[])
{
  c8:	8d 4c 24 04          	lea    0x4(%esp),%ecx
  cc:	83 e4 f0             	and    $0xfffffff0,%esp
  cf:	ff 71 fc             	push   -0x4(%ecx)
  d2:	55                   	push   %ebp
  d3:	89 e5                	mov    %esp,%ebp
  d5:	57                   	push   %edi
  d6:	56                   	push   %esi
  d7:	53                   	push   %ebx
  d8:	51                   	push   %ecx
  d9:	83 ec 18             	sub    $0x18,%esp
  dc:	8b 01                	mov    (%ecx),%eax
  de:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  e1:	8b 51 04             	mov    0x4(%ecx),%edx
  e4:	89 55 e0             	mov    %edx,-0x20(%ebp)
  int fd, i;

  if(argc <= 1){
  e7:	83 f8 01             	cmp    $0x1,%eax
  ea:	7e 07                	jle    f3 <main+0x2b>
    wc(0, "");
    exit();
  }

  for(i = 1; i < argc; i++){
  ec:	be 01 00 00 00       	mov    $0x1,%esi
  f1:	eb 2b                	jmp    11e <main+0x56>
    wc(0, "");
  f3:	83 ec 08             	sub    $0x8,%esp
  f6:	68 95 05 00 00       	push   $0x595
  fb:	6a 00                	push   $0x0
  fd:	e8 fe fe ff ff       	call   0 <wc>
    exit();
 102:	e8 d4 01 00 00       	call   2db <exit>
    if((fd = open(argv[i], 0)) < 0){
      printf(1, "wc: cannot open %s\n", argv[i]);
      exit();
    }
    wc(fd, argv[i]);
 107:	83 ec 08             	sub    $0x8,%esp
 10a:	ff 37                	push   (%edi)
 10c:	50                   	push   %eax
 10d:	e8 ee fe ff ff       	call   0 <wc>
    close(fd);
 112:	89 1c 24             	mov    %ebx,(%esp)
 115:	e8 e9 01 00 00       	call   303 <close>
  for(i = 1; i < argc; i++){
 11a:	46                   	inc    %esi
 11b:	83 c4 10             	add    $0x10,%esp
 11e:	3b 75 e4             	cmp    -0x1c(%ebp),%esi
 121:	7d 31                	jge    154 <main+0x8c>
    if((fd = open(argv[i], 0)) < 0){
 123:	8b 45 e0             	mov    -0x20(%ebp),%eax
 126:	8d 3c b0             	lea    (%eax,%esi,4),%edi
 129:	83 ec 08             	sub    $0x8,%esp
 12c:	6a 00                	push   $0x0
 12e:	ff 37                	push   (%edi)
 130:	e8 e6 01 00 00       	call   31b <open>
 135:	89 c3                	mov    %eax,%ebx
 137:	83 c4 10             	add    $0x10,%esp
 13a:	85 c0                	test   %eax,%eax
 13c:	79 c9                	jns    107 <main+0x3f>
      printf(1, "wc: cannot open %s\n", argv[i]);
 13e:	83 ec 04             	sub    $0x4,%esp
 141:	ff 37                	push   (%edi)
 143:	68 a3 05 00 00       	push   $0x5a3
 148:	6a 01                	push   $0x1
 14a:	e8 cf 02 00 00       	call   41e <printf>
      exit();
 14f:	e8 87 01 00 00       	call   2db <exit>
  }
  exit();
 154:	e8 82 01 00 00       	call   2db <exit>

00000159 <start>:

// Entry point of the library	
void
start()
{
}
 159:	c3                   	ret    

0000015a <strcpy>:

char*
strcpy(char *s, const char *t)
{
 15a:	55                   	push   %ebp
 15b:	89 e5                	mov    %esp,%ebp
 15d:	56                   	push   %esi
 15e:	53                   	push   %ebx
 15f:	8b 45 08             	mov    0x8(%ebp),%eax
 162:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 165:	89 c2                	mov    %eax,%edx
 167:	89 cb                	mov    %ecx,%ebx
 169:	41                   	inc    %ecx
 16a:	89 d6                	mov    %edx,%esi
 16c:	42                   	inc    %edx
 16d:	8a 1b                	mov    (%ebx),%bl
 16f:	88 1e                	mov    %bl,(%esi)
 171:	84 db                	test   %bl,%bl
 173:	75 f2                	jne    167 <strcpy+0xd>
    ;
  return os;
}
 175:	5b                   	pop    %ebx
 176:	5e                   	pop    %esi
 177:	5d                   	pop    %ebp
 178:	c3                   	ret    

00000179 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 179:	55                   	push   %ebp
 17a:	89 e5                	mov    %esp,%ebp
 17c:	8b 4d 08             	mov    0x8(%ebp),%ecx
 17f:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
 182:	eb 02                	jmp    186 <strcmp+0xd>
    p++, q++;
 184:	41                   	inc    %ecx
 185:	42                   	inc    %edx
  while(*p && *p == *q)
 186:	8a 01                	mov    (%ecx),%al
 188:	84 c0                	test   %al,%al
 18a:	74 04                	je     190 <strcmp+0x17>
 18c:	3a 02                	cmp    (%edx),%al
 18e:	74 f4                	je     184 <strcmp+0xb>
  return (uchar)*p - (uchar)*q;
 190:	0f b6 c0             	movzbl %al,%eax
 193:	0f b6 12             	movzbl (%edx),%edx
 196:	29 d0                	sub    %edx,%eax
}
 198:	5d                   	pop    %ebp
 199:	c3                   	ret    

0000019a <strlen>:

uint
strlen(const char *s)
{
 19a:	55                   	push   %ebp
 19b:	89 e5                	mov    %esp,%ebp
 19d:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
 1a0:	b8 00 00 00 00       	mov    $0x0,%eax
 1a5:	eb 01                	jmp    1a8 <strlen+0xe>
 1a7:	40                   	inc    %eax
 1a8:	80 3c 01 00          	cmpb   $0x0,(%ecx,%eax,1)
 1ac:	75 f9                	jne    1a7 <strlen+0xd>
    ;
  return n;
}
 1ae:	5d                   	pop    %ebp
 1af:	c3                   	ret    

000001b0 <memset>:

void*
memset(void *dst, int c, uint n)
{
 1b0:	55                   	push   %ebp
 1b1:	89 e5                	mov    %esp,%ebp
 1b3:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 1b4:	8b 7d 08             	mov    0x8(%ebp),%edi
 1b7:	8b 4d 10             	mov    0x10(%ebp),%ecx
 1ba:	8b 45 0c             	mov    0xc(%ebp),%eax
 1bd:	fc                   	cld    
 1be:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 1c0:	8b 45 08             	mov    0x8(%ebp),%eax
 1c3:	8b 7d fc             	mov    -0x4(%ebp),%edi
 1c6:	c9                   	leave  
 1c7:	c3                   	ret    

000001c8 <strchr>:

char*
strchr(const char *s, char c)
{
 1c8:	55                   	push   %ebp
 1c9:	89 e5                	mov    %esp,%ebp
 1cb:	8b 45 08             	mov    0x8(%ebp),%eax
 1ce:	8a 4d 0c             	mov    0xc(%ebp),%cl
  for(; *s; s++)
 1d1:	eb 01                	jmp    1d4 <strchr+0xc>
 1d3:	40                   	inc    %eax
 1d4:	8a 10                	mov    (%eax),%dl
 1d6:	84 d2                	test   %dl,%dl
 1d8:	74 06                	je     1e0 <strchr+0x18>
    if(*s == c)
 1da:	38 ca                	cmp    %cl,%dl
 1dc:	75 f5                	jne    1d3 <strchr+0xb>
 1de:	eb 05                	jmp    1e5 <strchr+0x1d>
      return (char*)s;
  return 0;
 1e0:	b8 00 00 00 00       	mov    $0x0,%eax
}
 1e5:	5d                   	pop    %ebp
 1e6:	c3                   	ret    

000001e7 <gets>:

char*
gets(char *buf, int max)
{
 1e7:	55                   	push   %ebp
 1e8:	89 e5                	mov    %esp,%ebp
 1ea:	57                   	push   %edi
 1eb:	56                   	push   %esi
 1ec:	53                   	push   %ebx
 1ed:	83 ec 1c             	sub    $0x1c,%esp
 1f0:	8b 7d 08             	mov    0x8(%ebp),%edi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1f3:	bb 00 00 00 00       	mov    $0x0,%ebx
 1f8:	89 de                	mov    %ebx,%esi
 1fa:	43                   	inc    %ebx
 1fb:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 1fe:	7d 2b                	jge    22b <gets+0x44>
    cc = read(0, &c, 1);
 200:	83 ec 04             	sub    $0x4,%esp
 203:	6a 01                	push   $0x1
 205:	8d 45 e7             	lea    -0x19(%ebp),%eax
 208:	50                   	push   %eax
 209:	6a 00                	push   $0x0
 20b:	e8 e3 00 00 00       	call   2f3 <read>
    if(cc < 1)
 210:	83 c4 10             	add    $0x10,%esp
 213:	85 c0                	test   %eax,%eax
 215:	7e 14                	jle    22b <gets+0x44>
      break;
    buf[i++] = c;
 217:	8a 45 e7             	mov    -0x19(%ebp),%al
 21a:	88 04 37             	mov    %al,(%edi,%esi,1)
    if(c == '\n' || c == '\r')
 21d:	3c 0a                	cmp    $0xa,%al
 21f:	74 08                	je     229 <gets+0x42>
 221:	3c 0d                	cmp    $0xd,%al
 223:	75 d3                	jne    1f8 <gets+0x11>
    buf[i++] = c;
 225:	89 de                	mov    %ebx,%esi
 227:	eb 02                	jmp    22b <gets+0x44>
 229:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 22b:	c6 04 37 00          	movb   $0x0,(%edi,%esi,1)
  return buf;
}
 22f:	89 f8                	mov    %edi,%eax
 231:	8d 65 f4             	lea    -0xc(%ebp),%esp
 234:	5b                   	pop    %ebx
 235:	5e                   	pop    %esi
 236:	5f                   	pop    %edi
 237:	5d                   	pop    %ebp
 238:	c3                   	ret    

00000239 <stat>:

int
stat(const char *n, struct stat *st)
{
 239:	55                   	push   %ebp
 23a:	89 e5                	mov    %esp,%ebp
 23c:	56                   	push   %esi
 23d:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 23e:	83 ec 08             	sub    $0x8,%esp
 241:	6a 00                	push   $0x0
 243:	ff 75 08             	push   0x8(%ebp)
 246:	e8 d0 00 00 00       	call   31b <open>
  if(fd < 0)
 24b:	83 c4 10             	add    $0x10,%esp
 24e:	85 c0                	test   %eax,%eax
 250:	78 24                	js     276 <stat+0x3d>
 252:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 254:	83 ec 08             	sub    $0x8,%esp
 257:	ff 75 0c             	push   0xc(%ebp)
 25a:	50                   	push   %eax
 25b:	e8 d3 00 00 00       	call   333 <fstat>
 260:	89 c6                	mov    %eax,%esi
  close(fd);
 262:	89 1c 24             	mov    %ebx,(%esp)
 265:	e8 99 00 00 00       	call   303 <close>
  return r;
 26a:	83 c4 10             	add    $0x10,%esp
}
 26d:	89 f0                	mov    %esi,%eax
 26f:	8d 65 f8             	lea    -0x8(%ebp),%esp
 272:	5b                   	pop    %ebx
 273:	5e                   	pop    %esi
 274:	5d                   	pop    %ebp
 275:	c3                   	ret    
    return -1;
 276:	be ff ff ff ff       	mov    $0xffffffff,%esi
 27b:	eb f0                	jmp    26d <stat+0x34>

0000027d <atoi>:

int
atoi(const char *s)
{
 27d:	55                   	push   %ebp
 27e:	89 e5                	mov    %esp,%ebp
 280:	53                   	push   %ebx
 281:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
 284:	ba 00 00 00 00       	mov    $0x0,%edx
  while('0' <= *s && *s <= '9')
 289:	eb 0e                	jmp    299 <atoi+0x1c>
    n = n*10 + *s++ - '0';
 28b:	8d 14 92             	lea    (%edx,%edx,4),%edx
 28e:	8d 1c 12             	lea    (%edx,%edx,1),%ebx
 291:	41                   	inc    %ecx
 292:	0f be c0             	movsbl %al,%eax
 295:	8d 54 18 d0          	lea    -0x30(%eax,%ebx,1),%edx
  while('0' <= *s && *s <= '9')
 299:	8a 01                	mov    (%ecx),%al
 29b:	8d 58 d0             	lea    -0x30(%eax),%ebx
 29e:	80 fb 09             	cmp    $0x9,%bl
 2a1:	76 e8                	jbe    28b <atoi+0xe>
  return n;
}
 2a3:	89 d0                	mov    %edx,%eax
 2a5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 2a8:	c9                   	leave  
 2a9:	c3                   	ret    

000002aa <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 2aa:	55                   	push   %ebp
 2ab:	89 e5                	mov    %esp,%ebp
 2ad:	56                   	push   %esi
 2ae:	53                   	push   %ebx
 2af:	8b 45 08             	mov    0x8(%ebp),%eax
 2b2:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 2b5:	8b 55 10             	mov    0x10(%ebp),%edx
  char *dst;
  const char *src;

  dst = vdst;
 2b8:	89 c1                	mov    %eax,%ecx
  src = vsrc;
  while(n-- > 0)
 2ba:	eb 0c                	jmp    2c8 <memmove+0x1e>
    *dst++ = *src++;
 2bc:	8a 13                	mov    (%ebx),%dl
 2be:	88 11                	mov    %dl,(%ecx)
 2c0:	8d 5b 01             	lea    0x1(%ebx),%ebx
 2c3:	8d 49 01             	lea    0x1(%ecx),%ecx
  while(n-- > 0)
 2c6:	89 f2                	mov    %esi,%edx
 2c8:	8d 72 ff             	lea    -0x1(%edx),%esi
 2cb:	85 d2                	test   %edx,%edx
 2cd:	7f ed                	jg     2bc <memmove+0x12>
  return vdst;
}
 2cf:	5b                   	pop    %ebx
 2d0:	5e                   	pop    %esi
 2d1:	5d                   	pop    %ebp
 2d2:	c3                   	ret    

000002d3 <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 2d3:	b8 01 00 00 00       	mov    $0x1,%eax
 2d8:	cd 40                	int    $0x40
 2da:	c3                   	ret    

000002db <exit>:
SYSCALL(exit)
 2db:	b8 02 00 00 00       	mov    $0x2,%eax
 2e0:	cd 40                	int    $0x40
 2e2:	c3                   	ret    

000002e3 <wait>:
SYSCALL(wait)
 2e3:	b8 03 00 00 00       	mov    $0x3,%eax
 2e8:	cd 40                	int    $0x40
 2ea:	c3                   	ret    

000002eb <pipe>:
SYSCALL(pipe)
 2eb:	b8 04 00 00 00       	mov    $0x4,%eax
 2f0:	cd 40                	int    $0x40
 2f2:	c3                   	ret    

000002f3 <read>:
SYSCALL(read)
 2f3:	b8 05 00 00 00       	mov    $0x5,%eax
 2f8:	cd 40                	int    $0x40
 2fa:	c3                   	ret    

000002fb <write>:
SYSCALL(write)
 2fb:	b8 10 00 00 00       	mov    $0x10,%eax
 300:	cd 40                	int    $0x40
 302:	c3                   	ret    

00000303 <close>:
SYSCALL(close)
 303:	b8 15 00 00 00       	mov    $0x15,%eax
 308:	cd 40                	int    $0x40
 30a:	c3                   	ret    

0000030b <kill>:
SYSCALL(kill)
 30b:	b8 06 00 00 00       	mov    $0x6,%eax
 310:	cd 40                	int    $0x40
 312:	c3                   	ret    

00000313 <exec>:
SYSCALL(exec)
 313:	b8 07 00 00 00       	mov    $0x7,%eax
 318:	cd 40                	int    $0x40
 31a:	c3                   	ret    

0000031b <open>:
SYSCALL(open)
 31b:	b8 0f 00 00 00       	mov    $0xf,%eax
 320:	cd 40                	int    $0x40
 322:	c3                   	ret    

00000323 <mknod>:
SYSCALL(mknod)
 323:	b8 11 00 00 00       	mov    $0x11,%eax
 328:	cd 40                	int    $0x40
 32a:	c3                   	ret    

0000032b <unlink>:
SYSCALL(unlink)
 32b:	b8 12 00 00 00       	mov    $0x12,%eax
 330:	cd 40                	int    $0x40
 332:	c3                   	ret    

00000333 <fstat>:
SYSCALL(fstat)
 333:	b8 08 00 00 00       	mov    $0x8,%eax
 338:	cd 40                	int    $0x40
 33a:	c3                   	ret    

0000033b <link>:
SYSCALL(link)
 33b:	b8 13 00 00 00       	mov    $0x13,%eax
 340:	cd 40                	int    $0x40
 342:	c3                   	ret    

00000343 <mkdir>:
SYSCALL(mkdir)
 343:	b8 14 00 00 00       	mov    $0x14,%eax
 348:	cd 40                	int    $0x40
 34a:	c3                   	ret    

0000034b <chdir>:
SYSCALL(chdir)
 34b:	b8 09 00 00 00       	mov    $0x9,%eax
 350:	cd 40                	int    $0x40
 352:	c3                   	ret    

00000353 <dup>:
SYSCALL(dup)
 353:	b8 0a 00 00 00       	mov    $0xa,%eax
 358:	cd 40                	int    $0x40
 35a:	c3                   	ret    

0000035b <getpid>:
SYSCALL(getpid)
 35b:	b8 0b 00 00 00       	mov    $0xb,%eax
 360:	cd 40                	int    $0x40
 362:	c3                   	ret    

00000363 <sbrk>:
SYSCALL(sbrk)
 363:	b8 0c 00 00 00       	mov    $0xc,%eax
 368:	cd 40                	int    $0x40
 36a:	c3                   	ret    

0000036b <sleep>:
SYSCALL(sleep)
 36b:	b8 0d 00 00 00       	mov    $0xd,%eax
 370:	cd 40                	int    $0x40
 372:	c3                   	ret    

00000373 <uptime>:
SYSCALL(uptime)
 373:	b8 0e 00 00 00       	mov    $0xe,%eax
 378:	cd 40                	int    $0x40
 37a:	c3                   	ret    

0000037b <date>:
SYSCALL(date)
 37b:	b8 16 00 00 00       	mov    $0x16,%eax
 380:	cd 40                	int    $0x40
 382:	c3                   	ret    

00000383 <dup2>:
SYSCALL(dup2)
 383:	b8 17 00 00 00       	mov    $0x17,%eax
 388:	cd 40                	int    $0x40
 38a:	c3                   	ret    

0000038b <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 38b:	55                   	push   %ebp
 38c:	89 e5                	mov    %esp,%ebp
 38e:	83 ec 1c             	sub    $0x1c,%esp
 391:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 394:	6a 01                	push   $0x1
 396:	8d 55 f4             	lea    -0xc(%ebp),%edx
 399:	52                   	push   %edx
 39a:	50                   	push   %eax
 39b:	e8 5b ff ff ff       	call   2fb <write>
}
 3a0:	83 c4 10             	add    $0x10,%esp
 3a3:	c9                   	leave  
 3a4:	c3                   	ret    

000003a5 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 3a5:	55                   	push   %ebp
 3a6:	89 e5                	mov    %esp,%ebp
 3a8:	57                   	push   %edi
 3a9:	56                   	push   %esi
 3aa:	53                   	push   %ebx
 3ab:	83 ec 2c             	sub    $0x2c,%esp
 3ae:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 3b1:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 3b3:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 3b7:	74 04                	je     3bd <printint+0x18>
 3b9:	85 d2                	test   %edx,%edx
 3bb:	78 3c                	js     3f9 <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 3bd:	89 d1                	mov    %edx,%ecx
  neg = 0;
 3bf:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 3c6:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 3cb:	89 c8                	mov    %ecx,%eax
 3cd:	ba 00 00 00 00       	mov    $0x0,%edx
 3d2:	f7 f6                	div    %esi
 3d4:	89 df                	mov    %ebx,%edi
 3d6:	43                   	inc    %ebx
 3d7:	8a 92 18 06 00 00    	mov    0x618(%edx),%dl
 3dd:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 3e1:	89 ca                	mov    %ecx,%edx
 3e3:	89 c1                	mov    %eax,%ecx
 3e5:	39 d6                	cmp    %edx,%esi
 3e7:	76 e2                	jbe    3cb <printint+0x26>
  if(neg)
 3e9:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 3ed:	74 24                	je     413 <printint+0x6e>
    buf[i++] = '-';
 3ef:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 3f4:	8d 5f 02             	lea    0x2(%edi),%ebx
 3f7:	eb 1a                	jmp    413 <printint+0x6e>
    x = -xx;
 3f9:	89 d1                	mov    %edx,%ecx
 3fb:	f7 d9                	neg    %ecx
    neg = 1;
 3fd:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 404:	eb c0                	jmp    3c6 <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 406:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 40b:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 40e:	e8 78 ff ff ff       	call   38b <putc>
  while(--i >= 0)
 413:	4b                   	dec    %ebx
 414:	79 f0                	jns    406 <printint+0x61>
}
 416:	83 c4 2c             	add    $0x2c,%esp
 419:	5b                   	pop    %ebx
 41a:	5e                   	pop    %esi
 41b:	5f                   	pop    %edi
 41c:	5d                   	pop    %ebp
 41d:	c3                   	ret    

0000041e <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 41e:	55                   	push   %ebp
 41f:	89 e5                	mov    %esp,%ebp
 421:	57                   	push   %edi
 422:	56                   	push   %esi
 423:	53                   	push   %ebx
 424:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 427:	8d 45 10             	lea    0x10(%ebp),%eax
 42a:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 42d:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 432:	bb 00 00 00 00       	mov    $0x0,%ebx
 437:	eb 12                	jmp    44b <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 439:	89 fa                	mov    %edi,%edx
 43b:	8b 45 08             	mov    0x8(%ebp),%eax
 43e:	e8 48 ff ff ff       	call   38b <putc>
 443:	eb 05                	jmp    44a <printf+0x2c>
      }
    } else if(state == '%'){
 445:	83 fe 25             	cmp    $0x25,%esi
 448:	74 22                	je     46c <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 44a:	43                   	inc    %ebx
 44b:	8b 45 0c             	mov    0xc(%ebp),%eax
 44e:	8a 04 18             	mov    (%eax,%ebx,1),%al
 451:	84 c0                	test   %al,%al
 453:	0f 84 1d 01 00 00    	je     576 <printf+0x158>
    c = fmt[i] & 0xff;
 459:	0f be f8             	movsbl %al,%edi
 45c:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 45f:	85 f6                	test   %esi,%esi
 461:	75 e2                	jne    445 <printf+0x27>
      if(c == '%'){
 463:	83 f8 25             	cmp    $0x25,%eax
 466:	75 d1                	jne    439 <printf+0x1b>
        state = '%';
 468:	89 c6                	mov    %eax,%esi
 46a:	eb de                	jmp    44a <printf+0x2c>
      if(c == 'd'){
 46c:	83 f8 25             	cmp    $0x25,%eax
 46f:	0f 84 cc 00 00 00    	je     541 <printf+0x123>
 475:	0f 8c da 00 00 00    	jl     555 <printf+0x137>
 47b:	83 f8 78             	cmp    $0x78,%eax
 47e:	0f 8f d1 00 00 00    	jg     555 <printf+0x137>
 484:	83 f8 63             	cmp    $0x63,%eax
 487:	0f 8c c8 00 00 00    	jl     555 <printf+0x137>
 48d:	83 e8 63             	sub    $0x63,%eax
 490:	83 f8 15             	cmp    $0x15,%eax
 493:	0f 87 bc 00 00 00    	ja     555 <printf+0x137>
 499:	ff 24 85 c0 05 00 00 	jmp    *0x5c0(,%eax,4)
        printint(fd, *ap, 10, 1);
 4a0:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 4a3:	8b 17                	mov    (%edi),%edx
 4a5:	83 ec 0c             	sub    $0xc,%esp
 4a8:	6a 01                	push   $0x1
 4aa:	b9 0a 00 00 00       	mov    $0xa,%ecx
 4af:	8b 45 08             	mov    0x8(%ebp),%eax
 4b2:	e8 ee fe ff ff       	call   3a5 <printint>
        ap++;
 4b7:	83 c7 04             	add    $0x4,%edi
 4ba:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 4bd:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 4c0:	be 00 00 00 00       	mov    $0x0,%esi
 4c5:	eb 83                	jmp    44a <printf+0x2c>
        printint(fd, *ap, 16, 0);
 4c7:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 4ca:	8b 17                	mov    (%edi),%edx
 4cc:	83 ec 0c             	sub    $0xc,%esp
 4cf:	6a 00                	push   $0x0
 4d1:	b9 10 00 00 00       	mov    $0x10,%ecx
 4d6:	8b 45 08             	mov    0x8(%ebp),%eax
 4d9:	e8 c7 fe ff ff       	call   3a5 <printint>
        ap++;
 4de:	83 c7 04             	add    $0x4,%edi
 4e1:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 4e4:	83 c4 10             	add    $0x10,%esp
      state = 0;
 4e7:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 4ec:	e9 59 ff ff ff       	jmp    44a <printf+0x2c>
        s = (char*)*ap;
 4f1:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 4f4:	8b 30                	mov    (%eax),%esi
        ap++;
 4f6:	83 c0 04             	add    $0x4,%eax
 4f9:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 4fc:	85 f6                	test   %esi,%esi
 4fe:	75 13                	jne    513 <printf+0xf5>
          s = "(null)";
 500:	be b7 05 00 00       	mov    $0x5b7,%esi
 505:	eb 0c                	jmp    513 <printf+0xf5>
          putc(fd, *s);
 507:	0f be d2             	movsbl %dl,%edx
 50a:	8b 45 08             	mov    0x8(%ebp),%eax
 50d:	e8 79 fe ff ff       	call   38b <putc>
          s++;
 512:	46                   	inc    %esi
        while(*s != 0){
 513:	8a 16                	mov    (%esi),%dl
 515:	84 d2                	test   %dl,%dl
 517:	75 ee                	jne    507 <printf+0xe9>
      state = 0;
 519:	be 00 00 00 00       	mov    $0x0,%esi
 51e:	e9 27 ff ff ff       	jmp    44a <printf+0x2c>
        putc(fd, *ap);
 523:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 526:	0f be 17             	movsbl (%edi),%edx
 529:	8b 45 08             	mov    0x8(%ebp),%eax
 52c:	e8 5a fe ff ff       	call   38b <putc>
        ap++;
 531:	83 c7 04             	add    $0x4,%edi
 534:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 537:	be 00 00 00 00       	mov    $0x0,%esi
 53c:	e9 09 ff ff ff       	jmp    44a <printf+0x2c>
        putc(fd, c);
 541:	89 fa                	mov    %edi,%edx
 543:	8b 45 08             	mov    0x8(%ebp),%eax
 546:	e8 40 fe ff ff       	call   38b <putc>
      state = 0;
 54b:	be 00 00 00 00       	mov    $0x0,%esi
 550:	e9 f5 fe ff ff       	jmp    44a <printf+0x2c>
        putc(fd, '%');
 555:	ba 25 00 00 00       	mov    $0x25,%edx
 55a:	8b 45 08             	mov    0x8(%ebp),%eax
 55d:	e8 29 fe ff ff       	call   38b <putc>
        putc(fd, c);
 562:	89 fa                	mov    %edi,%edx
 564:	8b 45 08             	mov    0x8(%ebp),%eax
 567:	e8 1f fe ff ff       	call   38b <putc>
      state = 0;
 56c:	be 00 00 00 00       	mov    $0x0,%esi
 571:	e9 d4 fe ff ff       	jmp    44a <printf+0x2c>
    }
  }
}
 576:	8d 65 f4             	lea    -0xc(%ebp),%esp
 579:	5b                   	pop    %ebx
 57a:	5e                   	pop    %esi
 57b:	5f                   	pop    %edi
 57c:	5d                   	pop    %ebp
 57d:	c3                   	ret    
