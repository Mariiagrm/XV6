
grep:     formato del fichero elf32-i386


Desensamblado de la sección .text:

00000000 <matchstar>:
  return 0;
}

// matchstar: search for c*re at beginning of text
int matchstar(int c, char *re, char *text)
{
   0:	55                   	push   %ebp
   1:	89 e5                	mov    %esp,%ebp
   3:	57                   	push   %edi
   4:	56                   	push   %esi
   5:	53                   	push   %ebx
   6:	83 ec 0c             	sub    $0xc,%esp
   9:	8b 75 08             	mov    0x8(%ebp),%esi
   c:	8b 7d 0c             	mov    0xc(%ebp),%edi
   f:	8b 5d 10             	mov    0x10(%ebp),%ebx
  do{  // a * matches zero or more instances
    if(matchhere(re, text))
  12:	83 ec 08             	sub    $0x8,%esp
  15:	53                   	push   %ebx
  16:	57                   	push   %edi
  17:	e8 29 00 00 00       	call   45 <matchhere>
  1c:	83 c4 10             	add    $0x10,%esp
  1f:	85 c0                	test   %eax,%eax
  21:	75 15                	jne    38 <matchstar+0x38>
      return 1;
  }while(*text!='\0' && (*text++==c || c=='.'));
  23:	8a 13                	mov    (%ebx),%dl
  25:	84 d2                	test   %dl,%dl
  27:	74 14                	je     3d <matchstar+0x3d>
  29:	43                   	inc    %ebx
  2a:	0f be d2             	movsbl %dl,%edx
  2d:	39 f2                	cmp    %esi,%edx
  2f:	74 e1                	je     12 <matchstar+0x12>
  31:	83 fe 2e             	cmp    $0x2e,%esi
  34:	74 dc                	je     12 <matchstar+0x12>
  36:	eb 05                	jmp    3d <matchstar+0x3d>
      return 1;
  38:	b8 01 00 00 00       	mov    $0x1,%eax
  return 0;
}
  3d:	8d 65 f4             	lea    -0xc(%ebp),%esp
  40:	5b                   	pop    %ebx
  41:	5e                   	pop    %esi
  42:	5f                   	pop    %edi
  43:	5d                   	pop    %ebp
  44:	c3                   	ret    

00000045 <matchhere>:
{
  45:	55                   	push   %ebp
  46:	89 e5                	mov    %esp,%ebp
  48:	83 ec 08             	sub    $0x8,%esp
  4b:	8b 55 08             	mov    0x8(%ebp),%edx
  if(re[0] == '\0')
  4e:	8a 02                	mov    (%edx),%al
  50:	84 c0                	test   %al,%al
  52:	74 62                	je     b6 <matchhere+0x71>
  if(re[1] == '*')
  54:	8a 4a 01             	mov    0x1(%edx),%cl
  57:	80 f9 2a             	cmp    $0x2a,%cl
  5a:	74 1c                	je     78 <matchhere+0x33>
  if(re[0] == '$' && re[1] == '\0')
  5c:	3c 24                	cmp    $0x24,%al
  5e:	74 30                	je     90 <matchhere+0x4b>
  if(*text!='\0' && (re[0]=='.' || re[0]==*text))
  60:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  63:	8a 09                	mov    (%ecx),%cl
  65:	84 c9                	test   %cl,%cl
  67:	74 54                	je     bd <matchhere+0x78>
  69:	3c 2e                	cmp    $0x2e,%al
  6b:	74 35                	je     a2 <matchhere+0x5d>
  6d:	38 c8                	cmp    %cl,%al
  6f:	74 31                	je     a2 <matchhere+0x5d>
  return 0;
  71:	b8 00 00 00 00       	mov    $0x0,%eax
  76:	eb 43                	jmp    bb <matchhere+0x76>
    return matchstar(re[0], re+2, text);
  78:	83 ec 04             	sub    $0x4,%esp
  7b:	ff 75 0c             	push   0xc(%ebp)
  7e:	83 c2 02             	add    $0x2,%edx
  81:	52                   	push   %edx
  82:	0f be c0             	movsbl %al,%eax
  85:	50                   	push   %eax
  86:	e8 75 ff ff ff       	call   0 <matchstar>
  8b:	83 c4 10             	add    $0x10,%esp
  8e:	eb 2b                	jmp    bb <matchhere+0x76>
  if(re[0] == '$' && re[1] == '\0')
  90:	84 c9                	test   %cl,%cl
  92:	75 cc                	jne    60 <matchhere+0x1b>
    return *text == '\0';
  94:	8b 45 0c             	mov    0xc(%ebp),%eax
  97:	80 38 00             	cmpb   $0x0,(%eax)
  9a:	0f 94 c0             	sete   %al
  9d:	0f b6 c0             	movzbl %al,%eax
  a0:	eb 19                	jmp    bb <matchhere+0x76>
    return matchhere(re+1, text+1);
  a2:	83 ec 08             	sub    $0x8,%esp
  a5:	8b 45 0c             	mov    0xc(%ebp),%eax
  a8:	40                   	inc    %eax
  a9:	50                   	push   %eax
  aa:	42                   	inc    %edx
  ab:	52                   	push   %edx
  ac:	e8 94 ff ff ff       	call   45 <matchhere>
  b1:	83 c4 10             	add    $0x10,%esp
  b4:	eb 05                	jmp    bb <matchhere+0x76>
    return 1;
  b6:	b8 01 00 00 00       	mov    $0x1,%eax
}
  bb:	c9                   	leave  
  bc:	c3                   	ret    
  return 0;
  bd:	b8 00 00 00 00       	mov    $0x0,%eax
  c2:	eb f7                	jmp    bb <matchhere+0x76>

000000c4 <match>:
{
  c4:	55                   	push   %ebp
  c5:	89 e5                	mov    %esp,%ebp
  c7:	56                   	push   %esi
  c8:	53                   	push   %ebx
  c9:	8b 75 08             	mov    0x8(%ebp),%esi
  cc:	8b 5d 0c             	mov    0xc(%ebp),%ebx
  if(re[0] == '^')
  cf:	80 3e 5e             	cmpb   $0x5e,(%esi)
  d2:	75 12                	jne    e6 <match+0x22>
    return matchhere(re+1, text);
  d4:	83 ec 08             	sub    $0x8,%esp
  d7:	53                   	push   %ebx
  d8:	46                   	inc    %esi
  d9:	56                   	push   %esi
  da:	e8 66 ff ff ff       	call   45 <matchhere>
  df:	83 c4 10             	add    $0x10,%esp
  e2:	eb 22                	jmp    106 <match+0x42>
  }while(*text++ != '\0');
  e4:	89 d3                	mov    %edx,%ebx
    if(matchhere(re, text))
  e6:	83 ec 08             	sub    $0x8,%esp
  e9:	53                   	push   %ebx
  ea:	56                   	push   %esi
  eb:	e8 55 ff ff ff       	call   45 <matchhere>
  f0:	83 c4 10             	add    $0x10,%esp
  f3:	85 c0                	test   %eax,%eax
  f5:	75 0a                	jne    101 <match+0x3d>
  }while(*text++ != '\0');
  f7:	8d 53 01             	lea    0x1(%ebx),%edx
  fa:	80 3b 00             	cmpb   $0x0,(%ebx)
  fd:	75 e5                	jne    e4 <match+0x20>
  ff:	eb 05                	jmp    106 <match+0x42>
      return 1;
 101:	b8 01 00 00 00       	mov    $0x1,%eax
}
 106:	8d 65 f8             	lea    -0x8(%ebp),%esp
 109:	5b                   	pop    %ebx
 10a:	5e                   	pop    %esi
 10b:	5d                   	pop    %ebp
 10c:	c3                   	ret    

0000010d <grep>:
{
 10d:	55                   	push   %ebp
 10e:	89 e5                	mov    %esp,%ebp
 110:	57                   	push   %edi
 111:	56                   	push   %esi
 112:	53                   	push   %ebx
 113:	83 ec 1c             	sub    $0x1c,%esp
 116:	8b 7d 08             	mov    0x8(%ebp),%edi
  m = 0;
 119:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 120:	eb 53                	jmp    175 <grep+0x68>
      p = q+1;
 122:	8d 73 01             	lea    0x1(%ebx),%esi
    while((q = strchr(p, '\n')) != 0){
 125:	83 ec 08             	sub    $0x8,%esp
 128:	6a 0a                	push   $0xa
 12a:	56                   	push   %esi
 12b:	e8 d1 01 00 00       	call   301 <strchr>
 130:	89 c3                	mov    %eax,%ebx
 132:	83 c4 10             	add    $0x10,%esp
 135:	85 c0                	test   %eax,%eax
 137:	74 2d                	je     166 <grep+0x59>
      *q = 0;
 139:	c6 03 00             	movb   $0x0,(%ebx)
      if(match(pattern, p)){
 13c:	83 ec 08             	sub    $0x8,%esp
 13f:	56                   	push   %esi
 140:	57                   	push   %edi
 141:	e8 7e ff ff ff       	call   c4 <match>
 146:	83 c4 10             	add    $0x10,%esp
 149:	85 c0                	test   %eax,%eax
 14b:	74 d5                	je     122 <grep+0x15>
        *q = '\n';
 14d:	c6 03 0a             	movb   $0xa,(%ebx)
        write(1, p, q+1 - p);
 150:	8d 43 01             	lea    0x1(%ebx),%eax
 153:	83 ec 04             	sub    $0x4,%esp
 156:	29 f0                	sub    %esi,%eax
 158:	50                   	push   %eax
 159:	56                   	push   %esi
 15a:	6a 01                	push   $0x1
 15c:	e8 d3 02 00 00       	call   434 <write>
 161:	83 c4 10             	add    $0x10,%esp
 164:	eb bc                	jmp    122 <grep+0x15>
    if(p == buf)
 166:	81 fe 40 0a 00 00    	cmp    $0xa40,%esi
 16c:	74 62                	je     1d0 <grep+0xc3>
    if(m > 0){
 16e:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
 171:	85 c9                	test   %ecx,%ecx
 173:	7f 3b                	jg     1b0 <grep+0xa3>
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 175:	b8 ff 03 00 00       	mov    $0x3ff,%eax
 17a:	8b 4d e4             	mov    -0x1c(%ebp),%ecx
 17d:	29 c8                	sub    %ecx,%eax
 17f:	83 ec 04             	sub    $0x4,%esp
 182:	50                   	push   %eax
 183:	8d 81 40 0a 00 00    	lea    0xa40(%ecx),%eax
 189:	50                   	push   %eax
 18a:	ff 75 0c             	push   0xc(%ebp)
 18d:	e8 9a 02 00 00       	call   42c <read>
 192:	83 c4 10             	add    $0x10,%esp
 195:	85 c0                	test   %eax,%eax
 197:	7e 40                	jle    1d9 <grep+0xcc>
    m += n;
 199:	01 45 e4             	add    %eax,-0x1c(%ebp)
 19c:	8b 55 e4             	mov    -0x1c(%ebp),%edx
    buf[m] = '\0';
 19f:	c6 82 40 0a 00 00 00 	movb   $0x0,0xa40(%edx)
    p = buf;
 1a6:	be 40 0a 00 00       	mov    $0xa40,%esi
    while((q = strchr(p, '\n')) != 0){
 1ab:	e9 75 ff ff ff       	jmp    125 <grep+0x18>
      m -= p - buf;
 1b0:	89 f0                	mov    %esi,%eax
 1b2:	2d 40 0a 00 00       	sub    $0xa40,%eax
 1b7:	29 c1                	sub    %eax,%ecx
 1b9:	89 4d e4             	mov    %ecx,-0x1c(%ebp)
      memmove(buf, p, m);
 1bc:	83 ec 04             	sub    $0x4,%esp
 1bf:	51                   	push   %ecx
 1c0:	56                   	push   %esi
 1c1:	68 40 0a 00 00       	push   $0xa40
 1c6:	e8 18 02 00 00       	call   3e3 <memmove>
 1cb:	83 c4 10             	add    $0x10,%esp
 1ce:	eb a5                	jmp    175 <grep+0x68>
      m = 0;
 1d0:	c7 45 e4 00 00 00 00 	movl   $0x0,-0x1c(%ebp)
 1d7:	eb 9c                	jmp    175 <grep+0x68>
}
 1d9:	8d 65 f4             	lea    -0xc(%ebp),%esp
 1dc:	5b                   	pop    %ebx
 1dd:	5e                   	pop    %esi
 1de:	5f                   	pop    %edi
 1df:	5d                   	pop    %ebp
 1e0:	c3                   	ret    

000001e1 <main>:
{
 1e1:	8d 4c 24 04          	lea    0x4(%esp),%ecx
 1e5:	83 e4 f0             	and    $0xfffffff0,%esp
 1e8:	ff 71 fc             	push   -0x4(%ecx)
 1eb:	55                   	push   %ebp
 1ec:	89 e5                	mov    %esp,%ebp
 1ee:	57                   	push   %edi
 1ef:	56                   	push   %esi
 1f0:	53                   	push   %ebx
 1f1:	51                   	push   %ecx
 1f2:	83 ec 18             	sub    $0x18,%esp
 1f5:	8b 01                	mov    (%ecx),%eax
 1f7:	89 45 e4             	mov    %eax,-0x1c(%ebp)
 1fa:	8b 51 04             	mov    0x4(%ecx),%edx
 1fd:	89 55 e0             	mov    %edx,-0x20(%ebp)
  if(argc <= 1){
 200:	83 f8 01             	cmp    $0x1,%eax
 203:	7e 4e                	jle    253 <main+0x72>
  pattern = argv[1];
 205:	8b 45 e0             	mov    -0x20(%ebp),%eax
 208:	8b 40 04             	mov    0x4(%eax),%eax
 20b:	89 45 dc             	mov    %eax,-0x24(%ebp)
  if(argc <= 2){
 20e:	83 7d e4 02          	cmpl   $0x2,-0x1c(%ebp)
 212:	7e 53                	jle    267 <main+0x86>
  for(i = 2; i < argc; i++){
 214:	be 02 00 00 00       	mov    $0x2,%esi
 219:	3b 75 e4             	cmp    -0x1c(%ebp),%esi
 21c:	7d 6f                	jge    28d <main+0xac>
    if((fd = open(argv[i], 0)) < 0){
 21e:	8b 45 e0             	mov    -0x20(%ebp),%eax
 221:	8d 3c b0             	lea    (%eax,%esi,4),%edi
 224:	83 ec 08             	sub    $0x8,%esp
 227:	6a 00                	push   $0x0
 229:	ff 37                	push   (%edi)
 22b:	e8 24 02 00 00       	call   454 <open>
 230:	89 c3                	mov    %eax,%ebx
 232:	83 c4 10             	add    $0x10,%esp
 235:	85 c0                	test   %eax,%eax
 237:	78 3e                	js     277 <main+0x96>
    grep(pattern, fd);
 239:	83 ec 08             	sub    $0x8,%esp
 23c:	50                   	push   %eax
 23d:	ff 75 dc             	push   -0x24(%ebp)
 240:	e8 c8 fe ff ff       	call   10d <grep>
    close(fd);
 245:	89 1c 24             	mov    %ebx,(%esp)
 248:	e8 ef 01 00 00       	call   43c <close>
  for(i = 2; i < argc; i++){
 24d:	46                   	inc    %esi
 24e:	83 c4 10             	add    $0x10,%esp
 251:	eb c6                	jmp    219 <main+0x38>
    printf(2, "usage: grep pattern [file ...]\n");
 253:	83 ec 08             	sub    $0x8,%esp
 256:	68 b8 06 00 00       	push   $0x6b8
 25b:	6a 02                	push   $0x2
 25d:	e8 f5 02 00 00       	call   557 <printf>
    exit();
 262:	e8 ad 01 00 00       	call   414 <exit>
    grep(pattern, 0);
 267:	83 ec 08             	sub    $0x8,%esp
 26a:	6a 00                	push   $0x0
 26c:	50                   	push   %eax
 26d:	e8 9b fe ff ff       	call   10d <grep>
    exit();
 272:	e8 9d 01 00 00       	call   414 <exit>
      printf(1, "grep: cannot open %s\n", argv[i]);
 277:	83 ec 04             	sub    $0x4,%esp
 27a:	ff 37                	push   (%edi)
 27c:	68 d8 06 00 00       	push   $0x6d8
 281:	6a 01                	push   $0x1
 283:	e8 cf 02 00 00       	call   557 <printf>
      exit();
 288:	e8 87 01 00 00       	call   414 <exit>
  exit();
 28d:	e8 82 01 00 00       	call   414 <exit>

00000292 <start>:

// Entry point of the library	
void
start()
{
}
 292:	c3                   	ret    

00000293 <strcpy>:

char*
strcpy(char *s, const char *t)
{
 293:	55                   	push   %ebp
 294:	89 e5                	mov    %esp,%ebp
 296:	56                   	push   %esi
 297:	53                   	push   %ebx
 298:	8b 45 08             	mov    0x8(%ebp),%eax
 29b:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 29e:	89 c2                	mov    %eax,%edx
 2a0:	89 cb                	mov    %ecx,%ebx
 2a2:	41                   	inc    %ecx
 2a3:	89 d6                	mov    %edx,%esi
 2a5:	42                   	inc    %edx
 2a6:	8a 1b                	mov    (%ebx),%bl
 2a8:	88 1e                	mov    %bl,(%esi)
 2aa:	84 db                	test   %bl,%bl
 2ac:	75 f2                	jne    2a0 <strcpy+0xd>
    ;
  return os;
}
 2ae:	5b                   	pop    %ebx
 2af:	5e                   	pop    %esi
 2b0:	5d                   	pop    %ebp
 2b1:	c3                   	ret    

000002b2 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 2b2:	55                   	push   %ebp
 2b3:	89 e5                	mov    %esp,%ebp
 2b5:	8b 4d 08             	mov    0x8(%ebp),%ecx
 2b8:	8b 55 0c             	mov    0xc(%ebp),%edx
  while(*p && *p == *q)
 2bb:	eb 02                	jmp    2bf <strcmp+0xd>
    p++, q++;
 2bd:	41                   	inc    %ecx
 2be:	42                   	inc    %edx
  while(*p && *p == *q)
 2bf:	8a 01                	mov    (%ecx),%al
 2c1:	84 c0                	test   %al,%al
 2c3:	74 04                	je     2c9 <strcmp+0x17>
 2c5:	3a 02                	cmp    (%edx),%al
 2c7:	74 f4                	je     2bd <strcmp+0xb>
  return (uchar)*p - (uchar)*q;
 2c9:	0f b6 c0             	movzbl %al,%eax
 2cc:	0f b6 12             	movzbl (%edx),%edx
 2cf:	29 d0                	sub    %edx,%eax
}
 2d1:	5d                   	pop    %ebp
 2d2:	c3                   	ret    

000002d3 <strlen>:

uint
strlen(const char *s)
{
 2d3:	55                   	push   %ebp
 2d4:	89 e5                	mov    %esp,%ebp
 2d6:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  for(n = 0; s[n]; n++)
 2d9:	b8 00 00 00 00       	mov    $0x0,%eax
 2de:	eb 01                	jmp    2e1 <strlen+0xe>
 2e0:	40                   	inc    %eax
 2e1:	80 3c 01 00          	cmpb   $0x0,(%ecx,%eax,1)
 2e5:	75 f9                	jne    2e0 <strlen+0xd>
    ;
  return n;
}
 2e7:	5d                   	pop    %ebp
 2e8:	c3                   	ret    

000002e9 <memset>:

void*
memset(void *dst, int c, uint n)
{
 2e9:	55                   	push   %ebp
 2ea:	89 e5                	mov    %esp,%ebp
 2ec:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 2ed:	8b 7d 08             	mov    0x8(%ebp),%edi
 2f0:	8b 4d 10             	mov    0x10(%ebp),%ecx
 2f3:	8b 45 0c             	mov    0xc(%ebp),%eax
 2f6:	fc                   	cld    
 2f7:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 2f9:	8b 45 08             	mov    0x8(%ebp),%eax
 2fc:	8b 7d fc             	mov    -0x4(%ebp),%edi
 2ff:	c9                   	leave  
 300:	c3                   	ret    

00000301 <strchr>:

char*
strchr(const char *s, char c)
{
 301:	55                   	push   %ebp
 302:	89 e5                	mov    %esp,%ebp
 304:	8b 45 08             	mov    0x8(%ebp),%eax
 307:	8a 4d 0c             	mov    0xc(%ebp),%cl
  for(; *s; s++)
 30a:	eb 01                	jmp    30d <strchr+0xc>
 30c:	40                   	inc    %eax
 30d:	8a 10                	mov    (%eax),%dl
 30f:	84 d2                	test   %dl,%dl
 311:	74 06                	je     319 <strchr+0x18>
    if(*s == c)
 313:	38 ca                	cmp    %cl,%dl
 315:	75 f5                	jne    30c <strchr+0xb>
 317:	eb 05                	jmp    31e <strchr+0x1d>
      return (char*)s;
  return 0;
 319:	b8 00 00 00 00       	mov    $0x0,%eax
}
 31e:	5d                   	pop    %ebp
 31f:	c3                   	ret    

00000320 <gets>:

char*
gets(char *buf, int max)
{
 320:	55                   	push   %ebp
 321:	89 e5                	mov    %esp,%ebp
 323:	57                   	push   %edi
 324:	56                   	push   %esi
 325:	53                   	push   %ebx
 326:	83 ec 1c             	sub    $0x1c,%esp
 329:	8b 7d 08             	mov    0x8(%ebp),%edi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 32c:	bb 00 00 00 00       	mov    $0x0,%ebx
 331:	89 de                	mov    %ebx,%esi
 333:	43                   	inc    %ebx
 334:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 337:	7d 2b                	jge    364 <gets+0x44>
    cc = read(0, &c, 1);
 339:	83 ec 04             	sub    $0x4,%esp
 33c:	6a 01                	push   $0x1
 33e:	8d 45 e7             	lea    -0x19(%ebp),%eax
 341:	50                   	push   %eax
 342:	6a 00                	push   $0x0
 344:	e8 e3 00 00 00       	call   42c <read>
    if(cc < 1)
 349:	83 c4 10             	add    $0x10,%esp
 34c:	85 c0                	test   %eax,%eax
 34e:	7e 14                	jle    364 <gets+0x44>
      break;
    buf[i++] = c;
 350:	8a 45 e7             	mov    -0x19(%ebp),%al
 353:	88 04 37             	mov    %al,(%edi,%esi,1)
    if(c == '\n' || c == '\r')
 356:	3c 0a                	cmp    $0xa,%al
 358:	74 08                	je     362 <gets+0x42>
 35a:	3c 0d                	cmp    $0xd,%al
 35c:	75 d3                	jne    331 <gets+0x11>
    buf[i++] = c;
 35e:	89 de                	mov    %ebx,%esi
 360:	eb 02                	jmp    364 <gets+0x44>
 362:	89 de                	mov    %ebx,%esi
      break;
  }
  buf[i] = '\0';
 364:	c6 04 37 00          	movb   $0x0,(%edi,%esi,1)
  return buf;
}
 368:	89 f8                	mov    %edi,%eax
 36a:	8d 65 f4             	lea    -0xc(%ebp),%esp
 36d:	5b                   	pop    %ebx
 36e:	5e                   	pop    %esi
 36f:	5f                   	pop    %edi
 370:	5d                   	pop    %ebp
 371:	c3                   	ret    

00000372 <stat>:

int
stat(const char *n, struct stat *st)
{
 372:	55                   	push   %ebp
 373:	89 e5                	mov    %esp,%ebp
 375:	56                   	push   %esi
 376:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 377:	83 ec 08             	sub    $0x8,%esp
 37a:	6a 00                	push   $0x0
 37c:	ff 75 08             	push   0x8(%ebp)
 37f:	e8 d0 00 00 00       	call   454 <open>
  if(fd < 0)
 384:	83 c4 10             	add    $0x10,%esp
 387:	85 c0                	test   %eax,%eax
 389:	78 24                	js     3af <stat+0x3d>
 38b:	89 c3                	mov    %eax,%ebx
    return -1;
  r = fstat(fd, st);
 38d:	83 ec 08             	sub    $0x8,%esp
 390:	ff 75 0c             	push   0xc(%ebp)
 393:	50                   	push   %eax
 394:	e8 d3 00 00 00       	call   46c <fstat>
 399:	89 c6                	mov    %eax,%esi
  close(fd);
 39b:	89 1c 24             	mov    %ebx,(%esp)
 39e:	e8 99 00 00 00       	call   43c <close>
  return r;
 3a3:	83 c4 10             	add    $0x10,%esp
}
 3a6:	89 f0                	mov    %esi,%eax
 3a8:	8d 65 f8             	lea    -0x8(%ebp),%esp
 3ab:	5b                   	pop    %ebx
 3ac:	5e                   	pop    %esi
 3ad:	5d                   	pop    %ebp
 3ae:	c3                   	ret    
    return -1;
 3af:	be ff ff ff ff       	mov    $0xffffffff,%esi
 3b4:	eb f0                	jmp    3a6 <stat+0x34>

000003b6 <atoi>:

int
atoi(const char *s)
{
 3b6:	55                   	push   %ebp
 3b7:	89 e5                	mov    %esp,%ebp
 3b9:	53                   	push   %ebx
 3ba:	8b 4d 08             	mov    0x8(%ebp),%ecx
  int n;

  n = 0;
 3bd:	ba 00 00 00 00       	mov    $0x0,%edx
  while('0' <= *s && *s <= '9')
 3c2:	eb 0e                	jmp    3d2 <atoi+0x1c>
    n = n*10 + *s++ - '0';
 3c4:	8d 14 92             	lea    (%edx,%edx,4),%edx
 3c7:	8d 1c 12             	lea    (%edx,%edx,1),%ebx
 3ca:	41                   	inc    %ecx
 3cb:	0f be c0             	movsbl %al,%eax
 3ce:	8d 54 18 d0          	lea    -0x30(%eax,%ebx,1),%edx
  while('0' <= *s && *s <= '9')
 3d2:	8a 01                	mov    (%ecx),%al
 3d4:	8d 58 d0             	lea    -0x30(%eax),%ebx
 3d7:	80 fb 09             	cmp    $0x9,%bl
 3da:	76 e8                	jbe    3c4 <atoi+0xe>
  return n;
}
 3dc:	89 d0                	mov    %edx,%eax
 3de:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 3e1:	c9                   	leave  
 3e2:	c3                   	ret    

000003e3 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 3e3:	55                   	push   %ebp
 3e4:	89 e5                	mov    %esp,%ebp
 3e6:	56                   	push   %esi
 3e7:	53                   	push   %ebx
 3e8:	8b 45 08             	mov    0x8(%ebp),%eax
 3eb:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 3ee:	8b 55 10             	mov    0x10(%ebp),%edx
  char *dst;
  const char *src;

  dst = vdst;
 3f1:	89 c1                	mov    %eax,%ecx
  src = vsrc;
  while(n-- > 0)
 3f3:	eb 0c                	jmp    401 <memmove+0x1e>
    *dst++ = *src++;
 3f5:	8a 13                	mov    (%ebx),%dl
 3f7:	88 11                	mov    %dl,(%ecx)
 3f9:	8d 5b 01             	lea    0x1(%ebx),%ebx
 3fc:	8d 49 01             	lea    0x1(%ecx),%ecx
  while(n-- > 0)
 3ff:	89 f2                	mov    %esi,%edx
 401:	8d 72 ff             	lea    -0x1(%edx),%esi
 404:	85 d2                	test   %edx,%edx
 406:	7f ed                	jg     3f5 <memmove+0x12>
  return vdst;
}
 408:	5b                   	pop    %ebx
 409:	5e                   	pop    %esi
 40a:	5d                   	pop    %ebp
 40b:	c3                   	ret    

0000040c <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 40c:	b8 01 00 00 00       	mov    $0x1,%eax
 411:	cd 40                	int    $0x40
 413:	c3                   	ret    

00000414 <exit>:
SYSCALL(exit)
 414:	b8 02 00 00 00       	mov    $0x2,%eax
 419:	cd 40                	int    $0x40
 41b:	c3                   	ret    

0000041c <wait>:
SYSCALL(wait)
 41c:	b8 03 00 00 00       	mov    $0x3,%eax
 421:	cd 40                	int    $0x40
 423:	c3                   	ret    

00000424 <pipe>:
SYSCALL(pipe)
 424:	b8 04 00 00 00       	mov    $0x4,%eax
 429:	cd 40                	int    $0x40
 42b:	c3                   	ret    

0000042c <read>:
SYSCALL(read)
 42c:	b8 05 00 00 00       	mov    $0x5,%eax
 431:	cd 40                	int    $0x40
 433:	c3                   	ret    

00000434 <write>:
SYSCALL(write)
 434:	b8 10 00 00 00       	mov    $0x10,%eax
 439:	cd 40                	int    $0x40
 43b:	c3                   	ret    

0000043c <close>:
SYSCALL(close)
 43c:	b8 15 00 00 00       	mov    $0x15,%eax
 441:	cd 40                	int    $0x40
 443:	c3                   	ret    

00000444 <kill>:
SYSCALL(kill)
 444:	b8 06 00 00 00       	mov    $0x6,%eax
 449:	cd 40                	int    $0x40
 44b:	c3                   	ret    

0000044c <exec>:
SYSCALL(exec)
 44c:	b8 07 00 00 00       	mov    $0x7,%eax
 451:	cd 40                	int    $0x40
 453:	c3                   	ret    

00000454 <open>:
SYSCALL(open)
 454:	b8 0f 00 00 00       	mov    $0xf,%eax
 459:	cd 40                	int    $0x40
 45b:	c3                   	ret    

0000045c <mknod>:
SYSCALL(mknod)
 45c:	b8 11 00 00 00       	mov    $0x11,%eax
 461:	cd 40                	int    $0x40
 463:	c3                   	ret    

00000464 <unlink>:
SYSCALL(unlink)
 464:	b8 12 00 00 00       	mov    $0x12,%eax
 469:	cd 40                	int    $0x40
 46b:	c3                   	ret    

0000046c <fstat>:
SYSCALL(fstat)
 46c:	b8 08 00 00 00       	mov    $0x8,%eax
 471:	cd 40                	int    $0x40
 473:	c3                   	ret    

00000474 <link>:
SYSCALL(link)
 474:	b8 13 00 00 00       	mov    $0x13,%eax
 479:	cd 40                	int    $0x40
 47b:	c3                   	ret    

0000047c <mkdir>:
SYSCALL(mkdir)
 47c:	b8 14 00 00 00       	mov    $0x14,%eax
 481:	cd 40                	int    $0x40
 483:	c3                   	ret    

00000484 <chdir>:
SYSCALL(chdir)
 484:	b8 09 00 00 00       	mov    $0x9,%eax
 489:	cd 40                	int    $0x40
 48b:	c3                   	ret    

0000048c <dup>:
SYSCALL(dup)
 48c:	b8 0a 00 00 00       	mov    $0xa,%eax
 491:	cd 40                	int    $0x40
 493:	c3                   	ret    

00000494 <getpid>:
SYSCALL(getpid)
 494:	b8 0b 00 00 00       	mov    $0xb,%eax
 499:	cd 40                	int    $0x40
 49b:	c3                   	ret    

0000049c <sbrk>:
SYSCALL(sbrk)
 49c:	b8 0c 00 00 00       	mov    $0xc,%eax
 4a1:	cd 40                	int    $0x40
 4a3:	c3                   	ret    

000004a4 <sleep>:
SYSCALL(sleep)
 4a4:	b8 0d 00 00 00       	mov    $0xd,%eax
 4a9:	cd 40                	int    $0x40
 4ab:	c3                   	ret    

000004ac <uptime>:
SYSCALL(uptime)
 4ac:	b8 0e 00 00 00       	mov    $0xe,%eax
 4b1:	cd 40                	int    $0x40
 4b3:	c3                   	ret    

000004b4 <date>:
SYSCALL(date)
 4b4:	b8 16 00 00 00       	mov    $0x16,%eax
 4b9:	cd 40                	int    $0x40
 4bb:	c3                   	ret    

000004bc <dup2>:
SYSCALL(dup2)
 4bc:	b8 17 00 00 00       	mov    $0x17,%eax
 4c1:	cd 40                	int    $0x40
 4c3:	c3                   	ret    

000004c4 <putc>:
#include "stat.h"
#include "user.h"

static void
putc(int fd, char c)
{
 4c4:	55                   	push   %ebp
 4c5:	89 e5                	mov    %esp,%ebp
 4c7:	83 ec 1c             	sub    $0x1c,%esp
 4ca:	88 55 f4             	mov    %dl,-0xc(%ebp)
  write(fd, &c, 1);
 4cd:	6a 01                	push   $0x1
 4cf:	8d 55 f4             	lea    -0xc(%ebp),%edx
 4d2:	52                   	push   %edx
 4d3:	50                   	push   %eax
 4d4:	e8 5b ff ff ff       	call   434 <write>
}
 4d9:	83 c4 10             	add    $0x10,%esp
 4dc:	c9                   	leave  
 4dd:	c3                   	ret    

000004de <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 4de:	55                   	push   %ebp
 4df:	89 e5                	mov    %esp,%ebp
 4e1:	57                   	push   %edi
 4e2:	56                   	push   %esi
 4e3:	53                   	push   %ebx
 4e4:	83 ec 2c             	sub    $0x2c,%esp
 4e7:	89 45 d4             	mov    %eax,-0x2c(%ebp)
 4ea:	89 ce                	mov    %ecx,%esi
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 4ec:	83 7d 08 00          	cmpl   $0x0,0x8(%ebp)
 4f0:	74 04                	je     4f6 <printint+0x18>
 4f2:	85 d2                	test   %edx,%edx
 4f4:	78 3c                	js     532 <printint+0x54>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 4f6:	89 d1                	mov    %edx,%ecx
  neg = 0;
 4f8:	c7 45 d0 00 00 00 00 	movl   $0x0,-0x30(%ebp)
  }

  i = 0;
 4ff:	bb 00 00 00 00       	mov    $0x0,%ebx
  do{
    buf[i++] = digits[x % base];
 504:	89 c8                	mov    %ecx,%eax
 506:	ba 00 00 00 00       	mov    $0x0,%edx
 50b:	f7 f6                	div    %esi
 50d:	89 df                	mov    %ebx,%edi
 50f:	43                   	inc    %ebx
 510:	8a 92 50 07 00 00    	mov    0x750(%edx),%dl
 516:	88 54 3d d8          	mov    %dl,-0x28(%ebp,%edi,1)
  }while((x /= base) != 0);
 51a:	89 ca                	mov    %ecx,%edx
 51c:	89 c1                	mov    %eax,%ecx
 51e:	39 d6                	cmp    %edx,%esi
 520:	76 e2                	jbe    504 <printint+0x26>
  if(neg)
 522:	83 7d d0 00          	cmpl   $0x0,-0x30(%ebp)
 526:	74 24                	je     54c <printint+0x6e>
    buf[i++] = '-';
 528:	c6 44 1d d8 2d       	movb   $0x2d,-0x28(%ebp,%ebx,1)
 52d:	8d 5f 02             	lea    0x2(%edi),%ebx
 530:	eb 1a                	jmp    54c <printint+0x6e>
    x = -xx;
 532:	89 d1                	mov    %edx,%ecx
 534:	f7 d9                	neg    %ecx
    neg = 1;
 536:	c7 45 d0 01 00 00 00 	movl   $0x1,-0x30(%ebp)
    x = -xx;
 53d:	eb c0                	jmp    4ff <printint+0x21>

  while(--i >= 0)
    putc(fd, buf[i]);
 53f:	0f be 54 1d d8       	movsbl -0x28(%ebp,%ebx,1),%edx
 544:	8b 45 d4             	mov    -0x2c(%ebp),%eax
 547:	e8 78 ff ff ff       	call   4c4 <putc>
  while(--i >= 0)
 54c:	4b                   	dec    %ebx
 54d:	79 f0                	jns    53f <printint+0x61>
}
 54f:	83 c4 2c             	add    $0x2c,%esp
 552:	5b                   	pop    %ebx
 553:	5e                   	pop    %esi
 554:	5f                   	pop    %edi
 555:	5d                   	pop    %ebp
 556:	c3                   	ret    

00000557 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 557:	55                   	push   %ebp
 558:	89 e5                	mov    %esp,%ebp
 55a:	57                   	push   %edi
 55b:	56                   	push   %esi
 55c:	53                   	push   %ebx
 55d:	83 ec 1c             	sub    $0x1c,%esp
  char *s;
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
 560:	8d 45 10             	lea    0x10(%ebp),%eax
 563:	89 45 e4             	mov    %eax,-0x1c(%ebp)
  state = 0;
 566:	be 00 00 00 00       	mov    $0x0,%esi
  for(i = 0; fmt[i]; i++){
 56b:	bb 00 00 00 00       	mov    $0x0,%ebx
 570:	eb 12                	jmp    584 <printf+0x2d>
    c = fmt[i] & 0xff;
    if(state == 0){
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
 572:	89 fa                	mov    %edi,%edx
 574:	8b 45 08             	mov    0x8(%ebp),%eax
 577:	e8 48 ff ff ff       	call   4c4 <putc>
 57c:	eb 05                	jmp    583 <printf+0x2c>
      }
    } else if(state == '%'){
 57e:	83 fe 25             	cmp    $0x25,%esi
 581:	74 22                	je     5a5 <printf+0x4e>
  for(i = 0; fmt[i]; i++){
 583:	43                   	inc    %ebx
 584:	8b 45 0c             	mov    0xc(%ebp),%eax
 587:	8a 04 18             	mov    (%eax,%ebx,1),%al
 58a:	84 c0                	test   %al,%al
 58c:	0f 84 1d 01 00 00    	je     6af <printf+0x158>
    c = fmt[i] & 0xff;
 592:	0f be f8             	movsbl %al,%edi
 595:	0f b6 c0             	movzbl %al,%eax
    if(state == 0){
 598:	85 f6                	test   %esi,%esi
 59a:	75 e2                	jne    57e <printf+0x27>
      if(c == '%'){
 59c:	83 f8 25             	cmp    $0x25,%eax
 59f:	75 d1                	jne    572 <printf+0x1b>
        state = '%';
 5a1:	89 c6                	mov    %eax,%esi
 5a3:	eb de                	jmp    583 <printf+0x2c>
      if(c == 'd'){
 5a5:	83 f8 25             	cmp    $0x25,%eax
 5a8:	0f 84 cc 00 00 00    	je     67a <printf+0x123>
 5ae:	0f 8c da 00 00 00    	jl     68e <printf+0x137>
 5b4:	83 f8 78             	cmp    $0x78,%eax
 5b7:	0f 8f d1 00 00 00    	jg     68e <printf+0x137>
 5bd:	83 f8 63             	cmp    $0x63,%eax
 5c0:	0f 8c c8 00 00 00    	jl     68e <printf+0x137>
 5c6:	83 e8 63             	sub    $0x63,%eax
 5c9:	83 f8 15             	cmp    $0x15,%eax
 5cc:	0f 87 bc 00 00 00    	ja     68e <printf+0x137>
 5d2:	ff 24 85 f8 06 00 00 	jmp    *0x6f8(,%eax,4)
        printint(fd, *ap, 10, 1);
 5d9:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 5dc:	8b 17                	mov    (%edi),%edx
 5de:	83 ec 0c             	sub    $0xc,%esp
 5e1:	6a 01                	push   $0x1
 5e3:	b9 0a 00 00 00       	mov    $0xa,%ecx
 5e8:	8b 45 08             	mov    0x8(%ebp),%eax
 5eb:	e8 ee fe ff ff       	call   4de <printint>
        ap++;
 5f0:	83 c7 04             	add    $0x4,%edi
 5f3:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 5f6:	83 c4 10             	add    $0x10,%esp
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 5f9:	be 00 00 00 00       	mov    $0x0,%esi
 5fe:	eb 83                	jmp    583 <printf+0x2c>
        printint(fd, *ap, 16, 0);
 600:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 603:	8b 17                	mov    (%edi),%edx
 605:	83 ec 0c             	sub    $0xc,%esp
 608:	6a 00                	push   $0x0
 60a:	b9 10 00 00 00       	mov    $0x10,%ecx
 60f:	8b 45 08             	mov    0x8(%ebp),%eax
 612:	e8 c7 fe ff ff       	call   4de <printint>
        ap++;
 617:	83 c7 04             	add    $0x4,%edi
 61a:	89 7d e4             	mov    %edi,-0x1c(%ebp)
 61d:	83 c4 10             	add    $0x10,%esp
      state = 0;
 620:	be 00 00 00 00       	mov    $0x0,%esi
        ap++;
 625:	e9 59 ff ff ff       	jmp    583 <printf+0x2c>
        s = (char*)*ap;
 62a:	8b 45 e4             	mov    -0x1c(%ebp),%eax
 62d:	8b 30                	mov    (%eax),%esi
        ap++;
 62f:	83 c0 04             	add    $0x4,%eax
 632:	89 45 e4             	mov    %eax,-0x1c(%ebp)
        if(s == 0)
 635:	85 f6                	test   %esi,%esi
 637:	75 13                	jne    64c <printf+0xf5>
          s = "(null)";
 639:	be ee 06 00 00       	mov    $0x6ee,%esi
 63e:	eb 0c                	jmp    64c <printf+0xf5>
          putc(fd, *s);
 640:	0f be d2             	movsbl %dl,%edx
 643:	8b 45 08             	mov    0x8(%ebp),%eax
 646:	e8 79 fe ff ff       	call   4c4 <putc>
          s++;
 64b:	46                   	inc    %esi
        while(*s != 0){
 64c:	8a 16                	mov    (%esi),%dl
 64e:	84 d2                	test   %dl,%dl
 650:	75 ee                	jne    640 <printf+0xe9>
      state = 0;
 652:	be 00 00 00 00       	mov    $0x0,%esi
 657:	e9 27 ff ff ff       	jmp    583 <printf+0x2c>
        putc(fd, *ap);
 65c:	8b 7d e4             	mov    -0x1c(%ebp),%edi
 65f:	0f be 17             	movsbl (%edi),%edx
 662:	8b 45 08             	mov    0x8(%ebp),%eax
 665:	e8 5a fe ff ff       	call   4c4 <putc>
        ap++;
 66a:	83 c7 04             	add    $0x4,%edi
 66d:	89 7d e4             	mov    %edi,-0x1c(%ebp)
      state = 0;
 670:	be 00 00 00 00       	mov    $0x0,%esi
 675:	e9 09 ff ff ff       	jmp    583 <printf+0x2c>
        putc(fd, c);
 67a:	89 fa                	mov    %edi,%edx
 67c:	8b 45 08             	mov    0x8(%ebp),%eax
 67f:	e8 40 fe ff ff       	call   4c4 <putc>
      state = 0;
 684:	be 00 00 00 00       	mov    $0x0,%esi
 689:	e9 f5 fe ff ff       	jmp    583 <printf+0x2c>
        putc(fd, '%');
 68e:	ba 25 00 00 00       	mov    $0x25,%edx
 693:	8b 45 08             	mov    0x8(%ebp),%eax
 696:	e8 29 fe ff ff       	call   4c4 <putc>
        putc(fd, c);
 69b:	89 fa                	mov    %edi,%edx
 69d:	8b 45 08             	mov    0x8(%ebp),%eax
 6a0:	e8 1f fe ff ff       	call   4c4 <putc>
      state = 0;
 6a5:	be 00 00 00 00       	mov    $0x0,%esi
 6aa:	e9 d4 fe ff ff       	jmp    583 <printf+0x2c>
    }
  }
}
 6af:	8d 65 f4             	lea    -0xc(%ebp),%esp
 6b2:	5b                   	pop    %ebx
 6b3:	5e                   	pop    %esi
 6b4:	5f                   	pop    %edi
 6b5:	5d                   	pop    %ebp
 6b6:	c3                   	ret    
